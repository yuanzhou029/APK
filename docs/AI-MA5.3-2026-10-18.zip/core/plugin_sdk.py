# -*- coding: utf-8 -*-
"""
AI-MA 开放式插件开发工具包 (Plugin SDK v3.0)
新增标准化：
1. get_config_schema(): 声明插件可配置项(类型、默认值、说明、校验规则)，供 UI 动态渲染配置表单
2. update_config(new_config): 运行时热更新插件参数
3. is_enabled: 插件启停状态
4. 插件静态/动态合规校验器 (PluginValidator)
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Callable
import inspect
import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
import logging
try:
    from diagnostics_logger import log_diagnostic_error
except ImportError:
    from core.diagnostics_logger import log_diagnostic_error

logger = logging.getLogger("PluginSDK")

class ServiceCircuitBreaker:
    """带超时与熔断保护的状态机 (Circuit Breaker)"""
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"

    def __init__(self, failure_threshold: int = 3, recovery_time_s: float = 5.0):
        self.failure_threshold = failure_threshold
        self.recovery_time_s = recovery_time_s
        self.state = self.CLOSED
        self.failure_count = 0
        self.last_failure_time = 0.0
        self._lock = threading.RLock()

    def can_execute(self) -> bool:
        with self._lock:
            now = time.time()
            if self.state == self.OPEN:
                if now - self.last_failure_time >= self.recovery_time_s:
                    self.state = self.HALF_OPEN
                    return True
                return False
            return True

    def record_success(self):
        with self._lock:
            self.failure_count = 0
            self.state = self.CLOSED

    def record_failure(self):
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            if self.failure_count >= self.failure_threshold:
                self.state = self.OPEN


class ServiceBrokerException(RuntimeError):
    """ServiceBroker 结构化业务异常基类"""
    def __init__(self, diag_code: str, message: str):
        super().__init__(f"[{diag_code}] {message}")
        self.diag_code = diag_code
        self.message = message


class ServiceBroker:
    """
    方案二：插件交互与通信机制 - Service Broker (服务注册、安全 RPC、带超时断路保护、权限白名单)
    """
    def __init__(self):
        self._services: Dict[str, Dict[str, Any]] = {}
        self._circuit_breakers: Dict[str, ServiceCircuitBreaker] = {}
        self._lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="ServiceBrokerRPC")

    def register_service(self, plugin_id: str, service_name: str, handler: Callable, spec: Optional[Dict[str, Any]] = None) -> None:
        """
        注册插件微服务
        :param plugin_id: 宿主/插件 ID
        :param service_name: 服务全局唯一标识
        :param handler: 可调用的服务执行函数 Callable[[dict], Any]
        :param spec: 服务元数据与安全规则，如:
                     {
                         "callers": ["allowed_plugin_id", "*"],  # 白名单
                         "schema": {"req": dict, "resp": dict},  # 参数规范
                         "timeout_ms": 500                      # 建议超时
                     }
        """
        with self._lock:
            spec = spec or {}
            # callers 白名单默认封闭：若未显式指定，仅允许插件自身 (plugin_id) 或 "host" 调用，不可默认 ["*"]
            if "callers" not in spec or spec["callers"] is None:
                spec["callers"] = [plugin_id, "host"]
            self._services[service_name] = {
                "plugin_id": plugin_id,
                "service_name": service_name,
                "handler": handler,
                "spec": spec
            }
            if service_name not in self._circuit_breakers:
                self._circuit_breakers[service_name] = ServiceCircuitBreaker()

    def unregister_service(self, plugin_id: str, service_name: str) -> None:
        """注销服务"""
        with self._lock:
            if service_name in self._services:
                if self._services[service_name]["plugin_id"] == plugin_id or plugin_id == "host":
                    del self._services[service_name]

    def unregister_all_for_plugin(self, plugin_id: str) -> None:
        """注销指定插件注册的所有服务"""
        with self._lock:
            to_remove = [k for k, v in self._services.items() if v["plugin_id"] == plugin_id]
            for k in to_remove:
                del self._services[k]

    def has_service(self, service_name: str) -> bool:
        with self._lock:
            return service_name in self._services

    def call_service(self, caller_id: str, service_name: str, payload: Optional[Dict[str, Any]] = None, timeout_ms: int = 500) -> Any:
        """
        安全 RPC 调用
        AC-2.1: 注册未知服务或无权限调用时，必须在 5ms 内抛出结构化异常 ERR-RPC-PERMISSION 或 ERR-SERVICE-NOT-FOUND
        """
        start_t = time.perf_counter()
        payload = payload or {}

        with self._lock:
            service_entry = self._services.get(service_name)
            cb = self._circuit_breakers.get(service_name)

        if not service_entry:
            raise ServiceBrokerException("ERR-SERVICE-NOT-FOUND", f"未找到服务: '{service_name}'")

        spec = service_entry.get("spec", {})
        allowed_callers = spec.get("callers")
        if allowed_callers is None:
            allowed_callers = [service_entry["plugin_id"], "host"]
        if "*" not in allowed_callers and caller_id not in allowed_callers and caller_id != "host":
            raise ServiceBrokerException("ERR-RPC-PERMISSION", f"调用者 [{caller_id}] 无权限调用服务 [{service_name}]")

        if cb and not cb.can_execute():
            raise ServiceBrokerException("ERR-RPC-TIMEOUT", f"服务 [{service_name}] 断路器处于 OPEN/熔断状态，调用被拦截")

        handler = service_entry["handler"]

        # 执行调用并带超时控制
        timeout_sec = max(0.001, timeout_ms / 1000.0)
        future = self._executor.submit(handler, payload)
        try:
            result = future.result(timeout=timeout_sec)
            if cb:
                cb.record_success()
            return result
        except FutureTimeoutError:
            if cb:
                cb.record_failure()
            raise ServiceBrokerException("ERR-RPC-TIMEOUT", f"调用服务 [{service_name}] 超时 (> {timeout_ms}ms)")
        except ServiceBrokerException:
            raise
        except Exception as e:
            if cb:
                cb.record_failure()
            raise RuntimeError(f"服务 [{service_name}] 执行抛出异常: {e}") from e


class EventHub:
    """
    方案二：双轨事件总线 (发布/订阅、高吞吐快速分发与异常隔离)
    支持同步 publish 与由工作线程池承载的异步广播。
    AC-2.2: EventHub 异步事件广播延迟在 100 个并发订阅者场景下应保持在 <= 2ms，严禁消息队列溢出丢失。
    """
    def __init__(self, max_workers: int = 16):
        self._subscribers: Dict[str, Dict[str, Callable[[str, Dict[str, Any]], None]]] = {}
        self._lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="EventHubDispatcher")

    def subscribe(self, topic: str, subscriber_id: str, callback: Callable[[str, Dict[str, Any]], None]) -> None:
        """订阅主题"""
        with self._lock:
            if topic not in self._subscribers:
                self._subscribers[topic] = {}
            self._subscribers[topic][subscriber_id] = callback

    def unsubscribe(self, topic: str, subscriber_id: str) -> None:
        """取消订阅指定主题"""
        with self._lock:
            if topic in self._subscribers and subscriber_id in self._subscribers[topic]:
                del self._subscribers[topic][subscriber_id]
                if not self._subscribers[topic]:
                    del self._subscribers[topic]

    def unsubscribe_all(self, subscriber_id: str) -> None:
        """取消该订阅者所有的订阅"""
        with self._lock:
            for topic in list(self._subscribers.keys()):
                if subscriber_id in self._subscribers[topic]:
                    del self._subscribers[topic][subscriber_id]
                if not self._subscribers[topic]:
                    del self._subscribers[topic]

    def publish(self, topic: str, sender_id: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        同步广播事件（带异常隔离与诊断日志，单个订阅者抛出异常记录诊断日志，绝不影响其他订阅者）
        """
        data = data if data is not None else {}
        targets = []
        with self._lock:
            # 精确匹配主题
            if topic in self._subscribers:
                targets.extend(list(self._subscribers[topic].values()))
            # 通配符支持 topic.* or *
            if "*" in self._subscribers:
                targets.extend(list(self._subscribers["*"].values()))

        for cb in targets:
            try:
                cb(topic, data)
            except Exception as e:
                # 异常捕获补充 diagnostics_logger 记录，严禁静默吞掉
                err_detail = f"EventHub 同步派发异常 [Topic: {topic}, 发送者: {sender_id}]: {e}"
                log_diagnostic_error(logger, "ERR-PLUGIN-FOUNDATION", err_detail)

    def publish_async(self, topic: str, sender_id: str, data: Optional[Dict[str, Any]] = None):
        """
        异步线程池派发，极速返回，高并发下无锁阻塞
        """
        data = data if data is not None else {}
        with self._lock:
            targets = []
            if topic in self._subscribers:
                targets.extend(list(self._subscribers[topic].values()))
            if "*" in self._subscribers:
                targets.extend(list(self._subscribers["*"].values()))

        def _dispatch():
            for cb in targets:
                try:
                    cb(topic, data)
                except Exception as e:
                    # 异常捕获补充 diagnostics_logger 记录，严禁静默吞掉
                    err_detail = f"EventHub 异步广播异常 [Topic: {topic}, 发送者: {sender_id}]: {e}"
                    log_diagnostic_error(logger, "ERR-PLUGIN-FOUNDATION", err_detail)

        try:
            return self._executor.submit(_dispatch)
        except RuntimeError:
            # 解释器或 EventHub 退出清理阶段 executor 已关闭，优雅丢弃残留帧并不抛出 RuntimeError
            return None

    def shutdown(self, wait: bool = False) -> None:
        """显式关闭异步事件执行线程池"""
        try:
            self._executor.shutdown(wait=wait, cancel_futures=True)
        except Exception:
            pass


class ReadOnlyStateMirror:
    """
    方案二：状态只读镜像 (Read-only State Mirror)
    基于微内核零拷贝/seqlock 或内存双缓冲机制，向插件暴露只读灯光状态快照，严禁写越权。
    AC-2.3: 状态只读镜像读取延迟低于 50 微秒，且在微内核高频写入（44Hz）时无死锁、无脏读。
    """
    def __init__(self, kernel_bridge: Any = None):
        self._bridge = kernel_bridge
        # 兜底本地无锁双缓冲
        self._buf_a = bytearray(64 * 512)
        self._buf_b = bytearray(64 * 512)
        self._active_buf_idx = 0
        self._seq = 0
        self._lock = threading.Lock()

    def update_snapshot(self, dmx_data: bytes | bytearray):
        """供宿主/内核写入端调用的安全快照刷新 (seqlock 机制)"""
        with self._lock:
            self._seq += 1  # 奇数表示正在写入
            target_buf = self._buf_b if self._active_buf_idx == 0 else self._buf_a
            size = min(len(dmx_data), len(target_buf))
            target_buf[:size] = dmx_data[:size]
            self._active_buf_idx = 1 - self._active_buf_idx
            self._seq += 1  # 偶数表示完成写入

    def get_universe_frame(self, universe: int) -> bytes:
        """
        快速读取单个宇宙只读快照 (512 字节)。
        直接零拷贝/高效切片，无写越权。
        耗时实测远低于 50µs。
        """
        if self._bridge and hasattr(self._bridge, "read_final_merged"):
            merged = self._bridge.read_final_merged()
            if merged is not None:
                offset = universe * 512
                # 返回不可变 bytes，确保外部无法篡改
                if hasattr(merged, "tobytes"):
                    return bytes(merged[offset:offset+512])
                return bytes(merged[offset:offset+512])

        # 本地 seqlock 双缓冲无脏读读取
        for _ in range(5):
            seq1 = self._seq
            if seq1 % 2 != 0:
                time.sleep(0.000001)
                continue
            idx = self._active_buf_idx
            active_buf = self._buf_a if idx == 0 else self._buf_b
            offset = universe * 512
            res = bytes(active_buf[offset:offset+512])
            seq2 = self._seq
            if seq1 == seq2 and seq2 % 2 == 0:
                return res
        return bytes(512)

    def get_rt_metrics(self) -> Dict[str, Any]:
        """读取微内核实时指标快照"""
        if self._bridge and hasattr(self._bridge, "get_rt_metrics"):
            m = self._bridge.get_rt_metrics()
            return {
                "rt_frame_index": m[0],
                "rt_timestamp_ns": m[1],
                "last_jitter_ns": m[2],
                "active_universe_count": m[3]
            }
        return {"rt_frame_index": 0, "rt_timestamp_ns": 0, "last_jitter_ns": 0, "active_universe_count": 0}


class PluginTier:
    """插件架构三层分级"""
    SYSTEM = 1      # 1 类：底层系统插件 (物理目录 plugins/system/，随系统OTA升级，无界面，不入市场)
    ADAPTER = 2     # 2 类：功能适配与资产总线插件 (物理目录 plugins/adapters/，由专业人员维护，向特定UI提供插槽，不入公开发布市场)
    CREATIVE = 3    # 3 类：表现与创意应用插件 (物理目录 plugins/community/，插件市场公开，支持灯光师与爱好者自制/上传/卸载)

class PluginType:
    PROTOCOL = "protocol"      # 输出协议 (Art-Net, sACN, OSC, Telnet, Modbus等)
    PERCEPTION = "perception"  # 外部感知 (音频分析, BPM提取, 摄像头追踪, 传感器等)
    MACRO = "macro"            # 动态特效宏引擎 (走马灯, 呼吸, 矩阵彩虹等)
    LLM = "llm"                # 大语言模型与决策器适配器 (Qwen, DeepSeek, Claude等)
    EFFECT = "effect"          # 静态/动态灯光特效发生器
    ADAPTER = "adapter"        # 外部资产与控台格式转换器 (MA2 XML, GDTF, Titan等)
    TRANSPORT = "transport"    # 外部成熟系统/物联网物理接口与通道驱动 (HA, MQTT, WebSocket, 总线等)

class CoreContext:
    """系统微内核暴露给插件的安全上下文对象"""
    def __init__(
        self,
        event_bus=None,
        dmx_merger=None,
        kb_manager=None,
        config: Optional[Dict[str, Any]] = None,
        services: Optional[Dict[str, Any]] = None,
        service_broker: Optional[ServiceBroker] = None,
        event_hub: Optional[EventHub] = None,
        state_mirror: Optional[ReadOnlyStateMirror] = None,
        hosted: bool = False
    ):
        self.event_bus = event_bus
        self.dmx_merger = dmx_merger
        self.kb = kb_manager
        self.config = config or {}
        self.services = services or {}
        self.service_broker: ServiceBroker = service_broker or ServiceBroker()
        self.event_hub: EventHub = event_hub or EventHub()
        self.state_mirror: ReadOnlyStateMirror = state_mirror or ReadOnlyStateMirror()
        self.hosted: bool = hosted

    def get_service(self, name: str) -> Any:
        return self.services.get(name)

    @property
    def broker(self) -> ServiceBroker:
        return self.service_broker

    @property
    def hub(self) -> EventHub:
        return self.event_hub

    @property
    def mirror(self) -> ReadOnlyStateMirror:
        return self.state_mirror

class BasePlugin(ABC):
    """所有插件的标准抽象基类"""
    def __init__(self):
        self._enabled: bool = False
        self._config: Dict[str, Any] = {}
        self.context: Optional[CoreContext] = None

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @property
    def tier(self) -> int:
        """插件所属分级层级 (默认 3 类表现级，子类可覆盖为 1 或 2)"""
        return PluginTier.CREATIVE

    def get_ai_prompts(self) -> Dict[str, str]:
        """
        插件内部专有大模型提示词隔离字典：
        {
            "default_system": "你是一个专职于该插件业务的专家...",
            "extract_schema": "专有格式化规则..."
        }
        让不同插件调用 LLM 时各持独立的专业上下文与角色，绝不相互污染。
        """
        return {}

    def call_ai_service(self, prompt_key: str, user_content: str, temperature: float = 0.2) -> str:
        """
        安全调用系统注册的大模型中枢服务，自动注入该插件独有的 System Prompt。
        """
        if not self.context:
            raise RuntimeError(f"插件 [{self.__class__.__name__}] 未初始化内核上下文，无法调用 AI 服务")
        llm_service = self.context.get_service("llm") or (self.context.kb.plugin_host.get_llm() if hasattr(self.context.kb, "plugin_host") else None)
        if not llm_service:
            raise RuntimeError("系统大模型服务未启用或不可用")

        prompts = self.get_ai_prompts()
        sys_prompt = prompts.get(prompt_key, prompts.get("default_system", "你是一个专业的舞台灯光操作系统助手。"))
        
        return llm_service.chat_completion([
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_content}
        ], temperature=temperature)

    def get_ui_extensions(self) -> List[Dict[str, Any]]:
        """
        2类/3类插件向宿主界面注册的扩展插槽定义 (如在物理灯库面板增加按钮):
        [
            {
                "slot": "kb_profiles_toolbar", # 插槽位置标识
                "id": "btn_import_ma2",
                "label": "导入 MA2 灯库",
                "icon": "fa-file-arrow-up",
                "action": "import_ma_xml"
            }
        ]
        """
        return []

    @abstractmethod
    def get_info(self) -> Dict[str, Any]:
        """
        必须返回插件元信息字典:
        {
            "id": "protocol_artnet_standard",
            "name": "Art-Net 3/4 工业标准协议驱动",
            "version": "2.1.0",
            "author": "AI-MA Core Team",
            "type": PluginType.PROTOCOL,
            "description": "详细描述与使用说明",
            "homepage": "可选主页",
            "requirements": ["可选外部依赖"]
        }
        """
        pass

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        """
        返回参数声明 Schema，供 Web UI 自动渲染配置表单。
        格式示例:
        {
            "target_ip": {
                "type": "string",
                "label": "目标广播/单播 IP",
                "default": "127.0.0.1",
                "description": "Art-Net 数据流发送的目标地址"
            },
            "port": {
                "type": "integer",
                "label": "端口号",
                "default": 6454,
                "description": "UDP 监听端口，标准为 6454"
            }
        }
        """
        return {}

    def get_config(self) -> Dict[str, Any]:
        """获取当前运行时的配置参数（合并默认值）"""
        schema = self.get_config_schema()
        merged = {}
        for k, v in schema.items():
            merged[k] = v.get("default")
        merged.update(self._config)
        return merged

    def update_config(self, new_config: Dict[str, Any]) -> bool:
        """更新插件参数（可由子类重写以应用热更新）"""
        self._config.update(new_config)
        return True

    def on_save_state(self) -> Dict[str, Any]:
        """
        方案四：平滑升级与演化机制 - 运行时状态导出钩子
        AC-4.1: 插件在热重载过程中 (Save -> Unload -> Reload -> Restore)，内部关键计数器与运行模式保持零丢失。
        默认返回空字典，子类可覆盖保存私有状态数据。
        """
        return {}

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """
        方案四：平滑升级与演化机制 - 运行时状态无缝恢复钩子
        :param state: 之前 on_save_state() 导出的字典状态
        """
        pass

    @property
    def broker(self) -> Optional[ServiceBroker]:
        """快捷获取 ServiceBroker"""
        return self.context.service_broker if self.context else None

    def get_service_broker(self) -> Optional[ServiceBroker]:
        """获取 ServiceBroker 上下文"""
        return self.broker

    @property
    def event_hub(self) -> Optional[EventHub]:
        """快捷获取 EventHub"""
        return self.context.event_hub if self.context else None

    def get_event_hub(self) -> Optional[EventHub]:
        """获取 EventHub 上下文"""
        return self.event_hub

    @property
    def state_mirror(self) -> Optional[ReadOnlyStateMirror]:
        """快捷获取 ReadOnlyStateMirror"""
        return self.context.state_mirror if self.context else None

    def get_state_mirror(self) -> Optional[ReadOnlyStateMirror]:
        """获取 ReadOnlyStateMirror 上下文"""
        return self.state_mirror

    @abstractmethod
    def on_init(self, context: CoreContext) -> bool:
        """插件初始化，注入内核上下文。返回 True 表示装载成功。"""
        pass

    @abstractmethod
    def on_enable(self) -> None:
        """插件启动运行。由框架在 set_enabled(True) 时调用。"""
        pass

    @abstractmethod
    def on_disable(self) -> None:
        """插件停止。由框架在 set_enabled(False) 时调用，必须释放网络与线程资源。"""
        pass

    def set_enabled(self, enabled: bool) -> bool:
        """安全启停状态切换"""
        if self._enabled == enabled:
            return True
        if enabled:
            try:
                self.on_enable()
                self._enabled = True
                return True
            except Exception as e:
                self._enabled = False
                raise e
        else:
            try:
                self.on_disable()
            finally:
                self._enabled = False
            return True

class BaseSystemPlugin(BasePlugin):
    """1 类 · 系统底层插件基类 (不可在市场卸载，随内核部署)"""
    @property
    def tier(self) -> int:
        return PluginTier.SYSTEM

class BaseAdapterPlugin(BasePlugin):
    """2 类 · 资产转换与控台生态适配插件基类 (向特定功能面板暴露插槽与转换方法，支持对外注册标准化能力)"""
    @property
    def tier(self) -> int:
        return PluginTier.ADAPTER

    @abstractmethod
    def supported_extensions(self) -> List[str]:
        """声明支持的文件格式，例如 ['.xml', '.gdtf']"""
        pass

    @abstractmethod
    def convert_to_profile(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """将外部控台格式转换为系统标准灯库 JSON 数据"""
        pass

    def get_provided_capabilities(self) -> List[str]:
        """
        向系统声明此 2 类适配插件对外提供的标准化能力标签 (Capabilities):
        例如: ["adapter.ma_fixture", "adapter.ha_entity_bridge", "adapter.audio_spectrum"]
        3 类创意插件可基于此能力标签进行依赖绑定。
        默认自动将插件 ID 注入为一项基础能力。
        """
        info = self.get_info()
        pid = info.get("id") if isinstance(info, dict) else None
        return [pid] if pid else []

    def get_service_provider(self, capability: str) -> Any:
        """对外暴露可供 3 类直接调用的安全接口实例或服务提供者"""
        return self

class BaseCreativePlugin(BasePlugin):
    """3 类 · 表现与创意插件基类 (必须建立在 2 类适配层支撑之上，声明依赖项)"""
    @property
    def tier(self) -> int:
        return PluginTier.CREATIVE

    def get_required_adapters(self) -> List[str]:
        """
        声明本 3 类创意插件运行所必须依赖的 2 类插件 ID 或其声明的能力标签 (Capability):
        例如: ["adapter_ma_fixture", "adapter.ha_entity_bridge"]
        若宿主系统中未加载并启用该依赖项，系统将执行安全门禁拦截，阻断该插件加载并提示运维/用户。
        返回空列表表示纯通用算法宏，无需外部专用硬件/协议适配器。
        """
        return []

class BaseTransportPlugin(BaseSystemPlugin):
    """
    1 类 · 外部系统底层物理通讯协议与接口通道插件基类 (向下无限开放自定义对接)
    负责对外部成熟生态 (Home Assistant, MQTT, Modbus, KNX, 私有 WebSocket 等) 建立原始数据传输管道。
    """
    @abstractmethod
    def open_channel(self, channel_id: str, config: Dict[str, Any]) -> bool:
        """打开/建立底层通信通道 (TCP/UDP/WebSocket/串口/现场总线等)"""
        pass

    @abstractmethod
    def send_raw(self, channel_id: str, payload: bytes) -> bool:
        """向外部系统或设备通道发送原始数据报文"""
        pass

    @abstractmethod
    def register_raw_receiver(self, channel_id: str, callback) -> None:
        """注册底层报文接收回调函数 (2 类适配插件通过此接口挂载监听与转译)"""
        pass

    def get_channel_status(self, channel_id: str) -> Dict[str, Any]:
        """查询指定通道的连接与保活状态"""
        return {"channel_id": channel_id, "connected": False}

class BaseProtocolPlugin(BaseSystemPlugin):
    """通信协议输出插件基类 (属于 1 类系统底层插件)"""
    @abstractmethod
    def send_universe(self, universe: int, dmx_data_512: bytearray) -> bool:
        """发送单个 Universe 的 512 通道数据"""
        pass

    def broadcast_sync(self) -> None:
        pass

class BaseMacroPlugin(BaseCreativePlugin):
    """动态宏插件基类 (属于 3 类创意插件)"""
    @abstractmethod
    def render(self, elapsed_ms: float, params: Dict[str, Any], current_frame: bytearray) -> bytearray:
        """根据耗时毫秒数与参数计算生成新的 DMX 帧"""
        pass

class BasePerceptionPlugin(BaseCreativePlugin):
    """外部感知输入插件基类 (属于 3 类创意插件)"""
    @abstractmethod
    def get_status(self) -> Dict[str, Any]:
        pass

class BaseLLMPlugin(BaseSystemPlugin):
    """大模型与认知中枢插件基类 (属于 1 类系统底层插件)"""
    @abstractmethod
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> str:
        pass

class PluginValidator:
    """插件市场合规与安全性验证器 (Plugin Market Verifier)"""
    REQUIRED_INFO_KEYS = ["id", "name", "version", "author", "type", "description"]
    VALID_TYPES = [PluginType.PROTOCOL, PluginType.PERCEPTION, PluginType.MACRO, PluginType.LLM, PluginType.EFFECT, PluginType.ADAPTER, PluginType.TRANSPORT]

    @classmethod
    def validate_plugin_instance(cls, plugin: BasePlugin) -> Dict[str, Any]:
        """验证已实例化插件对象是否符合工业标准"""
        errors = []
        warnings = []

        # 1. 继承检查
        is_plugin = isinstance(plugin, BasePlugin)
        if not is_plugin:
            # 兼容动态热加载或多重 importlib 空间下的同名基类识别
            mro_names = [base.__name__ for base in getattr(plugin.__class__, "__mro__", [])]
            if "BasePlugin" in mro_names:
                is_plugin = True

        if not is_plugin:
            return {"valid": False, "errors": ["插件未继承 BasePlugin 抽象基类"], "warnings": []}

        # 2. get_info 校验
        try:
            info = plugin.get_info()
            if not isinstance(info, dict):
                errors.append("get_info() 必须返回字典对象")
            else:
                for k in cls.REQUIRED_INFO_KEYS:
                    if k not in info or not str(info[k]).strip():
                        errors.append(f"get_info() 缺少必要字段: '{k}'")
                
                # 检查 ID 规范 (只能由小写字母、数字、下划线组成)
                pid = info.get("id", "")
                if not re.match(r"^[a-z0-9_]{3,40}$", pid):
                    errors.append(f"插件 ID [{pid}] 不合规，必须为 3-40 位小写英文、数字或下划线")

                # 检查类型合法性
                ptype = info.get("type")
                if ptype not in cls.VALID_TYPES:
                    errors.append(f"插件类型 [{ptype}] 不在受支持标准列表中 ({cls.VALID_TYPES})")

                # 版本号 semver 校验
                ver = info.get("version", "")
                if not re.match(r"^\d+\.\d+(\.\d+)?", ver):
                    warnings.append(f"版本号 [{ver}] 建议遵循语义化版本格式 (如 1.0.0)")

        except Exception as e:
            errors.append(f"调用 get_info() 发生异常: {e}")

        # 3. 参数 Schema 校验
        try:
            schema = plugin.get_config_schema()
            if not isinstance(schema, dict):
                errors.append("get_config_schema() 必须返回字典")
            else:
                for field_name, field_def in schema.items():
                    if not isinstance(field_def, dict):
                        errors.append(f"参数项 [{field_name}] 的定义必须为字典")
                    elif "type" not in field_def or "label" not in field_def:
                        errors.append(f"参数项 [{field_name}] 缺少 'type' 或 'label' 说明")
        except Exception as e:
            errors.append(f"校验 get_config_schema() 异常: {e}")

        # 4. 关键方法覆盖检查
        for m in ["on_init", "on_enable", "on_disable"]:
            if not hasattr(plugin, m) or not callable(getattr(plugin, m)):
                errors.append(f"插件缺少生命周期实现方法: {m}()")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "plugin_info": plugin.get_info() if len(errors) == 0 else {}
        }
