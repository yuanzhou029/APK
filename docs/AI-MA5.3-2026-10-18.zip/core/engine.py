# -*- coding: utf-8 -*-
"""
AI-MA 工业级微内核中央引擎 (Industrial Core Engine)
维持 30Hz 恒定硬实时 DMX 刷新、毫秒级平滑过渡 Crossfade、宏引擎调度与协议广播驱动。
"""

import time
import threading
import logging
from typing import Dict, List, Any, Optional

from event_bus import EventBus, SystemEvents
from dmx_merger import DmxMerger, PriorityLevel
from plugin_host import PluginHost
from plugin_sdk import CoreContext
from kernel_bridge import AimaKernelBridge

logger = logging.getLogger("CoreEngine")

class CoreEngine:
    def __init__(self, kb_manager, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.kb = kb_manager
        self.fps = self.config.get("fps", 30)
        self.frame_interval = 1.0 / self.fps

        # 挂载 AIMA v5.3 工业级硬实时微内核桥接层 (若可用则启用高速微内核卸载)
        self.kernel_bridge = AimaKernelBridge.get_instance()
        self.use_kernel_rt = self.kernel_bridge.is_available and self.config.get("use_kernel_rt", True)
        if self.use_kernel_rt:
            logger.info("CoreEngine: 已启用 AI-MA v5.3 硬实时微内核硬件卸载加速模式 (v5.3_shm)！")
        else:
            logger.info("CoreEngine: 未检测到微内核或已禁用，运行在 Python 纯软件兼容模式。")

        # 核心服务实例化
        self.event_bus = EventBus()
        self.dmx_merger = DmxMerger(universe_count=4)
        
        # 将知识库灯具通道安全掩码注册进仲裁器
        self._init_merger_rules()

        # 注入插件上下文 (含方案二 ServiceBroker、EventHub 与只读状态镜像)
        from plugin_sdk import ServiceBroker, EventHub, ReadOnlyStateMirror
        self.service_broker = ServiceBroker()
        self.event_hub = EventHub()
        self.state_mirror = ReadOnlyStateMirror(kernel_bridge=self.kernel_bridge)

        self.context = CoreContext(
            event_bus=self.event_bus,
            dmx_merger=self.dmx_merger,
            kb_manager=self.kb,
            config=self.config,
            service_broker=self.service_broker,
            event_hub=self.event_hub,
            state_mirror=self.state_mirror,
            hosted=True
        )

        # 插件管理器宿主
        plugins_dir = self.config.get("plugins_dir", "plugins")
        self.plugin_host = PluginHost(plugins_dir=plugins_dir, context=self.context)
        self.plugin_host.discover_and_load_all()

        # 心跳线程
        self._running = False
        self._heartbeat_thread: Optional[threading.Thread] = None

        # 动态宏与平滑过渡状态机
        self._active_macro_job: Optional[Dict[str, Any]] = None
        self._crossfade_jobs: List[Dict[str, Any]] = []
        self._job_lock = threading.RLock()

    def _init_merger_rules(self):
        """遍历当前场地拓扑与灯库，在仲裁器中固化安全掩码与属性映射"""
        fixtures = self.kb.current_venue.get("fixtures", [])
        for fix in fixtures:
            u = fix.get("universe", 0)
            addr = fix.get("address", 1)
            pid = fix.get("profile_id", "")
            prof = self.kb.profiles.get(pid, {})
            ch_defs = []
            for ch_def in prof.get("channels", []):
                ch_defs.append(ch_def)
            self.dmx_merger.configure_fixture_channels(u, addr, ch_defs)

    def start(self):
        """启动 30Hz 工业心跳刷新循环"""
        if self._running:
            return
        self._running = True
        self._heartbeat_thread = threading.Thread(target=self._loop, name="IndustrialDmxHeartbeat", daemon=True)
        self._heartbeat_thread.start()
        self.event_bus.publish(SystemEvents.SYSTEM_STARTED)
        logger.info(f"AI-MA 微内核引擎启动成功，刷新率: {self.fps} FPS")

    def stop(self):
        """安全停止内核与插件"""
        self._running = False
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=1.5)
        self.plugin_host.shutdown_all()
        self.event_bus.publish(SystemEvents.SYSTEM_STOPPING)
        logger.info("AI-MA 微内核引擎已安全停机。")

    def _loop(self):
        """高精度 30Hz 物理输出主循环 (工业级异常沙箱与不死看门狗)"""
        last_time = time.perf_counter()
        while self._running:
            start_tick = time.perf_counter()
            now = time.time()

            try:
                # 1. 执行 Crossfade 毫秒平滑线性插值
                self._update_crossfades(now)

                # 2. 执行动态宏演算 (如有)
                self._update_macro(now)

                # 3. 数据下发与发包 (新型硬实时微内核架构：彻底剥离 Python 发包)
                # 将本引擎演算的宏/Cue/过渡帧直接卸载写入 L4 控制台槽位
                # 耗时仅 0.57µs，物理发包与硬件安全钳位完全交由后台硬实时守护进程 aima-rt-daemon 承担！
                if self.kernel_bridge.is_available:
                    for u in range(self.dmx_merger.universe_count):
                        frame = self.dmx_merger.get_final_frame(u)
                        # 生成受控通道掩码：当且仅当该 Universe 存在激活受控信号源时置 1
                        # 确保通道值为 0 (如暗场、关光、拉低推杆) 时掩码位仍为 1，穿透写入内核槽位而非退让
                        mask = self.dmx_merger.get_controlled_channels_mask(u)
                        self.kernel_bridge.submit_layer("l4", u, frame, mask)
                else:
                    logger.critical("[FATAL] AIMA v5.3 物理硬实时微内核失联！未检测到底层共享内存！")
            except Exception as e_tick:
                logger.error(f"30Hz 物理输出主循环高精度时钟周期异常: {e_tick}")

            # 4. 纳秒/微秒级自适应休眠，保持恒定 33.3ms 周期
            elapsed = time.perf_counter() - start_tick
            sleep_time = self.frame_interval - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    def trigger_crossfade(self, universe: int, target_frame: bytearray, duration_ms: float = 1000.0, priority: int = PriorityLevel.AI_CUE):
        """启动毫秒级平滑过渡淡变"""
        start_frame = self.dmx_merger.get_final_frame(universe)
        job = {
            "universe": universe,
            "start_frame": start_frame,
            "target_frame": bytearray(target_frame[:512]),
            "start_time": time.time(),
            "duration": max(duration_ms / 1000.0, 0.001),
            "priority": priority
        }
        with self._job_lock:
            # 移除同 Universe 的旧过渡
            self._crossfade_jobs = [j for j in self._crossfade_jobs if j["universe"] != universe]
            self._crossfade_jobs.append(job)

    def _update_crossfades(self, now: float):
        finished = []
        with self._job_lock:
            for job in self._crossfade_jobs:
                u = job["universe"]
                progress = min((now - job["start_time"]) / job["duration"], 1.0)
                
                # 线性插值计算
                interpolated = bytearray(512)
                for i in range(512):
                    start_v = job["start_frame"][i]
                    target_v = job["target_frame"][i]
                    interpolated[i] = int(start_v + (target_v - start_v) * progress)

                # 提交给仲裁器
                self.dmx_merger.submit_frame(f"crossfade_u{u}", u, interpolated, priority=job["priority"])

                if progress >= 1.0:
                    finished.append(job)

            for f in finished:
                self._crossfade_jobs.remove(f)

    def start_macro(self, macro_id: str, params: Dict[str, Any]):
        """激活背景动态宏 (走马灯/呼吸)"""
        macro = self.plugin_host.get_macro(macro_id)
        if not macro:
            logger.warning(f"未找到特效宏插件: [{macro_id}]")
            return False
            
        with self._job_lock:
            self._active_macro_job = {
                "macro_id": macro_id,
                "macro": macro,
                "params": params,
                "start_time": time.time()
            }
        logger.info(f"已激活动态特效宏: [{macro_id}]")
        return True

    def stop_macro(self):
        """停止背景动态宏并清除信号源"""
        with self._job_lock:
            if self._active_macro_job:
                self._active_macro_job = None
                self.dmx_merger.clear_source("active_macro")
                logger.info("动态特效宏已停止。")

    def _update_macro(self, now: float):
        with self._job_lock:
            if not self._active_macro_job:
                return
            macro = self._active_macro_job["macro"]
            params = self._active_macro_job["params"]
            elapsed_ms = (now - self._active_macro_job["start_time"]) * 1000.0

        fixtures = params.get("fixtures", [])
        if fixtures:
            # 解决跨 Universe 宏截断问题：将 fixtures 按 universe 聚类循环渲染与提交
            u_fixtures: Dict[int, list] = {}
            for fix in fixtures:
                u = fix.get("universe", 0)
                u_fixtures.setdefault(u, []).append(fix)

            try:
                for u, f_list in u_fixtures.items():
                    u_params = dict(params)
                    u_params["fixtures"] = f_list
                    base_frame = self.dmx_merger.get_final_frame(u)
                    new_frame = macro.render(elapsed_ms, u_params, bytearray(base_frame))
                    self.dmx_merger.submit_frame("active_macro", u, new_frame, priority=PriorityLevel.AI_MACRO)
            except Exception as e_m:
                logger.error(f"动态特效宏演算发生故障，已自动保护性熔断停止: {e_m}")
                self.stop_macro()
