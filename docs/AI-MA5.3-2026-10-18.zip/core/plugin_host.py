# -*- coding: utf-8 -*-
"""
AI-MA 企业级插件宿主与生命周期管理器 (PluginHost v3.0)
支持：
1. 插件启动/停止 (set_enabled)
2. 插件参数读取/热更新/持久化配置 (config/plugins_config.json)
3. 动态热装载与卸载 (Hot Reload & Uninstall)
4. 插件市场合规性验证 (PluginValidator)
"""

import os
import sys
import json
import importlib
import importlib.util
import inspect
import shutil
import logging
from typing import Dict, List, Any, Optional

try:
    from plugin_sdk import (
        BasePlugin, BaseProtocolPlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin,
        BaseSystemPlugin, BaseAdapterPlugin, BaseCreativePlugin, BaseTransportPlugin,
        PluginTier, PluginValidator, CoreContext
    )
    from diagnostics_logger import log_diagnostic_error
except ImportError:
    from core.plugin_sdk import (
        BasePlugin, BaseProtocolPlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin,
        BaseSystemPlugin, BaseAdapterPlugin, BaseCreativePlugin, BaseTransportPlugin,
        PluginTier, PluginValidator, CoreContext
    )
    from core.diagnostics_logger import log_diagnostic_error

logger = logging.getLogger("PluginHost")

# 三层插件的中文类目名称。
# 面向用户的界面只展示 3 类；但运维日志与诊断接口必须能区分全部三层，
# 否则 1/2 类底座插件到底是"启动成功"还是"启动失败"将完全不可观测。
TIER_LABELS = {
    PluginTier.SYSTEM:   "1类·系统级",
    PluginTier.ADAPTER:  "2类·适配级",
    PluginTier.CREATIVE: "3类·表现创意",
}

# 1 类系统级与 2 类适配级是系统底座：
#   - 1 类承载物理协议驱动与端侧大模型中枢，缺了就没有任何物理输出；
#   - 2 类承载灯库资产总线，缺了就无法导入控台格式。
# 它们装载失败属于**严重故障**，必须按故障码告警，而不是像 3 类那样只提示。
FOUNDATIONAL_TIERS = (PluginTier.SYSTEM, PluginTier.ADAPTER)


def tier_label(tier) -> str:
    """把 PluginTier 数值转换为可读类目名，未知层级回退为原始值"""
    return TIER_LABELS.get(tier, f"未知层级({tier})")


class PluginHost:
    def __init__(self, plugins_dir: str, context: CoreContext, config_store_path: str = "config/plugins_config.json"):
        self.plugins_dir = os.path.abspath(plugins_dir)
        self.context = context
        self.config_store_path = os.path.abspath(config_store_path)
        
        # 运行时插件表: {plugin_id: instance}
        self._plugins: Dict[str, BasePlugin] = {}
        # 模块映射表: {plugin_id: module_name}
        self._plugin_modules: Dict[str, str] = {}
        # 插件源码路径: {plugin_id: file_path}
        self._plugin_files: Dict[str, str] = {}
        # 2 类能力提供者索引表: {capability_tag: [plugin_instance, ...]}
        self._capabilities_index: Dict[str, List[BasePlugin]] = {}

        # 装载失败登记表: [{"file", "module", "tier", "plugin_id", "reason", "stage"}]
        # 供 /api/plugins/diagnostics 与启动总览使用，避免失败被静默吞掉。
        self._load_failures: List[Dict[str, Any]] = []
        # 已扫描的插件源文件总数（用于校验"扫描数 == 成功数 + 失败数"）
        self._scanned_files: int = 0

        # 加载持久化配置
        self.stored_configs: Dict[str, Dict[str, Any]] = self._load_stored_configs()

    def is_adapter_available(self, dep_identifier: str) -> bool:
        """
        检查前置 2 类适配依赖是否可用。
        判定条件：
        1. 该依赖可为已启用的 2 类插件 ID；
        2. 或该依赖可为已启用的 2 类插件声明的能力标签 (Capability)。
        """
        # 1. 尝试按插件 ID 直接命中
        if dep_identifier in self._plugins:
            p = self._plugins[dep_identifier]
            if p.tier == PluginTier.ADAPTER and p.is_enabled:
                return True

        # 2. 尝试按能力标签索引命中
        if dep_identifier in self._capabilities_index:
            for p in self._capabilities_index[dep_identifier]:
                if p.is_enabled:
                    return True

        return False

    def verify_dependencies(self, instance: BasePlugin) -> tuple[bool, str]:
        """
        阶梯依赖架构准入门禁校验：
        3 类表现创意插件必须建立在已就绪的 2 类适配插件/能力基础之上。
        若声明的前置依赖缺失或未启用，安全阻断装载并返回原因。
        """
        if instance.tier == PluginTier.CREATIVE and hasattr(instance, "get_required_adapters"):
            try:
                required = instance.get_required_adapters()
            except Exception as e:
                return False, f"获取依赖声明异常: {e}"

            if required is not None and not isinstance(required, (list, tuple, set)):
                return False, "依赖声明类型非法: 必须为集合/列表类型"

            if required:
                missing = []
                for dep in required:
                    if not self.is_adapter_available(dep):
                        missing.append(dep)
                if missing:
                    return False, f"缺少前置 2 类适配支持: {missing} (请先启用或安装对应的 2 类适配组件)"
        return True, "依赖核验通过"

    def _register_capabilities(self, instance: BasePlugin):
        """当插件（特别是 2 类适配插件）加载启用时，登记其提供的能力索引"""
        if instance.tier == PluginTier.ADAPTER and hasattr(instance, "get_provided_capabilities"):
            try:
                caps = instance.get_provided_capabilities()
                if caps and isinstance(caps, list):
                    for cap in caps:
                        if cap not in self._capabilities_index:
                            self._capabilities_index[cap] = []
                        if instance not in self._capabilities_index[cap]:
                            self._capabilities_index[cap].append(instance)
            except Exception as e:
                logger.warning(f"登记插件能力异常 [{instance.get_info().get('id')}]: {e}")

    def _unregister_capabilities(self, plugin_or_id: Any):
        """当插件卸载或注销时，清理其提供的能力索引（支持传入 BasePlugin 实例或 plugin_id 字符串）"""
        target_instance = None
        target_id = None
        if isinstance(plugin_or_id, BasePlugin):
            target_instance = plugin_or_id
            try:
                target_id = target_instance.get_info().get("id")
            except Exception:
                target_id = None
        elif isinstance(plugin_or_id, str):
            target_id = plugin_or_id
            target_instance = self._plugins.get(target_id)

        for cap, plugins in list(self._capabilities_index.items()):
            # 清理匹配的 instance 或匹配的 id
            to_remove = []
            for p in plugins:
                p_id = None
                try:
                    p_id = p.get_info().get("id")
                except Exception:
                    pass
                if (target_instance is not None and p == target_instance) or (target_id is not None and p_id == target_id):
                    to_remove.append(p)
            for p in to_remove:
                if p in plugins:
                    plugins.remove(p)
            if not plugins:
                self._capabilities_index.pop(cap, None)

    def _record_failure(self, file_path: str, mod_name: str, stage: str, reason: str,
                        tier: Optional[int] = None, plugin_id: Optional[str] = None) -> Dict[str, Any]:
        """登记一次装载失败，并按层级决定告警级别"""
        entry = {
            "file": os.path.basename(file_path),
            "module": mod_name,
            "tier": tier,
            "tier_label": tier_label(tier) if tier is not None else "未知层级",
            "plugin_id": plugin_id or "(未识别)",
            "stage": stage,
            "reason": reason,
        }
        self._load_failures.append(entry)

        prefix = f"[{entry['tier_label']}] 插件 [{entry['plugin_id']}] 装载失败 @ {stage}: {reason}"
        if tier in FOUNDATIONAL_TIERS:
            # 底座插件失败：走诊断故障码，ERROR 级别
            log_diagnostic_error(logger, "ERR-PLUGIN-FOUNDATION", prefix)
        else:
            logger.error(prefix)
        return entry

    def _load_stored_configs(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(self.config_store_path):
            try:
                with open(self.config_store_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"读取插件持久化配置失败: {e}")
        return {}

    def _save_stored_configs(self):
        try:
            os.makedirs(os.path.dirname(self.config_store_path), exist_ok=True)
            with open(self.config_store_path, "w", encoding="utf-8") as f:
                json.dump(self.stored_configs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存插件持久化配置失败: {e}")

    def discover_and_load_all(self):
        """扫描并加载 plugins/ 下所有插件，收尾输出分层装载总览"""
        if not os.path.exists(self.plugins_dir):
            os.makedirs(self.plugins_dir, exist_ok=True)
            logger.warning(f"插件目录不存在，已创建空目录（无任何插件可装载）: {self.plugins_dir}")
            return

        if self.plugins_dir not in sys.path:
            sys.path.insert(0, self.plugins_dir)

        logger.info("=" * 76)
        logger.info(" 开始扫描并装载插件生态（三层分级）")
        logger.info("=" * 76)

        # 阶梯依赖拓扑排序与分层发现：
        # 1类(底层通讯/协议) -> 2类(适配/转译/功能扩展) -> 3类(创意表现与应用)
        # 严格保证底层优先装载并提供能力，使上层能够平滑依赖绑定
        files_by_tier = {
            PluginTier.SYSTEM: [],
            PluginTier.ADAPTER: [],
            PluginTier.CREATIVE: []
        }

        for root, _, files in os.walk(self.plugins_dir):
            for file in files:
                if file.endswith(".py") and not file.startswith("__"):
                    full_p = os.path.join(root, file)
                    rel_p = os.path.relpath(full_p, self.plugins_dir)
                    mod_name = os.path.splitext(rel_p)[0].replace(os.path.sep, ".")
                    
                    # 判定其所属物理目录层级
                    first_part = rel_p.split(os.path.sep)[0]
                    if first_part == "system":
                        files_by_tier[PluginTier.SYSTEM].append((full_p, mod_name))
                    elif first_part == "adapters":
                        files_by_tier[PluginTier.ADAPTER].append((full_p, mod_name))
                    else:
                        files_by_tier[PluginTier.CREATIVE].append((full_p, mod_name))

        # 按照 1 类 -> 2 类 -> 3 类顺序分层装载
        for tier in (PluginTier.SYSTEM, PluginTier.ADAPTER, PluginTier.CREATIVE):
            for full_p, mod_name in files_by_tier[tier]:
                self._scanned_files += 1
                self.load_plugin_from_file(full_p, mod_name)

        self.log_load_summary()

    def load_plugin_from_file(self, file_path: str, mod_name: str) -> Optional[BasePlugin]:
        """
        从单个 Python 源码文件加载插件并进行合规校验。

        本函数的每一条return路径都会留下带**层级标签**的日志记录：
        成功走 INFO，失败按层级决定告警级别（1/2 类底座插件走 ERR-PLUGIN-FOUNDATION 故障码）。
        历史上失败路径存在"无插件类则完全静默"的盲区，导致底座插件没起来却查无实据。
        """
        try:
            # 确保文件所在目录在 sys.path 中，以便 reload 和标准导入能够正常解析模块 spec
            if file_path and os.path.exists(file_path):
                file_dir = os.path.dirname(os.path.abspath(file_path))
                if file_dir not in sys.path:
                    sys.path.insert(0, file_dir)

            if mod_name in sys.modules:
                try:
                    mod = importlib.reload(sys.modules[mod_name])
                except Exception:
                    # 若 reload 失败，尝试通过 spec 重新加载
                    if file_path and os.path.exists(file_path):
                        spec = importlib.util.spec_from_file_location(mod_name, file_path)
                        if spec and spec.loader:
                            mod = importlib.util.module_from_spec(spec)
                            sys.modules[mod_name] = mod
                            spec.loader.exec_module(mod)
                        else:
                            raise
                    else:
                        raise
            elif file_path and os.path.exists(file_path):
                spec = importlib.util.spec_from_file_location(mod_name, file_path)
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    sys.modules[mod_name] = mod
                    spec.loader.exec_module(mod)
                else:
                    mod = importlib.import_module(mod_name)
            else:
                mod = importlib.import_module(mod_name)
        except Exception as e:
            self._record_failure(file_path, mod_name, "模块导入", f"{type(e).__name__}: {e}")
            logger.debug("模块导入异常堆栈", exc_info=True)
            return None

        matched_class = None
        for attr_name in dir(mod):
            attr = getattr(mod, attr_name)
            # 兼容模块从 core.plugin_sdk 或 plugin_sdk 导入导致的类型对象身份差异
            is_plugin_subclass = False
            if inspect.isclass(attr):
                is_plugin_subclass = issubclass(attr, BasePlugin) or any(base.__name__ == "BasePlugin" for base in attr.__mro__)

            if (inspect.isclass(attr) and is_plugin_subclass and 
                not inspect.isabstract(attr) and
                attr.__name__ not in ["BasePlugin", "BaseProtocolPlugin", "BaseMacroPlugin", "BasePerceptionPlugin", "BaseLLMPlugin", "BaseSystemPlugin", "BaseAdapterPlugin", "BaseCreativePlugin", "BaseTransportPlugin"]):
                matched_class = attr
                break

        # 盲区修补：源文件存在、导入成功，却没有任何可实例化的插件类。
        # 原实现在此静默返回 None，运维侧完全看不到这个文件被漏掉了。
        if matched_class is None:
            self._record_failure(file_path, mod_name, "类发现",
                                 "文件中未找到任何继承自 BasePlugin 的可实例化插件类")
            return None

        try:
            instance = matched_class()

            # 1. 验证器合规审查
            val_res = PluginValidator.validate_plugin_instance(instance)
            info = instance.get_info()
            pid = info.get("id")
            tier = instance.tier

            if not val_res["valid"]:
                self._record_failure(file_path, mod_name, "合规校验",
                                     str(val_res["errors"]), tier=tier, plugin_id=pid)
                return None

            # 2. 注入历史持久化配置
            if pid in self.stored_configs:
                p_cfg = self.stored_configs[pid].get("config", {})
                instance.update_config(p_cfg)

            # 3. 初始化
            if not instance.on_init(self.context):
                self._record_failure(file_path, mod_name, "on_init()",
                                     "on_init() 返回 False（插件自身初始化失败）",
                                     tier=tier, plugin_id=pid)
                return None

            # 3.5 阶梯依赖准入门禁检查 (3类必须依托 2类)
            dep_ok, dep_msg = self.verify_dependencies(instance)
            if not dep_ok:
                self._record_failure(file_path, mod_name, "阶梯依赖门禁",
                                     dep_msg, tier=tier, plugin_id=pid)
                return None

            # 4. 决定启停状态 (默认开启，或按持久化设置)
            saved_enabled = True
            if pid in self.stored_configs:
                saved_enabled = self.stored_configs[pid].get("enabled", True)

            instance.set_enabled(saved_enabled)

            self._plugins[pid] = instance
            self._plugin_modules[pid] = mod_name
            self._plugin_files[pid] = file_path
            self._register_capabilities(instance)

            # 成功日志带明确层级标签，使 1/2/3 类在日志中一眼可辨
            logger.info(
                f"[{tier_label(tier)}] 插件 [{info['name']}] (ID: {pid}) 装载成功，"
                f"状态: {'[已启用]' if instance.is_enabled else '[已停用]'}"
            )
            return instance

        except Exception as e:
            self._record_failure(file_path, mod_name, "实例化/初始化",
                                 f"{type(e).__name__}: {e}")
            logger.debug("插件实例化异常堆栈", exc_info=True)
            return None

    def log_load_summary(self):
        """
        输出分层的插件装载总览。

        这是判断"1 类 / 2 类底座插件到底起没起来"最直接的一处依据：
        按层级列出每个插件的 ID、名称、启停状态，并给出各层的 成功/预期 计数。
        """
        by_tier: Dict[Any, List[BasePlugin]] = {PluginTier.SYSTEM: [], PluginTier.ADAPTER: [], PluginTier.CREATIVE: []}
        for p in self._plugins.values():
            by_tier.setdefault(p.tier, []).append(p)

        # 各层"应有"数量 = 已装载 + 该层失败数
        failed_by_tier: Dict[Any, int] = {}
        for f in self._load_failures:
            if f["tier"] is not None:
                failed_by_tier[f["tier"]] = failed_by_tier.get(f["tier"], 0) + 1

        logger.info("=" * 76)
        logger.info(" 插件生态装载总览（1/2 类为系统底座，仅日志与诊断接口可见）")
        logger.info("=" * 76)

        for tier in (PluginTier.SYSTEM, PluginTier.ADAPTER, PluginTier.CREATIVE):
            items = by_tier.get(tier, [])
            failed = failed_by_tier.get(tier, 0)
            expected = len(items) + failed
            mark = "OK" if failed == 0 else f"!! {failed} 个失败"
            logger.info(f" 【{tier_label(tier)}】 已装载 {len(items)}/{expected}  [{mark}]")
            for p in items:
                info = p.get_info()
                state = "已启用" if p.is_enabled else "已停用"
                logger.info(f"      - {p.get_info().get('id'):<34} {info.get('name')}  [{state}]")
            if not items and expected == 0:
                logger.info("      (该层级无插件)")

        logger.info("-" * 76)
        logger.info(f" 合计: 扫描 {self._scanned_files} 个源文件 | "
                    f"装载成功 {len(self._plugins)} 个 | 失败 {len(self._load_failures)} 个")

        if self._load_failures:
            logger.error(" 以下插件装载失败，明细如下：")
            for f in self._load_failures:
                logger.error(f"      - [{f['tier_label']}] {f['plugin_id']} "
                             f"(文件 {f['file']}) @ {f['stage']}: {f['reason']}")
        else:
            logger.info(" 全部插件装载成功，无失败项。")

        # 底座插件失效是最严重的：1 类缺失 = 无物理输出，2 类缺失 = 无法导入控台资产
        foundation_failed = [f for f in self._load_failures if f["tier"] in FOUNDATIONAL_TIERS]
        if foundation_failed:
            logger.critical(
                f" 严重告警：{len(foundation_failed)} 个系统底座插件（1 类系统级 / 2 类适配级）装载失败！"
                f"系统可能无法进行物理推流或导入控台资产，请立即排查上列失败原因。"
            )
        logger.info("=" * 76)

    def get_diagnostic_report(self) -> Dict[str, Any]:
        """
        全量插件诊断报告（供管理员诊断接口 /api/plugins/diagnostics 使用）。

        这是与"面向用户只展示 3 类"并行的运维可见性通道：
        用户界面保持干净，运维却能完整掌握三层插件的启停与失败状态。
        """
        def _entry(p: BasePlugin) -> Dict[str, Any]:
            return {
                "id": p.get_info().get("id"),
                "name": p.get_info().get("name"),
                "version": p.get_info().get("version"),
                "type": p.get_info().get("type"),
                "tier": p.tier,
                "tier_label": tier_label(p.tier),
                "enabled": p.is_enabled,
                "protected": p.tier in FOUNDATIONAL_TIERS,
            }

        grouped = {}
        for tier in (PluginTier.SYSTEM, PluginTier.ADAPTER, PluginTier.CREATIVE):
            grouped[tier_label(tier)] = [_entry(p) for p in self._plugins.values() if p.tier == tier]

        return {
            "scanned_files": self._scanned_files,
            "loaded_total": len(self._plugins),
            "failed_total": len(self._load_failures),
            "foundation_healthy": not any(f["tier"] in FOUNDATIONAL_TIERS for f in self._load_failures),
            "by_tier": grouped,
            "failures": self._load_failures,
        }

    def set_plugin_enabled(self, plugin_id: str, enabled: bool) -> bool:
        """用户在 UI 中手动启停插件"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            raise KeyError(f"未找到插件: {plugin_id}")

        plugin.set_enabled(enabled)
        # 持久化启停状态
        if plugin_id not in self.stored_configs:
            self.stored_configs[plugin_id] = {}
        self.stored_configs[plugin_id]["enabled"] = enabled
        self._save_stored_configs()
        logger.info(f"插件 [{plugin_id}] 状态切换为: {'[已启用]' if enabled else '[已停用]'}")
        return True

    def hot_reload_plugin(self, plugin_id: str) -> bool:
        """
        方案四：平滑热重载与状态暂存迁移 (Save State -> Unload -> Reload -> Restore State)
        AC-4.1: 插件在热重载过程中内部关键计数器与灯光模式保持零丢失。
        """
        old_instance = self._plugins.get(plugin_id)
        if not old_instance:
            raise KeyError(f"未找到热重载目标插件: {plugin_id}")

        file_path = self._plugin_files.get(plugin_id)
        if not file_path or not os.path.exists(file_path):
            raise FileNotFoundError(f"插件源文件不存在: {file_path}")

        # 1. 导出旧版本状态
        saved_state = {}
        if hasattr(old_instance, "on_save_state"):
            try:
                saved_state = old_instance.on_save_state() or {}
            except Exception as e:
                logger.warning(f"插件 [{plugin_id}] on_save_state 异常: {e}")

        was_enabled = old_instance.is_enabled

        # 2. 停止旧实例并清理能力索引
        old_instance.set_enabled(False)
        self._unregister_capabilities(old_instance)
        if self.context and hasattr(self.context, "service_broker"):
            self.context.service_broker.unregister_all_for_plugin(plugin_id)
        if self.context and hasattr(self.context, "event_hub"):
            self.context.event_hub.unsubscribe_all(plugin_id)

        # 3. 获取模块名
        mod_name = self._plugin_modules.get(plugin_id)
        if not mod_name:
            # 尝试根据相对路径反推模块名
            rel_p = os.path.relpath(file_path, self.plugins_dir)
            mod_name = os.path.splitext(rel_p)[0].replace(os.path.sep, ".")

        # 4. 重新装载插件 (内部会重新 reload 模块并登记能力索引与字典)
        new_instance = self.load_plugin_from_file(file_path, mod_name)
        if not new_instance:
            logger.error(f"插件 [{plugin_id}] 热重载加载新文件失败")
            # 尝试恢复旧实例登记
            self._plugins[plugin_id] = old_instance
            self._register_capabilities(old_instance)
            old_instance.set_enabled(was_enabled)
            return False

        # 维护映射关系
        new_info = new_instance.get_info()
        new_id = new_info.get("id", plugin_id)
        self._plugins[new_id] = new_instance
        self._plugin_modules[new_id] = mod_name
        self._plugin_files[new_id] = file_path
        self._register_capabilities(new_instance)
        new_instance.set_enabled(was_enabled)

        # 5. 状态恢复
        if hasattr(new_instance, "on_restore_state") and saved_state:
            try:
                new_instance.on_restore_state(saved_state)
            except Exception as e:
                logger.warning(f"插件 [{new_id}] on_restore_state 异常: {e}")

        logger.info(f"插件 [{new_id}] 平滑热重载并恢复状态完成！")
        return True

    def configure_plugin(self, plugin_id: str, new_config: Dict[str, Any]) -> bool:
        """用户在 UI 中修改插件参数配置"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            raise KeyError(f"未找到插件: {plugin_id}")

        # 校验参数类型并热更新
        schema = plugin.get_config_schema()
        clean_cfg = {}
        for k, v in new_config.items():
            if k in schema:
                val_type = schema[k].get("type", "string")
                if val_type == "integer":
                    clean_cfg[k] = int(v)
                elif val_type == "number":
                    clean_cfg[k] = float(v)
                elif val_type == "boolean":
                    clean_cfg[k] = bool(v)
                else:
                    clean_cfg[k] = str(v)

        plugin.update_config(clean_cfg)
        
        # 持久化配置
        if plugin_id not in self.stored_configs:
            self.stored_configs[plugin_id] = {}
        self.stored_configs[plugin_id]["config"] = plugin.get_config()
        self._save_stored_configs()
        logger.info(f"插件 [{plugin_id}] 参数已更新并持久化: {clean_cfg}")
        return True

    def uninstall_plugin(self, plugin_id: str) -> bool:
        """用户在 UI 中卸载插件（严格限制：仅允许卸载 3 类创意插件，绝对禁止卸载 1 类系统与 2 类适配插件）"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            raise KeyError(f"未找到插件: {plugin_id}")

        if plugin.tier in [PluginTier.SYSTEM, PluginTier.ADAPTER]:
            raise PermissionError(f"插件 [{plugin_id}] 属于受保护的 {plugin.tier} 类系统/适配插件，禁止卸载！")

        # 1. 停用
        plugin.set_enabled(False)
        file_path = self._plugin_files.get(plugin_id)

        # 清除该插件在 ServiceBroker / EventHub 上的注册，防止悬空句柄与内存泄露
        if self.context and hasattr(self.context, "service_broker"):
            self.context.service_broker.unregister_all_for_plugin(plugin_id)
        if self.context and hasattr(self.context, "event_hub"):
            self.context.event_hub.unsubscribe_all(plugin_id)

        # 清理该插件提供的 2 类能力索引
        self._unregister_capabilities(plugin)

        # 2. 清除内存登记
        del self._plugins[plugin_id]
        if plugin_id in self._plugin_modules:
            del self._plugin_modules[plugin_id]
        if plugin_id in self._plugin_files:
            del self._plugin_files[plugin_id]
        if plugin_id in self.stored_configs:
            del self.stored_configs[plugin_id]
            self._save_stored_configs()

        # 3. 物理删除文件
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
                logger.info(f"3 类创意插件 [{plugin_id}] 物理文件已移除: {file_path}")
            except Exception as e:
                logger.error(f"移除插件文件失败: {e}")

        logger.info(f"插件 [{plugin_id}] 已完全卸载。")
        return True

    def get_plugin_details(self, plugin_id: str) -> Dict[str, Any]:
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            return {}
        return {
            "id": plugin_id,
            "tier": plugin.tier,
            "info": plugin.get_info(),
            "enabled": plugin.is_enabled,
            "schema": plugin.get_config_schema(),
            "config": plugin.get_config(),
            "ui_extensions": plugin.get_ui_extensions()
        }

    def list_all_plugins_summary(self) -> List[Dict[str, Any]]:
        """全量插件状态（供底层系统监控与诊断使用）"""
        res = []
        for pid, p in self._plugins.items():
            res.append({
                "id": pid,
                "tier": p.tier,
                "info": p.get_info(),
                "enabled": p.is_enabled,
                "schema": p.get_config_schema(),
                "config": p.get_config(),
                "ui_extensions": p.get_ui_extensions()
            })
        return res

    def list_community_plugins(self) -> List[Dict[str, Any]]:
        """仅返回 3 类创意插件（供面向灯光师与爱好者的插件市场展示）"""
        return [
            {
                "id": pid,
                "tier": p.tier,
                "info": p.get_info(),
                "enabled": p.is_enabled,
                "schema": p.get_config_schema(),
                "config": p.get_config()
            }
            for pid, p in self._plugins.items() if p.tier == PluginTier.CREATIVE
        ]

    def get_adapter_for_extension(self, ext: str) -> Optional[BaseAdapterPlugin]:
        """根据文件后缀查找对应的 2 类适配器插件"""
        ext = ext.lower()
        if not ext.startswith("."):
            ext = "." + ext
        for p in self._plugins.values():
            if isinstance(p, BaseAdapterPlugin) and p.is_enabled:
                if ext in [e.lower() for e in p.supported_extensions()]:
                    return p
        return None

    def get_ui_extensions_for_slot(self, slot_name: str) -> List[Dict[str, Any]]:
        """获取特定 UI 插槽（如 kb_profiles_toolbar）挂载的所有扩展按钮配置"""
        exts = []
        for p in self._plugins.values():
            if p.is_enabled:
                for ext in p.get_ui_extensions():
                    if ext.get("slot") == slot_name:
                        exts.append(ext)
        return exts

    def get_protocol_plugins(self) -> List[BaseProtocolPlugin]:
        return [p for p in self._plugins.values() if isinstance(p, BaseProtocolPlugin) and p.is_enabled]

    def get_macro(self, macro_id: str) -> Optional[BaseMacroPlugin]:
        p = self._plugins.get(macro_id)
        return p if (p and isinstance(p, BaseMacroPlugin) and p.is_enabled) else None

    def get_llm(self) -> Optional[BaseLLMPlugin]:
        for p in self._plugins.values():
            if isinstance(p, BaseLLMPlugin) and p.is_enabled:
                return p
        return None

    def shutdown_all(self):
        for pid, p in self._plugins.items():
            try:
                p.set_enabled(False)
            except Exception as e:
                logger.error(f"关闭插件 [{pid}] 时异常: {e}")

    # =========================================================================
    # 方案四：平滑升级与热重载状态暂存/恢复扩展
    # =========================================================================
    def save_plugin_state(self, plugin_id: str) -> Dict[str, Any]:
        """导出插件运行时内部状态字典（用于热重载与升级平滑迁移）"""
        plugin = self._plugins.get(plugin_id)
        if not plugin:
            return {}
        try:
            return plugin.on_save_state()
        except Exception as e:
            logger.error(f"插件 [{plugin_id}] 执行 on_save_state 失败: {e}")
            return {}

    def restore_plugin_state(self, plugin_id: str, state: Dict[str, Any]) -> bool:
        """为插件恢复运行时内部状态字典"""
        plugin = self._plugins.get(plugin_id)
        if not plugin or not state:
            return False
        try:
            plugin.on_restore_state(state)
            return True
        except Exception as e:
            logger.error(f"插件 [{plugin_id}] 执行 on_restore_state 失败: {e}")
            return False
