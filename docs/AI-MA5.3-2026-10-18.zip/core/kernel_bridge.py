# -*- coding: utf-8 -*-
"""
AI-MA v5.3 共享内存微内核适配驱动层 (AIMA Kernel Bridge)
提供 Python 上层系统与 Rust 硬实时微内核 (/dev/shm/aima_slot_l1 ~ l4) 的双向零拷贝桥接通道。
"""

import os
import sys
import logging
from typing import Optional, Dict, Any, Tuple
import numpy as np

# 将 kernel 根目录加入模块搜索路径，确保可以直接加载 aima_shm_sdk.pyd
KERNEL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if KERNEL_ROOT not in sys.path:
    sys.path.insert(0, KERNEL_ROOT)

logger = logging.getLogger("AimaKernelBridge")

class AimaKernelBridge:
    _instance: Optional["AimaKernelBridge"] = None

    def __init__(self):
        self._enabled = False
        self._sdk = None
        self._clients: Dict[str, Any] = {}
        self._core_client = None
        self._init_sdk()

    @classmethod
    def get_instance(cls) -> "AimaKernelBridge":
        if cls._instance is None:
            cls._instance = AimaKernelBridge()
        return cls._instance

    def _init_sdk(self):
        try:
            # 优先加载本工程 (AI-MA5.3) 内置的 aima_shm_sdk 动态链接库
            cur_core = os.path.dirname(os.path.abspath(__file__))
            cur_root = os.path.dirname(cur_core)
            kernel_dir = os.path.join(os.path.dirname(cur_root), "ai-ma-kernel-v5.3")
            for p in [cur_core, cur_root, kernel_dir]:
                if os.path.exists(p) and p not in sys.path:
                    sys.path.insert(0, p)

            import aima_shm_sdk
            self._sdk = aima_shm_sdk
            # 初始化 4 级槽位客户端 (L1=安全, L2=设备适配, L3=创意插件, L4=手动控制台)
            self._clients["l1"] = aima_shm_sdk.AimaPythonShmClient("/dev/shm/aima_slot_l1")
            self._clients["l2"] = aima_shm_sdk.AimaPythonShmClient("/dev/shm/aima_slot_l2")
            self._clients["l3"] = aima_shm_sdk.AimaPythonShmClient("/dev/shm/aima_slot_l3")
            self._clients["l4"] = aima_shm_sdk.AimaPythonShmClient("/dev/shm/aima_slot_l4")
            self._core_client = aima_shm_sdk.AimaCoreStateClient("/dev/shm/aima_core_state")
            self._enabled = True
            logger.info("AIMA v5.3 工业级硬实时微内核共享内存驱动初始化成功！")
        except Exception as e:
            self._enabled = False
            logger.warning(f"未能挂载 AIMA v5.3 微内核共享内存 (将回退至 Python 传统引擎): {e}")

    def reconnect(self) -> bool:
        """
        微内核崩溃重启后或共享内存句柄失效时，重新挂载并重置所有共享内存客户端
        """
        logger.info("正在执行 AimaKernelBridge 共享内存重新连接与句柄复位...")
        self._enabled = False
        self._clients.clear()
        self._core_client = None
        self._init_sdk()
        return self._enabled

    def reset(self) -> bool:
        """reconnect 的别名"""
        return self.reconnect()

    @property
    def is_available(self) -> bool:
        return self._enabled

    def submit_layer(
        self,
        slot_name: str,
        universe: int,
        dmx_data: bytes | bytearray | list | np.ndarray,
        mask_data: Optional[bytes | bytearray | list | np.ndarray] = None
    ) -> bool:
        """
        向指定共享内存槽位 (l1/l2/l3/l4) 提交单 Universe 的 512 通道 DMX 帧与覆盖掩码
        耗时仅约 0.57µs，彻底消灭 Python 运行阻塞。
        """
        if not self._enabled:
            return False

        client = self._clients.get(slot_name.lower())
        if not client:
            return False

        try:
            # 转换为 1D uint8 numpy array (通过 np.ascontiguousarray 确保 C 内存连续)
            if not isinstance(dmx_data, np.ndarray):
                dmx_arr = np.ascontiguousarray(np.frombuffer(dmx_data[:512], dtype=np.uint8) if isinstance(dmx_data, (bytes, bytearray)) else np.array(dmx_data[:512], dtype=np.uint8))
            else:
                dmx_arr = np.ascontiguousarray(dmx_data, dtype=np.uint8)

            if len(dmx_arr) < 512:
                padded = np.zeros(512, dtype=np.uint8)
                padded[:len(dmx_arr)] = dmx_arr
                dmx_arr = padded

            mask_arr = None
            if mask_data is not None:
                if not isinstance(mask_data, np.ndarray):
                    mask_arr = np.ascontiguousarray(np.frombuffer(mask_data[:512], dtype=np.uint8) if isinstance(mask_data, (bytes, bytearray)) else np.array(mask_data[:512], dtype=np.uint8))
                else:
                    mask_arr = np.ascontiguousarray(mask_data, dtype=np.uint8)
                if len(mask_arr) < 512:
                    padded_m = np.zeros(512, dtype=np.uint8)
                    padded_m[:len(mask_arr)] = mask_arr
                    mask_arr = padded_m
                    mask_arr = padded_m

            client.write_universe(universe, dmx_arr, mask_arr)
            return True
        except Exception as e:
            logger.error(f"写入共享内存槽位 [{slot_name}] 异常: {e}")
            return False

    def read_final_merged(self) -> Optional[np.ndarray]:
        """从微内核只读状态中零拷贝读取当前 64 宇宙经过 44Hz 仲裁与安全钳位后的最终合成帧"""
        if not self._enabled or not self._core_client:
            return None
        try:
            return self._core_client.read_final_merged()
        except Exception as e:
            logger.error(f"读取微内核全局合成帧异常: {e}")
            return None

    def get_rt_metrics(self) -> Tuple[int, int, int, int]:
        """获取微内核实时运行指标: (rt_frame_index, rt_timestamp_ns, last_jitter_ns, active_universe_count)"""
        if not self._enabled or not self._core_client:
            return (0, 0, 0, 0)
        try:
            return self._core_client.get_rt_metrics()
        except Exception:
            return (0, 0, 0, 0)
