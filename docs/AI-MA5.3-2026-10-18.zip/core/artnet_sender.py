# -*- coding: utf-8 -*-
"""
工业级 Art-Net (ArtDmx) 引擎驱动模块 (带动态宏特效与时序生成器)
特性：
1. 30Hz 持续恒定输出
2. 线性平滑插值 (Crossfade)
3. 动态宏引擎 (Dynamic Macro Engine): 支持走马灯 (chase)、呼吸 (breathe)、频闪 (strobe)
"""

import socket
import struct
import threading
import time
import math

ARTNET_PORT = 6454

class IndustrialArtNetEngine:
    def __init__(self, target_ip="127.0.0.1", port=ARTNET_PORT, fps=30, broadcast=False):
        self.target_ip = target_ip
        self.port = port
        self.fps = fps
        self.frame_interval = 1.0 / fps
        self.broadcast = broadcast
        self.sequence = 0

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.broadcast:
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        self.lock = threading.Lock()
        self.current_buffers = {0: [0.0] * 512, 1: [0.0] * 512}
        self.fade_tasks = []

        # 动态宏特效状态
        self.active_effect = None # dict: {"type": "chase"|"breathe", "fixtures": [...], "speed": float, "start_time": float, "duration": float}

        self.running = True
        self.worker_thread = threading.Thread(target=self._streaming_loop, daemon=True)
        self.worker_thread.start()

    def build_artdmx_packet(self, universe: int, dmx_data: bytes) -> bytes:
        if len(dmx_data) < 512:
            dmx_data = dmx_data + b'\x00' * (512 - len(dmx_data))
        else:
            dmx_data = dmx_data[:512]

        length = len(dmx_data)
        header_id = b'Art-Net\x00'
        opcode_bytes = struct.pack('<H', 0x5000)
        protver_bytes = struct.pack('>H', 14)
        seq_phys_bytes = struct.pack('BB', self.sequence, 0)
        universe_bytes = struct.pack('<H', universe)
        length_bytes = struct.pack('>H', length)

        header = header_id + opcode_bytes + protver_bytes + seq_phys_bytes + universe_bytes + length_bytes

        self.sequence = (self.sequence + 1) % 256
        if self.sequence == 0:
            self.sequence = 1

        return header + dmx_data

    def set_channel_targets(self, targets: list, transition_ms: int = 0):
        now = time.time()
        duration_sec = max(0.0, transition_ms / 1000.0)

        with self.lock:
            # 手动设值时清除正在执行的宏
            self.active_effect = None

            for item in targets:
                u = item["universe"]
                ch = item["physical_ch"] - 1
                val = max(0, min(255, int(item["target_val"])))

                if u not in self.current_buffers:
                    self.current_buffers[u] = [0.0] * 512

                start_val = self.current_buffers[u][ch]

                if duration_sec <= 0.05:
                    self.current_buffers[u][ch] = float(val)
                    self.fade_tasks = [t for t in self.fade_tasks if not (t["u"] == u and t["ch"] == ch)]
                else:
                    self.fade_tasks = [t for t in self.fade_tasks if not (t["u"] == u and t["ch"] == ch)]
                    self.fade_tasks.append({
                        "u": u,
                        "ch": ch,
                        "start_val": start_val,
                        "target_val": float(val),
                        "start_time": now,
                        "duration_sec": duration_sec
                    })

    def start_effect(self, effect_type: str, fixtures_meta: list, duration_sec: float = 30.0, speed: float = 2.0):
        """
        启动动态宏特效 (如走马灯 chase, 呼吸 breathe)
        fixtures_meta: [
            {"id": "fix_01", "universe": 0, "dimmer_ch": 32, "x": -3.5},
            ...
        ]
        """
        # 按空间 X 坐标由左到右排序
        sorted_fixtures = sorted(fixtures_meta, key=lambda f: f.get("x", 0))
        with self.lock:
            self.fade_tasks.clear()
            self.active_effect = {
                "type": effect_type,
                "fixtures": sorted_fixtures,
                "speed": speed,
                "start_time": time.time(),
                "duration": duration_sec
            }

    def stop_effect(self):
        with self.lock:
            self.active_effect = None

    def _streaming_loop(self):
        while self.running:
            start_tick = time.time()
            now = time.time()

            with self.lock:
                # 1. 动态宏计算 (走马灯 / 呼吸等)
                if self.active_effect:
                    eff = self.active_effect
                    elapsed = now - eff["start_time"]
                    if elapsed >= eff["duration"]:
                        self.active_effect = None
                    else:
                        fx_type = eff["type"]
                        fixtures = eff["fixtures"]
                        num_fx = max(1, len(fixtures))

                        if fx_type in ["chase", "走马灯"]:
                            # 走马灯算法：高斯或正弦波沿灯具次序移动
                            cycle = (elapsed * eff["speed"]) % num_fx
                            for idx, f in enumerate(fixtures):
                                u = f["universe"]
                                ch = f["dimmer_ch"] - 1
                                # 计算与当前高亮亮点的距离
                                dist = abs(idx - cycle)
                                dist = min(dist, num_fx - dist)
                                intensity = max(0.0, 255.0 * (1.0 - dist * 1.2))
                                self.current_buffers[u][ch] = intensity

                        elif fx_type in ["breathe", "呼吸"]:
                            # 全场平滑正弦波呼吸
                            intensity = (math.sin(elapsed * eff["speed"] * math.pi) + 1.0) * 0.5 * 255.0
                            for f in fixtures:
                                u = f["universe"]
                                ch = f["dimmer_ch"] - 1
                                self.current_buffers[u][ch] = intensity

                # 2. 常规淡变平滑插值
                remaining_tasks = []
                for t in self.fade_tasks:
                    elapsed = now - t["start_time"]
                    if elapsed >= t["duration_sec"]:
                        self.current_buffers[t["u"]][t["ch"]] = t["target_val"]
                    else:
                        progress = elapsed / t["duration_sec"]
                        current_interpolated = t["start_val"] + (t["target_val"] - t["start_val"]) * progress
                        self.current_buffers[t["u"]][t["ch"]] = current_interpolated
                        remaining_tasks.append(t)
                self.fade_tasks = remaining_tasks

                # 快照当前字节流
                send_snapshots = {}
                for u, buf in self.current_buffers.items():
                    send_snapshots[u] = bytes([int(round(max(0.0, min(255.0, v)))) for v in buf])

            # 3. 发送 UDP
            for u, dmx_bytes in send_snapshots.items():
                packet = self.build_artdmx_packet(u, dmx_bytes)
                try:
                    self.sock.sendto(packet, (self.target_ip, self.port))
                except Exception:
                    pass

            elapsed_time = time.time() - start_tick
            sleep_time = self.frame_interval - elapsed_time
            if sleep_time > 0:
                time.sleep(sleep_time)

    def stop(self):
        self.running = False
        if self.worker_thread.is_alive():
            self.worker_thread.join(timeout=1.0)
        self.sock.close()
