# -*- coding: utf-8 -*-
"""
AI-MA 本地插件市场服务核心 (Plugin Marketplace Service)
提供：
1. 浏览市场全部可用插件包 (包含详细功能介绍、版本、作者、类型、参数声明)
2. 校验插件是否符合系统标准 (PluginValidator 沙箱分析)
3. 在线一键安装插件 (自动下载/写入 plugins/ 并热加载激活)
4. 自定义上传插件并进行静态合规审查
"""

import os
import sys
import json
import logging
from typing import Dict, List, Any

from plugin_sdk import (
    PluginValidator, BasePlugin, BaseProtocolPlugin,
    BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin,
)

logger = logging.getLogger("PluginMarketplace")

class PluginMarketplace:
    def __init__(self, catalog_path: str = "marketplace/plugin_catalog.json", plugins_dir: str = "plugins"):
        self.catalog_path = os.path.abspath(catalog_path)
        self.plugins_dir = os.path.abspath(plugins_dir)

    def get_market_packages(self, installed_ids: List[str] = None) -> List[Dict[str, Any]]:
        """获取市场所有插件清单，并标注本地是否已安装"""
        installed_ids = installed_ids or []
        if not os.path.exists(self.catalog_path):
            return []
        try:
            with open(self.catalog_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                pkgs = data.get("packages", [])
                for p in pkgs:
                    p["is_installed"] = p["id"] in installed_ids
                return pkgs
        except Exception as e:
            logger.error(f"读取插件市场清单异常: {e}")
            return []

    def verify_plugin_code(self, code_str: str) -> Dict[str, Any]:
        """
        在临时隔离沙箱中编译并验证待安装代码是否合规
        """
        errors = []
        warnings = []
        try:
            compiled = compile(code_str, "<market_verify>", "exec")
        except SyntaxError as se:
            return {"valid": False, "errors": [f"语法编译错误 (第 {se.lineno} 行): {se.msg}"], "warnings": []}

        # 沙箱命名空间分析
        local_scope = {}
        try:
            # 导入 SDK
            exec("from plugin_sdk import BasePlugin, BaseProtocolPlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin, PluginType, CoreContext", local_scope)
            exec(compiled, local_scope)
        except Exception as e:
            return {"valid": False, "errors": [f"插件代码执行异常: {e}"], "warnings": []}

        found_classes = []
        for k, v in local_scope.items():
            if isinstance(v, type) and issubclass(v, BasePlugin) and v not in [BasePlugin, BaseProtocolPlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin]:
                found_classes.append(v)

        if not found_classes:
            return {"valid": False, "errors": ["未在代码中找到继承自 BasePlugin 的插件实现类"], "warnings": []}

        # 实例化第一个类进行全面审查
        target_cls = found_classes[0]
        try:
            inst = target_cls()
            val_res = PluginValidator.validate_plugin_instance(inst)
            return val_res
        except Exception as e:
            return {"valid": False, "errors": [f"插件类实例化审查异常: {e}"], "warnings": []}

    def install_package(self, package_id: str, plugin_host) -> Dict[str, Any]:
        """一键从市场安装插件包到本地 plugins/ 目录并动态加载"""
        pkgs = self.get_market_packages()
        pkg = next((p for p in pkgs if p["id"] == package_id), None)
        if not pkg:
            raise KeyError(f"插件市场中不存在 ID 为 [{package_id}] 的插件")

        code = pkg.get("code", "")
        # 1. 验证合规性
        val_res = self.verify_plugin_code(code)
        if not val_res["valid"]:
            return {"status": "error", "message": "插件未通过合规审查", "details": val_res["errors"]}

        # 2. 写入目标目录
        subfolder = pkg.get("target_subfolder", "macros")
        target_dir = os.path.join(self.plugins_dir, subfolder)
        os.makedirs(target_dir, exist_ok=True)
        fname = pkg.get("filename", f"{package_id}.py")
        file_path = os.path.join(target_dir, fname)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code)

        # 3. 动态热装载进 PluginHost
        mod_name = f"{subfolder}.{os.path.splitext(fname)[0]}"
        inst = plugin_host.load_plugin_from_file(file_path, mod_name)
        if not inst:
            return {"status": "error", "message": "插件写入成功，但在装载激活阶段失败"}

        logger.info(f"插件 [{pkg['name']}] (ID: {package_id}) 已从市场成功安装并激活！")
        return {"status": "ok", "message": f"插件 [{pkg['name']}] 安装并启用成功", "plugin_info": inst.get_info()}
