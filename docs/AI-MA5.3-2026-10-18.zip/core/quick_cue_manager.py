# -*- coding: utf-8 -*-
"""
AI-MA 快捷场景管理引擎 (Quick Cue Manager v4.0 - Execution-Ready JSON Storage)
核心设计：
1. 存储的是最终执行级的 Cue/Sequence JSON 数据（包括 mode, transition_ms, fixtures 通道电平等），
   触发时 0 毫秒直通底层 DMX 引擎，彻底不走大模型。
2. 创建与维护完全在独立管理标签页中进行：
   - 方式 A: 直接手动粘贴/编辑执行级 JSON
   - 方式 B: 本地 Qwen 2.5-7B 大模型辅助转换（仅在创建阶段运行一次，将自然语言编译为确定性 JSON 存入）
3. 移除了主界面的修改/删除按钮，杜绝现场误触。
"""

import os
import sys
import json
import uuid
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger("QuickCueManager")

# 出厂预设纯执行级 JSON 场景 (零延迟直通底层 DMX)
DEFAULT_EXECUTION_SCENES = [
    {
        "id": "scene_warm_gold",
        "name": "暖阳金",
        "color": "#f59e0b",
        "icon": "fa-sun",
        "desc": "舞台左前面光暖金色慢推",
        "payload": {
            "mode": "single",
            "transition_ms": 3000,
            "fixtures": [
                {
                    "id": "fix_01",
                    "channels": {
                        "dimmer": 255,
                        "red": 255,
                        "green": 190,
                        "blue": 80,
                        "white": 100
                    }
                }
            ]
        }
    },
    {
        "id": "scene_cyberpunk",
        "name": "赛博朋克",
        "color": "#06b6d4",
        "icon": "fa-bolt",
        "desc": "科技冷艳青蓝高光",
        "payload": {
            "mode": "single",
            "transition_ms": 1000,
            "fixtures": [
                {
                    "id": "fix_01",
                    "channels": {
                        "dimmer": 255,
                        "red": 0,
                        "green": 240,
                        "blue": 255,
                        "white": 0
                    }
                },
                {
                    "id": "fix_02",
                    "channels": {
                        "dimmer": 255,
                        "red": 255,
                        "green": 0,
                        "blue": 180,
                        "white": 0
                    }
                }
            ]
        }
    },
    {
        "id": "scene_rock_red",
        "name": "热烈摇滚红",
        "color": "#ef4444",
        "icon": "fa-fire",
        "desc": "全场红光高能爆发",
        "payload": {
            "mode": "single",
            "transition_ms": 500,
            "fixtures": [
                {
                    "id": "fix_01",
                    "channels": {
                        "dimmer": 255,
                        "red": 255,
                        "green": 0,
                        "blue": 0,
                        "white": 0
                    }
                },
                {
                    "id": "fix_02",
                    "channels": {
                        "dimmer": 255,
                        "red": 255,
                        "green": 0,
                        "blue": 0,
                        "white": 0
                    }
                }
            ]
        }
    },
    {
        "id": "scene_blackout_slow",
        "name": "全场平滑熄灯",
        "color": "#64748b",
        "icon": "fa-moon",
        "desc": "全场灯具在2秒内暗下",
        "payload": {
            "mode": "single",
            "transition_ms": 2000,
            "fixtures": [
                {
                    "id": "fix_01",
                    "channels": {
                        "dimmer": 0,
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "white": 0
                    }
                },
                {
                    "id": "fix_02",
                    "channels": {
                        "dimmer": 0,
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "white": 0
                    }
                }
            ]
        }
    }
]

class QuickCueManager:
    def __init__(self, config_path: str = "config/quick_scenes.json"):
        self.config_path = os.path.abspath(config_path)
        self.scenes = self._load_scenes()

    def _load_scenes(self) -> List[Dict[str, Any]]:
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # 兼容性检查：若旧版保存的是纯 string command，则重置为标准化 payload 格式
                    if data and isinstance(data, list) and "payload" in data[0]:
                        return data
            except Exception as e:
                logger.error(f"读取快捷场景配置文件失败: {e}")
        # 保存默认出厂场景
        self._save_scenes(DEFAULT_EXECUTION_SCENES)
        return list(DEFAULT_EXECUTION_SCENES)

    def _save_scenes(self, scenes_list: List[Dict[str, Any]]):
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(scenes_list, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存快捷场景失败: {e}")

    def get_all_scenes(self) -> List[Dict[str, Any]]:
        return self.scenes

    def save_scene(self, scene_data: Dict[str, Any]) -> Dict[str, Any]:
        """新增或更新快捷场景 (必须包含 payload 结构)"""
        sid = scene_data.get("id")
        if not sid:
            sid = "scene_" + uuid.uuid4().hex[:8]
            scene_data["id"] = sid

        # 确保 payload 为合法 dict 结构
        payload = scene_data.get("payload")
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
                scene_data["payload"] = payload
            except Exception as e:
                raise ValueError(f"Payload 必须是合法的 JSON 对象: {e}")

        found = False
        for idx, s in enumerate(self.scenes):
            if s["id"] == sid:
                self.scenes[idx] = scene_data
                found = True
                break
        if not found:
            self.scenes.append(scene_data)

        self._save_scenes(self.scenes)
        logger.info(f"快捷场景已保存: [{scene_data.get('name')}] (ID: {sid})")
        return scene_data

    def delete_scene(self, scene_id: str) -> bool:
        """删除指定快捷场景"""
        self.scenes = [s for s in self.scenes if s["id"] != scene_id]
        self._save_scenes(self.scenes)
        logger.info(f"快捷场景已删除: [{scene_id}]")
        return True

    def ai_assist_generate_scene(self, user_idea: str, kb_manager, llm_plugin) -> Dict[str, Any]:
        """
        在独立管理面板中使用本地大模型辅助生成：
        结合当前场地拓扑白名单与美学知识库，生成包含确定性 payload 的完整快捷场景对象。
        """
        if not llm_plugin:
            raise RuntimeError("大语言模型插件未启用，无法进行 AI 场景提炼")

        fixtures_context, preset_hint = kb_manager.retrieve_context(user_idea)

        system_prompt = f"""你是一个顶级舞台灯光设计师与控制工程师。
请将用户的灯光场景想法，编译为一个确定性的执行级快捷场景 JSON 数据包。

【当前舞台可用灯具与白名单通道】:
{json.dumps(fixtures_context, ensure_ascii=False, indent=2)}

【美学知识库参考】:
{json.dumps(preset_hint, ensure_ascii=False, indent=2) if preset_hint else "无预设，请推导专业通道参数"}

请严格输出为以下纯 JSON 结构（严禁包含任何 markdown 代码块或解释说明文字）：
{{
  "name": "简明按钮名 (2-5个汉字，如: 极光幽蓝)",
  "color": "推荐 Hex 颜色 (如: #0ea5e9)",
  "icon": "推荐 FontAwesome 图标 (如: fa-snowflake, fa-sun, fa-fire, fa-bolt, fa-moon)",
  "desc": "设计描述 (15字以内)",
  "payload": {{
    "mode": "single",
    "transition_ms": 1500,
    "fixtures": [
      {{
        "id": "fix_01",
        "channels": {{"dimmer": 255, "red": 0, "green": 200, "blue": 255}}
      }}
    ]
  }}
}}
注意：
1. 严禁控制未被白名单授权的通道！
2. payload 必须是系统可直接驱动 DMX 引擎执行的标准结构！"""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"用户场景构想: {user_idea}"}
        ]
        raw_res = llm_plugin.chat_completion(messages)
        cleaned = raw_res.strip()
        if "```json" in cleaned:
            cleaned = cleaned.split("```json")[1].split("```")[0].strip()
        elif "```" in cleaned:
            cleaned = cleaned.split("```")[1].split("```")[0].strip()

        parsed = json.loads(cleaned)
        parsed["id"] = "scene_ai_" + uuid.uuid4().hex[:8]
        return parsed
