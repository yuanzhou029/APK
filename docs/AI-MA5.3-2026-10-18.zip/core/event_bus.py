# -*- coding: utf-8 -*-
"""
AI-MA 线程安全发布/订阅事件总线 (EventBus)
解耦各层通信，支持同步与异步事件广播。
"""

import threading
import logging
from typing import Callable, Dict, List, Any

logger = logging.getLogger("EventBus")

class SystemEvents:
    # 核心系统事件
    SYSTEM_STARTED = "system.started"
    SYSTEM_STOPPING = "system.stopping"
    
    # 灯光控制与时序事件
    CUE_TRIGGERED = "lighting.cue_triggered"
    SEQUENCE_STARTED = "lighting.sequence_started"
    SEQUENCE_STEP = "lighting.sequence_step"
    SEQUENCE_FINISHED = "lighting.sequence_finished"
    
    # 仲裁与输出
    DMX_FRAME_OUTPUT = "lighting.dmx_frame_output"
    PANIC_BLACKOUT = "lighting.panic_blackout"
    
    # 感知与外部信号
    BEAT_TICK = "perception.beat_tick"
    TRACKING_UPDATE = "perception.tracking_update"
    MA_FADER_MOVED = "desk.fader_moved"

class EventBus:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Any], None]]] = {}
        self._lock = threading.RLock()

    def subscribe(self, event_type: str, callback: Callable[[Any], None]):
        """订阅指定类型的事件"""
        with self._lock:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []
            if callback not in self._subscribers[event_type]:
                self._subscribers[event_type].append(callback)
                logger.debug(f"Subscriber registered for [{event_type}]: {callback.__name__ if hasattr(callback, '__name__') else callback}")

    def unsubscribe(self, event_type: str, callback: Callable[[Any], None]):
        """取消订阅"""
        with self._lock:
            if event_type in self._subscribers and callback in self._subscribers[event_type]:
                self._subscribers[event_type].remove(callback)

    def publish(self, event_type: str, data: Any = None):
        """同步发布事件到所有监听者"""
        handlers = []
        with self._lock:
            if event_type in self._subscribers:
                handlers = list(self._subscribers[event_type])

        for handler in handlers:
            try:
                handler(data)
            except Exception as e:
                logger.error(f"Error executing event handler {handler} for event [{event_type}]: {e}", exc_info=True)

    def publish_async(self, event_type: str, data: Any = None):
        """异步线程发布事件（用于非阻塞耗时通知）"""
        t = threading.Thread(target=self.publish, args=(event_type, data), daemon=True)
        t.start()
