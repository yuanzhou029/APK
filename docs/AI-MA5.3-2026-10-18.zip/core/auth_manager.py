# -*- coding: utf-8 -*-
"""
AI-MA 生产级企业 RBAC 权限与会话鉴权管理器 (Authentication & RBAC Manager)
提供基于 PBKDF2-HMAC-SHA256 的密码哈希加盐、UUID Token 签发、会话超时与角色权限分级校验。
"""

import os
import json
import time
import uuid
import hashlib
import hmac
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("AuthManager")

EMERGENCY_ROOT_SEED = os.environ.get("AURA_ROOT_SEED", "AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026")

class Role:
    SUPERADMIN = "superadmin" # 系统超级维护者 (root 拥有最高底层权限)
    ADMIN = "admin"          # 系统主管理员 (全权控制、知识库与插件运维、用户管理)
    ENGINEER = "engineer"    # 主控灯光师 (可调光、控场、编排、修改预设)
    VIEWER = "viewer"        # 现场观察员 (只读查看看板、日志与 DMX 监视)

ROLE_PERMISSIONS = {
    Role.SUPERADMIN: ["manage_users", "manage_backups", "view_dashboard", "operate_lights", "edit_kb", "panic_control", "manage_plugins", "system_config", "view_logs"],
    Role.ADMIN: ["manage_users", "manage_backups", "view_dashboard", "operate_lights", "edit_kb", "panic_control", "manage_plugins", "system_config", "view_logs"],
    Role.ENGINEER: ["manage_backups", "view_dashboard", "operate_lights", "edit_kb", "panic_control", "view_logs"],
    Role.VIEWER: ["view_dashboard", "view_logs"]
}

class AuthManager:
    def __init__(self, user_db_path: str = "config/users.json"):
        self.user_db_path = user_db_path
        self.users: Dict[str, Dict[str, Any]] = {}
        self.active_sessions: Dict[str, Dict[str, Any]] = {} # {token: {"username": ..., "role": ..., "expire_at": ...}}
        self.session_ttl_sec = 24 * 3600 # 24 小时有效
        self._load_users()

    def _hash_password(self, password: str, salt: str) -> str:
        """PBKDF2-HMAC-SHA256 高强度哈希计算"""
        return hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            100000
        ).hex()

    def generate_emergency_key(self, date_str: Optional[str] = None) -> str:
        """
        基于固定字符密钥 + 系统日期计算 32 位 Hex 动态准入 Key。
        Debian Linux 生成命令示例:
        echo -n "AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026:$(date +%F)" | md5sum | cut -d' ' -f1
        """
        if not date_str:
            date_str = time.strftime("%Y-%m-%d")
        raw = f"{EMERGENCY_ROOT_SEED}:{date_str}"
        return hashlib.md5(raw.encode("utf-8")).hexdigest()

    def verify_emergency_key(self, key: str) -> bool:
        """校验动态 Key 是否匹配 (支持当天以及前后跨日容错)"""
        if not key or len(key.strip()) != 32:
            return False
        cleaned_key = key.strip().lower()
        # 检验当天
        if hmac.compare_digest(cleaned_key, self.generate_emergency_key()):
            return True
        # 兼容跨日时间差 (前后 1 天容错)
        now = time.time()
        yesterday = time.strftime("%Y-%m-%d", time.localtime(now - 86400))
        tomorrow = time.strftime("%Y-%m-%d", time.localtime(now + 86400))
        if hmac.compare_digest(cleaned_key, self.generate_emergency_key(yesterday)):
            return True
        if hmac.compare_digest(cleaned_key, self.generate_emergency_key(tomorrow)):
            return True
        return False

    def authenticate_emergency_root(self, key: str) -> Optional[Dict[str, Any]]:
        """通过动态 32 位 hex key 紧急签发 root 最高权限会话"""
        if not self.verify_emergency_key(key):
            logger.warning("动态应急 Key 校验失败，拒绝签发 root 权限！")
            return None

        # 确保 root 用户存在于数据库
        if "root" not in self.users:
            salt = uuid.uuid4().hex
            self.users["root"] = {
                "role": Role.SUPERADMIN,
                "salt": salt,
                "password_hash": self._hash_password(uuid.uuid4().hex, salt),
                "display_name": "系统底层维护者 (root)",
                "is_system_root": True
            }
            self._save_users()

        token = "root_emerg_" + uuid.uuid4().hex
        session_info = {
            "token": token,
            "username": "root",
            "display_name": "底层架构维护者 (root)",
            "role": Role.SUPERADMIN,
            "permissions": ROLE_PERMISSIONS[Role.SUPERADMIN],
            "is_emergency_root": True,
            "expire_at": time.time() + self.session_ttl_sec
        }
        self.active_sessions[token] = session_info
        logger.warning(f"!!! 触发底层维护者动态 Key 应急认证：成功签发 root 最高特权会话 [{token[:16]}...] !!!")
        return session_info

    def _load_users(self):
        """加载或初始化默认用户数据库"""
        if os.path.exists(self.user_db_path):
            try:
                with open(self.user_db_path, "r", encoding="utf-8") as f:
                    self.users = json.load(f)
                    # 确保具备主管理员标识和 root 底层标记
                    has_admin = False
                    for u, data in self.users.items():
                        if data.get("is_primary_admin") or data.get("role") in [Role.ADMIN, Role.SUPERADMIN] and u != "root":
                            data["is_primary_admin"] = True
                            has_admin = True
                            break
                    if not has_admin and "admin" in self.users:
                        self.users["admin"]["is_primary_admin"] = True
                    if "root" in self.users:
                        self.users["root"]["is_system_root"] = True
                        self.users["root"]["role"] = Role.SUPERADMIN
                    return
            except Exception as e:
                logger.error(f"读取用户数据异常: {e}")

        # 若不存在则创建默认出厂账户：
        # admin 为系统主管理员 (可修改账号名和密码，不可删除)
        # root 为系统底层维护者 (隐藏，通过动态 32 位 Hex Key 应急激活)
        os.makedirs(os.path.dirname(self.user_db_path) or ".", exist_ok=True)
        self.users = {
            "root": {
                "role": Role.SUPERADMIN,
                "salt": uuid.uuid4().hex,
                "password_hash": "",
                "display_name": "系统底层维护者 (root)",
                "is_system_root": True
            },
            "admin": {
                "role": Role.ADMIN,
                "salt": uuid.uuid4().hex,
                "password_hash": "",
                "display_name": "系统主管理员",
                "is_primary_admin": True
            },
            "engineer": {
                "role": Role.ENGINEER,
                "salt": uuid.uuid4().hex,
                "password_hash": "",
                "display_name": "主控灯光师"
            },
            "guest": {
                "role": Role.VIEWER,
                "salt": uuid.uuid4().hex,
                "password_hash": "",
                "display_name": "现场观察员"
            }
        }
        # 默认出厂密码设置: root -> 随机安全哈希, admin -> admin123, engineer -> 123456, guest -> guest
        self.users["root"]["password_hash"] = self._hash_password(uuid.uuid4().hex, self.users["root"]["salt"])
        self.users["admin"]["password_hash"] = self._hash_password("admin123", self.users["admin"]["salt"])
        self.users["engineer"]["password_hash"] = self._hash_password("123456", self.users["engineer"]["salt"])
        self.users["guest"]["password_hash"] = self._hash_password("guest", self.users["guest"]["salt"])
        self._save_users()
        logger.info("已生成出厂默认 RBAC 用户凭据库 (系统主管理员 admin + 底层维护者 root)。")

    def _save_users(self):
        try:
            with open(self.user_db_path, "w", encoding="utf-8") as f:
                json.dump(self.users, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存用户数据失败: {e}")

    def authenticate(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        """用户登录校验，成功则返回带有时效的 Session 凭证"""
        user = self.users.get(username)
        if not user:
            logger.warning(f"鉴权失败：用户名不存在 [{username}]")
            return None

        computed_hash = self._hash_password(password, user["salt"])
        if not hmac.compare_digest(computed_hash, user["password_hash"]):
            logger.warning(f"鉴权失败：密码错误 [{username}]")
            return None

        # 签发 Session Token
        token = "token_" + uuid.uuid4().hex
        session_info = {
            "token": token,
            "username": username,
            "display_name": user.get("display_name", username),
            "role": user["role"],
            "permissions": ROLE_PERMISSIONS.get(user["role"], []),
            "expire_at": time.time() + self.session_ttl_sec
        }
        self.active_sessions[token] = session_info
        logger.info(f"用户 [{username}] 成功登录，分配角色: [{user['role']}]")
        return session_info

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """校验 Token 是否有效且未过期"""
        if not token:
            return None
        session = self.active_sessions.get(token)
        if not session:
            return None
        if time.time() > session["expire_at"]:
            del self.active_sessions[token]
            logger.info(f"会话凭证已过期: {token[:12]}...")
            return None
        return session

    def check_permission(self, token: str, required_perm: str) -> bool:
        """检查会话是否具有特定业务权限"""
        session = self.verify_token(token)
        if not session:
            return False
        # 超级管理员具有全权穿透权限
        if session.get("role") == Role.SUPERADMIN:
            return True
        perms = session.get("permissions", [])
        return required_perm in perms

    def list_users(self) -> Dict[str, Any]:
        """获取用户列表 (脱敏输出，严格隐藏系统底层维护者 root)"""
        res = []
        for u, data in self.users.items():
            # 严格隐藏系统底层维护者 root (不到万不得已不启用，不对普通操作台暴露)
            if u == "root" or data.get("is_system_root"):
                continue
            res.append({
                "username": u,
                "role": data.get("role", Role.VIEWER),
                "display_name": data.get("display_name", u),
                "is_superadmin": False, # 对外统一呈现业务管理员及子用户
                "is_primary_admin": bool(data.get("is_primary_admin")),
                "has_custom_profile": bool(data.get("profile_data"))
            })
        return {"users": res}

    def rename_admin(self, old_username: str, new_username: str) -> Dict[str, Any]:
        """修改管理员账号名称 (支持用户自行设定管理员的账号名，不可删除)"""
        old_u = (old_username or "").strip().lower()
        new_u = (new_username or "").strip().lower()
        if not new_u or len(new_u) < 2:
            raise ValueError("新管理员账号名至少需要 2 个字符")
        if old_u not in self.users:
            raise ValueError(f"原管理员账号 [{old_u}] 不存在")
        if not self.users[old_u].get("is_primary_admin"):
            raise ValueError(f"账号 [{old_u}] 不是系统主管理员，仅主管理员支持全局更名重命名")
        if new_u != old_u and new_u in self.users:
            raise ValueError(f"账号名 [{new_u}] 已被占用，请更换其他名称")

        if new_u != old_u:
            user_data = self.users.pop(old_u)
            user_data["is_primary_admin"] = True
            if user_data.get("display_name") == old_u:
                user_data["display_name"] = new_u
            self.users[new_u] = user_data
            # 同步更新存活 Session
            for s in self.active_sessions.values():
                if s.get("username") == old_u:
                    s["username"] = new_u
            self._save_users()
            logger.info(f"系统主管理员账号已成功更名: [{old_u}] -> [{new_u}]")
        return {"status": "ok", "message": f"管理员账号名已成功修改为 [{new_u}]", "new_username": new_u}

    def change_password(self, username: str, new_password: str) -> Dict[str, Any]:
        """修改指定用户的安全密码 (支持主管理员及普通用户自行修改密码)"""
        u = (username or "").strip().lower()
        if u not in self.users:
            raise ValueError(f"用户 [{u}] 不存在")
        if not new_password or len(new_password) < 4:
            raise ValueError("新密码长度不能少于 4 位字符")

        salt = uuid.uuid4().hex
        self.users[u]["salt"] = salt
        self.users[u]["password_hash"] = self._hash_password(new_password, salt)
        self._save_users()
        logger.info(f"用户 [{u}] 密码已成功更新")
        return {"status": "ok", "message": f"用户 [{u}] 密码修改成功"}

    def add_or_update_user(self, username: str, role: str, password: Optional[str] = None, display_name: Optional[str] = None) -> Dict[str, Any]:
        """管理员添加或修改用户配置"""
        username = (username or "").strip().lower()
        if not username:
            raise ValueError("用户名不能为空")
        valid_roles = [Role.ADMIN, Role.ENGINEER, Role.VIEWER]
        if role not in valid_roles and role != Role.SUPERADMIN:
            raise ValueError(f"角色无效，支持角色: 管理员(admin)、灯光师(engineer)、观察员(viewer)")

        if username not in self.users:
            if not password:
                raise ValueError("新建用户必须指定初始密码")
            salt = uuid.uuid4().hex
            self.users[username] = {
                "role": role,
                "salt": salt,
                "password_hash": self._hash_password(password, salt),
                "display_name": (display_name or username).strip(),
                "created_at": time.time(),
                "profile_data": {} # 独立空白设置槽位
            }
        else:
            # 更新已有用户
            user = self.users[username]
            # 若为主管理员，角色固定为 ADMIN 且不可降权
            if user.get("is_primary_admin"):
                user["role"] = Role.ADMIN
            else:
                user["role"] = role
            if display_name:
                user["display_name"] = display_name.strip()
            if password:
                user["salt"] = uuid.uuid4().hex
                user["password_hash"] = self._hash_password(password, user["salt"])

        self._save_users()
        logger.info(f"用户配置已更新: [{username}] 角色={role}")
        return {"status": "ok", "message": f"用户 [{username}] 配置已保存"}

    def delete_user(self, username: str) -> Dict[str, Any]:
        """删除用户 (禁止删除 root 与系统主管理员账号)"""
        username = (username or "").strip().lower()
        if username == "root" or self.users.get(username, {}).get("is_system_root"):
            raise ValueError("系统底层维护者 [root] 受最高保护，禁止删除")
        if self.users.get(username, {}).get("is_primary_admin"):
            raise ValueError("系统主管理员账号受保护，不可从系统中删除！")
        if username not in self.users:
            raise ValueError(f"用户 [{username}] 不存在")
        del self.users[username]
        self._save_users()
        logger.info(f"用户已删除: [{username}]")
        return {"status": "ok", "message": f"用户 [{username}] 已安全删除"}

    def get_user_profile(self, username: str) -> Dict[str, Any]:
        """获取指定用户的专属设置配置"""
        user = self.users.get(username)
        if not user:
            return {}
        return user.get("profile_data", {})

    def save_user_profile(self, username: str, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """保存用户的专属设置配置 (面板、偏好、工作区)"""
        user = self.users.get(username)
        if not user:
            raise ValueError(f"用户 [{username}] 不存在")
        user["profile_data"] = profile_data or {}
        self._save_users()
        return {"status": "ok", "message": f"用户 [{username}] 专属设置已更新"}
