# -*- coding: utf-8 -*-
"""
AI-MA 离线独立运行模拟宿主 (MockHost v1.0)
为开发者与 CLI 工具链提供离线无真实微内核/无硬件 DMX 环境下的沙盒运行能力。
支持：
1. 虚拟 4 宇宙 2048 通道 DMX 帧注入与输出抓取
2. 模拟音频节拍 (BPM) 与感知输入
3. 性能门禁探针 (Performance Probe):
   - 单帧耗时采样
   - 连续 5 次 > 4.0ms 自动降级停用，并记录 ERR-PLUGIN-PERF-VIOLATION
   - 内存增量统计
"""

import time
import os
import sys
import tracemalloc
import logging
from typing import Dict, Any, List, Optional, Callable

# 保证 core 模块能被导入
CORE_DIR = os.path.dirname(os.path.abspath(__file__))
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from plugin_sdk import (
    BasePlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseCreativePlugin,
    BaseAdapterPlugin, BaseTransportPlugin, BaseProtocolPlugin,
    CoreContext, ServiceBroker, EventHub, ReadOnlyStateMirror, PluginTier
)
from diagnostics_logger import log_diagnostic_error

logger = logging.getLogger("MockHost")


class MockPerformanceProbe:
    """性能门禁探针：统计单帧渲染耗时、超标熔断与内存泄漏指标"""
    def __init__(self, warn_threshold_ms: float = 3.5, trip_threshold_ms: float = 4.0, max_consecutive_violations: int = 5):
        self.warn_threshold_ms = warn_threshold_ms
        self.trip_threshold_ms = trip_threshold_ms
        self.max_consecutive_violations = max_consecutive_violations
        self.consecutive_violations = 0
        self.is_tripped = False
        self.frame_durations_ms: List[float] = []
        self.violations_record: List[Dict[str, Any]] = []

    def record_frame(self, duration_ms: float, plugin_id: str) -> bool:
        """
        记录单帧耗时。
        当单帧渲染耗时连续 max_consecutive_violations (默认 5 次) 超过 trip_threshold_ms (4.0ms) 时，
        返回 False (表示触发熔断降级)。
        """
        self.frame_durations_ms.append(duration_ms)
        if duration_ms > self.trip_threshold_ms:
            self.consecutive_violations += 1
            if self.consecutive_violations >= self.max_consecutive_violations:
                self.is_tripped = True
                self.violations_record.append({
                    "plugin_id": plugin_id,
                    "consecutive": self.consecutive_violations,
                    "last_duration_ms": duration_ms,
                    "action": "degrade_and_disable"
                })
                return False
        else:
            self.consecutive_violations = 0
        return True


class MockHost:
    """离线模拟宿主环境"""
    def __init__(self, universe_count: int = 4):
        self.universe_count = universe_count
        self.service_broker = ServiceBroker()
        self.event_hub = EventHub()
        self.state_mirror = ReadOnlyStateMirror()
        
        # 4 宇宙 * 512 通道 DMX 虚拟帧存储
        self.virtual_dmx = [bytearray(512) for _ in range(universe_count)]
        
        self.context = CoreContext(
            event_bus=None,
            dmx_merger=None,
            kb_manager=None,
            config={"mock_mode": True},
            service_broker=self.service_broker,
            event_hub=self.event_hub,
            state_mirror=self.state_mirror
        )
        self._plugins: Dict[str, BasePlugin] = {}
        self._probes: Dict[str, MockPerformanceProbe] = {}
        self.logs: List[str] = []

    @property
    def virtual_dmx_memory(self) -> bytearray:
        """平铺 4 宇宙 2048 通道连续虚拟内存视图"""
        flat = bytearray(self.universe_count * 512)
        for u in range(self.universe_count):
            flat[u*512:(u+1)*512] = self.virtual_dmx[u]
        return flat

    def simulate_frame(self, plugin_id: str, elapsed_ms: float = 22.7, current_frame: Optional[bytearray] = None) -> Optional[bytearray]:
        """单帧离线仿真推演"""
        plugin = self._plugins.get(plugin_id)
        if not plugin or not plugin.is_enabled:
            return None
        frame = current_frame if current_frame is not None else bytearray(512)
        if hasattr(plugin, "render"):
            return plugin.render(elapsed_ms, {}, frame)
        return frame

    def load_plugin(self, plugin: BasePlugin) -> bool:
        """加载插件进离线沙盒并初始化"""
        info = plugin.get_info()
        pid = info.get("id", plugin.__class__.__name__)
        ok = plugin.on_init(self.context)
        if not ok:
            return False
        plugin.set_enabled(True)
        self._plugins[pid] = plugin
        self._probes[pid] = MockPerformanceProbe()
        return True

    def inject_virtual_input(self, universe: int, channel: int, value: int):
        """模拟 DMX 输入注入 (0-index)"""
        if 0 <= universe < self.universe_count and 0 <= channel < 512:
            self.virtual_dmx[universe][channel] = max(0, min(255, value))
            # 更新状态只读镜像
            flat_buf = bytearray(64 * 512)
            for u in range(self.universe_count):
                flat_buf[u*512:(u+1)*512] = self.virtual_dmx[u]
            self.state_mirror.update_snapshot(flat_buf)

    def trigger_mock_beat(self, bpm: float = 120.0, beat_index: int = 0):
        """模拟发布音频感知节拍事件"""
        self.event_hub.publish("perception.beat_tick", "mock_host", {"bpm": bpm, "beat_index": beat_index})

    def run_benchmark(self, plugin_id: str, frames: int = 100, frame_interval_ms: float = 22.7) -> Dict[str, Any]:
        """
        执行离线 Mock 压力测试与性能基准评测。
        AC-3.2: 模拟 4 宇宙 2048 通道 DMX 输入，并正确采样插件输出。
        AC-3.3: 当插件单帧渲染耗时连续 5 次超过 4.0ms 时，性能探针自动将其降级停用，并登记 ERR-PLUGIN-PERF-VIOLATION。
        """
        plugin = self._plugins.get(plugin_id)
        probe = self._probes.get(plugin_id)
        if not plugin or not probe:
            raise KeyError(f"插件 [{plugin_id}] 未在 Mock 沙盒中就绪")

        tracemalloc.start()
        mem_before, _ = tracemalloc.get_traced_memory()

        output_frames = []
        elapsed_total = 0.0
        degraded = False

        for i in range(frames):
            if not plugin.is_enabled:
                degraded = True
                break

            # 模拟时钟推进
            elapsed_total += frame_interval_ms
            
            t_start = time.perf_counter()
            # 若为宏插件则调用 render
            if isinstance(plugin, BaseMacroPlugin):
                current_frame = bytearray(self.virtual_dmx[0])
                new_frame = plugin.render(elapsed_total, plugin.get_config(), current_frame)
                t_end = time.perf_counter()
                frame_time_ms = (t_end - t_start) * 1000.0
                output_frames.append(list(new_frame[:16]))  # 采样前16通道
            else:
                # 普通插件空转或处理
                time.sleep(0.0001)
                t_end = time.perf_counter()
                frame_time_ms = (t_end - t_start) * 1000.0

            # 性能门禁采样
            can_continue = probe.record_frame(frame_time_ms, plugin_id)
            if not can_continue:
                # 连续超标，触发性能门禁熔断降级
                plugin.set_enabled(False)
                degraded = True
                log_diagnostic_error(logger, "ERR-PLUGIN-PERF-VIOLATION", f"插件 [{plugin_id}] 连续超标熔断已停用")
                break

        mem_after, _ = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        mem_delta_kb = (mem_after - mem_before) / 1024.0
        durations = probe.frame_durations_ms

        return {
            "plugin_id": plugin_id,
            "total_frames_executed": len(durations),
            "target_frames": frames,
            "avg_frame_time_ms": (sum(durations) / len(durations)) if durations else 0.0,
            "max_frame_time_ms": max(durations) if durations else 0.0,
            "min_frame_time_ms": min(durations) if durations else 0.0,
            "memory_delta_kb": mem_delta_kb,
            "degraded_by_probe": degraded,
            "consecutive_violations": probe.consecutive_violations,
            "violations_count": len(probe.violations_record),
            "sampled_output": output_frames[:5]
        }
