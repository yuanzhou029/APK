# -*- coding: utf-8 -*-
"""
AI-MA 三层 RAG 知识库统一服务层 (Knowledge Base Service v3.0)

统一承载：
  - 第一层 物理灯库 Profiles : 通道定义、危险通道安全标记、取值范围(range)与枚举档位(slots)
  - 第二层 场地空间拓扑 Venues: 四层节点树 解码器→接口→灯具→通道、端口自定义序号、
                               通道冲突碰撞检测、工作场地热切换
  - 第三层 艺术美学预设 Presets: 通道属性驱动的内容模型、完全自定义分类、属性分组
  - AI 辅助                  : 灯具说明书智能解析为结构化灯库
  - RAG 语义实测             : 自然语言 → 命中灯具白名单 + 美学预设建议

关键设计约束（务必遵守）：
  1. 场地文件以 `nodes[]` 为唯一事实来源，同时**派生出扁平 `fixtures[]` 写回文件**，
     使得引擎侧 kb_manager 与全部既有逻辑零改动即可继续工作。
  2. 预设以 `channel_values` 为唯一事实来源，同时**派生 `suggested_channels` 与 `desc`**，
     保证 RAG 检索链路完全向后兼容。
  3. 每条预设**强制归属**某个分类，缺失即拒绝保存。
  4. 所有写操作完成后回调 kb_manager 热重载，运行中的灯光引擎立即生效。
"""

import os
import io
import re
import base64
import json
import glob
import threading
import logging
from typing import Dict, List, Any, Optional, Tuple

logger = logging.getLogger("KnowledgeBaseService")

# ---------------------------------------------------------------------------
# 出厂预置：四组属性分组（用户可改、可增删、可拖动属性归组）
# ---------------------------------------------------------------------------
DEFAULT_ATTRIBUTE_GROUPS = {
    "groups": [
        {"id": "ag_intensity", "name": "亮度", "color": "#38bdf8",
         "attrs": ["dimmer", "intensity", "strobe", "shutter", "control"]},
        {"id": "ag_color", "name": "颜色", "color": "#f43f5e",
         "attrs": ["red", "green", "blue", "white", "cct", "ctc",
                   "cyan", "magenta", "yellow", "color_wheel"]},
        {"id": "ag_beam", "name": "光束", "color": "#f59e0b",
         "attrs": ["zoom", "focus", "iris", "frost", "prism", "prism_rot", "prism_rotate"]},
        {"id": "ag_gobo", "name": "图案", "color": "#6366f1",
         "attrs": ["gobo", "gobo_rotate", "gobo2", "gobo2_rotate"]},
    ]
}

# 初始分类（用户可自由增删改；既有预设全部归入此分类，由用户再行拆分）
DEFAULT_CATEGORIES = {
    "categories": [
        {"id": "cat_general", "name": "常规", "color": "#38bdf8", "order": 0,
         "icon": {"mode": "none", "builtin": "", "upload": "", "align": "inline"}}
    ]
}

CATEGORY_ICON_MODES = ("none", "builtin", "upload")


class KnowledgeBaseService:
    """线程安全的四层知识库服务"""

    def __init__(self, kb_root: str, kb_manager: Any = None):
        self.kb_root = os.path.abspath(kb_root)
        self.profiles_dir = os.path.join(self.kb_root, "profiles")
        self.venues_dir = os.path.join(self.kb_root, "venues")
        self.presets_dir = os.path.join(self.kb_root, "presets")

        self.preset_file = os.path.join(self.presets_dir, "aesthetic_presets.json")
        self.categories_file = os.path.join(self.presets_dir, "_categories.json")
        self.attr_groups_file = os.path.join(self.presets_dir, "_attribute_groups.json")

        self.kb_manager = kb_manager
        self.active_venue_file = "venue_livehouse_hall_a.json"
        self.lock = threading.RLock()

        for d in (self.profiles_dir, self.venues_dir, self.presets_dir):
            os.makedirs(d, exist_ok=True)

        self._ensure_seed_files()

        if not os.path.exists(os.path.join(self.venues_dir, self.active_venue_file)):
            candidates = sorted(glob.glob(os.path.join(self.venues_dir, "*.json")))
            if candidates:
                self.active_venue_file = os.path.basename(candidates[0])

    def _ensure_seed_files(self):
        """首次运行时落盘分类注册表与属性分组注册表"""
        if not os.path.exists(self.categories_file):
            self._write_json(self.categories_file, DEFAULT_CATEGORIES)
        if not os.path.exists(self.attr_groups_file):
            self._write_json(self.attr_groups_file, DEFAULT_ATTRIBUTE_GROUPS)

    # ------------------------------------------------------------------
    # 基础读写
    # ------------------------------------------------------------------
    @staticmethod
    def _read_json(path: str, default=None):
        if not os.path.exists(path):
            return default if default is not None else {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"读取知识库文件失败 [{path}]: {e}")
            return default if default is not None else {}

    @staticmethod
    def _write_json(path: str, data: Any):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    @staticmethod
    def _clamp255(v: Any, fallback: int = 0) -> int:
        try:
            return max(0, min(255, int(v)))
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def alpha_label(idx: int) -> str:
        """0→A, 1→B ... 25→Z, 26→AA。用于端口默认序号。"""
        idx = max(0, int(idx))
        label = ""
        while True:
            label = chr(ord("A") + idx % 26) + label
            idx = idx // 26 - 1
            if idx < 0:
                break
        return label

    def _reload_live_manager(self):
        """写操作后热重载运行中的知识库管理器，使改动立即被引擎采用"""
        if not self.kb_manager:
            return
        try:
            self.kb_manager.load_profiles()
            self.kb_manager.load_venue(self.active_venue_file)
            self.kb_manager.load_presets()
            logger.info(f"知识库已热重载，当前工作场地: [{self.active_venue_file}]")
        except Exception as e:
            logger.error(f"知识库热重载失败: {e}")

    # ==================================================================
    # 总览
    # ==================================================================
    def get_summary(self) -> Dict[str, Any]:
        with self.lock:
            profiles = glob.glob(os.path.join(self.profiles_dir, "*.json"))
            venues = glob.glob(os.path.join(self.venues_dir, "*.json"))
            presets = self._read_json(self.preset_file, {})
            categories = self.get_categories()["categories"]
            cur_venue = self._normalize_venue(
                self._read_json(os.path.join(self.venues_dir, self.active_venue_file), {})
            )
            nodes = cur_venue.get("nodes", [])
            ports = [p for n in nodes for p in n.get("ports", [])]
            universes = sorted({p.get("universe", 0) for p in ports})
            return {
                "profiles_count": len(profiles),
                "venues_count": len(venues),
                "presets_count": len(presets),
                "categories_count": len(categories),
                "kb_path": self.kb_root,
                "active_venue_file": self.active_venue_file,
                "active_venue_name": cur_venue.get("venue_name", "-"),
                "active_fixture_count": len(cur_venue.get("fixtures", [])),
                "active_node_count": len(nodes),
                "active_port_count": len(ports),
                "active_universes": universes
            }

    # ==================================================================
    # 第一层：物理灯库 Profiles
    # ==================================================================
    @staticmethod
    def _normalize_channel(ch: Dict[str, Any], idx: int) -> Dict[str, Any]:
        """规范化单个通道定义，并极大地增强对大模型异形字段（如 channel, no, 字符串编号）的容错能力"""
        # 兼容大模型可能返回的各种通道号字段名
        raw_ch = ch.get("ch") if ch.get("ch") is not None else (ch.get("channel") if ch.get("channel") is not None else (ch.get("no") if ch.get("no") is not None else ch.get("number")))
        
        parsed_ch = idx
        if raw_ch is not None:
            try:
                if isinstance(raw_ch, str):
                    # 尝试从字符串中提取数字，如 "CH1" -> 1, "通道1" -> 1
                    nums = re.findall(r'\d+', raw_ch)
                    if nums:
                        parsed_ch = int(nums[0])
                    else:
                        parsed_ch = int(raw_ch)
                else:
                    parsed_ch = int(raw_ch)
            except (TypeError, ValueError):
                parsed_ch = idx

        out = {
            "ch": parsed_ch if parsed_ch > 0 else idx,
            "type": str(ch.get("type", f"ch{idx}") or f"ch{idx}"),
            "name": str(ch.get("name", ch.get("type", f"CH{idx}")) or f"CH{idx}"),
            "default": int(ch.get("default", 0) or 0),
            "is_safe": bool(ch.get("is_safe", True)),
        }

        rng = ch.get("range")
        if isinstance(rng, (list, tuple)) and len(rng) == 2:
            try:
                lo, hi = int(rng[0]), int(rng[1])
            except (TypeError, ValueError):
                lo, hi = 0, 255
            lo, hi = max(0, min(255, lo)), max(0, min(255, hi))
            if hi < lo:
                lo, hi = hi, lo
            out["range"] = [lo, hi]

        slots = ch.get("slots")
        if isinstance(slots, list):
            clean: List[Dict[str, Any]] = []
            for s in slots:
                if isinstance(s, dict) and s.get("v") is not None:
                    try:
                        clean.append({"v": int(s["v"]), "label": str(s.get("label", ""))})
                    except (TypeError, ValueError):
                        continue
                elif isinstance(s, (int, float)):
                    clean.append({"v": int(s), "label": str(int(s))})
            if clean:
                out["slots"] = clean

        unit = ch.get("unit")
        if unit:
            out["unit"] = str(unit)
        return out

    def list_profiles(self) -> List[Dict[str, Any]]:
        with self.lock:
            res = []
            for f in sorted(os.listdir(self.profiles_dir)):
                if not f.endswith(".json"):
                    continue
                data = self._read_json(os.path.join(self.profiles_dir, f))
                if not data:
                    continue
                channels = data.get("channels", [])
                safe_cnt = sum(1 for c in channels if c.get("is_safe", True))
                ranged = sum(1 for c in channels if c.get("range") or c.get("slots"))
                res.append({
                    "filename": f,
                    "profile_id": data.get("profile_id", f.replace(".json", "")),
                    "manufacturer": data.get("manufacturer", ""),
                    "model": data.get("model", ""),
                    "channel_count": data.get("channel_count", len(channels)),
                    "channels": channels,
                    "safe_channel_count": safe_cnt,
                    "locked_channel_count": len(channels) - safe_cnt,
                    "ranged_channel_count": ranged,
                })
            return res

    def get_profile(self, profile_id: str) -> Dict[str, Any]:
        return self._read_json(os.path.join(self.profiles_dir, f"{profile_id}.json"), {})

    def save_profile(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pid = (data.get("profile_id") or "").strip()
        if not pid:
            raise ValueError("Profile ID 不能为空")
        if not data.get("channels"):
            raise ValueError(f"灯库 [{pid}] 必须至少定义 1 个通道")

        channels = [self._normalize_channel(c, i) for i, c in enumerate(data["channels"], start=1)]
        data["channels"] = channels
        data["profile_id"] = pid
        data["channel_count"] = data.get("channel_count") or len(channels)

        with self.lock:
            self._write_json(os.path.join(self.profiles_dir, f"{pid}.json"), data)
            self._reload_live_manager()
        logger.info(f"灯库已保存: [{pid}] ({data['channel_count']} 通道)")
        return {"status": "ok", "filename": f"{pid}.json", "profile_id": pid}

    def delete_profile(self, profile_id: str) -> Dict[str, Any]:
        fpath = os.path.join(self.profiles_dir, f"{profile_id}.json")
        if not os.path.exists(fpath):
            raise FileNotFoundError(f"未找到灯库文件: {profile_id}.json")

        # 安全拦截：被当前场地（节点树任意灯位）引用的灯库不允许删除
        referenced = [
            f.get("name")
            for f in self._flatten_nodes(
                self._normalize_venue(
                    self._read_json(os.path.join(self.venues_dir, self.active_venue_file), {})
                ).get("nodes", [])
            )
            if f.get("profile_id") == profile_id
        ]
        if referenced:
            raise ValueError(f"灯库 [{profile_id}] 正在被场地灯具使用 ({', '.join(referenced)})，禁止删除")

        with self.lock:
            os.remove(fpath)
            self._reload_live_manager()
        logger.info(f"灯库已删除: [{profile_id}]")
        return {"status": "ok", "deleted": profile_id}

    def profile_attributes(self, profile_id: str) -> Dict[str, Any]:
        """
        返回某灯库可用于预设编辑的**属性全集**（按自定义属性分组归类）。
        这是"预设内容按通道属性自定义"的数据基础——50 通道灯型即 50 个可选属性。
        """
        prof = self.get_profile(profile_id)
        if not prof:
            raise FileNotFoundError(f"未找到灯库: {profile_id}")

        channels = [self._normalize_channel(c, i) for i, c in enumerate(prof.get("channels", []), start=1)]
        groups = self.get_attribute_groups()["groups"]

        # 建立 属性名 -> 分组 的索引
        attr2group: Dict[str, str] = {}
        for g in groups:
            for a in g.get("attrs", []):
                attr2group.setdefault(a, g["id"])

        attrs: List[Dict[str, Any]] = []
        for ch in channels:
            if not ch.get("is_safe", True):
                continue  # 危险通道永不出现在预设可选项中
            atype = ch["type"]
            attrs.append({
                "attr": atype,
                "label": ch.get("name", atype),
                "ch": ch["ch"],
                "default": ch.get("default", 0),
                "range": ch.get("range") or [0, 255],
                "has_range": bool(ch.get("range")),
                "slots": ch.get("slots") or [],
                "unit": ch.get("unit"),
                "group_id": attr2group.get(atype, "_other"),
            })
        return {
            "profile_id": profile_id,
            "manufacturer": prof.get("manufacturer", ""),
            "model": prof.get("model", ""),
            "attributes": attrs,
            "groups": groups,
            "locked_channels": [c["type"] for c in channels if not c.get("is_safe", True)],
        }

    # ==================================================================
    # 第二层：场地空间拓扑 Venues（四层节点树）
    # ==================================================================
    DEFAULT_OFFLINE_POLICY = {
        "mode": "threshold",           # threshold 阈值触发 | ignore 忽略 | manual 手动
        # artpoll 主动探测应答（推荐，非侵入式）| artdmx 被动观测到该 IP 回传的数据帧
        # | ping ICMP 可达探测
        # 默认取 artpoll 而非 artdmx：调音台通常只发不收，用 artdmx 作判据会让每台
        # 正常解码器都收不到回传而集体误报。
        "liveness_source": "artpoll",
        "threshold_sec": 5,
        "grace_period_sec": 2,
        # 连一次心跳都没收到过时是否也算掉线。默认 False（报"未监测"），
        # 避免把"判据不适用"误当成"设备掉线"。
        "alarm_when_never_seen": False,
        "severity": "warning",
        "actions": ["log", "banner", "toast"],
        "auto_recover": True,
    }

    @staticmethod
    def _default_port(idx: int, universe: Optional[int] = None) -> Dict[str, Any]:
        return {
            "port_id": f"p{idx + 1}",
            "label": KnowledgeBaseService.alpha_label(idx),
            "label_style": "alpha",       # alpha(A/B/C) | numeric(1/2/3) | custom
            "universe": universe if universe is not None else idx,
            "direction": "out",
            "fixtures": [],
        }

    def _migrate_flat_to_nodes(self, venue: Dict[str, Any]) -> List[Dict[str, Any]]:
        """将旧版扁平 fixtures[] 自动归拢为 节点→端口→灯具 三层结构"""
        fixtures = venue.get("fixtures", []) or []
        by_universe: Dict[int, List[Dict[str, Any]]] = {}
        for f in fixtures:
            by_universe.setdefault(int(f.get("universe", 0) or 0), []).append(dict(f))

        ports = []
        for i, u in enumerate(sorted(by_universe.keys())):
            p = self._default_port(i, u)
            p["fixtures"] = by_universe[u]
            ports.append(p)
        if not ports:
            ports = [self._default_port(0, 0)]

        return [{
            "node_id": "node_1",
            "name": "默认解码器",
            "source": "manual",
            "ip": venue.get("default_target_ip", "127.0.0.1"),
            "protocol": "artnet",
            "groups": [],
            "discovery": {"online": None, "artpoll_reply": None, "rtt_ms": None,
                          "first_seen": None, "last_seen": None},
            "offline_policy": dict(self.DEFAULT_OFFLINE_POLICY),
            "ports": ports,
        }]

    def _normalize_venue(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """规范化场地结构：补齐节点树，并派生扁平 fixtures[] 供引擎使用"""
        if not data:
            return data

        nodes = data.get("nodes")
        if not isinstance(nodes, list) or not nodes:
            nodes = self._migrate_flat_to_nodes(data)

        norm_nodes = []
        for ni, node in enumerate(nodes):
            n = dict(node)
            n.setdefault("node_id", f"node_{ni + 1}")
            n.setdefault("name", f"解码器 {ni + 1}")
            n.setdefault("source", "manual")
            n.setdefault("ip", data.get("default_target_ip", "127.0.0.1"))
            n.setdefault("protocol", "artnet")
            n.setdefault("groups", [])
            disc = dict(n.get("discovery") or {})
            for k, v in (("online", None), ("artpoll_reply", None), ("rtt_ms", None),
                         ("first_seen", None), ("last_seen", None)):
                disc.setdefault(k, v)
            n["discovery"] = disc

            pol = dict(self.DEFAULT_OFFLINE_POLICY)
            pol.update(n.get("offline_policy") or {})
            if pol.get("mode") not in ("threshold", "ignore", "manual"):
                pol["mode"] = "threshold"
            if pol.get("liveness_source") not in ("artpoll", "artdmx", "ping"):
                pol["liveness_source"] = "artpoll"
            pol["alarm_when_never_seen"] = bool(pol.get("alarm_when_never_seen", False))
            if pol.get("severity") not in ("warning", "critical"):
                pol["severity"] = "warning"
            if not isinstance(pol.get("actions"), list):
                pol["actions"] = list(self.DEFAULT_OFFLINE_POLICY["actions"])
            pol["auto_recover"] = bool(pol.get("auto_recover", True))
            try:
                pol["threshold_sec"] = max(1, int(pol.get("threshold_sec", 5)))
                pol["grace_period_sec"] = max(0, int(pol.get("grace_period_sec", 2)))
            except (TypeError, ValueError):
                pol["threshold_sec"], pol["grace_period_sec"] = 5, 2
            n["offline_policy"] = pol

            ports = n.get("ports")
            if not isinstance(ports, list) or not ports:
                ports = [self._default_port(0, 0)]
            norm_ports = []
            for pi, port in enumerate(ports):
                p = dict(port)
                p.setdefault("port_id", f"p{pi + 1}")
                p.setdefault("label", self.alpha_label(pi))
                p.setdefault("label_style", "alpha")
                try:
                    p["universe"] = max(0, int(p.get("universe", pi)))
                except (TypeError, ValueError):
                    p["universe"] = pi
                p.setdefault("direction", "out")

                fx = []
                for fi, f in enumerate(p.get("fixtures") or []):
                    d = dict(f)
                    d.setdefault("id", f"fix_{pi + 1}_{fi + 1}")
                    d.setdefault("name", f"灯具 {fi + 1}")
                    d.setdefault("profile_id", "")
                    try:
                        d["address"] = max(1, int(d.get("address", 1)))
                    except (TypeError, ValueError):
                        d["address"] = 1
                    d.setdefault("tags", [])
                    d["allow_shared_address"] = bool(d.get("allow_shared_address", False))
                    fx.append(d)
                p["fixtures"] = fx
                norm_ports.append(p)
            n["ports"] = norm_ports
            norm_nodes.append(n)

        data["nodes"] = norm_nodes
        # 派生扁平视图：引擎侧 kb_manager 与既有全部逻辑继续零改动工作
        data["fixtures"] = self._flatten_nodes(norm_nodes)
        return data

    @staticmethod
    def _flatten_nodes(nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """把节点树拍平为 (universe, address) 灯具列表，供 DMX 引擎与冲突检测使用"""
        flat: List[Dict[str, Any]] = []
        for node in nodes or []:
            for port in node.get("ports", []) or []:
                for f in port.get("fixtures", []) or []:
                    item = dict(f)
                    item["universe"] = port.get("universe", 0)
                    item["node_id"] = node.get("node_id")
                    item["node_name"] = node.get("name")
                    item["port_id"] = port.get("port_id")
                    item["port_label"] = port.get("label")
                    flat.append(item)
        return flat

    def list_venues(self) -> List[Dict[str, Any]]:
        with self.lock:
            res = []
            for f in sorted(os.listdir(self.venues_dir)):
                if not f.endswith(".json"):
                    continue
                data = self._normalize_venue(self._read_json(os.path.join(self.venues_dir, f)))
                if not data:
                    continue
                res.append({
                    "filename": f,
                    "venue_id": data.get("venue_id", f.replace(".json", "")),
                    "venue_name": data.get("venue_name", ""),
                    "default_target_ip": data.get("default_target_ip", "127.0.0.1"),
                    "fixture_count": len(data.get("fixtures", [])),
                    "node_count": len(data.get("nodes", [])),
                    "port_count": sum(len(n.get("ports", [])) for n in data.get("nodes", [])),
                    "fixtures": data.get("fixtures", []),
                    "nodes": data.get("nodes", []),
                    "is_active": f == self.active_venue_file
                })
            return res

    def get_venue(self, venue_id: str) -> Dict[str, Any]:
        return self._normalize_venue(
            self._read_json(os.path.join(self.venues_dir, f"{venue_id}.json"), {})
        )

    def save_venue(self, data: Dict[str, Any]) -> Dict[str, Any]:
        vid = (data.get("venue_id") or "").strip()
        if not vid:
            raise ValueError("Venue ID 不能为空")

        data = self._normalize_venue(data)

        # 校验灯具引用的灯库必须真实存在
        known = {p["profile_id"] for p in self.list_profiles()}
        for fix in data.get("fixtures", []):
            pid = fix.get("profile_id")
            if pid and pid not in known:
                raise ValueError(f"灯具 [{fix.get('name', fix.get('id'))}] 引用了不存在的灯库 [{pid}]")

        # 同一接口内灯具 ID 不可重复
        for node in data.get("nodes", []):
            for port in node.get("ports", []):
                seen = set()
                for f in port.get("fixtures", []):
                    fid = f.get("id")
                    if fid in seen:
                        raise ValueError(f"解码器 [{node.get('name')}] 接口 [{port.get('label')}] "
                                         f"内灯具 ID [{fid}] 重复")
                    seen.add(fid)

        with self.lock:
            self._write_json(os.path.join(self.venues_dir, f"{vid}.json"), data)
            self._reload_live_manager()
        logger.info(f"场地拓扑已保存: [{vid}] "
                    f"({len(data.get('nodes', []))} 解码器 / {len(data.get('fixtures', []))} 台灯具)")
        return {"status": "ok", "filename": f"{vid}.json", "venue_id": vid,
                "node_count": len(data.get("nodes", [])),
                "fixture_count": len(data.get("fixtures", []))}

    def delete_venue(self, venue_id: str) -> Dict[str, Any]:
        fpath = os.path.join(self.venues_dir, f"{venue_id}.json")
        if not os.path.exists(fpath):
            raise FileNotFoundError(f"未找到场地文件: {venue_id}.json")
        if f"{venue_id}.json" == self.active_venue_file:
            raise ValueError(f"场地 [{venue_id}] 是当前正在使用的工作场地，请先切换到其他场地再删除")
        if len(glob.glob(os.path.join(self.venues_dir, "*.json"))) <= 1:
            raise ValueError("知识库中至少需要保留一个场地")

        with self.lock:
            os.remove(fpath)
            self._reload_live_manager()
        logger.info(f"场地已删除: [{venue_id}]")
        return {"status": "ok", "deleted": venue_id}

    def switch_active_venue(self, venue_id: str) -> Dict[str, Any]:
        """热切换当前工作场地，引擎立即按新场地布点推送 DMX"""
        fname = f"{venue_id}.json"
        if not os.path.exists(os.path.join(self.venues_dir, fname)):
            raise FileNotFoundError(f"未找到场地文件: {fname}")

        with self.lock:
            self.active_venue_file = fname
            if self.kb_manager:
                self.kb_manager.load_venue(fname)
        venue = self.get_venue(venue_id)
        logger.info(f"工作场地已切换为: [{venue.get('venue_name')}]")
        return {
            "status": "ok",
            "active_venue_file": fname,
            "venue_name": venue.get("venue_name"),
            "fixture_count": len(venue.get("fixtures", [])),
            "node_count": len(venue.get("nodes", []))
        }

    # ==================================================================
    # 通道冲突碰撞检测（支持共址豁免）
    # ==================================================================
    def detect_conflicts(self, venue_data: Dict[str, Any]) -> Dict[str, Any]:
        profiles_map = {p["profile_id"]: p for p in self.list_profiles()}
        venue_data = self._normalize_venue(venue_data or {})
        fixtures = venue_data.get("fixtures", [])
        universes: Dict[int, List[Dict[str, Any]]] = {}
        conflicts: List[Dict[str, Any]] = []

        for fix in fixtures:
            fid = fix.get("id", "unknown")
            fname = fix.get("name", "未命名")
            u = int(fix.get("universe", 0) or 0)
            addr = int(fix.get("address", 1) or 1)
            pid = fix.get("profile_id", "")
            ch_count = profiles_map.get(pid, {}).get("channel_count", 1)
            shared = bool(fix.get("allow_shared_address", False))

            start, end = addr, addr + ch_count - 1
            if end > 512:
                conflicts.append({
                    "type": "overflow", "severity": "danger", "universe": u,
                    "fix_id": fid, "fix_name": fname,
                    "desc": f"灯具 [{fname}] 通道区间 CH{start}~CH{end} 超过单 Universe 上限 512"
                })
            if start < 1:
                conflicts.append({
                    "type": "underflow", "severity": "danger", "universe": u,
                    "fix_id": fid, "fix_name": fname,
                    "desc": f"灯具 [{fname}] 起始地址 CH{start} 非法（必须 ≥ 1）"
                })
            if pid and pid not in profiles_map:
                conflicts.append({
                    "type": "missing_profile", "severity": "danger", "universe": u,
                    "fix_id": fid, "fix_name": fname,
                    "desc": f"灯具 [{fname}] 引用的灯库 [{pid}] 在知识库中不存在"
                })

            universes.setdefault(u, []).append(
                {"id": fid, "name": fname, "start": start, "end": end,
                 "profile_id": pid, "shared": shared,
                 "node_name": fix.get("node_name"), "port_label": fix.get("port_label")}
            )

        for u, fix_list in universes.items():
            ordered = sorted(fix_list, key=lambda x: x["start"])
            for i in range(len(ordered)):
                for j in range(i + 1, len(ordered)):
                    a, b = ordered[i], ordered[j]
                    if a["end"] >= b["start"]:
                        # 任一方勾选「允许共址」→ 降级为提示，不阻断保存
                        downgrade = a.get("shared") or b.get("shared")
                        conflicts.append({
                            "type": "shared_address" if downgrade else "overlap",
                            "severity": "warn" if downgrade else "danger",
                            "universe": u, "fix1": a, "fix2": b,
                            "desc": (f"Universe {u} 通道{'共址' if downgrade else '冲突'}："
                                     f"[{a['name']} (CH{a['start']}~CH{a['end']})] 与 "
                                     f"[{b['name']} (CH{b['start']}~CH{b['end']})] "
                                     f"{'地址相同（已标记允许共址，仅作提示）' if downgrade else '重叠！'}")
                        })

        danger = sum(1 for c in conflicts if c["severity"] == "danger")
        return {
            "has_conflict": danger > 0,
            "has_any_issue": len(conflicts) > 0,
            "danger_count": danger,
            "notice_count": len(conflicts) - danger,
            "conflicts": conflicts,
            "checked_fixtures": len(fixtures),
            "universe_count": len(universes)
        }

    def check_conflicts_of(self, venue_id: Optional[str] = None) -> Dict[str, Any]:
        vid = venue_id or self.active_venue_file.replace(".json", "")
        return self.detect_conflicts(self.get_venue(vid))

    # ==================================================================
    # 分类注册表（完全自定义；每条预设强制归属）
    # ==================================================================
    def get_categories(self) -> Dict[str, Any]:
        with self.lock:
            data = self._read_json(self.categories_file, {"categories": []})
            cats = data.get("categories")
            if not isinstance(cats, list):
                cats = []
            for c in cats:
                c.setdefault("color", "#38bdf8")
                c.setdefault("order", 0)
                icon = dict(c.get("icon") or {})
                if icon.get("mode") not in CATEGORY_ICON_MODES:
                    icon["mode"] = "none"
                icon.setdefault("builtin", "")
                icon.setdefault("upload", "")
                icon.setdefault("align", "inline")
                c["icon"] = icon
            cats.sort(key=lambda x: (x.get("order", 0), x.get("name", "")))
            return {"categories": cats}

    def save_categories(self, data: Dict[str, Any]) -> Dict[str, Any]:
        cats = (data or {}).get("categories")
        if not isinstance(cats, list):
            raise ValueError("分类注册表必须是 {\"categories\": [...]} 结构")

        ids, clean = set(), []
        for i, c in enumerate(cats):
            cid = (c.get("id") or "").strip()
            if not cid:
                raise ValueError(f"第 {i + 1} 个分类缺少 id")
            if cid in ids:
                raise ValueError(f"分类 id 重复: {cid}")
            ids.add(cid)
            icon = dict(c.get("icon") or {})
            if icon.get("mode") not in CATEGORY_ICON_MODES:
                icon["mode"] = "none"
            clean.append({
                "id": cid,
                "name": (c.get("name") or cid).strip(),
                "color": c.get("color") or "#38bdf8",
                "order": int(c.get("order", i) or 0),
                "icon": {
                    "mode": icon.get("mode", "none"),
                    "builtin": icon.get("builtin", "") or "",
                    "upload": icon.get("upload", "") or "",
                    "align": "inline",
                },
            })

        with self.lock:
            self._write_json(self.categories_file, {"categories": clean})
        logger.info(f"预设分类注册表已保存，共 {len(clean)} 个分类")
        return {"status": "ok", "count": len(clean), "categories": clean}

    def save_category(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """新增或更新单个分类"""
        cid = (data.get("id") or "").strip()
        if not cid:
            raise ValueError("分类 id 不能为空")
        reg = self.get_categories()
        cats = reg["categories"]
        icon = dict(data.get("icon") or {})
        if icon.get("mode") not in CATEGORY_ICON_MODES:
            icon["mode"] = "none"
        entry = {
            "id": cid,
            "name": (data.get("name") or cid).strip(),
            "color": data.get("color") or "#38bdf8",
            "order": int(data.get("order", len(cats)) or 0),
            "icon": {
                "mode": icon.get("mode", "none"),
                "builtin": icon.get("builtin", "") or "",
                "upload": icon.get("upload", "") or "",
                "align": "inline",
            },
        }
        replaced = False
        for i, c in enumerate(cats):
            if c["id"] == cid:
                cats[i] = entry
                replaced = True
                break
        if not replaced:
            cats.append(entry)
        self.save_categories({"categories": cats})
        return {"status": "ok", "category": entry, "created": not replaced}

    def delete_category(self, category_id: str) -> Dict[str, Any]:
        """删除分类；若其下仍有预设则拒绝，强制用户先迁移"""
        presets = self.get_presets()
        occupied = [k for k, v in presets.items() if v.get("category_id") == category_id]
        if occupied:
            raise ValueError(f"分类下仍有 {len(occupied)} 条预设（{', '.join(occupied[:4])}"
                             f"{'…' if len(occupied) > 4 else ''}），请先移出后再删除该分类")
        cats = [c for c in self.get_categories()["categories"] if c["id"] != category_id]
        self.save_categories({"categories": cats})
        logger.info(f"预设分类已删除: [{category_id}]")
        return {"status": "ok", "deleted": category_id}

    # ==================================================================
    # 属性分组注册表（出厂预置四组，用户可改）
    # ==================================================================
    def get_attribute_groups(self) -> Dict[str, Any]:
        with self.lock:
            data = self._read_json(self.attr_groups_file, DEFAULT_ATTRIBUTE_GROUPS)
            groups = data.get("groups")
            if not isinstance(groups, list) or not groups:
                groups = DEFAULT_ATTRIBUTE_GROUPS["groups"]
            for g in groups:
                g.setdefault("color", "#38bdf8")
                if not isinstance(g.get("attrs"), list):
                    g["attrs"] = []
            return {"groups": groups}

    def save_attribute_groups(self, data: Dict[str, Any]) -> Dict[str, Any]:
        groups = (data or {}).get("groups")
        if not isinstance(groups, list):
            raise ValueError("属性分组必须是 {\"groups\": [...]} 结构")

        seen_attr: Dict[str, str] = {}
        clean = []
        for i, g in enumerate(groups):
            gid = (g.get("id") or "").strip()
            if not gid:
                raise ValueError(f"第 {i + 1} 个属性分组缺少 id")
            attrs = []
            for a in (g.get("attrs") or []):
                a = str(a).strip()
                if not a or a in seen_attr:
                    continue          # 同一属性只允许归属一个分组，后者忽略
                seen_attr[a] = gid
                attrs.append(a)
            clean.append({"id": gid, "name": (g.get("name") or gid).strip(),
                          "color": g.get("color") or "#38bdf8", "attrs": attrs})

        with self.lock:
            self._write_json(self.attr_groups_file, {"groups": clean})
        logger.info(f"属性分组已保存，共 {len(clean)} 组")
        return {"status": "ok", "groups": clean}

    # ==================================================================
    # 第三层：艺术美学预设 Presets（通道属性驱动）
    # ==================================================================
    def get_presets(self) -> Dict[str, Any]:
        with self.lock:
            return self._read_json(self.preset_file, {})

    def _normalize_preset(self, pid: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """规范化单条预设，并派生兼容字段供 RAG 检索链路使用"""
        data = data or {}

        # 内容来源：优先新的 channel_values，否则从旧 suggested_channels 迁移
        values: Dict[str, int] = {}
        raw_cv = data.get("channel_values")
        if isinstance(raw_cv, dict) and raw_cv:
            for k, v in raw_cv.items():
                values[str(k)] = self._clamp255(v)
        else:
            legacy = data.get("suggested_channels") or {}
            for k in ("red", "green", "blue", "white"):
                if legacy.get(k) is not None:
                    values[k] = self._clamp255(legacy[k])

        tags = data.get("tags")
        if not isinstance(tags, list) or not tags:
            tags = [t.strip() for t in str(data.get("desc", "")).split("、") if t.strip()]

        try:
            transition = int(data.get("transition_ms", data.get("recommended_transition_ms", 1000)) or 1000)
        except (TypeError, ValueError):
            transition = 1000

        out = {
            "name": (data.get("name") or pid).strip(),
            "category_id": (data.get("category_id") or "").strip(),
            "profile_ref": (data.get("profile_ref") or None),
            "universal": bool(data.get("universal", False)) or not data.get("profile_ref"),
            "channel_values": values,
            "transition_ms": transition,
            "summary": (data.get("summary") or "").strip(),
            "tags": [str(t) for t in tags],
            "color": (data.get("color") or "").strip(),
            "icon": (data.get("icon") or "").strip(),
        }

        # ---- 派生兼容字段：保证 kb_manager.retrieve_context 零改动可用 ----
        out["suggested_channels"] = {
            "red": values.get("red", 0), "green": values.get("green", 0),
            "blue": values.get("blue", 0), "white": values.get("white", 0),
        }
        out["desc"] = "、".join(out["tags"]) if out["tags"] else out["summary"] or out["name"]
        out["recommended_transition_ms"] = transition
        return out

    def _validate_preset_category(self, normalized: Dict[str, Any]) -> None:
        """强制分类：缺失或指向不存在的分类一律拒绝"""
        cid = normalized.get("category_id")
        if not cid:
            raise ValueError(f"预设 [{normalized['name']}] 未指定分类。所有预设必须强制归属一个分类。")
        valid = {c["id"] for c in self.get_categories()["categories"]}
        if cid not in valid:
            raise ValueError(f"预设 [{normalized['name']}] 引用了不存在的分类 [{cid}]")

    def save_preset(self, preset_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """新增或更新单条预设（UI 主用路径，强制分类）"""
        pid = (preset_id or data.get("id") or "").strip()
        if not pid:
            raise ValueError("预设索引键不能为空")

        normalized = self._normalize_preset(pid, data)
        self._validate_preset_category(normalized)

        # 基准灯型必选（除非显式声明为跨灯型通用的 JSON 直输预设）
        if not normalized["universal"]:
            known = {p["profile_id"] for p in self.list_profiles()}
            if normalized["profile_ref"] not in known:
                raise ValueError(f"预设 [{normalized['name']}] 引用的基准灯型 "
                                 f"[{normalized['profile_ref']}] 在知识库中不存在")

        with self.lock:
            presets = self._read_json(self.preset_file, {})
            is_new = pid not in presets
            presets[pid] = normalized
            self._write_json(self.preset_file, presets)
            self._reload_live_manager()
        logger.info(f"预设已{'新增' if is_new else '更新'}: [{pid}] {normalized['name']}")
        return {"status": "ok", "preset_id": pid, "created": is_new, "preset": normalized}

    def delete_preset(self, preset_id: str) -> Dict[str, Any]:
        with self.lock:
            presets = self._read_json(self.preset_file, {})
            if preset_id not in presets:
                raise FileNotFoundError(f"未找到预设: {preset_id}")
            removed = presets.pop(preset_id)
            self._write_json(self.preset_file, presets)
            self._reload_live_manager()
        logger.info(f"预设已删除: [{preset_id}] {removed.get('name')}")
        return {"status": "ok", "deleted": preset_id}

    def save_presets(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """整库保存（导入路径）。同样强制分类，任一条缺失即整体拒绝。"""
        if not isinstance(data, dict):
            raise ValueError("美学预设必须是以 key 为索引的 JSON 对象")

        normalized_all = {}
        for pid, p in data.items():
            normalized_all[pid] = self._normalize_preset(pid, p)

        missing = [v["name"] for v in normalized_all.values() if not v["category_id"]]
        if missing:
            raise ValueError(f"以下 {len(missing)} 条预设缺少分类，无法保存: "
                             f"{', '.join(missing[:5])}{'…' if len(missing) > 5 else ''}")

        valid = {c["id"] for c in self.get_categories()["categories"]}
        bad = [v["name"] for v in normalized_all.values() if v["category_id"] not in valid]
        if bad:
            raise ValueError(f"以下预设引用了不存在的分类: {', '.join(bad[:5])}")

        with self.lock:
            self._write_json(self.preset_file, normalized_all)
            self._reload_live_manager()
        logger.info(f"美学预设库已保存，共 {len(normalized_all)} 条")
        return {"status": "ok", "count": len(normalized_all)}

    # ==================================================================
    # AI 辅助：说明书解析与 DMX 通道表智能搜索提取
    # ==================================================================
    AI_PROFILE_SYSTEM_PROMPT = """你是一个拥有 20 年舞台灯光行业经验的控台灯光师、MA 控台专家以及数据结构转换架构师。
现在需要将用户提供的舞台灯具说明书（特别是包含多模式如 13CH/16CH/17CH 的 DMX 通道表文本）精准解析为标准 JSON 结构化灯库。

输出必须是纯 JSON，且完全符合以下结构：
{
  "profile_id": "厂商_型号_通道数 (纯小写英文及下划线，如 gtd_450_beam_16ch)",
  "manufacturer": "厂商名称",
  "model": "灯具型号",
  "channel_count": 通道总数(数字),
  "channels": [
    {"ch": 1, "type": "pan", "name": "水平扫描", "default": 128, "is_safe": true, "range": [0, 255], "slots": []},
    {"ch": 10, "type": "color_wheel", "name": "颜色盘", "default": 0, "is_safe": true, "range": [0, 255], "slots": [{"v": 0, "label": "白光"}, {"v": 8, "label": "颜色 1"}]}
  ]
}

【GTD-450 II BEAM 标准 16 通道参考范例（如遇该型号或类似 Beam 灯，请参考此通道顺序）】：
CH1: 水平 (pan), CH2: 水平微调 (pan_fine), CH3: 垂直 (tilt), CH4: 垂直微调 (tilt_fine), CH5: 扫描速度 (speed), CH6: 频闪 (strobe), CH7: 调光 (dimmer), CH8: 调光微调 (dimmer_fine), CH9: 颜色盘 (color_wheel，含 slots), CH10: 固定图案盘 (gobo，含 slots), CH11: 棱镜 (prism，含 slots), CH12: 棱镜旋转 (prism), CH13: 雾化 (effect), CH14: 调焦 (focus), CH15: 宏功能/控制 (control，is_safe: false), CH16: 灯泡/休眠控制 (control，is_safe: false)

【核心解析准则】：
1. 严格保证通道号 `ch` 从 1 到 N 连续递增，绝对禁止重复或归零。
2. 涉及设备复位、开泡关泡、工厂设置的通道，`is_safe` 必须设为 `false`。
3. 颜色盘、图案盘、棱镜等枚举型通道，必须提取 `slots` 数组列出档位。
4. 严禁输出任何 markdown 代码块以外的多余废话。"""

    @classmethod
    def parse_document_content(cls, file_bytes: bytes, filename: str) -> str:
        """
        从多种格式说明书二进制数据中提取文本内容。
        支持 .pdf, .docx, .txt, .md, .csv
        """
        fn = filename.lower()
        if fn.endswith((".txt", ".md", ".csv")):
            for enc in ["utf-8", "gb18030", "gbk", "latin-1"]:
                try:
                    return file_bytes.decode(enc)
                except UnicodeDecodeError:
                    continue
            return file_bytes.decode("utf-8", errors="ignore")

        elif fn.endswith(".docx"):
            try:
                from docx import Document
                doc = Document(io.BytesIO(file_bytes))
                lines = []
                for p in doc.paragraphs:
                    t = p.text.strip()
                    if t:
                        lines.append(t)
                for table in doc.tables:
                    for row in table.rows:
                        row_vals = [c.text.strip().replace("\n", " ") for c in row.cells]
                        if any(row_vals):
                            lines.append(" | ".join(row_vals))
                return "\n".join(lines)
            except Exception as e:
                raise ValueError(f"DOCX 文档解析失败: {e}")

        elif fn.endswith(".pdf"):
            try:
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(file_bytes))
                lines = []
                for idx, page in enumerate(reader.pages):
                    ptxt = page.extract_text() or ""
                    if ptxt.strip():
                        lines.append(f"--- [Page {idx + 1}] ---")
                        lines.append(ptxt)
                return "\n".join(lines)
            except Exception as e:
                raise ValueError(f"PDF 文档解析失败: {e}")

        else:
            # 默认作为纯文本尝试解析
            try:
                return file_bytes.decode("utf-8")
            except Exception:
                raise ValueError(f"不支持的说明书文档格式: {filename}")

    @classmethod
    def search_dmx_sections(cls, full_text: str, custom_keywords: Optional[List[str]] = None) -> Tuple[str, Dict[str, Any]]:
        """
        DMX 通道表智能检索切片：
        1. 针对短说明书（<=4000 字符），直接返回全文策略为 full_pass。
        2. 针对长篇说明书，跳过前 10% 目录页干扰，精准定位正文中包含 DMX 通道表或关键词的段落。
        """
        if not full_text:
            return "", {"mode": "empty", "total_length": 0, "slice_length": 0}

        lines = full_text.splitlines()
        total_lines = len(lines)

        # 短文本直接全量送检
        if len(full_text) <= 4000:
            return full_text, {
                "strategy": "full_pass",
                "total_lines": total_lines,
                "hit_count": 1,
                "slice_length": len(full_text)
            }

        # 扫描关键词
        skip_lines = int(total_lines * 0.10)
        anchor_idx = -1
        hit_count = 0

        # 正文锚点：必须同时包含 DMX 通道与模式说明
        for i in range(skip_lines, total_lines):
            line = lines[i].strip()
            if not line:
                continue
            if ("DMX 通道表" in line or "通道表控制" in line or "Channel Function" in line or 
                ("标准模式" in line and "基本模式" in line) or
                (custom_keywords and any(kw.lower() in line.lower() for kw in custom_keywords if kw))):
                hit_count += 1
                if anchor_idx == -1:
                    anchor_idx = i

        if anchor_idx != -1:
            start_idx = max(0, anchor_idx - 2)
            end_idx = min(total_lines, start_idx + 220)
            selected_lines = lines[start_idx:end_idx]
            sliced_text = "\n".join(selected_lines)
            return sliced_text, {
                "strategy": "smart_slice",
                "total_lines": total_lines,
                "anchor_line": anchor_idx + 1,
                "start_line": start_idx + 1,
                "end_line": end_idx,
                "hit_count": hit_count,
                "slice_length": len(sliced_text)
            }

        half_pos = max(0, total_lines // 2)
        sliced_text = "\n".join(lines[half_pos:])
        return sliced_text, {
            "strategy": "fallback_second_half",
            "total_lines": total_lines,
            "hit_count": 0,
            "slice_length": len(sliced_text)
        }

    def ai_extract_profile(self,
                           raw_text: Optional[str] = None,
                           file_bytes: Optional[bytes] = None,
                           filename: Optional[str] = None,
                           custom_prompt: Optional[str] = None,
                           llm_plugin: Any = None) -> Dict[str, Any]:
        """
        AI 辅助说明书生成灯库综合入口：
        支持传入纯文本或二进制文件(PDF/DOCX/TXT)，结合智能通道表检索切片，并允许用户注入附加提示词。
        """
        if not llm_plugin:
            raise RuntimeError("本地大模型插件未启用，无法进行说明书智能解析")

        # 1. 提取原始文本
        if file_bytes and filename:
            extracted_doc = self.parse_document_content(file_bytes, filename)
        elif raw_text:
            extracted_doc = raw_text
        else:
            raise ValueError("未提供任何说明书文本或文件内容")

        # 2. 智能搜索定位 DMX 通道表切片
        search_keywords = []
        if custom_prompt:
            # 提取提示词中可能包含的模式或通道关键词 (如 16ch, 标准模式, 摇头灯)
            for kw in re.findall(r"(\d+\s*(?:ch|通道)|[a-zA-Z0-9_\u4e00-\u9fa5]{2,10})", custom_prompt):
                search_keywords.append(kw)

        channel_table_text, slice_meta = self.search_dmx_sections(extracted_doc, search_keywords)

        # 3. 组装发给大模型的指令上下文
        user_content_parts = [
            "【灯具说明书 DMX 通道表检索内容】：",
            channel_table_text
        ]

        if custom_prompt and custom_prompt.strip():
            user_content_parts.extend([
                "",
                "【用户特别附加提示要求】：",
                custom_prompt.strip()
            ])

        system_prompt = self.AI_PROFILE_SYSTEM_PROMPT
        if custom_prompt and ("模式" in custom_prompt or "channel" in custom_prompt.lower() or "ch" in custom_prompt.lower()):
            system_prompt += "\n特别注意：用户指定了提取特定模式或通道范围，请严格按用户提示中的通道模式进行解析输出！"

        # 4. 请求大模型推理
        raw_res = llm_plugin.chat_completion([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": "\n".join(user_content_parts)}
        ])
        cleaned = self._strip_code_fence(raw_res)
        try:
            parsed = json.loads(cleaned)
        except Exception as e:
            raise ValueError(f"大模型返回内容无法解析为 JSON: {e}\n模型原始返回: {raw_res[:300]}")

        # 5. 规范化通道与元数据挂载
        if isinstance(parsed.get("channels"), list):
            parsed["channels"] = [self._normalize_channel(c, i)
                                  for i, c in enumerate(parsed["channels"], start=1)]
            parsed["channel_count"] = len(parsed["channels"])

        # 附带检索切片元信息供前端展示
        parsed["_extract_meta"] = {
            "slice_meta": slice_meta,
            "source_type": "file" if file_bytes else "raw_text",
            "filename": filename or "",
            "has_custom_prompt": bool(custom_prompt and custom_prompt.strip())
        }
        return parsed

    @classmethod
    def import_external_profile(cls, file_bytes: bytes, filename: str, plugin_host: Any = None) -> Dict[str, Any]:
        """
        通过 2 类生态适配器插件总线，自动查找匹配后缀名（.xml, .gdtf 等）的已安装适配器完成转换。
        若未找到动态插件，则平滑回退至内置基础 MA 适配逻辑，确保绝对高可用。
        """
        ext = os.path.splitext(filename)[1].lower()
        if plugin_host and hasattr(plugin_host, "get_adapter_for_extension"):
            adapter = plugin_host.get_adapter_for_extension(ext)
            if adapter:
                logger.info(f"调用 2 类适配器插件 [{adapter.get_info().get('id')}] 解析 {filename}")
                return adapter.convert_to_profile(file_bytes, filename)

        # 回退至内置 MA XML 适配器基础实现
        from plugins.adapters.ma_fixture_adapter import MAFixtureAdapterPlugin
        fallback = MAFixtureAdapterPlugin()
        return fallback.convert_to_profile(file_bytes, filename)

    # ==================================================================
    # RAG 语义检索实测
    # ==================================================================
    def rag_test(self, query: str, venue_id: Optional[str] = None) -> Dict[str, Any]:
        from kb_manager import KnowledgeBaseManager

        vid = venue_id or self.active_venue_file.replace(".json", "")
        tmp_mgr = KnowledgeBaseManager(self.kb_root)
        tmp_mgr.load_venue(f"{vid}.json")
        fixtures_context, preset_hint = tmp_mgr.retrieve_context(query)
        return {
            "query": query,
            "venue_id": vid,
            "matched_count": len(fixtures_context),
            "matched_fixtures": fixtures_context,
            "preset_hint": preset_hint
        }

    @staticmethod
    def _strip_code_fence(text: str) -> str:
        cleaned = (text or "").strip()
        if "```json" in cleaned:
            return cleaned.split("```json")[1].split("```")[0].strip()
        if "```" in cleaned:
            return cleaned.split("```")[1].split("```")[0].strip()
        return cleaned
