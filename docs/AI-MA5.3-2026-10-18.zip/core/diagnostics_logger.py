# -*- coding: utf-8 -*-
"""
AI-MA 统一中文结构化日志与快速故障诊断定位引擎 (Chinese Diagnostics & Ring Buffer)
支持多目标分流（控制台彩色输出、自动轮转本地磁盘文件、Web端环形缓冲区实时推流），
并内置错误代码知识库，报错时提供明确的原因分析与修复建议。
"""

import os
import sys
import time
import logging
from logging.handlers import RotatingFileHandler
from collections import deque
import threading
from typing import List, Dict, Any, Optional

# 错误代码与中文故障诊断修复知识库 (Diagnostic Code Knowledge Base)
ERROR_DIAGNOSTICS_DB = {
    "ERR-NET-6454": {
        "title": "Art-Net 通信端口绑定失败 (UDP 6454)",
        "cause": "端口已被其他控制台软件（如 GrandMA onPC、Chamsys、TouchOSC）占用，或在 Linux/Debian 环境下缺少绑定特权。",
        "solution": "1. 检查是否有同类灯光软件在运行并关闭；2. 在 Debian 上执行 'sudo lsof -i :6454' 查看占用进程；3. 若以普通用户运行，请通过 setcap 为 Python 赋予网络绑定能力。"
    },
    "ERR-LLM-CONN": {
        "title": "大语言模型端点连接超时或服务离线",
        "cause": "本地 llama.app / vLLM 未启动，或者网络防火墙阻止了 8085 端口的 HTTP 请求。",
        "solution": "1. 请确认本地终端已运行 llama.app 并监听在 127.0.0.1:8085；2. 在浏览器中测试访问 http://127.0.0.1:8085/v1/models；3. 检查系统代理或防火墙配置。"
    },
    "ERR-DMX-OVERFLOW": {
        "title": "DMX 通道地址越界溢出",
        "cause": "灯具起始地址 (Address) 加上灯具占用通道总数超过了单 Universe 的 512 上限。",
        "solution": "打开知识库管理工作台，重新编排该灯具的起始地址，或者将其迁移至下一个 Universe。"
    },
    "ERR-AUTH-DENIED": {
        "title": "安全鉴权被拒绝（令牌有效但权限不足）",
        "cause": "当前登录角色不具备该操作所需的权限等级。例如观察员尝试执行需要管理员权限的写操作或系统配置。",
        "solution": "请在 Web 总控台右上角切换为具备对应权限的账号重新登录后执行操作。若确认当前账号权限足够，请检查 config/users.json 中该角色被授予的权限项。"
    },
    "ERR-AUTH-LOGIN-FAIL": {
        "title": "登录鉴权失败（账号或密码校验未通过）",
        "cause": "提交的账号不存在，或密码与该账号的散列记录不匹配。也可能是客户端在缓存了旧密码后自动重试。",
        "solution": "1. 确认账号与密码拼写正确（注意大小写）；2. 若确认忘记密码，请用系统底层维护者动态 Key 应急直通后重置；3. 若同一账号在短时间内反复失败，请关注是否伴随 ERR-AUTH-BRUTEFORCE 告警。"
    },
    "ERR-AUTH-BRUTEFORCE": {
        "title": "疑似会话令牌爆破或异常客户端扫描",
        "cause": "短时间内出现大量未携带有效会话令牌的 API 请求，已远超正常页面轮询的频率。常见成因：有人在用脚本穷举令牌或扫描接口、某个客户端在会话失效后未停止轮询、或存在异常代理重放。",
        "solution": "1. 先确认这不是正常注销后的在途轮询（正常注销只会在亚秒级内产生个位数请求，本告警阈值远高于此）；2. 检查是否有第三方脚本或旧版页面在持续轮询；3. 若判定为恶意扫描，请在网络层封禁来源 IP，并考虑缩短会话有效期；4. 查看本告警前后的 INFO/DEBUG 日志确认请求来源与命中路径。"
    },
    "ERR-MASK-TRIP": {
        "title": "物理安全掩码触发硬件熔断拦截",
        "cause": "大模型或外部指令尝试向被锁定的危险通道（如系统复位 Reset、危险宏）写入非安全数值。",
        "solution": "系统已自动将其强制归零，无需人工干预。如需开放该通道，请在对应灯库 Profile 中将 is_safe 显式配置为 true。"
    },
    "ERR-NODE-OFFLINE": {
        "title": "Art-Net 解码器节点掉线",
        "cause": "该解码器在设定的阈值时间内未按存活判据上报心跳。常见成因：网线/交换机端口松动、解码器断电重启、IP 被其他设备抢占、仅单向发送的解码器在无变化时静默（此时存活判据应从 artdmx 改为 artpoll）。",
        "solution": "1. 先确认解码器电源与链路指示灯；2. 在「设备节点与监视」中对该 IP 执行「测试连接」查看三态判定；3. 若设备本身正常但长期静默，把该节点的存活判据改为 artpoll 或把模式改为「忽略」；4. 若确需在掉线时主动归零，请在该节点策略中显式勾选「安全回退归零」（默认关闭）。"
    },
    "ERR-KERNEL-DAEMON": {
        "title": "硬实时微内核守护进程失联或异常退出",
        "cause": "Rust 微内核 aima-rt-daemon 被外部杀死、被系统 OOM 回收、二进制缺失或版本与 ABI 扩展不匹配。此时业务层已失去物理推流能力。",
        "solution": "1. 查看 logs/aima_rt_daemon.log 尾部获取内核侧真实死因；2. 确认 bin/aima-rt-daemon 存在且具有可执行权限；3. 确认 aima_shm_sdk 扩展与内核版本一致；4. 检查是否有人在 systemd 之外重复拉起内核导致争抢；5. 看门狗会在上限内自动重启，若持续失败请检查系统内存与实时权限。"
    },
    "ERR-KERNEL-STALL": {
        "title": "硬实时微内核时钟停摆（进程存活但帧计数不再推进）",
        "cause": "微内核主线程被阻塞或死锁、CPU 核心被其他高负载进程抢占、内存换页导致实时线程无法按时唤醒，或共享内存被外部进程破坏。",
        "solution": "1. 检查该 CPU 核心是否被别的进程占满（top -H 查看实时线程）；2. 确认内核启动参数已隔离核心：isolcpus/nohz_full/rcu_nocbs；3. 确认 aima-rt.service 已设置 LimitMEMLOCK=infinity 防止换页；4. 确认无人抢占同一组共享内存槽位；5. 看门狗会尝试杀死并重启内核自愈。"
    },
    "ERR-KERNEL-TELEMETRY": {
        "title": "微内核遥测数据读取或序列化失败",
        "cause": "共享内存尚未初始化、内核与上层结构体布局不一致，或遥测数据中含 numpy 标量导致 JSON 无法序列化。",
        "solution": "1. 确认内核已启动并完成共享内存挂载；2. 确认 aima_shm_sdk 与内核版本一致；3. 检查返回数据是否已显式转为 Python 原生类型。"
    },
    "ERR-PLUGIN-FOUNDATION": {
        "title": "系统底座插件（1 类系统级 / 2 类适配级）装载失败",
        "cause": "插件源码语法错误、缺少依赖、未通过合规校验（ID 格式 / get_info 字段 / 配置 schema）、on_init 返回 False，或源文件中不存在可实例化的插件类。",
        "solution": "1. 在启动日志的「插件生态装载总览」中查看具体失败层级、阶段与原因；2. 调用管理员接口 /api/plugins/diagnostics 获取结构化失败明细；3. 1 类失效将导致无物理推流（Art-Net/sACN 驱动缺失），2 类失效将无法导入控台灯库资产，必须优先修复；4. 修复后重启控制台。"
    },
    "ERR-KB-WRITE": {
        "title": "RAG 知识库写入或删除失败",
        "cause": "knowledge_base 目录无写权限、目标 JSON 被其他进程占用、磁盘空间不足，或提交的数据结构不合法。",
        "solution": "1. 确认 knowledge_base 目录存在且当前用户有写权限；2. 检查磁盘剩余空间；3. 确认提交的 JSON 结构符合该资源类型的约定格式。"
    },
    "ERR-ADAPTER-IMPORT": {
        "title": "外部控台灯库资产导入失败",
        "cause": "上传的文件格式不受任何 2 类适配器支持（如 MA2 XML / GDTF 解析失败）、文件损坏，或对应适配器插件未启用。",
        "solution": "1. 在「插件生态装载总览」中确认 2 类适配器插件装载成功且已启用；2. 检查源文件是否为受支持的控台导出格式；3. 用文本编辑器确认 XML 结构完整未被截断。"
    },
    "ERR-RPC-PERMISSION": {
        "title": "插件间 RPC 服务调用权限被拒绝",
        "cause": "调用方插件未在目标服务的权限白名单中，或调用方尝试越权访问非暴露的私有服务方法。",
        "solution": "1. 检查调用方插件 ID 是否已列入目标服务注册时的 callers 白名单中；2. 确认服务方法是否允许公开调用；3. 检查三类插件依赖与交互架构。"
    },
    "ERR-SERVICE-NOT-FOUND": {
        "title": "未找到请求的插件 RPC 目标服务",
        "cause": "所请求的服务名称未注册、目标提供者插件未加载启用，或服务已被注销。",
        "solution": "1. 确认提供该服务的插件已正常启用并完成服务注册；2. 检查 service_name 拼写是否正确；3. 在调用前通过 ServiceBroker 检查服务是否已就绪。"
    },
    "ERR-RPC-TIMEOUT": {
        "title": "插件间 RPC 服务调用超时或熔断保护触发",
        "cause": "目标服务执行时间超过设定的 timeout_ms，或服务频繁崩溃导致断路器打开进入熔断状态。",
        "solution": "1. 优化目标服务内部处理逻辑，避免阻塞操作；2. 检查断路器熔断恢复周期配置，待熔断器冷却后自动恢复；3. 适当调整调用超时阈值。"
    },
    "ERR-PLUGIN-PERF-VIOLATION": {
        "title": "插件性能门禁违规触发降级或熔断",
        "cause": "插件单帧渲染耗时或事件处理持续超时超标，严重挤占 44Hz 实时周期预算，性能探针自动执行熔断降级。",
        "solution": "1. 优化插件内部算法，消除大循环与同步 I/O；2. 使用 Mock 沙盒工具链进行性能分析与降级排查；3. 减少单帧渲染的计算复杂度。"
    }
}

class WebLogRingBuffer:
    """线程安全的内存环形日志缓冲区，供 Web UI 实时拉取最新日志"""
    def __init__(self, capacity: int = 500):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.lock = threading.RLock()

    def append(self, log_entry: Dict[str, Any]):
        with self.lock:
            self.buffer.append(log_entry)

    def get_logs(self, limit: int = 100, level_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.lock:
            entries = list(self.buffer)
        if level_filter:
            entries = [e for e in entries if e["level"] == level_filter.upper()]
        return entries[-limit:]

class CustomRingBufferHandler(logging.Handler):
    def __init__(self, ring_buffer: WebLogRingBuffer):
        super().__init__()
        self.ring_buffer = ring_buffer

    def emit(self, record):
        try:
            msg = self.format(record)
            entry = {
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(record.created)),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "formatted": msg,
                "diag_code": getattr(record, "diag_code", None)
            }
            if entry["diag_code"] and entry["diag_code"] in ERROR_DIAGNOSTICS_DB:
                entry["diagnostics"] = ERROR_DIAGNOSTICS_DB[entry["diag_code"]]
            self.ring_buffer.append(entry)
        except Exception:
            self.handleError(record)

# 全局环形缓冲区单例
GLOBAL_LOG_BUFFER = WebLogRingBuffer(capacity=1000)

def setup_chinese_logger(log_dir: str = "logs", app_name: str = "AI-MA") -> logging.Logger:
    """初始化生产级全链路中文日志"""
    os.makedirs(log_dir, exist_ok=True)
    log_file_path = os.path.join(log_dir, "ai_ma_system.log")

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    # 1. 格式化模板 (包含微秒时间戳与级别)
    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 2. 控制台输出处理器 (Stdout)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 3. 磁盘轮转日志文件处理器 (单个最大 10MB，保留 10 个备份)
    try:
        os.makedirs(os.path.dirname(os.path.abspath(log_file_path)), exist_ok=True)
        file_handler = RotatingFileHandler(
            log_file_path,
            maxBytes=10 * 1024 * 1024,
            backupCount=10,
            encoding="utf-8"
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"无法初始化本地磁盘日志处理器 ({log_file_path}): {e}，将保持控制台与内存环形缓冲输出")

    # 4. Web 环形缓冲区处理器
    web_handler = CustomRingBufferHandler(GLOBAL_LOG_BUFFER)
    web_handler.setLevel(logging.INFO)
    web_handler.setFormatter(formatter)
    logger.addHandler(web_handler)

    logger.info(f"=== {app_name} 工业级中文日志与故障诊断引擎已就绪 ===")
    logger.info(f"本地日志持久化文件路径: [{log_file_path}]")
    return logger

def log_diagnostic_error(logger: logging.Logger, diag_code: str, custom_detail: str = ""):
    """记录带故障诊断知识库的结构化错误日志"""
    info = ERROR_DIAGNOSTICS_DB.get(diag_code, {
        "title": "未知系统异常",
        "cause": "未收录的异常事件",
        "solution": "请查看完整堆栈追踪并联系系统核心架构团队"
    })
    msg = f"【故障告警 - 代码 {diag_code}】: {info['title']} | 详情: {custom_detail}\n  -> 可能原因: {info['cause']}\n  -> 建议排查: {info['solution']}"
    extra = {"diag_code": diag_code}
    logger.error(msg, extra=extra)
