# -*- coding: utf-8 -*-
"""
AI-MA 工业级多层容灾备份与跨用户配置交互管理器 (backup_manager.py)
实现：
1. 实时多版本自动备份队列 (轮转防溢出，保留最新 N 份原子快照)
2. 系统全量快照 (包含 presets, topology, profiles, users, config, plugins)
3. 用户级专属工作区独立配置包导出与恢复 (.json / .aimapack)
4. 跨用户数据导入/导出与合并交互 (灯光师 A 可将其场景与面板分享导出，灯光师 B 导入使用)
5. 带有校验和 (SHA-256) 的防篡改完整性校验与一键安全灾备回滚
"""

import os
import sys
import time
import json
import shutil
import hashlib
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger("BackupManager")

class BackupManager:
    def __init__(self, base_dir: str):
        self.base_dir = os.path.abspath(base_dir)
        self.backup_root = os.path.join(self.base_dir, "backups")
        self.auto_backup_dir = os.path.join(self.backup_root, "auto_snapshots")
        self.manual_backup_dir = os.path.join(self.backup_root, "manual_snapshots")
        self.user_exports_dir = os.path.join(self.backup_root, "user_exports")
        self.max_snapshots_per_type = 5  # 系统快照自动与手动各自最多保留 5 份循环覆盖
        self.max_user_backups = 5        # 每位用户在主机最多保留 5 份独立工作区备份
        self._ensure_dirs()

    def _ensure_dirs(self):
        for d in [self.auto_backup_dir, self.manual_backup_dir, self.user_exports_dir]:
            os.makedirs(d, exist_ok=True)

    def _calc_checksum(self, filepath: str) -> str:
        """计算文件的 SHA-256 哈希值确保容灾快照完整未被损坏"""
        hasher = hashlib.sha256()
        with open(filepath, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        return hasher.hexdigest()

    def create_system_snapshot(self, tag: str = "auto", description: str = "") -> Dict[str, Any]:
        """创建全系统级原子容灾快照 (知识库、控制面板、拓扑、场景、配置)"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        target_dir = self.manual_backup_dir if tag == "manual" else self.auto_backup_dir
        snapshot_id = f"snapshot_{tag}_{timestamp}"
        snapshot_path = os.path.join(target_dir, snapshot_id)
        os.makedirs(snapshot_path, exist_ok=True)

        meta = {
            "snapshot_id": snapshot_id,
            "created_at": time.time(),
            "timestamp_str": timestamp,
            "type": tag,
            "description": description or f"全系统容灾备份 ({tag})",
            "files": {}
        }

        # 待备份的关键资产树
        dirs_to_copy = [
            ("knowledge_base", os.path.join(self.base_dir, "knowledge_base")),
            ("config", os.path.join(self.base_dir, "config"))
        ]

        for rel_name, src_dir in dirs_to_copy:
            if os.path.exists(src_dir):
                dest_dir = os.path.join(snapshot_path, rel_name)
                shutil.copytree(src_dir, dest_dir, dirs_exist_ok=True)
                # 记录文件校验和
                for root, _, files in os.walk(dest_dir):
                    for file in files:
                        full_f = os.path.join(root, file)
                        rel_f = os.path.relpath(full_f, snapshot_path)
                        meta["files"][rel_f] = self._calc_checksum(full_f)

        meta_file = os.path.join(snapshot_path, "snapshot_meta.json")
        with open(meta_file, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

        # 严格执行循环覆盖，自动与手动模式各自最多保留 5 份
        self._rotate_snapshots(tag)

        logger.info(f"全系统容灾快照创建成功: [{snapshot_id}] ({description})")
        return {"status": "ok", "snapshot_id": snapshot_id, "meta": meta}

    def _rotate_snapshots(self, tag: str):
        """快照循环覆盖淘汰：自动与手动各自最多保留 max_snapshots_per_type 份"""
        target_dir = self.manual_backup_dir if tag == "manual" else self.auto_backup_dir
        try:
            dirs = [os.path.join(target_dir, d) for d in os.listdir(target_dir)]
            dirs = [d for d in dirs if os.path.isdir(d)]
            dirs.sort(key=lambda x: os.path.getmtime(x))
            while len(dirs) > self.max_snapshots_per_type:
                oldest = dirs.pop(0)
                shutil.rmtree(oldest, ignore_errors=True)
                logger.info(f"已循环清理超出上限({self.max_snapshots_per_type}份)的旧快照: {os.path.basename(oldest)}")
        except Exception as e:
            logger.error(f"快照循环清理失败: {e}")

    def delete_system_snapshot(self, snapshot_id: str) -> bool:
        """从主机上物理删除指定的系统快照"""
        cleaned_id = os.path.basename(snapshot_id.strip())
        deleted = False
        for target_dir in [self.manual_backup_dir, self.auto_backup_dir]:
            p = os.path.join(target_dir, cleaned_id)
            if os.path.exists(p) and os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
                deleted = True
                logger.info(f"系统快照已安全物理删除: [{cleaned_id}]")
        return deleted

    def list_snapshots(self) -> List[Dict[str, Any]]:
        """获取所有可用快照列表 (最多返回最新 5 份自动与 5 份手动)"""
        snapshots = []
        for target_dir in [self.manual_backup_dir, self.auto_backup_dir]:
            if not os.path.exists(target_dir):
                continue
            for d in os.listdir(target_dir):
                snap_dir = os.path.join(target_dir, d)
                meta_file = os.path.join(snap_dir, "snapshot_meta.json")
                if os.path.exists(meta_file):
                    try:
                        with open(meta_file, "r", encoding="utf-8") as f:
                            meta = json.load(f)
                            snapshots.append(meta)
                    except Exception:
                        pass
        snapshots.sort(key=lambda x: x.get("created_at", 0), reverse=True)
        return snapshots

    def restore_system_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """完整恢复至指定的系统级容灾快照，并校验文件 SHA-256"""
        snap_path = None
        for target_dir in [self.manual_backup_dir, self.auto_backup_dir]:
            p = os.path.join(target_dir, snapshot_id)
            if os.path.exists(p) and os.path.isdir(p):
                snap_path = p
                break
        if not snap_path:
            raise ValueError(f"未找到快照: {snapshot_id}")

        meta_file = os.path.join(snap_path, "snapshot_meta.json")
        if not os.path.exists(meta_file):
            raise ValueError("快照元数据丢失")

        with open(meta_file, "r", encoding="utf-8") as f:
            meta = json.load(f)

        # 校验哈希完整性
        for rel_f, expected_hash in meta.get("files", {}).items():
            curr_f = os.path.join(snap_path, rel_f)
            if not os.path.exists(curr_f):
                raise ValueError(f"快照文件缺失: {rel_f}")
            actual_hash = self._calc_checksum(curr_f)
            if actual_hash != expected_hash:
                raise ValueError(f"快照文件损坏 (SHA-256 校验失败): {rel_f}")

        # 先在回滚前自动生成一份保护快照
        self.create_system_snapshot(tag="auto", description=f"回滚前系统状态保护快照 (目标: {snapshot_id})")

        # 覆写恢复 (安全保护当前生效的管理员凭据库 users.json)
        current_users_data = None
        current_users_path = os.path.join(self.base_dir, "config", "users.json")
        if os.path.exists(current_users_path):
            try:
                with open(current_users_path, "r", encoding="utf-8") as uf:
                    current_users_data = json.load(uf)
            except Exception:
                pass

        for key in ["knowledge_base", "config"]:
            src_part = os.path.join(snap_path, key)
            if os.path.exists(src_part):
                target_part = os.path.join(self.base_dir, key)
                shutil.copytree(src_part, target_part, dirs_exist_ok=True)

        # 若当前存在活跃用户凭据库，恢复/合并主管理员及当前各角色凭据，杜绝凭据丢失
        if current_users_data and os.path.exists(current_users_path):
            try:
                with open(current_users_path, "r", encoding="utf-8") as uf:
                    restored_users = json.load(uf)
                # 将当前的主管理员和 root 以及最新用户凭据合并保留
                for u, u_info in current_users_data.items():
                    if u_info.get("is_primary_admin") or u_info.get("is_system_root") or u not in restored_users:
                        restored_users[u] = u_info
                with open(current_users_path, "w", encoding="utf-8") as uf:
                    json.dump(restored_users, uf, ensure_ascii=False, indent=2)
                logger.info("已完成用户安全凭据表的保护性合并，确保管理员登录不中断。")
            except Exception as e_u:
                logger.warning(f"用户表安全合并告警: {e_u}")

        logger.info(f"系统已成功恢复至快照: {snapshot_id}")
        return {"status": "ok", "message": f"系统已成功恢复至快照 [{snapshot_id}]"}

    # ================= 跨用户专属数据交互与备份恢复 =================

    def get_user_backup_files(self, username: str) -> List[str]:
        """获取指定用户在主机上的所有备份文件 (按时间由旧到新排序)"""
        files = []
        if not os.path.exists(self.user_exports_dir):
            return files
        for f in os.listdir(self.user_exports_dir):
            if f.endswith(".json") and (f.startswith(f"{username}_") or f.startswith(f"pkg_{username}_")):
                files.append(os.path.join(self.user_exports_dir, f))
        files.sort(key=lambda x: os.path.getmtime(x))
        return files

    def export_user_package(self, username: str, user_profile: Dict[str, Any], include_kb_presets: bool = True, force_rotate: bool = False) -> Dict[str, Any]:
        """导出用户专属配置包并保存在主机上，严格执行最多5份上限与循环覆盖"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        safe_name = f"{username}_{timestamp}"
        filename = f"{safe_name}.json"
        dest_file = os.path.join(self.user_exports_dir, filename)
        idx_suffix = 1
        while os.path.exists(dest_file):
            safe_name = f"{username}_{timestamp}_{idx_suffix}"
            filename = f"{safe_name}.json"
            dest_file = os.path.join(self.user_exports_dir, filename)
            idx_suffix += 1

        user_files = self.get_user_backup_files(username)
        if len(user_files) >= self.max_user_backups and not force_rotate:
            return {
                "status": "quota_full",
                "count": len(user_files),
                "max_allowed": self.max_user_backups,
                "message": f"当前用户在主机的备份槽位已满 ({len(user_files)}/{self.max_user_backups})。建议先下载本地备份或清理旧备份，继续操作将自动循环覆盖最旧备份。"
            }

        # 若达到或超过上限且允许轮转，则淘汰最旧的一份
        while len(user_files) >= self.max_user_backups:
            oldest_file = user_files.pop(0)
            try:
                os.remove(oldest_file)
                logger.info(f"已自动循环覆盖用户 [{username}] 的最旧备份: {os.path.basename(oldest_file)}")
            except Exception as e:
                logger.warning(f"清理旧备份文件失败: {e}")

        # 获取当前系统的面板和场景
        panel_file = os.path.join(self.base_dir, "config", "control_panel_layout.json")
        panel_data = {}
        if os.path.exists(panel_file):
            try:
                with open(panel_file, "r", encoding="utf-8") as f:
                    panel_data = json.load(f)
            except Exception:
                pass

        presets_file = os.path.join(self.base_dir, "knowledge_base", "presets", "aesthetic_presets.json")
        presets_data = {}
        if include_kb_presets and os.path.exists(presets_file):
            try:
                with open(presets_file, "r", encoding="utf-8") as f:
                    presets_data = json.load(f)
            except Exception:
                pass

        package = {
            "format": "AI_MA_USER_DATA_PACKAGE",
            "version": "5.0",
            "package_id": safe_name,
            "filename": filename,
            "safe_name": safe_name,
            "exported_by": username,
            "exported_at": time.time(),
            "exported_at_str": timestamp,
            "user_profile": user_profile or {},
            "panel_layout": panel_data,
            "shared_presets": presets_data
        }

        dest_file = os.path.join(self.user_exports_dir, filename)
        with open(dest_file, "w", encoding="utf-8") as f:
            json.dump(package, f, ensure_ascii=False, indent=2)

        logger.info(f"用户工作区配置已成功备份至主机文件: [{filename}] (操作用户: {username})")
        return {
            "status": "ok",
            "package_id": safe_name,
            "safe_name": safe_name,
            "filename": filename,
            "package": package
        }

    def list_user_packages(self) -> List[Dict[str, Any]]:
        """扫描并列出主机上存储的所有用户备份文件 (名称全部脱敏无后缀)"""
        pkgs = []
        if not os.path.exists(self.user_exports_dir):
            return pkgs

        for fname in sorted(os.listdir(self.user_exports_dir), reverse=True):
            if not fname.endswith(".json"):
                continue
            fpath = os.path.join(self.user_exports_dir, fname)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                safe_name = fname[:-5] if fname.endswith(".json") else fname
                pkgs.append({
                    "filename": fname,
                    "safe_name": safe_name,
                    "exported_by": data.get("exported_by", "unknown"),
                    "exported_at": data.get("exported_at", 0),
                    "exported_at_str": data.get("exported_at_str", ""),
                    "size_bytes": os.path.getsize(fpath),
                    "preset_count": len(data.get("shared_presets", {})),
                    "group_count": len(data.get("panel_layout", {}).get("groups", []))
                })
            except Exception:
                continue
        return pkgs

    def get_user_package(self, identifier: str) -> Optional[Dict[str, Any]]:
        """读取主机上指定的用户备份文件 (支持带或不带 .json 后缀)"""
        fname = identifier.strip()
        if not fname.endswith(".json"):
            fname = f"{fname}.json"
        fpath = os.path.join(self.user_exports_dir, os.path.basename(fname))
        if os.path.exists(fpath):
            with open(fpath, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    def delete_user_package(self, identifier: str) -> bool:
        """从主机上删除指定的用户备份文件 (支持带或不带 .json 后缀)"""
        fname = identifier.strip()
        if not fname.endswith(".json"):
            fname = f"{fname}.json"
        fpath = os.path.join(self.user_exports_dir, os.path.basename(fname))
        if os.path.exists(fpath):
            os.remove(fpath)
            return True
        return False

    def import_user_package(self, package_data: Dict[str, Any], target_username: str, merge_mode: str = "merge") -> Dict[str, Any]:
        """
        将来自其他用户或备份的配置包导入到目标用户中
        merge_mode:
          - 'merge': 保留现有设置，将新预设与面板合并补充
          - 'overwrite': 完全覆写当前面板与预设
        """
        if package_data.get("format") != "AI_MA_USER_DATA_PACKAGE":
            raise ValueError("无效的用户配置包文件格式")

        source_user = package_data.get("exported_by", "unknown")
        shared_presets = package_data.get("shared_presets", {})
        panel_layout = package_data.get("panel_layout", {})

        # 1. 合并或覆写预设
        presets_file = os.path.join(self.base_dir, "knowledge_base", "presets", "aesthetic_presets.json")
        if shared_presets and os.path.exists(presets_file):
            with open(presets_file, "r", encoding="utf-8") as f:
                curr_presets = json.load(f)
            if merge_mode == "overwrite":
                curr_presets = shared_presets
            else:
                for k, v in shared_presets.items():
                    if k not in curr_presets:
                        curr_presets[k] = v
            with open(presets_file, "w", encoding="utf-8") as f:
                json.dump(curr_presets, f, ensure_ascii=False, indent=2)

        # 2. 合并或覆写面板布局
        panel_file = os.path.join(self.base_dir, "config", "control_panel_layout.json")
        if panel_layout and os.path.exists(panel_file):
            with open(panel_file, "r", encoding="utf-8") as f:
                curr_panel = json.load(f)
            if merge_mode == "overwrite":
                curr_panel = panel_layout
            else:
                existing_gids = {g.get("group_id") for g in curr_panel.get("groups", [])}
                for g in panel_layout.get("groups", []):
                    if g.get("group_id") not in existing_gids:
                        curr_panel.setdefault("groups", []).append(g)
            with open(panel_file, "w", encoding="utf-8") as f:
                json.dump(curr_panel, f, ensure_ascii=False, indent=2)

        logger.info(f"用户配置包已成功导入给 [{target_username}] (来源: [{source_user}], 模式: {merge_mode})")
        return {
            "status": "ok",
            "message": f"成功将 [{source_user}] 的配置包导入给当前用户，导入预设 {len(shared_presets)} 条。"
        }
