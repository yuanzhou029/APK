# -*- coding: utf-8 -*-
"""
AI-MA DMX 物理安全掩码与多源合并仲裁器 (DmxMerger & Safety Shield)
提供 HTP (最高值优先)、LTP (最新值优先)、Priority 权限级别划分与危险通道强制熔断拦截。
"""

import threading
import time
from typing import Dict, List, Any, Optional

class PriorityLevel:
    PANIC = 100       # 紧急安全/一键黑场/全场报警 (最高级)
    MANUAL_DESK = 80 # 实体控制台/灯光师推杆接管
    AI_CUE = 50      # AI 单场景或时序 Cue
    AI_MACRO = 30    # AI 背景走马灯/呼吸动态宏 (最低级)

class DmxMerger:
    def __init__(self, universe_count: int = 4):
        self.universe_count = universe_count
        self._lock = threading.RLock()
        
        # 激活的信号源缓存: {universe: {source_name: {"priority": int, "data": bytearray, "timestamp": float}}}
        self._sources: Dict[int, Dict[str, Dict[str, Any]]] = {u: {} for u in range(universe_count)}
        
        # 仲裁合成后的输出缓冲帧: {universe: bytearray(512)}
        self._final_output: Dict[int, bytearray] = {u: bytearray(512) for u in range(universe_count)}
        
        # 通道属性定义表 (用于 HTP / LTP 区分): {universe: {ch_1based: "dimmer" / "red" / ...}}
        self._channel_types: Dict[int, Dict[int, str]] = {u: {} for u in range(universe_count)}
        
        # 危险通道黑名单掩码: {universe: set([ch1, ch2...])}
        self._blocked_channels: Dict[int, set] = {u: set() for u in range(universe_count)}

    def configure_fixture_channels(self, universe: int, start_address: int, channel_defs: List[Dict[str, Any]]):
        """配置灯具通道类型及安全白名单"""
        with self._lock:
            if universe not in self._channel_types:
                self._channel_types[universe] = {}
                self._blocked_channels[universe] = set()
            
            for ch_item in channel_defs:
                offset = ch_item.get("ch", 1) - 1
                abs_ch = start_address + offset
                if 1 <= abs_ch <= 512:
                    ch_type = ch_item.get("type", "generic")
                    self._channel_types[universe][abs_ch] = ch_type
                    
                    is_safe = ch_item.get("is_safe", True)
                    if not is_safe:
                        self._blocked_channels[universe].add(abs_ch)

    def submit_frame(self, source_name: str, universe: int, dmx_data_512: bytearray, priority: int = PriorityLevel.AI_CUE):
        """提交信号源数据帧"""
        if universe not in self._sources:
            return
            
        with self._lock:
            # 严格克隆，防止外部引用污染
            cloned = bytearray(dmx_data_512[:512])
            self._sources[universe][source_name] = {
                "priority": priority,
                "data": cloned,
                "timestamp": time.time()
            }
            self._recalculate_universe(universe)

    def clear_source(self, source_name: str, universe: Optional[int] = None):
        """清除指定信号源"""
        with self._lock:
            universes_to_clear = [universe] if universe is not None else list(self._sources.keys())
            for u in universes_to_clear:
                if source_name in self._sources[u]:
                    del self._sources[u][source_name]
                    self._recalculate_universe(u)

    def _recalculate_universe(self, universe: int):
        """核心仲裁计算算法"""
        sources = self._sources.get(universe, {})
        if not sources:
            return

        out_frame = bytearray(512)
        
        # 获取当前最高优先级
        max_prio = max(s["priority"] for s in sources.values())
        
        # 筛选出处于当前最高优先级的所有源
        active_sources = [s for s in sources.values() if s["priority"] == max_prio]
        
        # 按通道逐一决策
        for ch in range(1, 513):
            # 1. 物理安全熔断：若通道在黑名单内且当前不是最高安全级别的 PANIC，强制归零
            if ch in self._blocked_channels.get(universe, set()) and max_prio < PriorityLevel.PANIC:
                out_frame[ch - 1] = 0
                continue
                
            ch_type = self._channel_types.get(universe, {}).get(ch, "generic")
            
            # 2. HTP 仲裁 (适用于亮度调光通道)
            if ch_type in ["dimmer", "white"]:
                max_val = max(s["data"][ch - 1] for s in active_sources)
                out_frame[ch - 1] = max_val
            # 3. LTP 仲裁 (适用于颜色、坐标运动、图案，按最新时间戳覆盖)
            else:
                latest_source = max(active_sources, key=lambda s: s["timestamp"])
                out_frame[ch - 1] = latest_source["data"][ch - 1]
                
        self._final_output[universe] = out_frame

    def get_final_frame(self, universe: int) -> bytearray:
        """获取仲裁计算完毕的安全输出帧"""
        with self._lock:
            return bytearray(self._final_output.get(universe, bytearray(512)))

    def has_active_sources(self, universe: int) -> bool:
        """检查指定 Universe 当前是否存在任何激活的信号源 (Cue, Macro, Manual Desk, Panic 等)"""
        with self._lock:
            return bool(self._sources.get(universe))

    def get_controlled_channels_mask(self, universe: int) -> bytearray:
        """
        获取指定 Universe 当前受控通道的活跃掩码 (bytearray of 512).
        当且仅当当前 Universe 存在有效激活的信号源时：
        - 若配置了灯具物理通道映射，则属于受控灯具通道的位置置为 1；
        - 若未配置具体通道类型映射（如未绑定拓扑），只要有信号源激活，则所有 512 通道均视为受控 (置 1)；
        - 若完全无信号源激活（无 Cue/Macro/Desk），则全 0，退让给其他槽位。
        保证暗场/关死/拉低推杆（电平 0）时掩码仍为 1，确保 0 值穿透写入共享内存槽位。
        """
        with self._lock:
            if not self._sources.get(universe):
                return bytearray(512)
            types_map = self._channel_types.get(universe)
            if types_map:
                mask = bytearray(512)
                for ch in types_map:
                    if 1 <= ch <= 512:
                        mask[ch - 1] = 1
                return mask
            else:
                return bytearray(b"\x01" * 512)
