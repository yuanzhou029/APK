# -*- coding: utf-8 -*-
"""
Art-Net 节点自动发现、连接测试与掉线看门狗模块 (NodeDiscovery v1.0)
用途：
1. ArtPollProber  —— 主动探测：向指定 IP（或广播地址）发送 ArtPoll，等待 ArtPollReply，
                     解析节点名称、端口数量、各端口 Universe、MAC、Style 等身份信息。
2. PassiveRegistry —— 被动登记：记录每个源 IP 的最近一次活动时间与观测到的 Universe，
                     用于"不打扰现场"的静默发现与在线时长统计。
3. OfflineWatchdog —— 掉线看门狗：按每个节点独立的策略（threshold/ignore/manual）判定掉线，
                     只产生"状态发生变化"的告警事件（去重），支持自动恢复事件。

【强制性安全约束 —— 现场安全红线】
本模块**绝对禁止**通过发送 ArtDmx（灯光数据）来探测设备是否在线：那会让现场灯具闪烁，
属于重大安全事故。探测/探活只允许使用以下两种手段：
    (1) ArtPoll 主动探测（发 ArtPoll，收 ArtPollReply）；
    (2) 被动流量观测（监听该 IP 是否在发送 ArtDmx，仅收听、绝不外发）。
因此本文件中不存在任何构造/发送 ArtDmx（OpCode 0x5000）的代码路径。

依赖：仅使用 Python 标准库 (socket / struct / threading / time / ipaddress / logging)。
"""

import ipaddress
import logging
import os
import socket
import struct
import subprocess
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("NodeDiscovery")

# -------------------------------------------------------------
# Art-Net 协议常量
# -------------------------------------------------------------
ARTNET_PORT = 6454                      # Art-Net 标准 UDP 端口
ARTNET_ID = b"Art-Net\x00"              # 报文标识 (8 字节)
OP_POLL = 0x2000                        # ArtPoll 操作码
OP_POLL_REPLY = 0x2100                  # ArtPollReply 操作码
PROT_VER = 0x000E                       # 协议版本 14 (Art-Net 4)
TALK_TO_ME_CHANGE = 0x02                # 仅在节点状态变化时回复，避免广播刷屏
MIN_POLL_REPLY_LEN = 239                # ArtPollReply 最小合法长度 (Art-Net 4 为 261)
MAX_SUBNET_HOSTS = 1024                 # 网段展开的最大主机数硬上限，防止误扫打爆网络
BROADCAST_ALL = "255.255.255.255"       # 全局广播地址
MAX_TRACKED_UNIVERSES = 128             # 单个源 IP 最多登记的 Universe 数量（防御异常节点）

# Style 字段 (偏移 206) 的可读名称
ARTNET_STYLE_NAMES = {
    0: "Node (DMX 节点)",
    1: "Controller (控制台)",
    2: "Media (媒体服务器)",
    3: "Route (路由)",
    4: "Backup (备份)",
    5: "Config (配置工具)",
    6: "Visual (可视化)",
}


# -------------------------------------------------------------
# 内部通用小工具：全部为防御式读取，越界一律返回默认值，绝不抛异常
# -------------------------------------------------------------
def _read_u8(data: bytes, offset: int) -> int:
    """安全读取 1 字节无符号整数，越界返回 0。"""
    if not data or offset < 0 or offset >= len(data):
        return 0
    return data[offset]


def _read_u16_le(data: bytes, offset: int) -> int:
    """安全读取 2 字节小端无符号整数，越界返回 0。"""
    if not data or offset < 0 or offset + 2 > len(data):
        return 0
    return struct.unpack_from("<H", data, offset)[0]


def _read_u16_be(data: bytes, offset: int) -> int:
    """安全读取 2 字节大端无符号整数，越界返回 0。"""
    if not data or offset < 0 or offset + 2 > len(data):
        return 0
    return struct.unpack_from(">H", data, offset)[0]


def _decode_text(raw: bytes) -> str:
    """把报文中的定长字符串安全解码为文本：截断到首个 NUL，非 ASCII 用替换字符兜底。"""
    if not raw:
        return ""
    cut = raw.split(b"\x00", 1)[0]
    try:
        return cut.decode("utf-8", errors="replace").strip()
    except Exception:
        return cut.decode("ascii", errors="replace").strip()


def _format_mac(raw: bytes) -> str:
    """把 6 字节 MAC 格式化为 'AA:BB:CC:DD:EE:FF'，长度不足返回空串。"""
    if not raw or len(raw) < 6:
        return ""
    return ":".join(f"{b:02X}" for b in raw[:6])


def _as_float(value: Any, default: float) -> float:
    """把配置值安全转换为 float，非法值返回默认值。"""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _empty_reply_result(ip: str = "", error: Optional[str] = None) -> Dict[str, Any]:
    """构造一份标准的 ArtPollReply 探测结果骨架（全部字段就位，便于调用方无脑取值）。"""
    return {
        "ip": ip,
        "reply": False,
        "node_name": "",
        "short_name": "",
        "num_ports": 0,
        "port_universes": [],
        "style": 0,
        "style_name": "",
        "mac": "",
        "rtt_ms": 0.0,
        "error": error,
    }


def build_artpoll_packet() -> bytes:
    """
    构造 14 字节的 ArtPoll 请求包（本模块唯一允许主动外发的报文类型）。

    结构：ID(8) + OpCode 0x2000 小端(2) + ProtVer 0x000E 大端(2) + TalkToMe(1) + Priority(1)
    """
    return (
        ARTNET_ID
        + struct.pack("<H", OP_POLL)            # 8-9   OpCode 小端
        + struct.pack(">H", PROT_VER)           # 10-11 ProtVer 大端
        + struct.pack("B", TALK_TO_ME_CHANGE)   # 12    TalkToMe = 0x02
        + struct.pack("B", 0x00)                # 13    Priority = 0x00
    )


def parse_artpoll_reply(data: bytes, src_ip: str = "") -> Dict[str, Any]:
    """
    防御式解析 ArtPollReply 应答包，返回与 probe() 一致的结果字典。

    :param data:   UDP 收到的原始字节串（长度可能不足 239，必须安全兜底）
    :param src_ip: 报文来源 IP（写入 reply_ip；传入时也作为 ip 字段的兜底值）
    :return: {"ip","reply","node_name","short_name","num_ports","port_universes",
              "style","style_name","mac","rtt_ms","error", ... 若干补充字段}

    解析规则：
    - 非 Art-Net 报文 / OpCode 不是 0x2100 → reply=False 并给出 error；
    - 长度不足 239 → 仍尽力解析已有字段，reply=True（确实收到了应答），error 记录长度告警；
    - 名称字段按 NUL 截断并以 errors="replace" 解码；
    - 任何异常都被吞掉并写入 error，绝不向上抛出（畸形包不得导致服务崩溃）。
    """
    result = _empty_reply_result(ip=src_ip)
    try:
        if not data:
            result["error"] = "空报文"
            return result

        if len(data) < len(ARTNET_ID) or not data.startswith(ARTNET_ID):
            result["error"] = "非 Art-Net 报文（标识不匹配）"
            return result

        if len(data) < 10:
            result["error"] = f"报文过短（{len(data)} 字节），无法读取 OpCode"
            return result

        opcode = _read_u16_le(data, 8)
        if opcode != OP_POLL_REPLY:
            result["error"] = f"OpCode 不是 ArtPollReply(0x2100)，实际为 0x{opcode:04X}"
            return result

        # --- 报文内自述的 IP 与端口 ---
        reply_ip = ".".join(str(b) for b in data[10:14]) if len(data) >= 14 else ""
        result["reply_ip"] = reply_ip or src_ip or ""
        result["ip"] = src_ip or reply_ip
        result["reply"] = True

        if len(data) < MIN_POLL_REPLY_LEN:
            result["error"] = (f"ArtPollReply 长度不足（{len(data)} < {MIN_POLL_REPLY_LEN}），"
                               f"仅解析已到达的字段")

        # --- 网络参数与名称 ---
        result["port"] = _read_u16_le(data, 14)
        result["vers_info"] = _read_u16_be(data, 16)
        result["net_switch"] = _read_u8(data, 18)
        result["sub_switch"] = _read_u8(data, 19)
        result["oem"] = _read_u16_be(data, 20)
        result["esta_man"] = _read_u16_le(data, 24)

        result["short_name"] = _decode_text(data[26:44])     # ShortName (18 字节)
        result["node_name"] = _decode_text(data[44:108])     # LongName  (64 字节)
        result["node_report"] = _decode_text(data[108:172])  # NodeReport(64 字节)

        # --- 端口数量与各端口 Universe ---
        num_ports_raw = _read_u16_be(data, 172)
        result["num_ports"] = num_ports_raw
        result["port_types"] = list(data[174:178]) if len(data) >= 178 else [0, 0, 0, 0]

        net_switch = result["net_switch"]
        sub_switch = result["sub_switch"]
        sw_out = list(data[190:194]) if len(data) >= 194 else [0, 0, 0, 0]

        universes: List[int] = []
        # 仅取 port_index < num_ports 的端口，且本布局最多承载 4 个端口
        usable = min(max(num_ports_raw, 0), len(sw_out))
        for idx in range(usable):
            universe = (net_switch << 8) | (sub_switch << 4) | (sw_out[idx] & 0x0F)
            universes.append(int(universe))
        result["port_universes"] = universes

        # --- 身份信息 ---
        result["style"] = _read_u8(data, 206)
        result["style_name"] = ARTNET_STYLE_NAMES.get(result["style"], f"未知样式({result['style']})")
        result["mac"] = _format_mac(data[207:213])           # MAC (6 字节)
        result["bind_index"] = _read_u8(data, 217)

        return result
    except Exception as e:  # 兜底：任何畸形包都不得让调用方崩溃
        result["reply"] = False
        result["error"] = f"解析 ArtPollReply 异常：{e}"
        return result


def expand_subnet(base_ip: str, prefix_len: int, max_hosts: int = MAX_SUBNET_HOSTS) -> List[str]:
    """
    用 ipaddress 模块把网段展开为可用主机 IP 列表（不含网络号与广播地址）。

    :param base_ip:    基准 IP，例如 "192.168.1.0"（host 位非 0 时按 strict=False 归整）
    :param prefix_len: 前缀长度，例如 24
    :param max_hosts:  允许展开的最大主机数，默认 1024
    :raises ValueError: 参数非法、非 IPv4，或主机数超过 max_hosts（防止误扫整个 B 段打爆网络）
    """
    try:
        network = ipaddress.ip_network(f"{base_ip}/{int(prefix_len)}", strict=False)
    except Exception as e:
        raise ValueError(f"无效的网段参数：{base_ip}/{prefix_len}（{e}）") from e

    if network.version != 4:
        raise ValueError(f"仅支持 IPv4 网段展开，收到：{base_ip}/{prefix_len}")

    # 先按数量判断，再实体化列表：避免 /8 这类大网段在检查前就把内存吃爆
    if network.prefixlen >= 31:
        host_count = network.num_addresses          # /31、/32 无传统网络号/广播号
    else:
        host_count = max(network.num_addresses - 2, 0)

    if host_count > int(max_hosts):
        raise ValueError(
            f"网段 {base_ip}/{prefix_len} 含 {host_count} 个主机地址，"
            f"超过上限 {int(max_hosts)}，已拒绝展开以防误扫（如确需请显式传入更大的 max_hosts）"
        )

    if network.prefixlen >= 31:
        return [str(host) for host in network]
    return [str(host) for host in network.hosts()]


class ArtPollProber:
    """
    Art-Net ArtPoll 主动探测器。

    仅使用 ArtPoll / ArtPollReply 完成探测，**绝不发送 ArtDmx**（避免现场灯具闪烁）。
    每次 probe 使用独立的临时 UDP socket（打开 SO_BROADCAST 与 SO_REUSEADDR），
    发完即收，超时后必须在 finally 中关闭 socket，确保不残留句柄。
    由于每次调用各自持有 socket，本类可被多线程并发调用。
    """

    def __init__(self, port: int = 6454, timeout: float = 1.5):
        """
        :param port:    Art-Net UDP 端口，默认 6454
        :param timeout: 等待 ArtPollReply 的超时时间（秒），默认 1.5
        """
        self.port = int(port)
        self.timeout = max(0.05, _as_float(timeout, 1.5))
        logger.debug(f"ArtPollProber 初始化：端口={self.port}，超时={self.timeout}s")

    # ---------------------------------------------------------
    # 内部工具
    # ---------------------------------------------------------
    @staticmethod
    def _is_broadcast_target(ip: str) -> bool:
        """判断目标是否为广播地址（全局广播或以 .255 结尾的子网广播）。"""
        if not ip:
            return False
        return ip == BROADCAST_ALL or ip.endswith(".255")

    def _accept_source(self, target_ip: str, src_ip: str) -> bool:
        """校验应答来源：单播探测只接受目标 IP 的回复；广播探测接受任意来源。"""
        if src_ip == target_ip:
            return True
        return self._is_broadcast_target(target_ip)

    def _open_socket(self) -> socket.socket:
        """创建并配置一次性探测用 UDP socket。"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(self.timeout)
        return sock

    # ---------------------------------------------------------
    # 对外接口
    # ---------------------------------------------------------
    def probe(self, ip: str) -> Dict[str, Any]:
        """
        向单个 IP 发送 ArtPoll 并等待 ArtPollReply。

        :param ip: 目标节点 IP（也可以是广播地址，如 "255.255.255.255" 或 "192.168.1.255"）
        :return: {"ip": 探测目标, "reply": bool, "node_name": str, "short_name": str,
                  "num_ports": int, "port_universes": [int, ...], "style": int,
                  "style_name": str, "mac": str, "rtt_ms": float, "error": str|None,
                  "reply_ip": 实际应答 IP, "node_report"/"oem"/"bind_index" 等补充字段}
                 未应答时 reply=False，error 说明原因，绝不抛异常。
        """
        result = _empty_reply_result(ip=ip, error=None)
        sock: Optional[socket.socket] = None
        started = time.monotonic()

        try:
            sock = self._open_socket()
            sock.sendto(build_artpoll_packet(), (ip, self.port))

            deadline = started + self.timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                sock.settimeout(remaining)
                try:
                    data, addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                except OSError as e:
                    result["error"] = f"接收 ArtPollReply 失败：{e}"
                    break

                # 过滤：只认合法的 ArtPollReply，其余（例如别人回的 ArtDmx）直接丢弃
                if not data or len(data) < 10 or not data.startswith(ARTNET_ID):
                    continue
                if _read_u16_le(data, 8) != OP_POLL_REPLY:
                    continue

                src_ip = addr[0] if addr else ip
                if not self._accept_source(ip, src_ip):
                    continue

                parsed = parse_artpoll_reply(data, src_ip=src_ip)
                parsed["ip"] = ip
                parsed["reply"] = True
                parsed["reply_ip"] = src_ip
                parsed["rtt_ms"] = round((time.monotonic() - started) * 1000.0, 2)
                if parsed.get("error"):
                    logger.warning(f"节点 {ip} 的 ArtPollReply 存在异常但仍判定为在线：{parsed['error']}")
                return parsed

            if result["error"] is None:
                result["error"] = (f"{self.timeout:.2f}s 内未收到 ArtPollReply"
                                   f"（节点可能不在线、IP 有误或屏蔽了单播探测）")
            logger.debug(f"ArtPoll 探测 {ip}:{self.port} 无应答：{result['error']}")
            return result

        except Exception as e:
            result["reply"] = False
            result["error"] = f"探测 {ip} 失败：{e}"
            logger.debug(f"ArtPoll 探测 {ip}:{self.port} 异常：{e}")
            return result
        finally:
            # 硬性要求：无论成功失败都必须关闭临时 socket
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

    def scan(self, targets: List[str]) -> List[Dict[str, Any]]:
        """
        对一组 IP 逐一 probe，返回结果列表。

        :param targets: IP 字符串列表（可由 expand_subnet 生成）
        :return: 与 targets 顺序一致的探测结果列表；无应答者以 reply=False 项保留，
                 便于前端一次性展示"在线/离线"两态。单个 IP 探测异常不会中断整轮扫描。
        """
        results: List[Dict[str, Any]] = []
        target_list = list(targets or [])
        for ip in target_list:
            try:
                results.append(self.probe(ip))
            except Exception as e:  # probe 已自带兜底，此处为最后一道保险
                item = _empty_reply_result(ip=str(ip), error=f"探测异常：{e}")
                results.append(item)

        alive = sum(1 for r in results if r.get("reply"))
        logger.info(f"ArtPoll 批量探测完成：目标 {len(target_list)} 个，应答 {alive} 个")
        return results

    def scan_broadcast(self, broadcast_ip: str = BROADCAST_ALL) -> List[Dict[str, Any]]:
        """
        额外方法：向广播地址发送一次 ArtPoll，收集超时窗口内所有应答节点（整网段自动发现）。

        :param broadcast_ip: 广播地址，默认 "255.255.255.255"
        :return: 去重后的节点信息列表（按 (来源 IP, MAC) 去重，同一节点的多个 BindIndex 只保留首个）
        """
        nodes: List[Dict[str, Any]] = []
        seen = set()
        sock: Optional[socket.socket] = None
        started = time.monotonic()

        try:
            sock = self._open_socket()
            sock.sendto(build_artpoll_packet(), (broadcast_ip, self.port))
            deadline = started + self.timeout

            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                sock.settimeout(remaining)
                try:
                    data, addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                except OSError as e:
                    logger.warning(f"广播发现接收异常：{e}")
                    break

                if not data or len(data) < 10 or not data.startswith(ARTNET_ID):
                    continue
                if _read_u16_le(data, 8) != OP_POLL_REPLY:
                    continue

                src_ip = addr[0] if addr else ""
                parsed = parse_artpoll_reply(data, src_ip=src_ip)
                key = (src_ip, parsed.get("mac", ""), parsed.get("bind_index", 0))
                if key in seen:
                    continue
                seen.add(key)
                parsed["reply"] = True
                parsed["rtt_ms"] = round((time.monotonic() - started) * 1000.0, 2)
                nodes.append(parsed)

            logger.info(f"ArtPoll 广播发现完成：广播地址 {broadcast_ip}，发现节点 {len(nodes)} 个")
        except Exception as e:
            logger.warning(f"ArtPoll 广播发现失败（{broadcast_ip}）：{e}")
        finally:
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass

        return nodes


class PassiveRegistry:
    """
    被动发现登记表：记录每个源 IP 的最近一次活动时间与观测到的 Universe。

    只做"收听登记"，绝不产生任何外发流量，因此不会影响现场灯具。
    内部所有读写均由 threading.RLock 保护，可供接收线程与前端查询线程并发使用。
    """

    def __init__(self, stale_sec: float = 60.0):
        """
        :param stale_sec: 超过该秒数未再观测到流量即标记为 stale（陈旧/可能已掉线），默认 60
        """
        self.stale_sec = max(0.0, _as_float(stale_sec, 60.0))
        self._lock = threading.RLock()
        # ip -> {"last_seen": 单调时钟, "last_seen_ms": 墙钟毫秒, "universes": [int, ...]}
        self._table: Dict[str, Dict[str, Any]] = {}

    def observe(self, ip: str, universe: Optional[int] = None, now: Optional[float] = None) -> None:
        """
        登记一次被动观测（例如收到了某 IP 发来的 ArtDmx 帧）。

        :param ip:       源 IP
        :param universe: 该帧的 Universe（可为 None，表示只登记活动不登记宇宙）
        :param now:      单调时钟时间戳；默认取 time.monotonic()，测试可注入
        """
        if not ip:
            return

        ts = time.monotonic() if now is None else _as_float(now, time.monotonic())
        wall_ms = int(time.time() * 1000)

        u: Optional[int] = None
        if universe is not None:
            try:
                u = int(universe)
            except (TypeError, ValueError):
                u = None

        with self._lock:
            item = self._table.get(ip)
            if item is None:
                item = {"last_seen": ts, "last_seen_ms": wall_ms, "universes": []}
                self._table[ip] = item
            item["last_seen"] = ts
            item["last_seen_ms"] = wall_ms
            if u is not None and u not in item["universes"]:
                item["universes"].append(u)
                # 防御异常节点狂刷 Universe 导致内存无界增长
                if len(item["universes"]) > MAX_TRACKED_UNIVERSES:
                    del item["universes"][0]

    def snapshot(self) -> List[Dict[str, Any]]:
        """
        返回全部登记项的当前快照，按最近活动时间由新到旧排序。

        :return: [{"ip": str, "last_seen_ms": int(墙钟毫秒时间戳), "age_sec": float(距上次活动秒数),
                   "universes": [int, ...], "stale": bool}, ...]
        """
        now = time.monotonic()
        with self._lock:
            items = []
            for ip, item in self._table.items():
                age = max(0.0, now - item["last_seen"])
                items.append({
                    "ip": ip,
                    "last_seen_ms": int(item["last_seen_ms"]),
                    "age_sec": round(age, 3),
                    "universes": sorted(item["universes"]),
                    "stale": age > self.stale_sec,
                })
        items.sort(key=lambda x: x["age_sec"])
        return items

    def forget(self, ip: str) -> None:
        """移除某个 IP 的登记记录（例如确认设备已下线或 IP 变更）。"""
        if not ip:
            return
        with self._lock:
            self._table.pop(ip, None)
        logger.debug(f"被动登记表已移除：{ip}")


def ping_host(ip: str, timeout_sec: float = 1.0) -> bool:
    """
    用系统 ping 命令做一次 ICMP 可达性探测。

    为什么用子进程而不是原生 ICMP：Windows 上发原始 ICMP 需要管理员权限，
    而本系统要求能以普通用户身份双击启动，因此退回调用系统自带的 ping。
    ping 是**无副作用**的探测——绝不会像发 ArtDmx 那样让现场灯具闪一下。

    :return: True 表示对端可达
    """
    if not ip:
        return False
    try:
        if os.name == "nt":
            cmd = ["ping", "-n", "1", "-w", str(int(max(0.2, timeout_sec) * 1000)), ip]
        else:
            cmd = ["ping", "-c", "1", "-W", str(max(1, int(round(timeout_sec)))), ip]
        proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              timeout=timeout_sec + 1.5)
        return proc.returncode == 0
    except Exception as e:
        logger.debug(f"ping {ip} 失败：{e}")
        return False


class LivenessProbe:
    """
    主动存活探测调度器。

    轮询线程每秒调用一次 tick()，本类负责按各自节奏对节点做**非侵入式**探测：
      · liveness_source == "artpoll"：每 poll_interval_sec 秒发一次 ArtPoll，收到
        ArtPollReply 即记一次 artpoll 心跳；
      · liveness_source == "ping"：每 ping_interval_sec 秒做一次 ICMP 探测，可达即记
        ping 心跳；
      · liveness_source == "artdmx"：不做主动探测，只依赖被动观测到的回传流量。

    **绝不发送 ArtDmx 来探测**：那会让现场灯具闪一下，是明确禁止的做法。
    """

    def __init__(self, watchdog, prober=None, ip_resolver=None,
                 poll_interval_sec: float = 10.0, ping_interval_sec: float = 15.0,
                 clock=time.monotonic):
        """
        :param watchdog:        OfflineWatchdog 实例
        :param prober:          ArtPollProber 实例；None 时延迟到首次需要时再建
        :param ip_resolver:     可调用对象，返回 {node_id: ip}；用于把心跳打到正确节点
        :param poll_interval_sec: ArtPoll 探测间隔
        :param ping_interval_sec: ICMP 探测间隔
        """
        self.watchdog = watchdog
        self._prober = prober
        self.ip_resolver = ip_resolver or (lambda: {})
        self.poll_interval_sec = max(1.0, poll_interval_sec)
        self.ping_interval_sec = max(1.0, ping_interval_sec)
        self.clock = clock
        self._last_poll = 0.0
        self._last_ping = 0.0
        self.stats = {"artpoll_sent": 0, "artpoll_replied": 0, "ping_sent": 0, "ping_ok": 0}
        self._lock = threading.RLock()

    @property
    def prober(self):
        if self._prober is None:
            self._prober = ArtPollProber()
        return self._prober

    def tick(self) -> Dict[str, int]:
        """
        轮询一次；到达各自间隔才真正发起探测，因此可以每秒安全调用。

        :return: 本轮产生的 {"artpoll": 命中数, "ping": 命中数}
        """
        now = self.clock()
        hits = {"artpoll": 0, "ping": 0}

        status = self.watchdog.status()
        ipmap = self.ip_resolver() or {}
        if not ipmap:
            return hits

        # 只探测仍处于 threshold 模式的节点
        targets = {}
        for node_id, st in status.items():
            if st.get("mode") != "threshold":
                continue
            ip = ipmap.get(node_id)
            if ip:
                targets[node_id] = (ip, st.get("liveness_source"))

        needs_poll = [n for n, (ip, src) in targets.items() if src == "artpoll"]
        needs_ping = [n for n, (ip, src) in targets.items() if src == "ping"]

        if needs_poll and (now - self._last_poll) >= self.poll_interval_sec:
            self._last_poll = now
            for node_id in needs_poll:
                ip = targets[node_id][0]
                try:
                    res = self.prober.probe(ip)
                except Exception as e:
                    logger.debug(f"ArtPoll 存活探测异常（{ip}）：{e}")
                    continue
                with self._lock:
                    self.stats["artpoll_sent"] += 1
                if res.get("reply"):
                    self.watchdog.heartbeat(node_id, "artpoll")
                    hits["artpoll"] += 1
                    with self._lock:
                        self.stats["artpoll_replied"] += 1

        if needs_ping and (now - self._last_ping) >= self.ping_interval_sec:
            self._last_ping = now
            for node_id in needs_ping:
                ip = targets[node_id][0]
                with self._lock:
                    self.stats["ping_sent"] += 1
                if ping_host(ip):
                    self.watchdog.heartbeat(node_id, "ping")
                    hits["ping"] += 1
                    with self._lock:
                        self.stats["ping_ok"] += 1

        return hits


class OfflineWatchdog:
    """
    设备掉线看门狗：按每个节点独立的策略判定掉线，并只产生"状态发生变化"的告警事件。

    策略字段：
        mode            "threshold"（阈值判定）| "ignore"（永不报警）| "manual"（人工标记）
        liveness_source "artpoll"（主动探测有应答，推荐）| "artdmx"（被动观测到该 IP 回传的灯光数据）
                        | "ping"（ICMP 可达）
        threshold_sec   超过该秒数未收到对应来源心跳即判定掉线
        grace_period_sec 注册后的宽限期：距注册不足该秒数时一律不报警（避免启动瞬间误报）
        alarm_when_never_seen
                        True 时，连一次心跳都没收到过也算掉线；默认 False。
                        这是本模块最重要的安全设计：调音台通常只"发"不"收"，
                        若把"从未收到回传"直接判为掉线，会让每一台正常解码器在阈值后
                        集体误报，运维人员很快就会对告警脱敏，反而失去告警意义。
                        因此默认报"未监测"（unknown），由人工确认或改用 artpoll/ping 后
                        才进入真实的在线/掉线二值判定。
        severity        "warning" | "critical"，写入事件供前端分级展示
        actions         ["log","banner","toast"]，写入事件供调用方执行动作
        auto_recover    True 时恢复后产生 "recovered" 事件并附带离线时长

    说明：任一来源的心跳都会刷新 last_seen（更宽容，避免误报）；status() 始终反映
    事实上的在线状态，auto_recover=False 只抑制"恢复事件"的产生，不锁存离线状态。
    所有内部读写均由 threading.RLock 保护，可被接收线程与轮询线程并发调用。
    """

    VALID_MODES = ("threshold", "ignore", "manual")
    VALID_SOURCES = ("artpoll", "artdmx", "ping")

    def __init__(self, clock=time.monotonic):
        """
        :param clock: 单调时钟函数，默认 time.monotonic；测试可注入假时钟
        """
        self.clock = clock
        self._lock = threading.RLock()
        # node_id -> 状态与策略
        self._nodes: Dict[str, Dict[str, Any]] = {}

    # ---------------------------------------------------------
    # 内部工具
    # ---------------------------------------------------------
    def _normalize_policy(self, policy: Any) -> Dict[str, Any]:
        """把外部策略字典规整为内部安全格式（缺失/非法字段一律回退默认值）。"""
        src = policy if isinstance(policy, dict) else {}

        mode = str(src.get("mode", "threshold")).lower()
        if mode not in self.VALID_MODES:
            logger.warning(f"未知的看门狗模式 {mode!r}，已回退为 threshold")
            mode = "threshold"

        source = str(src.get("liveness_source", "artpoll")).lower()
        if source not in self.VALID_SOURCES:
            logger.warning(f"未知的存活来源 {source!r}，已回退为 artpoll")
            source = "artpoll"

        raw_actions = src.get("actions", ["log"])
        if isinstance(raw_actions, (list, tuple)):
            actions = [str(a) for a in raw_actions]
        elif raw_actions is None:
            actions = []
        else:
            actions = [str(raw_actions)]

        severity = str(src.get("severity", "warning")).lower()
        if severity not in ("warning", "critical"):
            severity = "warning"

        return {
            "mode": mode,
            "liveness_source": source,
            "threshold_sec": max(0.0, _as_float(src.get("threshold_sec", 5.0), 5.0)),
            "grace_period_sec": max(0.0, _as_float(src.get("grace_period_sec", 2.0), 2.0)),
            "alarm_when_never_seen": bool(src.get("alarm_when_never_seen", False)),
            "severity": severity,
            "actions": actions,
            "auto_recover": bool(src.get("auto_recover", True)),
        }

    # ---------------------------------------------------------
    # 对外接口
    # ---------------------------------------------------------
    def register_node(self, node_id: str, policy: Dict[str, Any]) -> None:
        """
        注册（或覆盖）一个节点的监控策略；注册时刻同时作为初始心跳与宽限期起点。

        :param node_id: 节点唯一标识（建议用 IP 或 IP:Universe）
        :param policy:  策略字典，见类文档；非法字段自动回退默认值
        """
        if not node_id:
            return

        now = self.clock()
        norm = self._normalize_policy(policy)
        with self._lock:
            existed = node_id in self._nodes
            self._nodes[node_id] = {
                "policy": norm,
                "registered_at": now,
                "last_seen": now,                       # 任一来源的最近活动
                "last_seen_by_source": {},              # source -> 单调时钟
                "manual_offline": False,
                "offline": False,
                "offline_since": None,
            }
        logger.info(f"看门狗{'更新' if existed else '注册'}节点 [{node_id}]："
                    f"模式={norm['mode']}，存活来源={norm['liveness_source']}，"
                    f"阈值={norm['threshold_sec']}s，宽限={norm['grace_period_sec']}s")

    def unregister_node(self, node_id: str) -> None:
        """注销节点，停止对其的一切掉线判定。"""
        with self._lock:
            removed = self._nodes.pop(node_id, None)
        if removed is not None:
            logger.info(f"看门狗已注销节点 [{node_id}]")

    def heartbeat(self, node_id: str, source: str = "artdmx") -> None:
        """
        收到该节点心跳/数据帧时调用。

        :param node_id: 节点标识
        :param source:  "artdmx"（被动观测到灯光数据）或 "artpoll"（主动探测有应答）
        说明：任一来源都会刷新 last_seen；同时按来源分别记录，供 threshold 模式精确判定。
        """
        src = str(source or "artdmx").lower()
        if src not in self.VALID_SOURCES:
            src = "artdmx"

        now = self.clock()
        with self._lock:
            entry = self._nodes.get(node_id)
            if entry is None:
                # 未注册节点的心跳直接忽略，避免隐式创建监控项
                logger.debug(f"忽略未注册节点 [{node_id}] 的心跳（来源 {src}）")
                return
            entry["last_seen"] = now
            entry["last_seen_by_source"][src] = now

    def set_manual_state(self, node_id: str, offline: bool) -> None:
        """
        手动模式下手动标记掉线/恢复；下一次 evaluate() 会依据状态变化产生对应事件。

        :param node_id: 节点标识
        :param offline: True 表示人工确认掉线，False 表示人工确认恢复
        """
        with self._lock:
            entry = self._nodes.get(node_id)
            if entry is None:
                logger.debug(f"忽略未注册节点 [{node_id}] 的人工标记")
                return
            entry["manual_offline"] = bool(offline)
        logger.info(f"人工标记节点 [{node_id}] 为 {'掉线' if offline else '在线'}")

    def evaluate(self, now: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        轮询一次，返回**状态发生变化**的告警事件列表（状态未变化时不重复产生事件）。

        :param now: 单调时钟时间戳；默认取注入的 clock()
        :return: [{"node_id": str, "event": "offline"|"recovered", "severity": str,
                   "offline_sec": float|None, "reason": str, "actions": [str, ...]}, ...]

        判定规则：
        - mode == "ignore"：永不报警；
        - mode == "manual"：只依据 set_manual_state 的标记报警；
        - mode == "threshold"：仅以 liveness_source 对应来源的最后心跳为基准，
          且距注册时间已超过 grace_period_sec 宽限期，静默超过 threshold_sec 才报警。
          **该来源从未产生过任何心跳时，节点状态为"未监测"（unknown），不报警**；
          只有策略显式设置 alarm_when_never_seen=True，才以注册时刻为基准报警。
        - offline 事件的 offline_sec 为触发时的静默时长（manual 模式为 0.0）；
          recovered 事件的 offline_sec 为本次掉线持续时长。
        """
        t = self.clock() if now is None else _as_float(now, self.clock())
        events: List[Dict[str, Any]] = []

        with self._lock:
            for node_id, entry in self._nodes.items():
                policy = entry["policy"]
                mode = policy["mode"]

                # ---- 1. ignore 模式：完全不参与判定 ----
                if mode == "ignore":
                    continue

                # ---- 2. 计算期望状态 ----
                if mode == "manual":
                    should_offline = bool(entry["manual_offline"])
                    reason = "人工标记为掉线" if should_offline else "人工标记为恢复在线"
                    silent_sec = 0.0
                else:
                    source = policy["liveness_source"]
                    last_src = entry["last_seen_by_source"].get(source)
                    grace_ok = (t - entry["registered_at"]) >= policy["grace_period_sec"]

                    if last_src is None:
                        # 从未收到过该来源的心跳：既可能是真掉线，也可能是该判据
                        # 根本不适配这台设备。默认按"未监测"处理，绝不误报。
                        unseen_sec = max(0.0, t - entry["registered_at"])
                        should_offline = (policy["alarm_when_never_seen"]
                                          and grace_ok
                                          and unseen_sec > policy["threshold_sec"])
                        silent_sec = unseen_sec
                        if should_offline:
                            reason = (f"自注册起 {unseen_sec:.1f}s 从未收到 "
                                      f"{source.upper()} 心跳（已按策略要求报警）")
                        else:
                            reason = f"尚未收到 {source.upper()} 心跳，状态未监测"
                    else:
                        silent_sec = max(0.0, t - last_src)
                        should_offline = silent_sec > policy["threshold_sec"] and grace_ok
                        if should_offline:
                            reason = (f"超过阈值 {policy['threshold_sec']}s 未收到 "
                                      f"{source.upper()} 心跳（已静默 {silent_sec:.1f}s）")
                        else:
                            reason = f"{source.upper()} 心跳正常"

                was_offline = bool(entry["offline"])

                # ---- 3. 只在状态翻转时产生事件（天然去重） ----
                if should_offline and not was_offline:
                    entry["offline"] = True
                    entry["offline_since"] = t
                    events.append({
                        "node_id": node_id,
                        "event": "offline",
                        "severity": policy["severity"],
                        "offline_sec": round(silent_sec, 3),
                        "reason": reason,
                        "actions": list(policy["actions"]),
                    })
                    logger.warning(f"【掉线告警】节点 [{node_id}] 判定掉线：{reason}")

                elif (not should_offline) and was_offline:
                    offline_since = entry["offline_since"]
                    duration = None if offline_since is None else round(max(0.0, t - offline_since), 3)
                    entry["offline"] = False
                    entry["offline_since"] = None
                    if policy["auto_recover"]:
                        events.append({
                            "node_id": node_id,
                            "event": "recovered",
                            "severity": policy["severity"],
                            "offline_sec": duration,
                            "reason": f"节点已恢复在线（本次掉线 {duration}s）"
                                      if duration is not None else "节点已恢复在线",
                            "actions": list(policy["actions"]),
                        })
                        logger.info(f"【掉线恢复】节点 [{node_id}] 已恢复在线，本次离线 {duration}s")

        return events

    def status(self) -> Dict[str, Any]:
        """
        返回全部节点的当前在线状态快照（以 node_id 为键），供前端轮询显示。

        :return: {node_id: {"node_id","state","online","mode","liveness_source","severity",
                            "actions","auto_recover","manual_offline","last_seen_age_sec",
                            "source_age_sec","offline_sec","never_seen"}, ...}
                 state 取值 "online" / "offline" / "unknown"；
                 online 为 None 表示状态未知（从未收到该来源心跳），前端应显示为"未监测"。
        """
        t = self.clock()
        snapshot: Dict[str, Any] = {}
        with self._lock:
            for node_id, entry in self._nodes.items():
                policy = entry["policy"]
                source = policy["liveness_source"]
                last_src = entry["last_seen_by_source"].get(source)
                offline = bool(entry["offline"])
                offline_since = entry["offline_since"]
                never_seen = last_src is None

                if policy["mode"] == "ignore":
                    state = "unknown"
                elif offline:
                    state = "offline"
                elif never_seen and policy["mode"] == "threshold":
                    state = "unknown"
                else:
                    state = "online"

                snapshot[node_id] = {
                    "node_id": node_id,
                    "state": state,
                    "online": None if state == "unknown" else (state == "online"),
                    "never_seen": never_seen,
                    "mode": policy["mode"],
                    "liveness_source": source,
                    "severity": policy["severity"],
                    "actions": list(policy["actions"]),
                    "auto_recover": policy["auto_recover"],
                    "alarm_when_never_seen": policy["alarm_when_never_seen"],
                    "threshold_sec": policy["threshold_sec"],
                    "grace_period_sec": policy["grace_period_sec"],
                    "manual_offline": bool(entry["manual_offline"]),
                    "last_seen_age_sec": round(max(0.0, t - entry["last_seen"]), 3),
                    "source_age_sec": None if last_src is None else round(max(0.0, t - last_src), 3),
                    "offline_sec": None if offline_since is None else round(max(0.0, t - offline_since), 3),
                }
        return snapshot
