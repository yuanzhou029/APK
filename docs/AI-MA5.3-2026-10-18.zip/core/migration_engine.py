# -*- coding: utf-8 -*-
"""
AI-MA 数据结构与配置渐进式平滑迁移引擎 (MigrationEngine v1.0)
职责：
1. 配置/数据快照自动备份 (Snapshot Backup)
2. Schema 版本比较与拓扑链式升级 (Chained Migration: e.g. 5.0 -> 5.1 -> 5.2 -> 5.3)
3. 迁移失败安全回滚 (Rollback on Failure)
4. 历史遗留 API 垫片与弃用警告 (Deprecation Shims)
AC-4.2: Schema 迁移引擎能够将 v5.0 旧版配置自动升级至 v5.3 结构，转换准确率达 100% 且无异常抛出。
AC-4.3: 弃用垫片对所有历史遗留接口访问输出规范的 DeprecationWarning 日志，且保持调用链路完全畅通。
"""

import copy
import json
import logging
import warnings
from typing import Dict, Any, Callable, List, Optional, Tuple

logger = logging.getLogger("MigrationEngine")


def normalize_version(v: Optional[str]) -> str:
    """
    归一化版本字符串，支持 '5.0', 'v5.0', '5.0.0', 'v5.3.0', '5' 等，
    统一转换为标准的 'X.Y.Z' Semver 字符串。
    """
    if not v:
        return "5.0.0"
    v_clean = str(v).strip().lstrip("v").lstrip("V").strip()
    parts = []
    for p in v_clean.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return f"{parts[0]}.{parts[1]}.{parts[2]}"


def semver_tuple(v: str) -> Tuple[int, ...]:
    """解析形如 '5.0.0' 或 '5.0' 为整数元组进行排序比较"""
    norm = normalize_version(v)
    return tuple(int(x) for x in norm.split("."))


class MigrationEngine:
    """Schema 数据迁移与演进引擎"""
    def __init__(self):
        # 迁移路径注册表: {(from_v, to_v): migrator_fn}
        self._migrators: Dict[Tuple[str, str], Callable[[Dict[str, Any]], Dict[str, Any]]] = {}
        # 逆向回滚路径注册表: {(from_v, to_v): rollback_fn}
        self._rollback_migrators: Dict[Tuple[str, str], Callable[[Dict[str, Any]], Dict[str, Any]]] = {}
        # 自动快照历史堆栈
        self._snapshots: List[Dict[str, Any]] = []

    def register_migration(
        self,
        from_version: str,
        to_version: str,
        migrator: Callable[[Dict[str, Any]], Dict[str, Any]],
        rollback: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None
    ) -> None:
        """注册一步式迁移函数（自动归一化版本字符串）"""
        norm_from = normalize_version(from_version)
        norm_to = normalize_version(to_version)
        self._migrators[(norm_from, norm_to)] = migrator
        if rollback:
            self._rollback_migrators[(norm_to, norm_from)] = rollback

    def create_snapshot(self, data: Dict[str, Any], tag: str = "auto") -> Dict[str, Any]:
        """创建配置/数据内存快照备份"""
        snap = {
            "tag": tag,
            "version": normalize_version(data.get("version") or data.get("schema_version")),
            "payload": copy.deepcopy(data)
        }
        self._snapshots.append(snap)
        return snap

    def get_last_snapshot(self) -> Optional[Dict[str, Any]]:
        return self._snapshots[-1] if self._snapshots else None

    def find_migration_path(self, current_version: str, target_version: str) -> List[Tuple[str, str]]:
        """在已注册的迁移图中寻找自当前版本到目标版本的连通路径 (BFS)"""
        norm_curr = normalize_version(current_version)
        norm_target = normalize_version(target_version)
        if norm_curr == norm_target:
            return []

        queue = [[norm_curr]]
        visited = {norm_curr}

        while queue:
            path = queue.pop(0)
            node = path[-1]
            if node == norm_target:
                # 转换节点序列为边列表: [(v1, v2), (v2, v3)]
                return [(path[i], path[i+1]) for i in range(len(path)-1)]

            # 寻找后续节点
            for (f_v, t_v) in self._migrators.keys():
                if f_v == node and t_v not in visited:
                    visited.add(t_v)
                    new_path = list(path)
                    new_path.append(t_v)
                    queue.append(new_path)

        raise ValueError(f"未找到自版本 [{current_version}] 到目标版本 [{target_version}] 的迁移路径")

    def migrate_data(self, data: Dict[str, Any], target_version: str, backup: bool = True) -> Dict[str, Any]:
        """
        链式执行数据结构渐进式迁移。
        若迁移中途发生任何异常，自动从最近快照回滚并重新抛出异常（严禁静默吞掉异常伪装成功）。
        """
        raw_v = data.get("version") or data.get("schema_version")
        current_v = normalize_version(raw_v)
        norm_target = normalize_version(target_version)

        if backup:
            self.create_snapshot(data, tag=f"pre_migrate_from_{current_v}")

        if current_v == norm_target:
            return copy.deepcopy(data)

        path = self.find_migration_path(current_v, norm_target)
        working_data = copy.deepcopy(data)

        try:
            for step_from, step_to in path:
                migrator = self._migrators.get((step_from, step_to))
                if not migrator:
                    raise RuntimeError(f"缺失迁移器: {step_from} -> {step_to}")
                working_data = migrator(working_data)
                # 显式更新版本字段
                if "schema_version" in working_data:
                    working_data["schema_version"] = step_to
                if "version" in working_data:
                    working_data["version"] = step_to
                logger.info(f"Schema 迁移执行完毕: {step_from} -> {step_to}")
            return working_data
        except Exception as e:
            logger.error(f"Schema 迁移在步骤失败，自动触发安全回滚: {e}")
            last_snap = self.get_last_snapshot()
            if last_snap:
                # 回滚数据保持未漂移状态
                data.clear()
                data.update(copy.deepcopy(last_snap["payload"]))
            # 坚决显式 re-raise 异常，严禁静默伪装成功
            raise RuntimeError(f"Schema 数据迁移执行失败并已安全回滚: {e}") from e


# =========================================================================
# 内置内置标准迁移规则：将 v5.0 旧版配置平滑升级至 v5.3 架构
# =========================================================================
def _migrate_v50_to_v51(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """v5.0 -> v5.1: 补充三层分级与适配器插槽"""
    new_cfg = copy.deepcopy(cfg)
    # 迁移 plugins_config 中的结构
    for pid, pdata in new_cfg.get("plugins", {}).items():
        if "tier" not in pdata:
            # 默认归类为 3 类社区插件
            pdata["tier"] = 3
    return new_cfg

def _migrate_v51_to_v52(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """v5.1 -> v5.2: 补充微内核共享内存配置与安全掩码"""
    new_cfg = copy.deepcopy(cfg)
    if "kernel" not in new_cfg:
        new_cfg["kernel"] = {
            "use_kernel_rt": True,
            "shm_slots": ["l1", "l2", "l3", "l4"]
        }
    return new_cfg

def _migrate_v52_to_v53(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """v5.2 -> v5.3: 补充 ServiceBroker, EventHub 与 阶梯式能力依赖拓扑"""
    new_cfg = copy.deepcopy(cfg)
    if "interaction" not in new_cfg:
        new_cfg["interaction"] = {
            "service_broker_enabled": True,
            "event_hub_enabled": True,
            "read_only_mirror_enabled": True
        }
    return new_cfg


def get_default_migration_engine() -> MigrationEngine:
    """获取预置了标准升级规则的系统全局迁移引擎实例"""
    engine = MigrationEngine()
    engine.register_migration("5.0.0", "5.1.0", _migrate_v50_to_v51)
    engine.register_migration("5.1.0", "5.2.0", _migrate_v51_to_v52)
    engine.register_migration("5.2.0", "5.3.0", _migrate_v52_to_v53)
    return engine


# =========================================================================
# 弃用垫片与兼容层 (Deprecation Shims)
# =========================================================================
class DeprecationShim:
    """弃用垫片包装器：当外部访问旧属性或调用旧方法时发出警告并转发至新实现"""
    def __init__(self, target_obj: Any, aliases: Dict[str, str], version_deprecated: str = "v5.3"):
        self._target_obj = target_obj
        self._aliases = aliases  # {old_name: new_name}
        self._version_deprecated = version_deprecated

    def __getattr__(self, name: str) -> Any:
        if name in self._aliases:
            new_name = self._aliases[name]
            warnings.warn(
                f"[DeprecationWarning] 属性/方法 '{name}' 在 {self._version_deprecated} 已弃用，请迁移至 '{new_name}'",
                category=DeprecationWarning,
                stacklevel=2
            )
            logger.warning(f"检测到历史弃用接口访问: '{name}' -> 转发至 '{new_name}'")
            return getattr(self._target_obj, new_name)
        return getattr(self._target_obj, name)

    def __setattr__(self, name: str, value: Any):
        if name in ["_target_obj", "_aliases", "_version_deprecated"]:
            super().__setattr__(name, value)
        elif name in self._aliases:
            new_name = self._aliases[name]
            warnings.warn(
                f"[DeprecationWarning] 属性赋值 '{name}' 在 {self._version_deprecated} 已弃用，已映射赋值到 '{new_name}'",
                category=DeprecationWarning,
                stacklevel=2
            )
            setattr(self._target_obj, new_name, value)
        else:
            setattr(self._target_obj, name, value)
