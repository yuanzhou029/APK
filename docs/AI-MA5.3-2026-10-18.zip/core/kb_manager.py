# -*- coding: utf-8 -*-
"""
核心知识库管理器 (Knowledge Base Manager) - 增强泛化匹配版
"""

import os
import json
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class KnowledgeBaseManager:
    def __init__(self, kb_root_path: str):
        self.kb_root = os.path.abspath(kb_root_path)
        self.profiles_dir = os.path.join(self.kb_root, "profiles")
        self.venues_dir = os.path.join(self.kb_root, "venues")
        self.presets_dir = os.path.join(self.kb_root, "presets")

        self.profiles = {}
        self.current_venue = {}
        self.presets = {}

        self.load_all()

    def load_all(self, venue_filename="venue_livehouse_hall_a.json"):
        logging.info(f"正在从 [{self.kb_root}] 加载独立知识库...")
        self.load_profiles()
        self.load_venue(venue_filename)
        self.load_presets()
        logging.info("知识库加载与安全校验全部完成！")

    def load_profiles(self):
        self.profiles.clear()
        if not os.path.exists(self.profiles_dir):
            raise FileNotFoundError(f"灯库目录不存在: {self.profiles_dir}")

        for fname in os.listdir(self.profiles_dir):
            if fname.endswith(".json"):
                fpath = os.path.join(self.profiles_dir, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    pid = data["profile_id"]

                    allowed_channels = {}
                    for ch_def in data.get("channels", []):
                        if ch_def.get("is_safe", True):
                            allowed_channels[ch_def["type"]] = ch_def["ch"]
                        else:
                            logging.warning(f"安全机制生效: 已封锁灯库 [{pid}] 的危险通道 CH{ch_def['ch']} ({ch_def['name']})")

                    self.profiles[pid] = {
                        "profile_id": pid,
                        "manufacturer": data.get("manufacturer", ""),
                        "model": data.get("model", ""),
                        "channel_count": data.get("channel_count", 512),
                        "allowed_channels": allowed_channels
                    }
        logging.info(f"已加载 {len(self.profiles)} 个灯具Profile定义。")

    def load_venue(self, venue_filename: str):
        fpath = os.path.join(self.venues_dir, venue_filename)
        if not os.path.exists(fpath):
            raise FileNotFoundError(f"场地文件不存在: {fpath}")

        with open(fpath, "r", encoding="utf-8") as f:
            self.current_venue = json.load(f)
        nodes = self.current_venue.get("nodes")
        if nodes:
            logging.info(f"已切换当前场地为: [{self.current_venue.get('venue_name')}] "
                         f"({len(nodes)} 个解码器节点 / {len(self.current_venue.get('fixtures', []))} 台灯具)")
        else:
            logging.info(f"已切换当前场地为: [{self.current_venue.get('venue_name')}] "
                         f"(包含 {len(self.current_venue.get('fixtures', []))} 台灯具)")

    def load_presets(self):
        preset_file = os.path.join(self.presets_dir, "aesthetic_presets.json")
        if os.path.exists(preset_file):
            with open(preset_file, "r", encoding="utf-8") as f:
                self.presets = json.load(f)
        logging.info(f"已加载 {len(self.presets)} 个美学艺术预设。")

    def retrieve_context(self, user_query: str):
        """
        全量/局部拓扑匹配（大幅扩展全场泛化词）
        """
        fixtures = self.current_venue.get("fixtures", [])
        matched_fixtures = []

        # 扩展泛化关键词词库
        all_indicators = [
            "全场", "所有", "全部", "每台", "每一台", "每盏", "每一盏", "整场", "通通", "统统"
        ]
        wash_indicators = ["面光", "面灯", "前光", "主光"]
        beam_indicators = ["光束", "摇头", "光柱", "背光", "逆光"]

        is_all = any(k in user_query for k in all_indicators)
        is_wash = any(k in user_query for k in wash_indicators) and not any(k in user_query for k in beam_indicators)
        is_beam = any(k in user_query for k in beam_indicators) and not any(k in user_query for k in wash_indicators)

        for fix in fixtures:
            fix_tags = fix.get("tags", [])
            if is_all:
                matched_fixtures.append(fix)
            elif is_wash and "面光" in fix_tags:
                matched_fixtures.append(fix)
            elif is_beam and "光束" in fix_tags:
                matched_fixtures.append(fix)
            elif any(tag in user_query for tag in fix_tags):
                matched_fixtures.append(fix)

        if not matched_fixtures and fixtures:
            matched_fixtures = fixtures if is_all else [fixtures[0]]

        # 组装上下文
        fixtures_context = []
        for fix in matched_fixtures:
            pid = fix["profile_id"]
            prof = self.profiles.get(pid, {})
            fixtures_context.append({
                "id": fix["id"],
                "name": fix["name"],
                "universe": fix["universe"],
                "address": fix["address"],
                "controllable_keys": list(prof.get("allowed_channels", {}).keys())
            })

        # 美学预设匹配
        preset_hint = None
        for key, p_data in self.presets.items():
            name = p_data.get("name", "")
            # desc 可能缺失（新模型用 tags / summary 承载语义），必须安全兜底
            desc = p_data.get("desc") or "、".join(p_data.get("tags") or []) or p_data.get("summary", "")
            keywords = [k.strip() for k in str(desc).split("、") if k.strip()]
            if (name and name in user_query) or any(k in user_query for k in keywords):
                preset_hint = {
                    "preset_id": key,
                    "preset_name": name,
                    "category_id": p_data.get("category_id"),
                    "profile_ref": p_data.get("profile_ref"),
                    "suggested_channels": p_data.get(
                        "suggested_channels",
                        {k: v for k, v in (p_data.get("channel_values") or {}).items()
                         if k in ("red", "green", "blue", "white")}
                    ),
                    "channel_values": p_data.get("channel_values") or {},
                    "recommended_transition_ms": p_data.get("recommended_transition_ms",
                                                           p_data.get("transition_ms", 1000))
                }
                break

        return fixtures_context, preset_hint
