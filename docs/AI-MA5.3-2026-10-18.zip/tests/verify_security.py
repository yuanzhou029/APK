# -*- coding: utf-8 -*-
"""
企业级安全性、RBAC 鉴权与故障诊断综合自动化验证
测试项：
1. PBKDF2-HMAC-SHA256 鉴权与 Session Token 签发有效性
2. 权限分级拦截校验 (Admin 拥有所有权限，Guest 拦截控光/Panic)
3. 结构化中文日志捕获与 ERR-NET-6454 / ERR-MASK-TRIP 故障诊断匹配
4. 代码加固流水线字节码编译与防篡改指纹生成
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE_DIR, "core"))

from auth_manager import AuthManager, Role
from diagnostics_logger import setup_chinese_logger, GLOBAL_LOG_BUFFER, log_diagnostic_error, ERROR_DIAGNOSTICS_DB

# 原套件从这里 `from build_hardener import CodeHardener`。
# build_hardener 模块已在重构中移除，其能力（Cython 机器码编译 + 防篡改发布清单）
# 现由 tools/build_release.py 承担。第 4 节已改为直接校验当前流水线。

def run_security_test():
    print("=" * 65)
    print(" 开始执行企业级安全性、RBAC 权限分级与中文故障诊断测试")
    print("=" * 65)

    # 1. 验证 RBAC 鉴权与哈希防破解
    auth = AuthManager(user_db_path=os.path.join(BASE_DIR, "config", "test_users.json"))
    
    # 错误密码应拒绝
    fail_sess = auth.authenticate("admin", "wrong_password")
    assert fail_sess is None, "密码校验失败用例未通过"
    
    # 正确管理员密码
    admin_sess = auth.authenticate("admin", "admin123")
    assert admin_sess is not None, "管理员登录失败"
    assert admin_sess["role"] == Role.ADMIN, "管理员角色分配错误"
    admin_token = admin_sess["token"]
    
    # 观察员登录
    guest_sess = auth.authenticate("guest", "guest")
    assert guest_sess is not None, "观察员登录失败"
    guest_token = guest_sess["token"]

    print("[PASS] PBKDF2-HMAC-SHA256 加盐防碰撞密码校验与 Token 签发通过")

    # 2. 验证权限拦截机制
    # 观察员尝试执行控光或熔断应返回 False
    assert not auth.check_permission(guest_token, "operate_lights"), "安全漏洞：观察员未被拦截控光权限！"
    assert not auth.check_permission(guest_token, "panic_control"), "安全漏洞：观察员未被拦截 Panic 权限！"
    
    # 管理员执行控光或熔断应返回 True
    assert auth.check_permission(admin_token, "operate_lights"), "管理员控光权限缺失"
    assert auth.check_permission(admin_token, "panic_control"), "管理员 Panic 权限缺失"

    print("[PASS] 严格 RBAC 角色权限分级拦截隔离校验 100% 通过")

    # 3. 验证中文日志与故障诊断秒级定位
    logger = setup_chinese_logger(log_dir=os.path.join(BASE_DIR, "logs"), app_name="SecurityTest")
    log_diagnostic_error(logger, "ERR-NET-6454", "端口 6454 冲突模拟")
    
    recent_logs = GLOBAL_LOG_BUFFER.get_logs(limit=10)
    assert len(recent_logs) > 0, "内存环形日志缓冲区捕获失败"
    
    last_log = recent_logs[-1]
    assert last_log["diag_code"] == "ERR-NET-6454", "故障诊断错误代码未正确定位"
    assert "diagnostics" in last_log, "未附带故障诊断知识库建议"
    print(f"[PASS] 中文结构化故障诊断引擎校验通过:")
    print(f"       -> 诊断代码: {last_log['diag_code']}")
    print(f"       -> 故障标题: {last_log['diagnostics']['title']}")
    print(f"       -> 排查建议: {last_log['diagnostics']['solution']}")

    # 4. 验证代码加固与发布流水线
    #
    # 原套件用 build_hardener.CodeHardener().obfuscate_and_compile()，该模块已移除。
    # 现直接校验 tools/build_release.py —— 它是当前唯一的发布构建真源。
    sys.path.insert(0, os.path.join(BASE_DIR, "tools"))
    import build_release as br

    # 4a. Cython 机器码编译脚本：必须覆盖全部核心模块
    core_dir = os.path.join(BASE_DIR, "core")
    setup_path = br.generate_cython_setup(core_dir)
    assert os.path.exists(setup_path), f"Cython 编译脚本未生成: {setup_path}"
    with open(setup_path, "r", encoding="utf-8") as sf:
        setup_src = sf.read()
    missing = [m for m in br.CORE_MODULES_TO_COMPILE
               if m.replace(".py", "") not in setup_src]
    assert not missing, f"Cython 编译脚本漏列核心模块: {missing}"
    print(f"[PASS] Cython 机器码编译脚本生成通过"
          f"（覆盖全部 {len(br.CORE_MODULES_TO_COMPILE)} 个核心模块）")

    # 4b. 双 systemd 单元：实时加固参数与强绑定关系必须齐备
    unit_dir = os.path.join(BASE_DIR, "dist_core_test")
    os.makedirs(unit_dir, exist_ok=True)
    br.generate_systemd_units(unit_dir)
    rt_unit = os.path.join(unit_dir, "aima-rt.service")
    app_unit = os.path.join(unit_dir, "ai-ma.service")
    assert os.path.exists(rt_unit), "微内核 systemd 单元未生成"
    assert os.path.exists(app_unit), "业务控制台 systemd 单元未生成"
    rt_txt = open(rt_unit, "r", encoding="utf-8").read()
    app_txt = open(app_unit, "r", encoding="utf-8").read()
    for token in ["CPUAffinity=3", "CPUSchedulingPolicy=fifo",
                  "CPUSchedulingPriority=98", "LimitMEMLOCK=infinity",
                  "WatchdogSec=1s", "ReadWritePaths=/dev/shm"]:
        assert token in rt_txt, f"微内核单元缺少实时加固参数: {token}"
    for token in ["BindsTo=aima-rt.service", "Requires=aima-rt.service",
                  'Environment="AIMA_RT_EXTERNAL=1"']:
        assert token in app_txt, f"业务单元缺少内核绑定/防双内核参数: {token}"
    assert "@@VERSION@@" not in rt_txt and "@@VERSION@@" not in app_txt, \
        "systemd 单元占位符未被替换"
    print("[PASS] systemd 双单元生成与实时加固参数校验通过")

    # 4c. 前端混淆：必须产出经变换的代码，而非原样返回
    sample_js = "function plainHello(){return 42;}var plainVar=1;plainHello();"
    ob = br.obfuscate_js_content(sample_js)
    assert ob != sample_js, "前端 JS 混淆未生效（输出与输入完全相同）"
    assert len(ob) > len(sample_js), "前端 JS 混淆未注入解码器包装"
    print(f"[PASS] 前端 AST 混淆生效（{len(sample_js)} -> {len(ob)} 字符）")

    # 4d. 发布清单常量齐备
    assert br.VERSION == "5.3.0", f"发布版本号异常: {br.VERSION}"
    assert br.REQUIRED_KERNEL_BINARIES, "未声明必需的内核二进制"
    assert "aima-rt-daemon" in br.REQUIRED_KERNEL_BINARIES, "必需内核二进制清单缺 aima-rt-daemon"
    assert br.SHM_SDK_BASENAME == "aima_shm_sdk", "共享内存 SDK 基名异常"
    print("[PASS] 发布清单常量与必需构件声明校验通过")

    # 5. 清理测试产物：验证套件不得在交付目录里留下任何痕迹，
    #    否则客户拿到的包里会多出 test_users.json、dist_core_test/、
    #    core/setup_cython.py 这类测试垃圾。
    import shutil

    cleaned = []
    test_users = os.path.join(BASE_DIR, "config", "test_users.json")
    if os.path.exists(test_users):
        os.remove(test_users)
        cleaned.append("config/test_users.json")
    dist_test = os.path.join(BASE_DIR, "dist_core_test")
    if os.path.isdir(dist_test):
        shutil.rmtree(dist_test, ignore_errors=True)
        cleaned.append("dist_core_test/")
    # generate_cython_setup() 会顺带写出 core/setup_cython.py，必须一并清掉
    if os.path.exists(setup_path):
        os.remove(setup_path)
        cleaned.append("core/setup_cython.py")
    print(f"[PASS] 测试产物清理完毕: {cleaned if cleaned else '无残留'}")

    assert not os.path.exists(test_users), "测试用户库未被清理"
    assert not os.path.isdir(dist_test), "加固测试输出目录未被清理"
    assert not os.path.exists(setup_path), "Cython 编译脚本未被清理"

    print("\n" + "=" * 65)
    print(" 所有企业级安全加固、鉴权隔离、中文诊断与构建测试全部 PASS！")
    print("=" * 65)

if __name__ == "__main__":
    run_security_test()
