# -*- coding: utf-8 -*-
"""
设备发现与掉线看门狗 · 常驻回归套件

覆盖 core/node_discovery.py 的全部协议层与状态机不变量。

为什么这些断言值得常驻：
  · Art-Net 是二进制协议，字节序写反（OpCode 小端 / ProtVer 大端）不会有任何报错，
    只会"设备就是不响应"，现场极难排查——必须用构造/解析往返把它钉死。
  · 看门狗的"从未见过心跳"语义直接决定告警是否可信。判错方向只有两种后果：
    要么漏报真实掉线，要么让每台正常设备都误报，运维人员很快就对告警脱敏。
  · 网段展开必须有硬上限，否则一次误操作就能把整个 B 段扫穿、打爆现场网络。
  · 探测过程**绝不能发 ArtDmx**——那会让现场灯具闪一下。这里用字节级断言守住这条线。
"""

import os
import socket
import struct
import sys
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE, "core"))

from node_discovery import (  # noqa: E402
    ARTNET_ID, ARTNET_PORT, MAX_SUBNET_HOSTS, OP_POLL, OP_POLL_REPLY, PROT_VER,
    ArtPollProber, LivenessProbe, OfflineWatchdog, PassiveRegistry,
    build_artpoll_packet, expand_subnet, parse_artpoll_reply, ping_host,
)

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")


# ---------------------------------------------------------------------------
# 构造一个合规的 ArtPollReply 应答包（239 字节标准长度）
# ---------------------------------------------------------------------------
def build_reply(node_name="AI-MA Node 4Port", short_name="AI-MA NODE 01",
                num_ports=4, universes=(0, 1, 2, 3), style=0, mac=b"\x00\x11\x22\x33\x44\x55",
                bind_index=0, net_switch=0, sub_switch=0, reply_ip="192.168.1.50"):
    pkt = bytearray(239)
    pkt[0:8] = ARTNET_ID
    pkt[8:10] = struct.pack("<H", OP_POLL_REPLY)     # OpCode 小端
    pkt[10:14] = bytes(int(x) for x in reply_ip.split("."))
    pkt[14:16] = struct.pack("<H", ARTNET_PORT)      # Port 小端
    pkt[16:18] = struct.pack(">H", PROT_VER)         # VersInfo 大端
    pkt[18] = net_switch
    pkt[19] = sub_switch
    pkt[20:22] = struct.pack(">H", 0x0001)           # OEM 大端
    pkt[24:26] = struct.pack("<H", 0x1234)           # EstaMan 小端
    pkt[26:44] = short_name.encode("ascii")[:18].ljust(18, b"\x00")
    pkt[44:108] = node_name.encode("ascii")[:64].ljust(64, b"\x00")
    pkt[108:172] = b"OK\x00".ljust(64, b"\x00")
    pkt[172:174] = struct.pack(">H", num_ports)      # NumPorts 大端
    pkt[174:178] = bytes([0x80, 0x80, 0x80, 0x80])   # PortTypes
    pkt[190:194] = bytes([u & 0x0F for u in universes])[:4].ljust(4, b"\x00")
    pkt[206] = style
    pkt[207:213] = mac
    pkt[217] = bind_index
    return bytes(pkt)


class FakeClock:
    """可注入的单调时钟，使阈值判定测试无需真的等待"""

    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t

    def advance(self, dt):
        self.t += dt


def main():
    print("=" * 74)
    print(" 设备发现与掉线看门狗 · 常驻回归套件")
    print("=" * 74)

    # ==================================================== 一、ArtPoll 报文构造
    pkt = build_artpoll_packet()
    check("1. ArtPoll 报文为 14 字节标准长度", len(pkt) == 14, f"-> {len(pkt)} 字节")
    check("2. Art-Net 标识与 OpCode 字节序正确",
          pkt[0:8] == b"Art-Net\x00"
          and struct.unpack("<H", pkt[8:10])[0] == OP_POLL
          and OP_POLL == 0x2000,
          f"-> OpCode=0x{struct.unpack('<H', pkt[8:10])[0]:04X}（小端）")
    check("3. ProtVer 为大端 0x000E（Art-Net 4）",
          struct.unpack(">H", pkt[10:12])[0] == PROT_VER == 0x000E,
          f"-> 0x{struct.unpack('>H', pkt[10:12])[0]:04X}")
    check("4. TalkToMe 置位 0x02（请求节点状态变化上报）",
          pkt[12] == 0x02, f"-> TalkToMe=0x{pkt[12]:02X}")
    check("5. 报文不包含任何 ArtDmx 语义（探测绝不推送灯光数据）",
          struct.unpack("<H", pkt[8:10])[0] != 0x5000 and len(pkt) < 530,
          "-> 长度 14 字节，无法承载 DMX 载荷")

    # ==================================================== 二、应答包解析
    r = parse_artpoll_reply(build_reply(), src_ip="192.168.1.50")
    check("6. 完整应答包解析成功",
          r["reply"] is True and r["node_name"] == "AI-MA Node 4Port"
          and r["short_name"] == "AI-MA NODE 01" and r["error"] is None,
          f"-> {r['node_name']} / {r['short_name']}")
    check("7. 端口数量与各端口 Universe 正确还原",
          r["num_ports"] == 4 and r["port_universes"] == [0, 1, 2, 3],
          f"-> {r['num_ports']} 口 / {r['port_universes']}")
    check("8. MAC 与设备样式正确解析",
          r["mac"] == "00:11:22:33:44:55" and r["style_name"],
          f"-> {r['mac']} / {r['style_name']}")
    check("9. 来源 IP 写入 ip 字段（供上层定位设备）",
          r["ip"] == "192.168.1.50" and r["reply_ip"] == "192.168.1.50",
          f"-> ip={r['ip']}")

    # NetSwitch/SubSwitch 参与 Universe 计算
    r2 = parse_artpoll_reply(build_reply(universes=(1, 2, 3, 4), net_switch=1, sub_switch=2))
    check("10. NetSwitch/SubSwitch 正确参与 Universe 计算",
          r2["port_universes"] == [(1 << 8) | (2 << 4) | x for x in (1, 2, 3, 4)],
          f"-> {r2['port_universes']}")

    # 畸形包不得抛异常、不得误判为在线
    for label, bad in [
        ("空报文", b""),
        ("非 Art-Net 标识", b"NOT-ARTNET" + b"\x00" * 40),
        ("OpCode 非 ArtPollReply", ARTNET_ID + struct.pack("<H", 0x5000) + b"\x00" * 30),
        ("被截断到 10 字节", ARTNET_ID + struct.pack("<H", OP_POLL_REPLY)),
        ("随机二进制", bytes(range(256)) * 2),
    ]:
        try:
            rb = parse_artpoll_reply(bad, src_ip="10.0.0.1")
            ok = (rb["reply"] is False) or (rb["reply"] is True and rb.get("error"))
            check(f"11. 畸形包安全兜底 · {label}", ok,
                  f"-> reply={rb['reply']} / error={str(rb.get('error'))[:40]}")
        except Exception as e:
            check(f"11. 畸形包安全兜底 · {label}", False, f"-> 抛异常: {e}")

    # ==================================================== 三、网段展开与上限
    hosts = expand_subnet("192.168.1.0", 24)
    check("12. /24 网段展开为 254 个可用主机（不含网络号与广播号）",
          len(hosts) == 254 and "192.168.1.1" in hosts and "192.168.1.254" in hosts
          and "192.168.1.0" not in hosts and "192.168.1.255" not in hosts,
          f"-> {len(hosts)} 个，首={hosts[0]} 末={hosts[-1]}")
    check("13. /31 与 /32 按无网络号/广播号处理",
          len(expand_subnet("10.0.0.0", 31)) == 2 and len(expand_subnet("10.0.0.7", 32)) == 1,
          f"-> /31={len(expand_subnet('10.0.0.0', 31))} /32={len(expand_subnet('10.0.0.7', 32))}")

    over = False
    try:
        expand_subnet("10.0.0.0", 8)
    except ValueError as e:
        over = "超过上限" in str(e)
    check("14. 超大网段被硬上限拒绝（防止误扫打爆现场网络）", over,
          f"-> /8 含 16777214 台，上限 {MAX_SUBNET_HOSTS}，已拒绝")
    check("15. 上限恰好等于阈值时允许展开",
          len(expand_subnet("10.0.0.0", 22)) == MAX_SUBNET_HOSTS - 2,
          f"-> /22 展开 {len(expand_subnet('10.0.0.0', 22))} 个主机")

    for label, args in [("非 IP 字符串", ("not-an-ip", 24)),
                        ("IPv6", ("2001:db8::", 64)),
                        ("非法前缀", ("192.168.1.0", 99))]:
        bad = False
        try:
            expand_subnet(*args)
        except ValueError:
            bad = True
        check(f"16. 非法网段参数被拒绝 · {label}", bad, f"-> {args}")

    # ==================================================== 四、被动发现登记表
    reg = PassiveRegistry(stale_sec=10.0)
    reg.observe("192.168.1.51", 0)
    reg.observe("192.168.1.51", 1)
    reg.observe("192.168.1.51", 0)
    reg.observe("192.168.1.52", 5)
    snap = reg.snapshot()
    by_ip = {x["ip"]: x for x in snap}
    check("17. 被动发现按 IP 归并并去重 Universe",
          by_ip["192.168.1.51"]["universes"] == [0, 1] and len(snap) == 2,
          f"-> {by_ip['192.168.1.51']['universes']}")
    check("18. 快照携带墙钟毫秒时间戳与新鲜度",
          all(isinstance(x["last_seen_ms"], int) and x["last_seen_ms"] > 1_600_000_000_000 for x in snap)
          and by_ip["192.168.1.51"]["stale"] is False,
          f"-> last_seen_ms={by_ip['192.168.1.51']['last_seen_ms']}")
    check("19. last_seen_ms 只在真的收到新报文时变化（心跳去重的前提）",
          (lambda a, b: a == b)(
              {x["ip"]: x["last_seen_ms"] for x in reg.snapshot()},
              (lambda: (time.sleep(0.05), {x["ip"]: x["last_seen_ms"] for x in reg.snapshot()})[1])()),
          "-> 无新报文时时间戳保持不变")
    reg.forget("192.168.1.52")
    check("20. 可显式移除已下线设备", len(reg.snapshot()) == 1)

    # ==================================================== 五、看门狗状态机
    ck = FakeClock()
    wd = OfflineWatchdog(clock=ck)
    wd.register_node("n_thr", {"mode": "threshold", "threshold_sec": 5,
                               "grace_period_sec": 2, "liveness_source": "artpoll"})
    wd.register_node("n_ign", {"mode": "ignore", "threshold_sec": 1})
    wd.register_node("n_man", {"mode": "manual"})

    check("21. 注册后宽限期内不报警",
          wd.evaluate() == [] and wd.status()["n_thr"]["state"] == "unknown",
          f"-> state={wd.status()['n_thr']['state']}（从未收到探针应答）")

    ck.advance(2.5)
    wd.heartbeat("n_thr", "artpoll")
    check("22. 主动探测应答后节点转为在线",
          wd.evaluate() == [] and wd.status()["n_thr"]["state"] == "online",
          f"-> state={wd.status()['n_thr']['state']}")

    ck.advance(5.5)
    ev = wd.evaluate()
    check("23. 超过阈值后产生一次掉线事件",
          len(ev) == 1 and ev[0]["event"] == "offline" and ev[0]["node_id"] == "n_thr"
          and ev[0]["offline_sec"] > 5,
          f"-> {ev[0]['event']} / 静默 {ev[0]['offline_sec']}s")
    check("24. 状态未变化时不重复产生事件（天然去重）",
          wd.evaluate() == [] and wd.status()["n_thr"]["state"] == "offline",
          "-> 第二轮无新事件")

    ck.advance(1.0)
    wd.heartbeat("n_thr", "artpoll")
    ev2 = wd.evaluate()
    check("25. 恢复心跳后产生一次恢复事件并销警",
          len(ev2) == 1 and ev2[0]["event"] == "recovered" and ev2[0]["offline_sec"] is not None,
          f"-> 本次离线 {ev2[0]['offline_sec']}s")

    # 关键语义：从未收到过该来源心跳 ≠ 掉线
    ck2 = FakeClock()
    wd2 = OfflineWatchdog(clock=ck2)
    wd2.register_node("never", {"mode": "threshold", "threshold_sec": 3,
                                "grace_period_sec": 0, "liveness_source": "artpoll",
                                "alarm_when_never_seen": False})
    wd2.register_node("strict", {"mode": "threshold", "threshold_sec": 3,
                                 "grace_period_sec": 0, "liveness_source": "artpoll",
                                 "alarm_when_never_seen": True})
    ck2.advance(10.0)
    ev3 = wd2.evaluate()
    st2 = wd2.status()
    check("26. 从未收到心跳的节点默认报「未监测」而非掉线（防告警脱敏）",
          st2["never"]["state"] == "unknown" and st2["never"]["online"] is None
          and st2["never"]["never_seen"] is True,
          f"-> state={st2['never']['state']} / online={st2['never']['online']}")
    check("27. 未监测节点不产生任何告警事件",
          all(e["node_id"] != "never" for e in ev3),
          f"-> 本轮事件={[e['node_id'] for e in ev3]}")
    check("28. 显式开启 alarm_when_never_seen 后才按掉线告警",
          [e for e in ev3 if e["node_id"] == "strict" and e["event"] == "offline"],
          f"-> strict 节点已告警")

    # 三种模式的行为差异
    ck3 = FakeClock()
    wd3 = OfflineWatchdog(clock=ck3)
    wd3.register_node("i", {"mode": "ignore", "threshold_sec": 1, "grace_period_sec": 0,
                            "liveness_source": "artpoll", "alarm_when_never_seen": True})
    wd3.register_node("m", {"mode": "manual"})
    ck3.advance(100.0)
    check("29. ignore 模式永不报警（即便显式要求从未上线也告警）",
          wd3.evaluate() == [], "-> ignore 优先级最高")
    check("30. manual 模式在人工标记前保持沉默",
          wd3.status()["m"]["state"] == "online" and wd3.evaluate() == [],
          "-> 等待人工判定")

    wd3.set_manual_state("m", True)
    ev4 = wd3.evaluate()
    check("31. 人工标记掉线后立即产生告警",
          len(ev4) == 1 and ev4[0]["event"] == "offline" and ev4[0]["node_id"] == "m",
          "-> 手动模式生效")
    wd3.set_manual_state("m", False)
    ev5 = wd3.evaluate()
    check("32. 人工标记恢复后立即销警",
          len(ev5) == 1 and ev5[0]["event"] == "recovered",
          "-> 手动恢复生效")

    # auto_recover=False 抑制恢复事件
    ck4 = FakeClock()
    wd4 = OfflineWatchdog(clock=ck4)
    wd4.register_node("nr", {"mode": "threshold", "threshold_sec": 1, "grace_period_sec": 0,
                             "liveness_source": "artpoll", "auto_recover": False})
    wd4.heartbeat("nr", "artpoll")
    ck4.advance(5)
    wd4.evaluate()
    wd4.heartbeat("nr", "artpoll")
    check("33. auto_recover=False 抑制恢复事件但不锁存状态",
          wd4.evaluate() == [] and wd4.status()["nr"]["state"] == "online",
          "-> 无恢复事件，但状态已回到在线")

    # 未注册节点不产生隐式监控项
    ck5 = FakeClock()
    wd5 = OfflineWatchdog(clock=ck5)
    wd5.heartbeat("ghost", "artpoll")
    wd5.set_manual_state("ghost", True)
    ck5.advance(100)
    check("34. 未注册节点的心跳与人工标记被安全忽略",
          wd5.status() == {} and wd5.evaluate() == [],
          "-> 不产生隐式监控项")
    check("35. 注销后停止一切判定",
          (lambda: (wd5.register_node("x", {"mode": "manual"}), wd5.unregister_node("x"),
                    wd5.status() == {})[-1])(), "-> 已摘除")

    # 非法策略字段回退
    ck6 = FakeClock()
    wd6 = OfflineWatchdog(clock=ck6)
    wd6.register_node("bad", {"mode": "nonsense", "liveness_source": "carrier-pigeon",
                              "threshold_sec": "abc", "severity": "apocalyptic",
                              "actions": "log"})
    st6 = wd6.status()["bad"]
    check("36. 非法策略字段一律安全回退默认值",
          st6["mode"] == "threshold" and st6["liveness_source"] == "artpoll"
          and st6["severity"] == "warning" and st6["threshold_sec"] == 5.0,
          f"-> mode={st6['mode']} / source={st6['liveness_source']} / 阈值={st6['threshold_sec']}s")

    # 心跳来源隔离：判据是 artpoll 时，artdmx 心跳不得让节点"看起来在线"
    ck7 = FakeClock()
    wd7 = OfflineWatchdog(clock=ck7)
    wd7.register_node("mix", {"mode": "threshold", "threshold_sec": 3, "grace_period_sec": 0,
                              "liveness_source": "artpoll"})
    wd7.heartbeat("mix", "artdmx")
    ck7.advance(5)
    check("37. 心跳按来源隔离，非判据来源不得掩盖掉线",
          wd7.status()["mix"]["state"] == "unknown"
          and wd7.status()["mix"]["source_age_sec"] is None,
          "-> 收到 artdmx 但判据为 artpoll，仍为未监测")

    # ==================================================== 六、主动探测调度
    ck8 = FakeClock()

    class CountingProber:
        def __init__(self, reply=True):
            self.calls = []
            self.reply = reply

        def probe(self, ip):
            self.calls.append(ip)
            return {"ip": ip, "reply": self.reply, "error": None if self.reply else "超时"}

    cut = OfflineWatchdog(clock=ck8)
    cut.register_node("p1", {"mode": "threshold", "threshold_sec": 5,
                             "grace_period_sec": 0, "liveness_source": "artpoll"})
    cp = CountingProber(reply=True)
    lp = LivenessProbe(cut, prober=cp, ip_resolver=lambda: {"p1": "10.0.0.9"},
                       poll_interval_sec=10.0, clock=ck8)
    hits = lp.tick()
    check("38. artpoll 判据会主动发起探测并折算心跳",
          cp.calls == ["10.0.0.9"] and hits["artpoll"] == 1
          and cut.status()["p1"]["state"] == "online",
          f"-> 探测 {cp.calls} / 命中 {hits['artpoll']}")
    ck8.advance(3)
    lp.tick()
    check("39. 未到探测间隔不重复发探测（避免刷爆现场网络）",
          len(cp.calls) == 1, f"-> 累计探测 {len(cp.calls)} 次")
    ck8.advance(8)
    lp.tick()
    check("40. 到达间隔后再次探测", len(cp.calls) == 2, f"-> 累计探测 {len(cp.calls)} 次")

    # ignore / manual 模式不应被主动探测打扰，artdmx 判据也不应主动探测。
    # 让所有节点都有可解析的 IP，才能真正证明"是判据和模式决定了是否探测"，
    # 而不是"因为解析不到 IP 所以没探测"。
    cut.register_node("p2", {"mode": "ignore"})
    cut.register_node("p3", {"mode": "manual"})
    cut.register_node("p4", {"mode": "threshold", "liveness_source": "artdmx"})
    all_ips = {"p1": "10.0.0.9", "p2": "10.0.0.10", "p3": "10.0.0.11", "p4": "10.0.0.12"}
    lp_all = LivenessProbe(cut, prober=cp, ip_resolver=lambda: all_ips,
                           poll_interval_sec=10.0, clock=ck8)
    cp.calls.clear()
    ck8.advance(30)
    lp_all.tick()
    check("41. ignore / manual 模式不参与主动探测",
          cp.calls == ["10.0.0.9"],
          f"-> 探测目标 {cp.calls}（仅 artpoll 判据的 p1，p2/p3 被跳过）")
    check("42. artdmx 判据不做主动探测（只依赖被动观测）",
          "10.0.0.12" not in cp.calls,
          f"-> 探测目标 {cp.calls}（artdmx 节点 p4 未被探测）")

    # ping 判据走 ICMP
    lp2 = LivenessProbe(cut, prober=cp, ip_resolver=lambda: {"p4": "10.0.0.9"},
                        ping_interval_sec=5.0, clock=ck8)
    check("43. ping 探测函数对不可达地址安全返回 False",
          ping_host("10.255.255.1", timeout_sec=0.4) is False,
          "-> 无异常抛出")

    # ==================================================== 七、绝不发 ArtDmx 的红线
    # 用 AST 做结构性检查，而不是字符串匹配：注释和文档字符串里提到 ArtDmx 是好事
    # （说明约束被写清楚了），真正要守住的是"代码里不存在构造/发送 ArtDmx 的路径"。
    import ast

    src_path = os.path.join(BASE, "core", "node_discovery.py")
    with open(src_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=src_path)

    dmx_constants = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, int) and node.value == 0x5000:
            dmx_constants.append(getattr(node, "lineno", "?"))
    check("44. 代码中不存在 ArtDmx(0x5000) 常量（注释提及不算）",
          not dmx_constants, f"-> 代码位置 {dmx_constants or '无'}")

    sendto_payloads = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr == "sendto" and node.args:
            arg = node.args[0]
            if isinstance(arg, ast.Call) and isinstance(arg.func, ast.Name):
                sendto_payloads.append(arg.func.id)
            else:
                sendto_payloads.append(f"<{type(arg).__name__}:{getattr(arg, 'lineno', '?')}>")
    dmx_send = [p for p in sendto_payloads if p != "build_artpoll_packet"]
    check("45. 所有 UDP sendto 的载荷都来自 build_artpoll_packet",
          len(sendto_payloads) >= 2 and not dmx_send,
          f"-> {len(sendto_payloads)} 处发送，载荷={sorted(set(sendto_payloads))}")

    # 载荷尺寸也能反证：ArtPoll 只有 14 字节，ArtDmx 至少 530 字节
    check("46. 发送载荷尺寸符合 ArtPoll（远小于 ArtDmx 的 530 字节）",
          len(build_artpoll_packet()) == 14 < 530,
          "-> 14 字节，不可能承载 512 通道 DMX 数据")

    # ==================================================== 八、真实 socket 自环
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        srv.bind(("127.0.0.1", 0))
        srv.settimeout(2.0)
        port = srv.getsockname()[1]
        prober = ArtPollProber(port=port, timeout=1.0)
        reply_pkt = build_reply(reply_ip="127.0.0.1")

        import threading

        def responder():
            try:
                data, addr = srv.recvfrom(1024)
                srv.sendto(reply_pkt, addr)
            except Exception:
                pass

        th = threading.Thread(target=responder, daemon=True)
        th.start()
        res = prober.probe("127.0.0.1")
        th.join(timeout=3)
        check("47. 真实 UDP 往返：发出 ArtPoll 并解析到 ArtPollReply",
              res.get("reply") is True and res.get("node_name") == "AI-MA Node 4Port"
              and res.get("rtt_ms") is not None,
              f"-> {res.get('node_name')} / RTT {res.get('rtt_ms')}ms")
        srv.close()
    except Exception as e:
        check("47. 真实 UDP 往返：发出 ArtPoll 并解析到 ArtPollReply", False, f"-> {e}")

    # 无应答时不得抛异常
    prober2 = ArtPollProber(port=6454, timeout=0.4)
    res2 = prober2.probe("10.255.255.1")
    check("48. 对无人应答的地址安全返回（不抛异常）",
          res2.get("reply") is False and isinstance(res2.get("error"), str),
          f"-> error={str(res2.get('error'))[:40]}")

    print("=" * 74)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 74)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
