# -*- coding: utf-8 -*-
"""
AI-MA 5.3 发布包完整性预检与产线回归测试

本测试直接回答一个关键问题：
    "一键生成发布包.bat 打出来的包，在新内核架构下到底能不能跑？"

分三个阶段，全部为真实执行，不做任何 mock：
  阶段一：真实运行 tools/build_release.py，构建必须成功退出
  阶段二：对 dist/ai-ma-v5-release 做产物完整性强校验
          (bin/ 微内核 + abi3 ABI 扩展 + 双 systemd 单元 + 保护清单一致性)
  阶段三：真实启动打出来的发布包，验证其能拉起微内核、挂载 ABI 扩展、
          进入 v5.3_shm 硬件卸载模式，且 1/2 类插件零泄漏
"""

import os
import sys
import json
import time
import socket
import subprocess
import urllib.request

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD_PY = os.path.join(SYS_ROOT, "tools", "build_release.py")
DIST = os.path.join(SYS_ROOT, "dist", "ai-ma-v5-release")
DIST_LOG = os.path.join(DIST, "logs", "ai_ma_system.log")

HOST = "127.0.0.1"
PORT = 9000
BASE = f"http://{HOST}:{PORT}"

HIDDEN_PLUGIN_IDS = {
    "protocol_artnet_standard", "protocol_sacn_standard",
    "llm_local_qwen_7b", "system_log_ai_repair", "adapter_ma_fixture",
}

_results = []


def check(name, ok, detail=""):
    _results.append((name, ok, detail))
    print(f"    -> [{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))
    return ok


def wait_port(host, port, timeout=40.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.3)
    return False


def http_json(path, token=None, method="GET", payload=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if payload is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


def find_kernel_pids():
    try:
        out = subprocess.run(
            ["wmic", "process", "where", "name='aima-rt-daemon.exe'", "get", "ProcessId"],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace"
        ).stdout
        return [int(x) for x in out.split() if x.strip().isdigit()]
    except Exception:
        return []


def phase1_build():
    print("\n" + "=" * 74)
    print(" [阶段一] 真实运行打包流水线 tools/build_release.py")
    print("=" * 74)
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(
        [sys.executable, BUILD_PY], cwd=SYS_ROOT, env=env,
        capture_output=True, text=True, timeout=300,
        encoding="utf-8", errors="replace"
    )
    ok = (proc.returncode == 0)
    check("打包流水线成功退出", ok, f"exit={proc.returncode}")
    if not ok:
        print("\n--- 构建 stdout 尾部 ---")
        print("\n".join(proc.stdout.strip().splitlines()[-25:]))
        print("\n--- 构建 stderr 尾部 ---")
        print("\n".join(proc.stderr.strip().splitlines()[-25:]))
    return ok


def phase2_integrity():
    print("\n" + "=" * 74)
    print(" [阶段二] 发布包产物完整性强校验")
    print("=" * 74)

    check("发布目录已生成", os.path.isdir(DIST), DIST)

    ext = ".exe" if sys.platform == "win32" else ""

    # --- 关键构件 1: 微内核二进制 (旧流水线完全漏掉) ---
    daemon = os.path.join(DIST, "bin", f"aima-rt-daemon{ext}")
    check("含微内核二进制 bin/aima-rt-daemon (旧流水线遗漏项)",
          os.path.isfile(daemon),
          f"{os.path.getsize(daemon)} 字节" if os.path.isfile(daemon) else "缺失")

    # --- 关键构件 2: abi3 ABI 扩展 (旧流水线遗漏项) ---
    sdk_name = "aima_shm_sdk.pyd" if sys.platform == "win32" else "aima_shm_sdk.so"
    for rel in (sdk_name, os.path.join("core", sdk_name)):
        p = os.path.join(DIST, rel)
        check(f"含共享内存 ABI 扩展 {rel} (旧流水线遗漏项)",
              os.path.isfile(p),
              f"{os.path.getsize(p)} 字节" if os.path.isfile(p) else "缺失")

    # --- 关键构件 3: 双 systemd 单元 ---
    rt_p = os.path.join(DIST, "aima-rt.service")
    app_p = os.path.join(DIST, "ai-ma.service")
    check("含硬实时微内核单元 aima-rt.service", os.path.isfile(rt_p))
    check("含业务控制台单元 ai-ma.service", os.path.isfile(app_p))
    check("旧内核语义单元 ai-lighting.service 已清除",
          not os.path.exists(os.path.join(DIST, "deploy", "ai-lighting.service")))

    rt_txt = open(rt_p, encoding="utf-8").read() if os.path.isfile(rt_p) else ""
    app_txt = open(app_p, encoding="utf-8").read() if os.path.isfile(app_p) else ""

    check("aima-rt.service 声明硬实时调度 (SCHED_FIFO)",
          "CPUSchedulingPolicy=fifo" in rt_txt)
    check("aima-rt.service 声明 CPU 亲和性隔离",
          "CPUAffinity=" in rt_txt)
    check("aima-rt.service 声明内存锁定防换页抖动",
          "LimitMEMLOCK=infinity" in rt_txt)
    check("aima-rt.service 启动微内核二进制",
          "/bin/aima-rt-daemon" in rt_txt)

    check("ai-ma.service 与微内核建立强依赖 (BindsTo)",
          "BindsTo=aima-rt.service" in app_txt)
    check("ai-ma.service 声明 PartOf 联动重启",
          "PartOf=aima-rt.service" in app_txt)
    check("ai-ma.service 禁止重复伴生拉起微内核 (AIMA_RT_EXTERNAL=1)",
          "AIMA_RT_EXTERNAL=1" in app_txt)

    # --- 关键构件 4: kernel_bridge 纳入 Cython 保护 ---
    manifest_p = os.path.join(DIST, "RELEASE_MANIFEST.json")
    check("含发布清单 RELEASE_MANIFEST.json", os.path.isfile(manifest_p))
    manifest = json.load(open(manifest_p, encoding="utf-8")) if os.path.isfile(manifest_p) else {}
    protected = manifest.get("protected_core_modules", [])
    check("kernel_bridge.py 已纳入核心编译保护 (共享内存 ABI 契约)",
          "kernel_bridge.py" in protected, f"保护清单={protected}")
    check("失效模块名 artnet_controller.py 已修正",
          "artnet_controller.py" not in protected and "artnet_sender.py" in protected)
    check("发布清单版本号为 v5.3",
          manifest.get("release_tag") == "v5.3", f"tag={manifest.get('release_tag')}")

    # --- 关键构件 5: build_debian.sh 含 Rust 构建段 ---
    sh_p = os.path.join(DIST, "build_debian.sh")
    sh_txt = open(sh_p, encoding="utf-8").read() if os.path.isfile(sh_p) else ""
    check("build_debian.sh 含 Rust 微内核构建段", "cargo build --release" in sh_txt)
    check("build_debian.sh 构建 aima-rt-daemon 与 SDK",
          "aima-rt-daemon" in sh_txt and "aima-shm-sdk" in sh_txt)
    missing = [m[:-3] for m in protected if m[:-3] not in sh_txt]
    check("build_debian.sh 源码销毁清单完整覆盖保护清单",
          not missing, f"未覆盖={missing}" if missing else f"覆盖 {len(protected)} 个模块")

    # --- 关键构件 6: 包内 control_station.py 带 systemd 托管保护 ---
    cs_txt = ""
    cs_p = os.path.join(DIST, "control_station.py")
    if os.path.isfile(cs_p):
        cs_txt = open(cs_p, encoding="utf-8").read()
    check("包内控制台含 AIMA_RT_EXTERNAL 托管保护",
          "AIMA_RT_EXTERNAL" in cs_txt)
    check("包内控制台含双内核争抢防护探针",
          "_kernel_already_live" in cs_txt)

    # --- 前端混淆产物 ---
    check("前端混淆产物齐备",
          os.path.isfile(os.path.join(DIST, "web", "index.html")) and
          os.path.isfile(os.path.join(DIST, "web", "assets", "app.js")))
    return manifest


def phase3_boot_package():
    print("\n" + "=" * 74)
    print(" [阶段三] 真实启动发布包 (证明包是活的，不是只有文件齐)")
    print("=" * 74)

    # 独占性前置检查：共享内存槽位与 9000 端口是全局单例资源。
    # 若已有实例在跑，本阶段必须跳过而非杀死别人的进程。
    pre_kernel_pids = set(find_kernel_pids())
    port_busy = False
    try:
        with socket.create_connection((HOST, PORT), timeout=1.0):
            port_busy = True
    except OSError:
        pass
    if pre_kernel_pids or port_busy:
        check("阶段三独占性前置检查", False,
              f"已有 AI-MA 实例在运行 (内核 PID={sorted(pre_kernel_pids)}, 端口占用={port_busy})，"
              f"本阶段跳过以避免打断正在使用的会话")
        return

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    boot_log = open(os.path.join(DIST, "logs", "_pkg_boot.log"), "w",
                    encoding="utf-8", errors="replace")
    proc = subprocess.Popen(
        [sys.executable, os.path.join(DIST, "control_station.py")],
        cwd=DIST, env=env, stdout=boot_log, stderr=subprocess.STDOUT
    )
    print(f"    -> 发布包总控已启动 (PID: {proc.pid})")
    started = False
    try:
        started = wait_port(HOST, PORT, timeout=40)
        check("发布包 HTTP 服务就绪", started)
        if not started:
            return
        time.sleep(1.5)

        pids = find_kernel_pids()
        check("发布包成功拉起微内核伴生进程", len(pids) >= 1, f"PID={pids}")

        log_txt = ""
        if os.path.exists(DIST_LOG):
            with open(DIST_LOG, encoding="utf-8", errors="replace") as f:
                log_txt = "".join(f.readlines()[-400:])
        check("发布包挂载 abi3 ABI 扩展成功",
              "微内核共享内存驱动初始化成功" in log_txt)
        check("发布包进入 v5.3_shm 硬件卸载模式",
              "硬实时微内核硬件卸载加速模式" in log_txt)
        check("发布包未退回 Python 纯软件模式",
              "未检测到微内核或已禁用" not in log_txt)

        st, res = http_json("/api/auth/login", method="POST",
                            payload={"username": "admin", "password": "admin123"})
        token = res.get("session", {}).get("token", "")
        check("发布包登录鉴权可用", bool(token))

        st, installed = http_json("/api/plugins/installed", token=token)
        tiers = sorted({p.get("tier") for p in installed})
        leaked = HIDDEN_PLUGIN_IDS & {p.get("id") for p in installed}
        check("发布包插件三层隔离生效 (仅 3 类)", tiers == [3], f"tiers={tiers}")
        check("发布包 1/2 类插件零泄漏", not leaked,
              f"泄漏={sorted(leaked)}" if leaked else f"可见={[p.get('id') for p in installed]}")

        st, tel = http_json("/api/kernel/telemetry", token=token)
        check("发布包遥测链路可用且数据有效",
              tel.get("enabled") is True and tel.get("frame_index", 0) > 0,
              f"frame_index={tel.get('frame_index')} jitter_ns={tel.get('jitter_ns')}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=12)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=5)
        boot_log.close()
        time.sleep(2.0)
        # 只关心本次新拉起的内核是否被回收
        leftover = [p for p in find_kernel_pids() if p not in pre_kernel_pids]
        check("包退出后微内核被原子回收 (无孤儿)",
              len(leftover) == 0, f"残留={leftover}" if leftover else "已干净退出")


def main():
    print("=" * 74)
    print("   AI-MA 5.3 发布包完整性预检与产线回归 (真实构建 + 真实启动)")
    print("=" * 74)

    if not phase1_build():
        print("\n[中止] 打包流水线未能成功，后续校验无意义。")
        return
    phase2_integrity()
    phase3_boot_package()

    print("\n" + "=" * 74)
    passed = sum(1 for _, ok, _ in _results if ok)
    total = len(_results)
    if passed == total:
        print(f"  [ALL PASSED] 发布包完整性预检 {passed}/{total} 全部通过！")
    else:
        print(f"  [FAILED] 通过 {passed}/{total}，未通过项：")
        for n, ok, d in _results:
            if not ok:
                print(f"      - {n} | {d}")
    print("=" * 74)
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
