# -*- coding: utf-8 -*-
"""
AI-MA 现役 10 款插件适配验收测试套件
覆盖标准：
1. 测试全部 10 款插件实例化与新接口规范完整性 (get_info, tier, get_provided_capabilities, get_required_adapters 等)
2. 测试全部 10 款插件执行 on_save_state() 和 on_restore_state(state)，验证热重载状态零丢失
3. 使用 tools/aima_plugin_cli.py verify 静态门禁检查全部 10 款插件，确保 100% PASS
4. 测试 2 类与 3 类阶梯依赖在现役插件生态组合下完整连通 (PluginHost 完整装载)
5. 测试 1 类 RPC 注册及 3 类事件广播与状态镜像访问能力
"""

import os
import sys
import unittest
import subprocess

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
CORE_DIR = os.path.join(BASE_DIR, "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from core.plugin_sdk import (
    PluginTier, PluginType, CoreContext, ServiceBroker, EventHub, ReadOnlyStateMirror
)
from core.plugin_host import PluginHost

# 导入全部 10 款插件
from plugins.adapters.ma_fixture_adapter import MAFixtureAdapterPlugin
from plugins.adapters.artnet_dashboard_adapter import ArtNetDashboardAdapter

from plugins.community.breathing_plugin import BreathingMacroPlugin
from plugins.community.marquee_plugin import MarqueeMacroPlugin
from plugins.community.perception_audio_beat_sim import AudioBeatSimPlugin
from plugins.community.show_evolution_learning_plugin import ShowEvolutionLearningPlugin

from plugins.system.artnet_plugin import ArtNetProtocolPlugin
from plugins.system.sacn_plugin import SACNProtocolPlugin
from plugins.system.qwen_plugin import LocalQwenLLMPlugin
from plugins.system.system_log_ai_repair_plugin import SystemLogAIRepairPlugin


class TestExistingPluginsAdaptation(unittest.TestCase):

    def setUp(self):
        self.broker = ServiceBroker()
        self.hub = EventHub()
        self.mirror = ReadOnlyStateMirror()
        self.ctx = CoreContext(
            service_broker=self.broker,
            event_hub=self.hub,
            state_mirror=self.mirror
        )
        self._active_plugins = []
        self._active_hosts = []

    def tearDown(self):
        """显式释放所有启用的插件和宿主资源，避免 UDP 端口 (6454) 或后台子线程泄漏"""
        for p in self._active_plugins:
            try:
                p.set_enabled(False)
            except Exception:
                pass
            try:
                p.on_disable()
            except Exception:
                pass
        self._active_plugins.clear()

        for host in self._active_hosts:
            try:
                for p in list(host._plugins.values()):
                    try:
                        p.set_enabled(False)
                    except Exception:
                        pass
                    try:
                        p.on_disable()
                    except Exception:
                        pass
            except Exception:
                pass
        self._active_hosts.clear()

    def test_01_all_10_plugins_instantiation_and_contract(self):
        """1. 测试全部 10 款插件实例化与新接口规范完整性"""
        plugin_classes = [
            MAFixtureAdapterPlugin,
            ArtNetDashboardAdapter,
            BreathingMacroPlugin,
            MarqueeMacroPlugin,
            AudioBeatSimPlugin,
            ShowEvolutionLearningPlugin,
            ArtNetProtocolPlugin,
            SACNProtocolPlugin,
            LocalQwenLLMPlugin,
            SystemLogAIRepairPlugin,
        ]
        self.assertEqual(len(plugin_classes), 10, "必须覆盖 10 款现役插件")

        for cls in plugin_classes:
            p = cls()
            init_ok = p.on_init(self.ctx)
            self.assertTrue(init_ok, f"插件 {cls.__name__} on_init 失败")

            info = p.get_info()
            self.assertIsInstance(info, dict)
            self.assertIn("id", info)
            self.assertIn("name", info)
            self.assertIn("version", info)
            self.assertIn("type", info)

            # 验证上下文挂载
            self.assertIsNotNone(p.get_service_broker())
            self.assertIsNotNone(p.get_event_hub())
            self.assertIsNotNone(p.get_state_mirror())

        # 针对 2 类适配插件验证能力提供
        p_ma = MAFixtureAdapterPlugin()
        p_ma.on_init(self.ctx)
        caps_ma = p_ma.get_provided_capabilities()
        self.assertIn("fixture_profile_conversion", caps_ma)
        self.assertIn("grandma_xml_import", caps_ma)
        self.assertIn("adapter_ma_fixture", caps_ma)

        p_artnet_dash = ArtNetDashboardAdapter()
        p_artnet_dash.on_init(self.ctx)
        caps_dash = p_artnet_dash.get_provided_capabilities()
        self.assertIn("artnet_monitor", caps_dash)
        self.assertIn("dmx_telemetry", caps_dash)
        self.assertIn("adapter_artnet_dashboard", caps_dash)

        # 针对 3 类创意插件验证依赖声明
        p_breath = BreathingMacroPlugin()
        self.assertIn("fixture_profile_conversion", p_breath.get_required_adapters())

        p_marquee = MarqueeMacroPlugin()
        self.assertIn("fixture_profile_conversion", p_marquee.get_required_adapters())

        p_audio = AudioBeatSimPlugin()
        self.assertIn("artnet_monitor", p_audio.get_required_adapters())

        p_evo = ShowEvolutionLearningPlugin()
        self.assertIn("fixture_profile_conversion", p_evo.get_required_adapters())

        print("\n[PASS] 断言 1: 全部 10 款插件实例化与新接口规范完整性校验通过")

    def test_02_hot_reload_state_zero_loss(self):
        """2. 测试 10 款插件全部成功执行 on_save_state() 和 on_restore_state(state)，验证热重载零丢失"""
        # 1. MAFixtureAdapterPlugin
        p_ma = MAFixtureAdapterPlugin()
        p_ma.on_init(self.ctx)
        p_ma._converted_count = 42
        state_ma = p_ma.on_save_state()
        p_ma_new = MAFixtureAdapterPlugin()
        p_ma_new.on_init(self.ctx)
        p_ma_new.on_restore_state(state_ma)
        self.assertEqual(p_ma_new._converted_count, 42)

        # 2. ArtNetDashboardAdapter
        p_dash = ArtNetDashboardAdapter()
        p_dash.on_init(self.ctx)
        p_dash._stats["total_packets"] = 10086
        p_dash._stats["universes"][1] = {"packets": 500, "seq": 12}
        state_dash = p_dash.on_save_state()
        p_dash_new = ArtNetDashboardAdapter()
        p_dash_new.on_init(self.ctx)
        p_dash_new.on_restore_state(state_dash)
        self.assertEqual(p_dash_new._stats["total_packets"], 10086)
        self.assertEqual(p_dash_new._stats["universes"][1]["packets"], 500)

        # 3. BreathingMacroPlugin
        p_breath = BreathingMacroPlugin()
        p_breath.on_init(self.ctx)
        p_breath.current_phase = 0.75
        p_breath.cycle_time = 3500.0
        state_breath = p_breath.on_save_state()
        p_breath_new = BreathingMacroPlugin()
        p_breath_new.on_init(self.ctx)
        p_breath_new.on_restore_state(state_breath)
        self.assertEqual(p_breath_new.current_phase, 0.75)
        self.assertEqual(p_breath_new.cycle_time, 3500.0)

        # 4. MarqueeMacroPlugin
        p_mar = MarqueeMacroPlugin()
        p_mar.on_init(self.ctx)
        p_mar.step_offset = 7
        p_mar.direction = -1
        state_mar = p_mar.on_save_state()
        p_mar_new = MarqueeMacroPlugin()
        p_mar_new.on_init(self.ctx)
        p_mar_new.on_restore_state(state_mar)
        self.assertEqual(p_mar_new.step_offset, 7)
        self.assertEqual(p_mar_new.direction, -1)

        # 5. AudioBeatSimPlugin
        p_audio = AudioBeatSimPlugin()
        p_audio.on_init(self.ctx)
        p_audio.beat_count = 120
        p_audio.bpm = 140
        p_audio.current_energy = 0.88
        state_audio = p_audio.on_save_state()
        p_audio_new = AudioBeatSimPlugin()
        p_audio_new.on_init(self.ctx)
        p_audio_new.on_restore_state(state_audio)
        self.assertEqual(p_audio_new.beat_count, 120)
        self.assertEqual(p_audio_new.bpm, 140)
        self.assertAlmostEqual(p_audio_new.current_energy, 0.88, places=2)

        # 6. ShowEvolutionLearningPlugin
        p_evo = ShowEvolutionLearningPlugin()
        p_evo.on_init(self.ctx)
        p_evo.learning_weights["dimmer"] = 1.5
        p_evo.evolution_rounds = 9
        p_evo.learning_rate = 0.02
        state_evo = p_evo.on_save_state()
        p_evo_new = ShowEvolutionLearningPlugin()
        p_evo_new.on_init(self.ctx)
        p_evo_new.on_restore_state(state_evo)
        self.assertEqual(p_evo_new.learning_weights["dimmer"], 1.5)
        self.assertEqual(p_evo_new.evolution_rounds, 9)
        self.assertAlmostEqual(p_evo_new.learning_rate, 0.02, places=3)

        # 7. ArtNetProtocolPlugin
        p_art = ArtNetProtocolPlugin()
        p_art.on_init(self.ctx)
        p_art.packet_count = 999
        p_art.target_ip = "192.168.1.100"
        p_art.port = 6454
        state_art = p_art.on_save_state()
        p_art_new = ArtNetProtocolPlugin()
        p_art_new.on_init(self.ctx)
        p_art_new.on_restore_state(state_art)
        self.assertEqual(p_art_new.packet_count, 999)
        self.assertEqual(p_art_new.target_ip, "192.168.1.100")

        # 8. SACNProtocolPlugin
        p_sacn = SACNProtocolPlugin()
        p_sacn.on_init(self.ctx)
        p_sacn.packet_count = 888
        p_sacn._sequences[1] = 65
        state_sacn = p_sacn.on_save_state()
        p_sacn_new = SACNProtocolPlugin()
        p_sacn_new.on_init(self.ctx)
        p_sacn_new.on_restore_state(state_sacn)
        self.assertEqual(p_sacn_new.packet_count, 888)
        self.assertEqual(p_sacn_new._sequences[1], 65)

        # 9. LocalQwenLLMPlugin
        p_qwen = LocalQwenLLMPlugin()
        p_qwen.on_init(self.ctx)
        p_qwen.total_calls = 35
        p_qwen.last_latency_ms = 120.5
        p_qwen.model_name = "qwen2.5-32b-custom"
        state_qwen = p_qwen.on_save_state()
        p_qwen_new = LocalQwenLLMPlugin()
        p_qwen_new.on_init(self.ctx)
        p_qwen_new.on_restore_state(state_qwen)
        self.assertEqual(p_qwen_new.total_calls, 35)
        self.assertEqual(p_qwen_new.model_name, "qwen2.5-32b-custom")

        # 10. SystemLogAIRepairPlugin
        p_log = SystemLogAIRepairPlugin()
        p_log.on_init(self.ctx)
        p_log.analyzed_logs_count = 18
        p_log.repair_suggestions_cache = [{"timestamp": 123456, "analysis": {"severity": "LOW"}}]
        state_log = p_log.on_save_state()
        p_log_new = SystemLogAIRepairPlugin()
        p_log_new.on_init(self.ctx)
        p_log_new.on_restore_state(state_log)
        self.assertEqual(p_log_new.analyzed_logs_count, 18)
        self.assertEqual(len(p_log_new.repair_suggestions_cache), 1)

        print("[PASS] 断言 2: 全部 10 款插件热重载状态导出与恢复零丢失验证通过")

    def test_03_static_cli_verify_all_10_plugins(self):
        """3. 使用 tools/aima_plugin_cli.py verify 对 10 款插件逐一进行静态门禁检查，确保 100% PASS"""
        plugin_files = [
            "plugins/adapters/ma_fixture_adapter.py",
            "plugins/adapters/artnet_dashboard_adapter.py",
            "plugins/community/breathing_plugin.py",
            "plugins/community/marquee_plugin.py",
            "plugins/community/perception_audio_beat_sim.py",
            "plugins/community/show_evolution_learning_plugin.py",
            "plugins/system/artnet_plugin.py",
            "plugins/system/sacn_plugin.py",
            "plugins/system/qwen_plugin.py",
            "plugins/system/system_log_ai_repair_plugin.py",
        ]
        cli_path = os.path.join(BASE_DIR, "tools", "aima_plugin_cli.py")

        for rel_path in plugin_files:
            abs_path = os.path.join(BASE_DIR, rel_path)
            cmd = [sys.executable, cli_path, "verify", "--file", abs_path]
            res = subprocess.run(cmd, capture_output=True, text=True, cwd=BASE_DIR)
            self.assertEqual(
                res.returncode, 0,
                f"CLI 门禁检查失败: {rel_path}\nSTDOUT: {res.stdout}\nSTDERR: {res.stderr}"
            )
            self.assertIn("[PASS]", res.stdout, f"CLI 输出应包含 [PASS]: {res.stdout}")

        print("[PASS] 断言 3: CLI 静态门禁对 10 款插件 100% 校验通过")

    def test_04_layered_dependencies_full_topology(self):
        """4. 测试 2 类与 3 类阶梯依赖在现有插件组合下完整连通 (PluginHost 完整装载)"""
        real_plugins_dir = os.path.join(BASE_DIR, "plugins")
        config_path = os.path.join(BASE_DIR, "config", "plugins_config.json")
        host = PluginHost(real_plugins_dir, self.ctx, config_path)
        self._active_hosts.append(host)
        host.discover_and_load_all()

        report = host.get_diagnostic_report()
        self.assertEqual(report["failed_total"], 0, f"插件装载失败项: {report['failures']}")
        self.assertEqual(report["loaded_total"], 10, f"应成功装载 10 款现役插件，实得: {report['loaded_total']}")

        # 验证 2 类提供的能力全部被注册
        self.assertTrue(host.is_adapter_available("fixture_profile_conversion"))
        self.assertTrue(host.is_adapter_available("grandma_xml_import"))
        self.assertTrue(host.is_adapter_available("adapter_ma_fixture"))
        self.assertTrue(host.is_adapter_available("artnet_monitor"))
        self.assertTrue(host.is_adapter_available("dmx_telemetry"))
        self.assertTrue(host.is_adapter_available("adapter_artnet_dashboard"))

        # 验证 3 类插件的依赖全部满足
        p_breath = host._plugins.get("macro_breathing")
        self.assertIsNotNone(p_breath)
        dep_ok, _ = host.verify_dependencies(p_breath)
        self.assertTrue(dep_ok)

        p_marquee = host._plugins.get("macro_marquee")
        self.assertIsNotNone(p_marquee)
        dep_ok, _ = host.verify_dependencies(p_marquee)
        self.assertTrue(dep_ok)

        p_audio = host._plugins.get("perception_audio_beat_sim")
        self.assertIsNotNone(p_audio)
        dep_ok, _ = host.verify_dependencies(p_audio)
        self.assertTrue(dep_ok)

        p_evo = host._plugins.get("show_evolution_learning")
        self.assertIsNotNone(p_evo)
        dep_ok, _ = host.verify_dependencies(p_evo)
        self.assertTrue(dep_ok)

        print("[PASS] 断言 4: 2 类与 3 类阶梯依赖在现役插件生态下 100% 完整连通")

    def test_05_rpc_and_event_hub_connectivity(self):
        """5. 测试 1 类 RPC 注册及 3 类事件广播连通性（确定性消除竞态、分离断言、完善资源释放）"""
        p_art = ArtNetProtocolPlugin()
        self._active_plugins.append(p_art)
        p_art.on_init(self.ctx)
        p_art.packet_count = 15

        # 跨插件安全 RPC 查询 Art-Net 统计 (调用者为 host 白名单)
        stats = self.broker.call_service(
            caller_id="host",
            service_name="artnet_stats",
            payload={}
        )
        self.assertEqual(stats["packet_count"], 15)

        # 3 类 AudioBeatSimPlugin 事件广播测试
        p_audio = AudioBeatSimPlugin()
        self._active_plugins.append(p_audio)
        p_audio.on_init(self.ctx)
        p_audio.set_enabled(True)

        received_events = []
        def _on_beat(topic, data):
            received_events.append(data)

        self.hub.subscribe("audio.beat", "test_subscriber", _on_beat)

        # (a) 验证插件自身发布的事件：
        # 通过 mock 时间将当前时间对齐到节拍间隔起点 (beat_phase 趋近于 0，满足 < 0.15 且满足 last_beat_time 间隔)，
        # 彻底消除时间/相位随机竞态，100% 确定性触发节拍分支并发布事件
        import unittest.mock as mock
        cfg = p_audio.get_config()
        bpm = int(cfg.get("bpm", 128))
        beat_interval = 60.0 / max(1, bpm)
        fixed_beat_time = beat_interval * 1000.0 + 0.001  # 确保 (time % beat_interval) / beat_interval < 0.15

        with mock.patch("time.time", return_value=fixed_beat_time):
            p_audio.get_status()

        # 断言接收到来自插件发布的真实事件，且包含真实节拍元数据
        self.assertGreaterEqual(len(received_events), 1, "必须接收到插件自身发布的节拍事件")
        plugin_event = received_events[0]
        self.assertIn("beat_count", plugin_event)
        self.assertIn("bpm", plugin_event)
        self.assertIn("energy", plugin_event)
        self.assertEqual(plugin_event["bpm"], bpm)
        self.assertEqual(plugin_event["beat_count"], 1)

        # (b) 验证手动发布通道：
        received_events.clear()
        self.hub.publish("audio.beat", "manual_test", {"beat_count": 999, "bpm": 128})
        self.assertEqual(len(received_events), 1, "必须接收到手动发布的事件")
        self.assertEqual(received_events[0]["beat_count"], 999)

        print("[PASS] 断言 5: RPC 跨插件服务调用与 EventHub 事件驱动链路通畅 (竞态彻底消除)")


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestExistingPluginsAdaptation)
    res = unittest.TextTestRunner(verbosity=1).run(suite)
    if res.wasSuccessful():
        print(f"\n结果: {res.testsRun} 项全部通过 / 0 项失败")
        sys.exit(0)
    else:
        sys.exit(1)
