# -*- coding: utf-8 -*-
"""
AI-MA 5.3 独立系统 · 双进程伴生架构端到端启动准出测试

验证目标（全部为真实进程与真实 HTTP 调用，不做任何 mock）：
  1. control_station.py 启动后自动伴生拉起 Rust 硬实时微内核 aima-rt-daemon；
  2. 微内核进程存活，且内核日志独立落盘 logs/aima_rt_daemon.log；
  3. CoreEngine 进入 v5.3_shm 硬件卸载模式（微内核共享内存挂载成功）；
  4. 系统日志中不出现 ERR-KERNEL-DAEMON 故障码；
  5. /api/plugins/installed 仅返回 3 类表现创意插件，1 类 / 2 类 100% 隐匿；
  6. /api/kernel/telemetry 遥测链路可用；
  7. 关闭总控后，伴生微内核被优雅回收，不留孤儿进程。
"""

import os
import sys
import json
import time
import socket
import subprocess
import urllib.request
import urllib.error

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_FILE = os.path.join(SYS_ROOT, "logs", "ai_ma_system.log")
RT_LOG_FILE = os.path.join(SYS_ROOT, "logs", "aima_rt_daemon.log")
CONTROL_PY = os.path.join(SYS_ROOT, "control_station.py")

HOST = "127.0.0.1"
PORT = 9000
BASE = f"http://{HOST}:{PORT}"

# 必须隐匿的 1 类（系统底层）与 2 类（资产适配）插件
HIDDEN_PLUGIN_IDS = {
    "protocol_artnet_standard",   # 1 类 Art-Net 协议驱动
    "protocol_sacn_standard",     # 1 类 sACN E1.31 协议驱动
    "llm_local_qwen_7b",          # 1 类 端侧大模型中枢
    "system_log_ai_repair",       # 1 类 AI 日志自愈中枢
    "adapter_ma_fixture",         # 2 类 GrandMA 灯库资产适配器
}

_results = []

def check(name, ok, detail=""):
    _results.append((name, ok, detail))
    print(f"    -> [{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))
    return ok

def wait_port(host, port, timeout=30.0):
    """轮询等待端口进入可连接状态"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.3)
    return False

def http_json(path, token=None, method="GET", payload=None):
    """
    发起 JSON 请求并返回 (status_code, body)。

    必须捕获 HTTPError：4xx/5xx 是**测试要断言的有效结果**（例如未授权访问
    诊断接口应当返回 401）。若不捕获，urllib 会直接抛异常中断整个测试，
    反而掩盖了服务端本来就正确的拒绝行为。
    """
    url = BASE + path
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    if payload is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, {"raw": raw}

def read_log_tail(path, n=400):
    if not os.path.exists(path):
        return ""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return "".join(f.readlines()[-n:])

def python_procs_matching(needle):
    """用 tasklist 枚举进程命令行，返回匹配 needle 的 PID 列表"""
    try:
        out = subprocess.run(
            ["wmic", "process", "where", "name='aima-rt-daemon.exe'", "get", "ProcessId"],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace"
        ).stdout
        pids = [int(x) for x in out.split() if x.strip().isdigit()]
        return pids
    except Exception:
        return []

def main():
    print("=" * 74)
    print("   AI-MA 5.3 双进程伴生架构 · 端到端启动准出测试 (真实进程 + 真实 HTTP)")
    print("=" * 74)

    # ---------------------------------------------------------------
    # 独占性前置检查（关键：绝不越界杀死别人的进程）
    # 本系统的共享内存槽位 (/dev/shm/aima_slot_*) 与 9000 端口是全局单例资源，
    # 因此同一时刻只允许一个控制台实例运行。若检测到已有实例在跑，
    # 本测试必须"拒绝运行"而不是"杀掉了事"——否则会打断用户正在使用的会话。
    # ---------------------------------------------------------------
    existing_kernels = python_procs_matching("aima-rt-daemon")
    port_busy = False
    try:
        with socket.create_connection((HOST, PORT), timeout=1.0):
            port_busy = True
    except OSError:
        pass

    if existing_kernels or port_busy:
        print("\n[SKIP] 检测到已有 AI-MA 实例正在运行，本测试需要独占环境，故拒绝执行。")
        if existing_kernels:
            print(f"       已存在的微内核进程 PID: {existing_kernels}")
        if port_busy:
            print(f"       端口 {HOST}:{PORT} 已被占用")
        print("\n       请先关闭正在运行的控制台（Ctrl+C 或结束对应进程），再重新运行本测试。")
        print("       本测试不会为了自身方便而杀死你正在使用的进程。")
        sys.exit(2)

    # 记录启动前的内核 PID 集合，用于退出时只回收"本次测试自己拉起的"内核
    pre_kernel_pids = set(python_procs_matching("aima-rt-daemon"))

    # 记录启动前的日志长度，便于只检查本次启动产生的新日志
    pre_log_len = len(read_log_tail(LOG_FILE, n=100000))

    print("\n[1] 启动总控台 control_station.py ...")
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    boot_log = open(os.path.join(SYS_ROOT, "logs", "_boot_stdout.log"), "w",
                    encoding="utf-8", errors="replace")
    proc = subprocess.Popen(
        [sys.executable, CONTROL_PY],
        cwd=SYS_ROOT, env=env,
        stdout=boot_log, stderr=subprocess.STDOUT
    )
    print(f"    -> 总控台已启动 (PID: {proc.pid})")

    try:
        # ---------- 2. 等待服务就绪 ----------
        print("\n[2] 等待 HTTP 服务就绪 (127.0.0.1:9000) ...")
        if not wait_port(HOST, PORT, timeout=40):
            check("总控台 HTTP 服务就绪", False, "端口 9000 未在 40s 内监听")
            return
        check("总控台 HTTP 服务就绪", True, "端口 9000 已监听")
        time.sleep(1.5)  # 留出微内核初始化与首轮日志落盘时间

        # ---------- 3. 伴生微内核进程存活 ----------
        print("\n[3] 校验伴生硬实时微内核守护进程 ...")
        kernel_pids = python_procs_matching("aima-rt-daemon")
        check("aima-rt-daemon 伴生进程存活", len(kernel_pids) >= 1,
              f"PID={kernel_pids}" if kernel_pids else "未发现微内核进程")
        check("微内核运行日志独立落盘", os.path.exists(RT_LOG_FILE),
              RT_LOG_FILE if os.path.exists(RT_LOG_FILE) else "日志文件不存在")

        # ---------- 4. 系统日志关键基线 ----------
        print("\n[4] 校验系统日志关键基线 ...")
        full_log = read_log_tail(LOG_FILE, n=100000)
        new_log = full_log[pre_log_len:] if len(full_log) > pre_log_len else full_log

        check("日志记录微内核已伴生拉起",
              "已成功拉起伴生运行" in new_log)
        check("AimaKernelBridge 共享内存挂载成功",
              "微内核共享内存驱动初始化成功" in new_log)
        check("CoreEngine 进入 v5.3_shm 硬件卸载模式",
              "硬实时微内核硬件卸载加速模式" in new_log)
        check("未出现内核守护故障码 ERR-KERNEL-DAEMON",
              "ERR-KERNEL-DAEMON" not in new_log)
        check("未回退到 Python 纯软件兼容模式",
              "未检测到微内核或已禁用" not in new_log)

        # 插件分层装载可观测性：1/2 类虽然不上面向用户的界面，
        # 但必须在启动日志里明确交代"装载成功还是失败"。
        check("启动日志输出分层装载总览",
              "插件生态装载总览" in new_log)
        check("1 类系统级插件在日志中带层级标签可见",
              "[1类·系统级] 插件 [" in new_log)
        check("2 类适配级插件在日志中带层级标签可见",
              "[2类·适配级] 插件 [" in new_log)
        check("启动日志无底座插件装载失败告警",
              "ERR-PLUGIN-FOUNDATION" not in new_log)

        # ---------- 5. 登录 ----------
        print("\n[5] 管理员登录鉴权 ...")
        st, res = http_json("/api/auth/login", method="POST",
                            payload={"username": "admin", "password": "admin123"})
        ok = (st == 200 and res.get("status") == "ok")
        token = res.get("session", {}).get("token", "") if ok else ""
        check("admin 登录成功并签发会话凭证", bool(token), f"role={res.get('session', {}).get('role')}")
        if not token:
            return

        # ---------- 6. 插件三层物理隔离 ----------
        print("\n[6] 校验插件三层物理隔离 (1/2 类必须隐匿) ...")
        st, installed = http_json("/api/plugins/installed", token=token)
        ids = [p.get("id") for p in installed]
        tiers = sorted({p.get("tier") for p in installed})
        check("已装载插件接口返回成功", st == 200, f"HTTP {st}")
        check("返回列表 100% 为 3 类创意插件", tiers == [3], f"tiers={tiers}")
        leaked = HIDDEN_PLUGIN_IDS & set(ids)
        check("1 类 / 2 类底层插件零泄漏", not leaked,
              f"泄漏项={sorted(leaked)}" if leaked else f"在线用户可见插件={ids}")
        # 交付基线：4 个 3 类创意插件应全部处于启用态。
        # 启停是灯光师的合法操作，故此项以"交付基线"名义报告，便于发现状态漂移。
        state = {p.get("id"): bool(p.get("enabled")) for p in installed}
        disabled = [k for k, v in state.items() if not v]
        check("交付基线：4 个创意插件全部启用", not disabled,
              f"当前状态={state}" if not disabled else f"处于停用态={disabled}")

        # ---------- 6b. 运维可见性通道：诊断接口必须能看到全部三层 ----------
        print("\n[6b] 校验插件诊断接口 (运维可见性, 与用户界面隔离) ...")
        st, diag = http_json("/api/plugins/diagnostics", token=token)
        check("诊断接口返回成功", st == 200, f"HTTP {st}")
        by_tier = diag.get("by_tier", {})
        check("诊断接口按三层分组返回",
              set(by_tier.keys()) == {"1类·系统级", "2类·适配级", "3类·表现创意"},
              f"keys={list(by_tier.keys())}")
        check("诊断接口列出 1 类系统级插件",
              len(by_tier.get("1类·系统级", [])) >= 2,
              f"1类={[p.get('id') for p in by_tier.get('1类·系统级', [])]}")
        check("诊断接口列出 2 类适配级插件",
              len(by_tier.get("2类·适配级", [])) >= 1,
              f"2类={[p.get('id') for p in by_tier.get('2类·适配级', [])]}")
        check("诊断接口报告系统底座健康",
              diag.get("foundation_healthy") is True)
        check("诊断接口报告零装载失败",
              diag.get("failed_total") == 0,
              f"失败项={diag.get('failures')}")
        check("诊断接口的 3 类计数与用户界面一致",
              len(by_tier.get("3类·表现创意", [])) == len(installed),
              f"诊断={len(by_tier.get('3类·表现创意', []))} 用户界面={len(installed)}")
        # 权限边界：未登录不得读取诊断报告
        st_anon, _ = http_json("/api/plugins/diagnostics")
        check("未登录访问诊断接口被拒绝", st_anon == 401, f"HTTP {st_anon}")

        # ---------- 7. 遥测链路（不仅接口可达，内容必须真实有效） ----------
        print("\n[7] 校验微内核遥测链路与数据有效性 ...")
        st, tel = http_json("/api/kernel/telemetry", token=token)
        check("遥测接口可访问", st == 200, f"HTTP {st}")
        check("遥测标记微内核已启用", tel.get("enabled") is True, f"enabled={tel.get('enabled')}")
        check("遥测帧计数为真实递增值", isinstance(tel.get("frame_index"), int) and tel["frame_index"] > 0,
              f"frame_index={tel.get('frame_index')}  (44Hz 内核已实际渲染帧)")
        check("遥测时间戳为有效纳秒时钟", isinstance(tel.get("timestamp_ns"), int) and tel["timestamp_ns"] > 0,
              f"timestamp_ns={tel.get('timestamp_ns')}")
        check("遥测抖动指标为可读整数", isinstance(tel.get("jitter_ns"), int),
              f"jitter_ns={tel.get('jitter_ns')} ns")
        head = tel.get("sample_universe_0_head") or []
        check("仲裁后通道采样为纯 Python 整型列表 (JSON 可序列化)",
              len(head) == 16 and all(isinstance(v, int) for v in head),
              f"前 16 通道采样={head[:8]}...")

    finally:
        # ---------- 8. 优雅关闭与孤儿进程回收 ----------
        print("\n[8] 关闭总控台并校验微内核优雅回收 ...")
        proc.terminate()
        try:
            proc.wait(timeout=12)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
        boot_log.close()
        time.sleep(2.0)
        # 只关心"本次测试新拉起的"内核是否被回收，绝不评估或触碰测试前就存在的进程
        leftover = [p for p in python_procs_matching("aima-rt-daemon") if p not in pre_kernel_pids]
        check("伴生微内核已被优雅回收 (无孤儿进程)",
              len(leftover) == 0, f"残留 PID={leftover}" if leftover else "已干净退出")

    print("\n" + "=" * 74)
    passed = sum(1 for _, ok, _ in _results if ok)
    total = len(_results)
    if passed == total:
        print(f"  [ALL PASSED] AI-MA 5.3 双进程伴生架构端到端准出 {passed}/{total} 全部通过！")
    else:
        print(f"  [FAILED] 通过 {passed}/{total}，存在未通过项：")
        for n, ok, d in _results:
            if not ok:
                print(f"      - {n} | {d}")
    print("=" * 74)
    sys.exit(0 if passed == total else 1)

if __name__ == "__main__":
    main()
