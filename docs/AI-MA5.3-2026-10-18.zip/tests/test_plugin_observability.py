# -*- coding: utf-8 -*-
"""
AI-MA 5.3 插件装载可观测性验证（进程内自包含版）

背景（本测试的由来）：
    三层插件分级落地后，面向用户的界面只展示 3 类创意插件。但原实现在日志里
    对所有插件使用**完全相同**的一行输出：
        插件 [xxx] (ID: yyy) 加载完成，状态: [已启用]
    完全没有层级标识。于是 1 类系统级（Art-Net 协议驱动、Qwen 端侧中枢）与
    2 类适配级（灯库资产总线）到底"启动成功"还是"启动失败"，**无法从日志判断**。

    更严重的是一个静默盲区：若插件源文件导入成功但不含任何可实例化的插件类，
    原实现直接 return None，**不留任何日志**——底座插件被漏掉却查无实据。

设计说明：
    本测试**不启动控制台、不占用 9000 端口、不触碰微内核**，而是在临时目录内
    构造合成插件，直接驱动 PluginHost，用 logging Handler 捕获输出后断言。
    因此它可以在你正开着控制台时安全运行，也不会与真实共享内存槽位冲突。

验证内容：
    阶段一：正常装载时按层级输出总览，成功日志带层级标签
    阶段二：四类失败路径全部被显式登记（导入异常 / 无插件类 / 合规校验 / on_init 失败）
    阶段三：1/2 类底座插件失败走 ERR-PLUGIN-FOUNDATION 故障码并触发 CRITICAL 告警
    阶段四：get_diagnostic_report() 结构化报告正确
    阶段五：故障诊断知识库已收录新增故障码（不再显示"未知系统异常"）
"""

import os
import sys
import shutil
import logging
import tempfile
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CORE_DIR = os.path.join(SYS_ROOT, "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from plugin_host import PluginHost, tier_label, TIER_LABELS          # noqa: E402
from plugin_sdk import CoreContext, PluginTier                        # noqa: E402
import diagnostics_logger                                             # noqa: E402
from diagnostics_logger import ERROR_DIAGNOSTICS_DB, log_diagnostic_error  # noqa: E402

_results = []


def check(name, ok, detail=""):
    _results.append((name, ok, detail))
    print(f"    -> [{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))
    return ok


# ---------------------------------------------------------------------------
# 合成插件源码。每个文件只放一个插件类。
# ---------------------------------------------------------------------------
def mk_plugin(pid, name, base, ptype, on_init_ok=True):
    """
    生成一个**符合基类抽象契约**的合成插件源码。

    注意：BasePlugin 声明了 get_info / on_init / on_enable / on_disable 四个抽象方法，
    BaseAdapterPlugin 另加 supported_extensions / convert_to_profile。
    少实现任何一个，类都会保持抽象状态而被 PluginHost 正确拒收
    （第一版夹具就漏了 on_enable/on_disable，导致 8 个插件全部在"类发现"阶段失败）。
    """
    adapter_methods = ""
    if base == "BaseAdapterPlugin":
        adapter_methods = '''
    def supported_extensions(self):
        return [".xml"]

    def convert_to_profile(self, file_bytes, filename):
        return {}
'''
    init_ret = "True" if on_init_ok else "False"
    return f'''# -*- coding: utf-8 -*-
from plugin_sdk import {base}, PluginType


class Synth_{pid}({base}):
    type = PluginType.{ptype}

    def get_info(self):
        return {{
            "id": "{pid}",
            "name": "{name}",
            "version": "1.0.0",
            "author": "obs-test",
            "type": self.type,
            "description": "合成测试插件",
        }}

    def get_config_schema(self):
        return {{"k": {{"type": "string", "label": "参数"}}}}

    def on_init(self, context):
        self.context = context
        return {init_ret}

    def on_enable(self):
        pass

    def on_disable(self):
        pass
{adapter_methods}'''


PLUGIN_SOURCES = {
    os.path.join("system", "synth_protocol.py"): mk_plugin(
        "synth_protocol", "合成协议驱动", "BaseSystemPlugin", "PROTOCOL"),
    os.path.join("system", "synth_llm.py"): mk_plugin(
        "synth_llm", "合成端侧中枢", "BaseSystemPlugin", "LLM"),
    os.path.join("adapters", "synth_fixture.py"): mk_plugin(
        "synth_fixture", "合成灯库适配器", "BaseAdapterPlugin", "ADAPTER"),
    os.path.join("community", "synth_effect.py"): mk_plugin(
        "synth_effect", "合成创意特效", "BaseCreativePlugin", "EFFECT"),

    # ---- 失败路径 1: on_init 返回 False（1 类底座）----
    os.path.join("system", "synth_dead_init.py"): mk_plugin(
        "synth_dead_init", "合成初始化失败插件", "BaseSystemPlugin", "PROTOCOL",
        on_init_ok=False),

    # ---- 失败路径 2: 源文件里没有任何插件类（原实现的完全静默盲区）----
    os.path.join("system", "synth_no_class.py"): '''# -*- coding: utf-8 -*-
"""这个文件故意不定义任何插件类——原实现在此处静默 return None，不留日志。"""
SOME_CONSTANT = 42


def helper():
    return "not a plugin"
''',

    # ---- 失败路径 3: 模块导入即抛异常 ----
    os.path.join("community", "synth_bad_import.py"): '''# -*- coding: utf-8 -*-
raise RuntimeError("故意制造的导入期异常")
''',

    # ---- 失败路径 4: 未通过合规校验（ID 含大写，违反 ^[a-z0-9_]{3,40}$）----
    os.path.join("system", "synth_bad_id.py"): mk_plugin(
        "BadID", "合成非法ID插件", "BaseSystemPlugin", "PROTOCOL"),
}


class CapturingHandler(logging.Handler):
    """捕获 PluginHost 日志器的全部记录"""
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.records = []

    def emit(self, record):
        self.records.append(record)

    @property
    def text(self):
        return "\n".join(r.getMessage() for r in self.records)

    def diag_codes(self):
        return {getattr(r, "diag_code", None) for r in self.records if getattr(r, "diag_code", None)}


def build_plugin_tree(root):
    for rel, src in PLUGIN_SOURCES.items():
        p = os.path.join(root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(src)


def main():
    print("=" * 74)
    print("   AI-MA 5.3 插件装载可观测性验证（进程内自包含 · 不占用端口）")
    print("=" * 74)

    tmp = os.path.join(tempfile.gettempdir(), f"aima_obs_{int(time.time()*1000)}")
    plugins_dir = os.path.join(tmp, "plugins")
    os.makedirs(plugins_dir, exist_ok=True)
    build_plugin_tree(plugins_dir)

    handler = CapturingHandler()
    host_logger = logging.getLogger("PluginHost")
    host_logger.addHandler(handler)
    host_logger.setLevel(logging.DEBUG)

    try:
        ctx = CoreContext(event_bus=None, dmx_merger=None, kb_manager=None,
                          config={}, services={})
        host = PluginHost(plugins_dir, ctx,
                          config_store_path=os.path.join(tmp, "plugins_config.json"))

        # ================================================================
        print("\n[阶段一] 正常装载的分层可见性")
        # ================================================================
        host.discover_and_load_all()
        txt = handler.text

        check("输出分层装载总览标题", "插件生态装载总览" in txt)
        for label in ("1类·系统级", "2类·适配级", "3类·表现创意"):
            check(f"总览含【{label}】分层计数块", f"【{label}】 已装载" in txt)

        # 成功日志必须带层级标签
        check("1 类成功日志带层级标签",
              "[1类·系统级] 插件 [合成协议驱动] (ID: synth_protocol) 装载成功" in txt,
              next((l for l in txt.splitlines() if "synth_protocol" in l and "装载成功" in l), ""))
        check("2 类成功日志带层级标签",
              "[2类·适配级] 插件 [合成灯库适配器] (ID: synth_fixture) 装载成功" in txt,
              next((l for l in txt.splitlines() if "synth_fixture" in l and "装载成功" in l), ""))
        check("3 类成功日志带层级标签",
              "[3类·表现创意] 插件 [合成创意特效] (ID: synth_effect) 装载成功" in txt)

        check("成功装载 4 个插件", len(host.list_all_plugins_summary()) == 4,
              f"实际={[p['id'] for p in host.list_all_plugins_summary()]}")

        # ================================================================
        print("\n[阶段二] 四类失败路径全部被显式登记（不再是静默盲区）")
        # ================================================================
        report = host.get_diagnostic_report()
        failures = report["failures"]
        stages = {(f["plugin_id"], f["stage"]) for f in failures}

        check("失败路径① on_init 返回 False 被记录",
              ("synth_dead_init", "on_init()") in stages, f"stages={sorted(stages)}")
        check("失败路径② 源文件无插件类被记录（原静默盲区已修补）",
              any(f["file"] == "synth_no_class.py" and f["stage"] == "类发现" for f in failures),
              next((str(f) for f in failures if f["file"] == "synth_no_class.py"), ""))
        check("失败路径③ 模块导入异常被记录",
              any(f["file"] == "synth_bad_import.py" and f["stage"] == "模块导入" for f in failures))
        check("失败路径④ 合规校验不通过被记录",
              any(f["plugin_id"] == "BadID" and f["stage"] == "合规校验" for f in failures))

        check("扫描文件数 == 成功数 + 失败数",
              report["scanned_files"] == report["loaded_total"] + report["failed_total"],
              f"扫描 {report['scanned_files']} = 成功 {report['loaded_total']} + 失败 {report['failed_total']}")

        # ================================================================
        print("\n[阶段三] 底座插件失败的告警级别与故障码")
        # ================================================================
        check("1 类底座失败走 ERR-PLUGIN-FOUNDATION 故障码",
              "ERR-PLUGIN-FOUNDATION" in handler.diag_codes(),
              f"捕获到的故障码={sorted(c for c in handler.diag_codes() if c)}")
        check("底座插件失效触发 CRITICAL 级告警",
              any(r.levelno >= logging.CRITICAL and "系统底座插件" in r.getMessage()
                  for r in handler.records))
        check("底座健康标志被置为不健康",
              report["foundation_healthy"] is False)
        check("总览的 1 类计数体现缺失",
              "【1类·系统级】 已装载 2/4" in txt,
              next((l for l in txt.splitlines() if "【1类·系统级】" in l), ""))

        # ================================================================
        print("\n[阶段四] 诊断报告结构")
        # ================================================================
        check("报告按三层分组",
              set(report["by_tier"].keys()) == {"1类·系统级", "2类·适配级", "3类·表现创意"},
              f"keys={list(report['by_tier'].keys())}")
        check("1 类分组含 2 个成功插件",
              len(report["by_tier"]["1类·系统级"]) == 2,
              f"={[p['id'] for p in report['by_tier']['1类·系统级']]}")
        check("底座插件被标记为受保护",
              all(p["protected"] for p in report["by_tier"]["1类·系统级"]
                  + report["by_tier"]["2类·适配级"]))
        check("3 类插件不被标记为受保护",
              all(not p["protected"] for p in report["by_tier"]["3类·表现创意"]))
        check("报告带层级中文标签",
              all("tier_label" in p and "类·" in p["tier_label"]
                  for grp in report["by_tier"].values() for p in grp))
        check("失败项含插件ID/文件/阶段/原因四要素",
              all(all(k in f for k in ("plugin_id", "file", "stage", "reason")) for f in failures))

        # ================================================================
        print("\n[阶段五] 故障诊断知识库收录情况")
        # ================================================================
        for code in ("ERR-PLUGIN-FOUNDATION", "ERR-KERNEL-DAEMON", "ERR-KERNEL-STALL",
                     "ERR-KERNEL-TELEMETRY", "ERR-KB-WRITE", "ERR-ADAPTER-IMPORT"):
            entry = ERROR_DIAGNOSTICS_DB.get(code)
            check(f"知识库已收录 {code}",
                  bool(entry) and entry.get("title") != "未知系统异常",
                  entry.get("title", "") if entry else "未收录")

        # 确认告警日志里不再出现"未知系统异常"
        probe_logger = logging.getLogger("DiagProbe")
        probe_handler = CapturingHandler()
        probe_logger.addHandler(probe_handler)
        probe_logger.setLevel(logging.DEBUG)
        log_diagnostic_error(probe_logger, "ERR-PLUGIN-FOUNDATION", "探针")
        check("新故障码告警不再显示『未知系统异常』",
              "未知系统异常" not in probe_handler.text,
              probe_handler.text.splitlines()[0] if probe_handler.text else "")

        # 层级标签映射
        check("层级标签映射完整",
              tier_label(PluginTier.SYSTEM) == "1类·系统级"
              and tier_label(PluginTier.ADAPTER) == "2类·适配级"
              and tier_label(PluginTier.CREATIVE) == "3类·表现创意")

    finally:
        host_logger.removeHandler(handler)
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"\n[收尾] 临时插件目录已清理: {tmp}")

    print("\n" + "=" * 74)
    passed = sum(1 for _, ok, _ in _results if ok)
    total = len(_results)
    if passed == total:
        print(f"  [ALL PASSED] 插件装载可观测性验证 {passed}/{total} 全部通过！")
    else:
        print(f"  [FAILED] 通过 {passed}/{total}，未通过项：")
        for n, ok, d in _results:
            if not ok:
                print(f"      - {n} | {d}")
    print("=" * 74)
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
