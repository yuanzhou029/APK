# -*- coding: utf-8 -*-
"""
UI v4.2 企业级界面重构 · 端到端验证
覆盖：登录门禁、静态资源服务、路径穿越防护、登出、既有 API 回归。
"""

import os
import sys
import json
import time
import http.cookiejar
import threading
import urllib.request
import urllib.error
import urllib.parse
from http.server import HTTPServer

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE_DIR, "core"))
sys.path.append(BASE_DIR)

PORT = 9098
PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")


def call(method, path, body=None, token=None):
    url = f"http://127.0.0.1:{PORT}" + urllib.parse.quote(path, safe="/?&=%")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with _OPENER.open(req, timeout=15) as r:
            raw = r.read().decode("utf-8", errors="replace")
            ctype = r.headers.get("Content-Type", "")
            try:
                return r.status, json.loads(raw), ctype
            except Exception:
                return r.status, raw, ctype
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            return e.code, json.loads(raw), e.headers.get("Content-Type", "")
        except Exception:
            return e.code, raw, e.headers.get("Content-Type", "")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """禁止自动跟随 302，否则"未登录被弹回登录页"会被跟到 200 而误判"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


# 全局统一使用"不跟随重定向"的 opener，使门禁/跳转类断言能观察到真实状态码
_OPENER = urllib.request.build_opener(_NoRedirect())


def fetch_app_as_browser():
    """
    以真实浏览器的方式取回后台页面：先登录，再用同一个 CookieJar 请求 /app。

    v4.3 起 /app 由服务端门禁保护（未登录 302 回登录页），
    因此"校验后台元素"必须先建立会话，不能再匿名 GET。
    返回 (状态码, HTML, 管理员令牌)。
    """
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar), _NoRedirect())
    login = urllib.request.Request(
        f"http://127.0.0.1:{PORT}/api/auth/login",
        data=json.dumps({"username": "admin", "password": "admin123"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    with opener.open(login, timeout=15) as r:
        session = json.loads(r.read().decode("utf-8"))["session"]
    with opener.open(f"http://127.0.0.1:{PORT}/app", timeout=15) as r:
        return r.status, r.read().decode("utf-8", errors="replace"), session["token"]


def main():
    print("=" * 72)
    print(" UI v4.2 企业级界面重构 · 端到端验证")
    print("=" * 72)

    import control_station as cs

    srv = HTTPServer(("127.0.0.1", PORT), cs.UnifiedControlStationServer)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.6)

    try:
        # ---------------- 1. 首页 = 登录门头页 ----------------
        st, html, ctype = call("GET", "/")
        check("1. GET / 返回登录首页", st == 200 and "text/html" in ctype)
        for m, label in [
            ("gate-brand", "品牌门头区"),
            ("控制台登录", "登录卡标题"),
            ("异构协同与自适应", "产品全称"),
            ("loginForm", "登录表单容器"),
            ("username", "账号输入框"),
            ("password", "密码输入框"),
            ("loginBtn", "登录按钮"),
            ("auth-card", "玻璃拟态登录卡"),
            ("/assets/theme.css", "引用企业设计系统"),
        ]:
            check(f"1. 登录页元素 · {label}", m in html)
        # 原断言要求登录页存在 quick-roles（快捷身份一键填入）。
        # 该入口在 v5 已被有意移除——它允许任何人点一下即以管理员身份登录，
        # 属安全缺陷。verify_v5_rbac_and_disaster_recovery.py 有对应断言
        # 「登录页已彻底移除快捷身份填入区域」，两者曾互相矛盾。
        # 现按 v5 的实际设计，断言该快捷入口确实不存在。
        check("1. 登录页已移除快捷身份一键填入入口（安全要求）",
              "quick-roles" not in html and ".quick-roles" not in html)
        check("1. 登录页不含后台骨架", "appShell" not in html and "sidebar" not in html)

        # ---------------- 2. /app = 后台主界面（服务端门禁保护） ----------------
        st_anon, anon, _ = call("GET", "/app")
        check("2a. 未登录访问 /app 被服务端拦回登录页（后台 DOM 不下发）",
              st_anon in (301, 302, 303, 401, 403) and "appShell" not in anon,
              f"-> HTTP {st_anon}")

        st, app, ctype = fetch_app_as_browser()
        check("2b. 登录后 GET /app 返回后台界面", st == 200)
        for m, label in [
            ("bootMask", "启动鉴权遮罩"),
            ("appShell", "应用骨架"),
            ("sidebar", "侧边导航栏"),
            ("navItems", "导航项容器"),
            ("userRole", "角色徽章"),
            ("btnLogout", "退出登录"),
            ("view-control", "交互控制台视图"),
            ("view-scenes_studio", "快捷场景视图"),
            ("view-marketplace", "插件市场视图"),
            ("view-llm_cfg", "大模型视图"),
            ("view-kb", "知识库视图"),
            ("kbSubnav", "知识库五页签"),
            ("view-monitor", "UDP监视器视图"),
            ("view-diagnostics", "诊断日志视图"),
            ("modalConfirm", "通用确认框"),
            ("toastStack", "轻提示容器"),
        ]:
            check(f"2. 后台元素 · {label}", m in app)

        # ---------------- 3. 静态资源 ----------------
        st, css, ctype = call("GET", "/assets/theme.css")
        check("3. GET /assets/theme.css", st == 200 and "text/css" in ctype and "--brand" in css,
              f"-> {st}, {len(css)} 字节")
        st, js, ctype = call("GET", "/assets/app.js")
        check("3. GET /assets/app.js", st == 200 and "javascript" in ctype and "forceLogout" in js,
              f"-> {st}, {len(js)} 字节")

        # ---------------- 4. 路径穿越防护 ----------------
        for bad in ["/assets/../control_station.py", "/assets/..%2fcontrol_station.py", "/assets/../../config/users.json"]:
            st, body, _ = call("GET", bad)
            check(f"4. 路径穿越防护 · {bad}", st == 403, f"-> HTTP {st}")

        st, body, _ = call("GET", "/assets/missing-asset-404.css")
        check("4. 缺失静态资源返回 404", st == 404, f"-> HTTP {st}")

        # ---------------- 5. 未登录访问受保护接口（全部只读接口逐一验证） ----------------
        GET_ROUTES = [
            "/api/system/status", "/api/dmx/universe/0", "/api/monitor/stats",
            "/api/logs/stream", "/api/scenes/list", "/api/plugins/installed",
            "/api/plugins/detail?id=llm_local_qwen_7b", "/api/market/packages",
            "/api/kb/summary", "/api/kb/profiles", "/api/kb/profile_detail?id=martin_mac_aura_14ch",
            "/api/kb/venues", "/api/kb/venue_detail?id=venue_livehouse_hall_a",
            "/api/kb/presets", "/api/kb/conflicts", "/api/llm/config",
        ]
        leaked = []
        for r in GET_ROUTES:
            st, _, _ = call("GET", r)
            if st != 401:
                leaked.append(f"{r} -> {st}")
        check(f"5. 全部 {len(GET_ROUTES)} 条只读接口未登录一律 401", not leaked,
              "" if not leaked else f"-> 泄露: {leaked}")

        # POST 接口同样需鉴权
        leaked_post = []
        for r in ["/api/kb/save_presets", "/api/kb/switch_venue", "/api/scenes/save",
                  "/api/market/verify_code", "/api/plugins/uninstall"]:
            st, _, _ = call("POST", r, {})
            if st != 401:
                leaked_post.append(f"{r} -> {st}")
        check("5. 写接口未登录一律 401", not leaked_post,
              "" if not leaked_post else f"-> 泄露: {leaked_post}")

        # ---------------- 6. 登录 -> 令牌 ----------------
        st, res, _ = call("POST", "/api/auth/login", {"username": "admin", "password": "admin123"})
        check("6. 管理员登录成功", st == 200 and res.get("status") == "ok")
        token = res["session"]["token"]
        check("6. 会话字段完整（角色 + 权限集）",
              res["session"].get("role") == "admin" and "operate_lights" in res["session"].get("permissions", []),
              f"-> role={res['session'].get('role')}, perms={len(res['session'].get('permissions', []))} 项")

        st, res, _ = call("POST", "/api/auth/login", {"username": "admin", "password": "wrong-password"})
        check("6. 错误密码被拒绝", st == 401 and res.get("status") == "error")

        # ---------------- 7. 令牌校验 ----------------
        st, res, _ = call("GET", "/api/auth/verify", token=token)
        check("7. 令牌校验通过", st == 200 and res.get("status") == "ok")

        # ---------------- 8. 既有 API 回归 ----------------
        for path, label in [
            ("/api/system/status", "系统状态"),
            ("/api/dmx/universe/0", "DMX 帧"),
            ("/api/monitor/stats", "UDP 监视统计"),
            ("/api/logs/stream", "诊断日志"),
            ("/api/scenes/list", "快捷场景列表"),
            ("/api/plugins/installed", "已装载插件"),
            ("/api/market/packages", "插件市场"),
            ("/api/kb/summary", "知识库总览"),
            ("/api/kb/profiles", "灯库列表"),
            ("/api/kb/venues", "场地列表"),
            ("/api/kb/presets", "美学预设"),
            ("/api/kb/conflicts", "冲突检测"),
            ("/api/llm/config", "大模型配置"),
        ]:
            st, res, _ = call("GET", path, token=token)
            check(f"8. 回归 GET {path} · {label}", st == 200, f"-> HTTP {st}")

        st, res, _ = call("POST", "/api/kb/rag_test", {"query": "暖阳金"}, token=token)
        check("8. 回归 POST /api/kb/rag_test", st == 200 and res.get("matched_count", 0) >= 1)

        # ---------------- 9. 登出 ----------------
        st, res, _ = call("POST", "/api/auth/logout", {}, token=token)
        check("9. 登出接口返回成功", st == 200 and res.get("status") == "ok")

        st, res, _ = call("GET", "/api/auth/verify", token=token)
        check("9. 登出后令牌立即失效", st == 401, f"-> HTTP {st}")

        st, res, _ = call("GET", "/api/kb/summary", token=token)
        check("9. 登出后受保护接口不可访问", st == 401, f"-> HTTP {st}")

    finally:
        srv.shutdown()

    print("=" * 72)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 72)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
