# -*- coding: utf-8 -*-
"""
AI-MA 插件三层阶梯式依赖模型专项回归与对抗测试套件
测试目标：
1. 验证 1 类 BaseTransportPlugin 接口与类型合规性
2. 验证 2 类 BaseAdapterPlugin 的能力标签注册与索引机制 (get_provided_capabilities)
3. 验证 3 类 BaseCreativePlugin 的依赖拦截门禁 (get_required_adapters)：
   - 当依赖的 2 类适配器或能力标签不存在时，加载被安全阻断，报阶梯依赖错误
   - 当依赖的 2 类适配器就绪并启用时，3 类插件成功装载
4. 验证现有 9 个插件生态在升级后保持 100% 完整加载
"""

import os
import sys
import tempfile
import unittest

# 确定 BASE_DIR
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
CORE_DIR = os.path.join(BASE_DIR, "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from core.plugin_sdk import (
    PluginTier, PluginType, BasePlugin, BaseSystemPlugin,
    BaseAdapterPlugin, BaseCreativePlugin, BaseTransportPlugin,
    PluginValidator, CoreContext
)
from core.plugin_host import PluginHost


class DummyContext:
    def __init__(self):
        self.event_bus = None
        self.dmx_merger = None
        self.kb = None
        self.config = {}
        self.services = {}


class TestPluginLayeredDependencies(unittest.TestCase):

    def setUp(self):
        self.ctx = CoreContext(None, None, None)

    def tearDown(self):
        pass

    def test_01_transport_plugin_contract(self):
        """测试 1 类 BaseTransportPlugin 抽象规范与合规性"""
        class MockTransport(BaseTransportPlugin):
            def get_info(self):
                return {
                    "id": "transport_ha_ws",
                    "name": "Home Assistant WebSocket 驱动",
                    "version": "1.0.0",
                    "author": "AI-MA Core",
                    "type": PluginType.TRANSPORT,
                    "description": "HA 底层长连接通讯"
                }
            def on_init(self, context): return True
            def on_enable(self): pass
            def on_disable(self): pass
            def open_channel(self, channel_id, config): return True
            def send_raw(self, channel_id, payload): return True
            def register_raw_receiver(self, channel_id, callback): pass

        p = MockTransport()
        self.assertEqual(p.tier, PluginTier.SYSTEM)
        v = PluginValidator.validate_plugin_instance(p)
        self.assertTrue(v["valid"], f"合规性应通过: {v['errors']}")
        print("\n[PASS] 断言 1: 1 类 BaseTransportPlugin 抽象契约与市场合规校验通过")

    def test_02_adapter_capabilities_registration(self):
        """测试 2 类 BaseAdapterPlugin 的能力声明与 Host 索引绑定"""
        class MockAdapter(BaseAdapterPlugin):
            def get_info(self):
                return {
                    "id": "adapter_ha_bridge",
                    "name": "HA 智能家居实体网关",
                    "version": "1.0.0",
                    "author": "AI-MA Core",
                    "type": PluginType.ADAPTER,
                    "description": "实体映射转译"
                }
            def on_init(self, context): return True
            def on_enable(self): pass
            def on_disable(self): pass
            def supported_extensions(self): return [".json"]
            def convert_to_profile(self, b, f): return {}
            def get_provided_capabilities(self):
                return ["adapter.ha_entity_bridge", "adapter.iot_lighting"]

        host = PluginHost(os.path.join(BASE_DIR, "plugins"), self.ctx, os.path.join(BASE_DIR, "config", "plugins_config.json"))
        adapter = MockAdapter()
        adapter.set_enabled(True)
        host._plugins[adapter.get_info()["id"]] = adapter
        host._register_capabilities(adapter)

        self.assertTrue(host.is_adapter_available("adapter_ha_bridge"))
        self.assertTrue(host.is_adapter_available("adapter.ha_entity_bridge"))
        self.assertTrue(host.is_adapter_available("adapter.iot_lighting"))
        self.assertFalse(host.is_adapter_available("adapter.non_existent"))
        print("[PASS] 断言 2: 2 类插件能力标签 (Capabilities) 注册与双向索引有效")

    def test_03_creative_missing_dependency_blocked(self):
        """测试 3 类创意插件在缺少 2 类依赖时，被安全门禁拦截拒绝装载"""
        class MockCinemaMacro(BaseCreativePlugin):
            def get_info(self):
                return {
                    "id": "macro_ha_cinema",
                    "name": "HA 智能影院光影宏",
                    "version": "1.0.0",
                    "author": "Community",
                    "type": PluginType.MACRO,
                    "description": "依赖 HA 网关联动"
                }
            def on_init(self, context): return True
            def on_enable(self): pass
            def on_disable(self): pass
            def get_required_adapters(self):
                return ["adapter.ha_entity_bridge"]  # 声明依赖该 2 类能力

        host = PluginHost(os.path.join(BASE_DIR, "plugins"), self.ctx, os.path.join(BASE_DIR, "config", "plugins_config.json"))
        macro = MockCinemaMacro()
        macro.on_init(self.ctx)

        dep_ok, dep_msg = host.verify_dependencies(macro)
        self.assertFalse(dep_ok, "缺少依赖时必须拦截")
        self.assertIn("缺少前置 2 类适配支持", dep_msg)
        print("[PASS] 断言 3: 3 类插件缺少 2 类依赖被安全门禁准确拦截")

    def test_04_creative_with_dependency_passed(self):
        """测试 3 类创意插件在 2 类依赖满足并启用后，安全门禁放行"""
        class MockAdapter(BaseAdapterPlugin):
            def get_info(self):
                return {
                    "id": "adapter_ha_bridge",
                    "name": "HA 智能家居实体网关",
                    "version": "1.0.0",
                    "author": "AI-MA Core",
                    "type": PluginType.ADAPTER,
                    "description": "实体映射转译"
                }
            def on_init(self, context): return True
            def on_enable(self): pass
            def on_disable(self): pass
            def supported_extensions(self): return []
            def convert_to_profile(self, b, f): return {}
            def get_provided_capabilities(self):
                return ["adapter.ha_entity_bridge"]

        class MockCinemaMacro(BaseCreativePlugin):
            def get_info(self):
                return {
                    "id": "macro_ha_cinema",
                    "name": "HA 智能影院光影宏",
                    "version": "1.0.0",
                    "author": "Community",
                    "type": PluginType.MACRO,
                    "description": "依赖 HA 网关联动"
                }
            def on_init(self, context): return True
            def on_enable(self): pass
            def on_disable(self): pass
            def get_required_adapters(self):
                return ["adapter.ha_entity_bridge"]

        host = PluginHost(os.path.join(BASE_DIR, "plugins"), self.ctx, os.path.join(BASE_DIR, "config", "plugins_config.json"))
        adp = MockAdapter()
        adp.set_enabled(True)
        host._plugins[adp.get_info()["id"]] = adp
        host._register_capabilities(adp)

        macro = MockCinemaMacro()
        macro.on_init(self.ctx)

        dep_ok, dep_msg = host.verify_dependencies(macro)
        self.assertTrue(dep_ok, f"依赖已存在时应放行: {dep_msg}")
        print("[PASS] 断言 4: 3 类插件前置 2 类依赖就绪后成功放行")

    def test_05_production_plugins_all_load(self):
        """测试 AI-MA 现役所有工业级插件在三层分级依赖架构下 100% 加载成功"""
        real_plugins_dir = os.path.join(BASE_DIR, "plugins")
        host = PluginHost(real_plugins_dir, self.ctx, os.path.join(BASE_DIR, "config", "plugins_config.json"))
        host.discover_and_load_all()

        report = host.get_diagnostic_report()
        self.assertEqual(report["failed_total"], 0, f"现役插件不应有失败项: {report['failures']}")
        self.assertGreaterEqual(report["loaded_total"], 9, f"现役插件应全部装载成功: {report['loaded_total']}")
        print(f"[PASS] 断言 5: 现役 {report['loaded_total']} 个工业级插件分层加载 100% 成功 (0 失败)")


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestPluginLayeredDependencies)
    res = unittest.TextTestRunner(verbosity=1).run(suite)
    if res.wasSuccessful():
        print(f"\n结果: {res.testsRun} 项全部通过 / 0 项失败")
        sys.exit(0)
    else:
        sys.exit(1)
