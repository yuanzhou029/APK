# -*- coding: utf-8 -*-
"""
AI-MA 5.3 运行期内核看门狗 (Runtime Kernel Watchdog) 端到端验证

背景（本测试的由来）：
    原实现只在控制台**启动时**做一次内核健康自检。若微内核在运行期被外部杀死、
    OOM 回收、或共享内存时钟停摆，控制台会毫无察觉地继续"空转"——业务帧写进
    无人消费的共享内存，现场直接黑屏且系统不报任何告警。

本测试真实复现该故障并验证看门狗的自愈能力：
    阶段一：独占性前置检查（共享内存槽位与 9000 端口是全局单例资源）
    阶段二：启动控制台，确认微内核已伴生拉起
    阶段三：**强行杀死微内核**，模拟运行期崩溃
    阶段四：验证看门狗产生 ERR-KERNEL-DAEMON 告警并自动拉起新的微内核
    阶段五：验证看门狗静态接线（停摆检测 / 重启上限 / systemd 托管分支）
    阶段六：关闭控制台并验证无孤儿进程
"""

import os
import re
import sys
import time
import socket
import subprocess

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTROL_STATION = os.path.join(SYS_ROOT, "control_station.py")
LOG_FILE = os.path.join(SYS_ROOT, "logs", "ai_ma_system.log")

HOST = "127.0.0.1"
PORT = 9000

# 加速看门狗周期，使测试可在数十秒内完成（生产默认 5s）
WATCHDOG_INTERVAL = 1.5
WATCHDOG_STALL_LIMIT = 3

_results = []


def check(name, ok, detail=""):
    _results.append((name, ok, detail))
    print(f"    -> [{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))
    return ok


def find_kernel_pids():
    try:
        out = subprocess.run(
            ["wmic", "process", "where", "name='aima-rt-daemon.exe'", "get", "ProcessId"],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace"
        ).stdout
        return sorted(int(x) for x in out.split() if x.strip().isdigit())
    except Exception:
        return []


def wait_port(timeout=40.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((HOST, PORT), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.3)
    return False


def port_busy():
    try:
        with socket.create_connection((HOST, PORT), timeout=1.0):
            return True
    except OSError:
        return False


def read_new_log(pre_len):
    """
    按**字节**偏移读取新增日志。

    注意：不能用 f.read()[pre_len:] —— f.read() 返回 str，而下标是**字符**索引，
    而 os.path.getsize() 返回的是**字节**数。中文日志下每个汉字占 3 字节，
    两者相差数倍，按字符切片会直接跳过大段新增内容（曾因此误判看门狗未生效）。
    """
    if not os.path.exists(LOG_FILE):
        return ""
    with open(LOG_FILE, "rb") as f:
        f.seek(pre_len)
        return f.read().decode("utf-8", errors="replace")


def kill_pid(pid):
    subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=15)
    return pid not in find_kernel_pids()


def main():
    print("=" * 74)
    print("   AI-MA 5.3 运行期内核看门狗 · 故障自愈端到端验证")
    print("=" * 74)

    # ---------------- 阶段一：独占性前置检查 ----------------
    print("\n[阶段一] 独占性前置检查 (绝不越界杀死他人进程)")
    existing = find_kernel_pids()
    busy = port_busy()
    if existing or busy:
        print(f"    [SKIP] 已有 AI-MA 实例在运行 "
              f"(微内核 PID={existing}, 端口占用={busy})，本测试需要独占环境，拒绝执行。")
        print("           请先关闭正在运行的控制台再重试。本测试不会杀死你正在使用的进程。")
        sys.exit(2)
    check("环境独占可用", True, "无既有内核 / 9000 端口空闲")

    pre_log_len = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0
    proc = None
    boot_log = None
    try:
        # ---------------- 阶段二：启动控制台 ----------------
        print("\n[阶段二] 启动控制台并确认微内核伴生拉起")
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["AIMA_WATCHDOG_INTERVAL_SEC"] = str(WATCHDOG_INTERVAL)
        env["AIMA_WATCHDOG_STALL_LIMIT"] = str(WATCHDOG_STALL_LIMIT)

        boot_log = open(os.path.join(SYS_ROOT, "logs", "_watchdog_test_boot.log"), "w",
                        encoding="utf-8", errors="replace")
        proc = subprocess.Popen([sys.executable, CONTROL_STATION], cwd=SYS_ROOT, env=env,
                                stdout=boot_log, stderr=subprocess.STDOUT)
        print(f"    -> 控制台已启动 (PID: {proc.pid})")

        if not wait_port(40):
            check("控制台 HTTP 服务就绪", False)
            return
        check("控制台 HTTP 服务就绪", True)

        time.sleep(2.0)
        pids_before = find_kernel_pids()
        check("微内核已伴生拉起", len(pids_before) == 1, f"PID={pids_before}")
        if not pids_before:
            return

        log_now = read_new_log(pre_log_len)
        check("看门狗已启动并记录巡检参数",
              "运行期内核看门狗已启动" in log_now,
              next((l.strip() for l in log_now.splitlines() if "运行期内核看门狗已启动" in l), ""))

        # ---------------- 阶段三：模拟运行期内核崩溃 ----------------
        print("\n[阶段三] 强行杀死微内核，模拟运行期崩溃 / OOM / 外部误杀")
        victim = pids_before[0]
        killed = kill_pid(victim)
        check("微内核已被强制杀死 (模拟故障)", killed, f"victim PID={victim}")
        mark_len = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0

        # ---------------- 阶段四：验证看门狗自愈 ----------------
        print(f"\n[阶段四] 等待看门狗巡检周期 ({WATCHDOG_INTERVAL}s) 并执行自愈")
        deadline = time.time() + 40
        pids_after = []
        while time.time() < deadline:
            time.sleep(1.0)
            pids_after = [p for p in find_kernel_pids() if p != victim]
            if pids_after:
                break

        check("看门狗自动拉起了新的微内核 (自愈成功)",
              len(pids_after) >= 1,
              f"旧 PID={victim} -> 新 PID={pids_after}")

        heal_log = read_new_log(mark_len)
        check("看门狗记录了 ERR-KERNEL-DAEMON 故障码",
              "ERR-KERNEL-DAEMON" in heal_log,
              next((l.strip() for l in heal_log.splitlines() if "ERR-KERNEL-DAEMON" in l), ""))
        check("看门狗记录了自动重启动作",
              "微内核自动重启" in heal_log,
              next((l.strip() for l in heal_log.splitlines() if "微内核自动重启" in l), ""))

        # 自愈后系统应恢复推流能力
        time.sleep(3.0)
        after_log = read_new_log(pre_log_len)
        check("自愈后微内核重新挂载共享内存驱动",
              after_log.count("共享内存驱动初始化成功") >= 1)

        # ---------------- 阶段五：静态接线核验 ----------------
        print("\n[阶段五] 看门狗静态接线核验")
        src = open(CONTROL_STATION, encoding="utf-8").read()
        check("含共享内存停摆检测 (ERR-KERNEL-STALL)", "ERR-KERNEL-STALL" in src)
        check("含自动重启次数上限 (防重启风暴)",
              "KERNEL_MAX_AUTO_RESTART" in src and "重启风暴" in src)
        check("含 systemd 托管分支 (AIMA_RT_EXTERNAL)",
              'externally_managed = (os.environ.get("AIMA_RT_EXTERNAL") == "1")' in src)
        check("看门狗为守护线程 (不阻塞主服务退出)",
              'name="AimaKernelWatchdog", daemon=True' in src)
        check("stop_microkernel 会先停止看门狗",
              "_watchdog_stop.set()" in src)
        check("看门狗异常被隔离 (单次巡检异常不影响主服务)",
              "微内核看门狗巡检异常" in src)
        check("看门狗参数支持环境变量调优",
              "AIMA_WATCHDOG_INTERVAL_SEC" in src and "AIMA_WATCHDOG_STALL_LIMIT" in src)

    finally:
        # ---------------- 阶段六：清理 ----------------
        print("\n[阶段六] 关闭控制台并校验微内核优雅回收")
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=12)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=5)
        if boot_log:
            boot_log.close()
        time.sleep(2.5)
        leftover = find_kernel_pids()
        check("控制台退出后微内核被原子回收 (无孤儿)",
              len(leftover) == 0, f"残留={leftover}" if leftover else "已干净退出")

    print("\n" + "=" * 74)
    passed = sum(1 for _, ok, _ in _results if ok)
    total = len(_results)
    if passed == total:
        print(f"  [ALL PASSED] 运行期内核看门狗验证 {passed}/{total} 全部通过！")
    else:
        print(f"  [FAILED] 通过 {passed}/{total}，未通过项：")
        for n, ok, d in _results:
            if not ok:
                print(f"      - {n} | {d}")
    print("=" * 74)
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
