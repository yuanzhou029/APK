# -*- coding: utf-8 -*-
"""
验证快捷场景确定性 JSON 直通执行 (0毫秒不请求大模型) 与独立管理中心
"""

import os
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE_DIR, "core"))
sys.path.append(BASE_DIR)   # control_station.py 在项目根，脚本在 tests/ 下时需显式加入

from control_station import quick_cue_mgr, engine, execute_payload_directly

def test_direct_execution():
    print("=" * 65)
    print(" 开始验证快捷场景执行级 JSON 直通与独立 Scene Studio 管理")
    print("=" * 65)

    # 1. 验证快捷场景列表及数据结构
    scenes = quick_cue_mgr.get_all_scenes()
    assert len(scenes) > 0, "场景列表为空"
    first = scenes[0]
    assert "payload" in first, "快捷场景未包含执行级 payload 数据包"
    payload = first["payload"]
    assert "mode" in payload and "fixtures" in payload, "payload 不符合执行级规范"
    print(f"[PASS] 1. 快捷场景数据结构验证通过: 存储了标准执行级 JSON (mode: {payload.get('mode')})")

    # 2. 验证直通执行 (0毫秒不经由大模型)
    t0 = time.perf_counter()
    execute_payload_directly(payload)
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    print(f"[PASS] 2. 快捷场景直通执行测速: 耗时 {elapsed_ms:.2f} ms (直接下发至 DMX 缓动插值器，完全不请求大模型！)")
    assert elapsed_ms < 20.0, f"执行时间过长 ({elapsed_ms}ms)，疑似未直通"

    # 3. 验证独立管理中心的新增/导入场景
    custom_scene = {
        "id": "scene_custom_cyber",
        "name": "极光冷蓝",
        "color": "#0ea5e9",
        "icon": "fa-snowflake",
        "desc": "舞台冷调极光",
        "payload": {
            "mode": "single",
            "transition_ms": 1200,
            "fixtures": [
                {
                    "id": "fix_01",
                    "channels": {"dimmer": 255, "red": 0, "green": 220, "blue": 255}
                }
            ]
        }
    }
    quick_cue_mgr.save_scene(custom_scene)
    refreshed = quick_cue_mgr.get_all_scenes()
    assert any(s["id"] == "scene_custom_cyber" for s in refreshed), "保存场景失败"
    print(f"[PASS] 3. 独立管理中心快捷场景保存与持久化成功")

    # 4. 验证清理
    quick_cue_mgr.delete_scene("scene_custom_cyber")
    print(f"[PASS] 4. 独立管理中心快捷场景安全删除测试通过")

    print("\n" + "=" * 65)
    print(" 快捷场景 0 毫秒直通执行与独立管理中心全部测试 PASS！")
    print("=" * 65)

if __name__ == "__main__":
    test_direct_execution()
