# -*- coding: utf-8 -*-
"""
AI-MA 插件三层分级架构自动化测试脚本
全面覆盖：
1. 1类/2类/3类分级加载与物理隔离
2. 卸载安全保护边界 (禁止卸载 1/2 类)
3. 2类适配器插件调用与灯库转换
4. 插件专属大模型 Prompt 隔离调用机制
5. 3类创意插件动态上传与合规校验
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "core")))
from plugin_sdk import PluginTier, PluginType, CoreContext, BasePlugin, PluginValidator
from plugin_host import PluginHost

class MockEventBus:
    def publish(self, topic, payload): pass

class MockMerger:
    pass

class MockKB:
    pass

class MockLLM:
    def chat_completion(self, messages, temperature=0.2):
        sys_msg = messages[0]["content"] if messages else ""
        return f"[MOCK_REPLY_FOR: {sys_msg[:30]}]"

class TestPluginTierArchitecture(unittest.TestCase):
    def setUp(self):
        self.plugins_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "plugins"))
        self.ctx = CoreContext(MockEventBus(), MockMerger(), MockKB(), services={"llm": MockLLM()})
        self.host = PluginHost(self.plugins_dir, self.ctx, config_store_path="config/test_plugins_cfg.json")
        self.host.discover_and_load_all()

    def test_01_tier_loading(self):
        """验证 1/2/3 类插件全部成功按分层装载"""
        summary = self.host.list_all_plugins_summary()
        self.assertTrue(len(summary) >= 3, "已加载插件数量不足")
        
        tiers = {p["id"]: p["tier"] for p in summary}
        
        # 1 类
        if "protocol_artnet_standard" in tiers:
            self.assertEqual(tiers["protocol_artnet_standard"], PluginTier.SYSTEM)
        if "llm_local_qwen_7b" in tiers:
            self.assertEqual(tiers["llm_local_qwen_7b"], PluginTier.SYSTEM)
            
        # 2 类
        if "adapter_ma_fixture" in tiers:
            self.assertEqual(tiers["adapter_ma_fixture"], PluginTier.ADAPTER)
            
        # 3 类
        if "macro_breathing" in tiers:
            self.assertEqual(tiers["macro_breathing"], PluginTier.CREATIVE)

    def test_02_uninstall_protection(self):
        """验证安全边界：绝对禁止卸载 1 类系统插件与 2 类适配插件"""
        # 尝试卸载 1 类
        if "protocol_artnet_standard" in self.host._plugins:
            with self.assertRaises(PermissionError):
                self.host.uninstall_plugin("protocol_artnet_standard")

        # 尝试卸载 2 类
        if "adapter_ma_fixture" in self.host._plugins:
            with self.assertRaises(PermissionError):
                self.host.uninstall_plugin("adapter_ma_fixture")

    def test_03_marketplace_isolation(self):
        """验证市场隔离：面向用户的社区市场仅允许展示 3 类插件"""
        community_plugins = self.host.list_community_plugins()
        for p in community_plugins:
            self.assertEqual(p["tier"], PluginTier.CREATIVE, f"市场中泄露了非 3 类插件: {p['id']}")

    def test_04_adapter_execution(self):
        """验证 2 类 MA 灯库适配器无损转换"""
        adapter = self.host.get_adapter_for_extension(".xml")
        self.assertIsNotNone(adapter, "未能获取到 .xml 适配器插件")
        
        sample_xml = b'''<?xml version="1.0" encoding="utf-8"?>
        <MA xmlns="http://schemas.malighting.de/grandma2/xml/MA">
            <FixtureType name="TEST_BEAM" mode="Standard">
                <manufacturer>TestBrand</manufacturer>
                <ChannelType coarse="0" attribute="PAN" />
                <ChannelType coarse="1" attribute="TILT" />
                <ChannelType coarse="2" attribute="DIM" />
                <ChannelType coarse="3" attribute="RESET" />
            </FixtureType>
        </MA>'''
        profile = adapter.convert_to_profile(sample_xml, "test.xml")
        self.assertEqual(profile["channel_count"], 4)
        self.assertEqual(profile["channels"][0]["type"], "pan")
        self.assertEqual(profile["channels"][3]["is_safe"], False, "复位通道必须被锁定")

    def test_05_isolated_ai_prompt(self):
        """验证每个插件独占的专用 AI 提示词隔离调用"""
        p = self.host._plugins.get("adapter_ma_fixture")
        if p:
            res = p.call_ai_service("default_system", "用户测试属性")
            self.assertIn("MOCK_REPLY_FOR: 你是一个精通 MA2/MA3 控台语法", res)

if __name__ == "__main__":
    unittest.main()
