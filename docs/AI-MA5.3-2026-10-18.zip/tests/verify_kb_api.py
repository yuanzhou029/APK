# -*- coding: utf-8 -*-
"""
统一总控台 · 三层 RAG 知识库 HTTP 端到端接口验证
在进程内启动控制台 HTTP 服务，实测全部知识库路由与前端资产。
"""

import os
import sys
import json
import time
import http.cookiejar
import threading
import urllib.request
import urllib.error
from http.server import HTTPServer

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE_DIR, "core"))
sys.path.append(BASE_DIR)

PORT = 9099
PASS = 0
FAIL = 0


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """禁止自动跟随 302：否则"未登录访问 /app 被弹回"会被跟到登录页而误判为 200"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


# 全局统一使用"不跟随重定向"的 opener，使门禁/跳转类断言能观察到真实状态码
_OPENER = urllib.request.build_opener(_NoRedirect())


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")

def call(method, path, body=None, token=None):
    url = f"http://127.0.0.1:{PORT}{path}"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with _OPENER.open(req, timeout=15) as r:
            raw = r.read().decode("utf-8")
            return r.status, (json.loads(raw) if raw.strip().startswith(("{", "[")) else raw)
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8")
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, raw


def fetch_page_with_session(path, username="admin", password="admin123"):
    """
    以"已登录的浏览器"身份抓取后台页面。

    v4.3 起 /app 由服务端门禁保护：未持有效会话一律 302 回登录页，后台 DOM 不再下发。
    因此校验后台元素必须先登录，并让 CookieJar 自动携带会话 Cookie——
    这正是真实浏览器的行为，测试不能再像以前那样匿名 GET /app。
    """
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar), _NoRedirect())

    login = urllib.request.Request(
        f"http://127.0.0.1:{PORT}/api/auth/login",
        data=json.dumps({"username": username, "password": password}).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    with opener.open(login, timeout=15) as r:
        session = json.loads(r.read().decode("utf-8"))["session"]

    with opener.open(f"http://127.0.0.1:{PORT}{path}", timeout=15) as r:
        return r.status, r.read().decode("utf-8"), session["token"]

def main():
    print("=" * 70)
    print(" 统一总控台 · RAG 知识库 HTTP 端到端接口验证")
    print("=" * 70)

    import control_station as cs

    # 观察员 fixture：出厂默认用户库含 guest(viewer)，但交付的 config/users.json
    # 里只有 admin 与 root（guest 曾被删）。本套件第 23 项要验证"观察员写知识库被拒"，
    # 缺少观察员账号会导致登录失败、拿到 401 而非 403，断言随之全错。
    # 这里按需创建，跑完在 finally 中删除，不污染交付配置。
    _guest_created = False
    if "guest" not in cs.auth.users:
        cs.auth.add_or_update_user("guest", "viewer", "guest", "现场观察员")
        _guest_created = True

    srv = HTTPServer(("127.0.0.1", PORT), cs.UnifiedControlStationServer)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.6)

    try:
        # 0. 前端页面资产（v4.2 起 UI 已解耦为 web/ 静态资产，首页为登录门头页）
        _, home = call("GET", "/")
        check("0. 首页 · 登录门头页", "控制台登录" in home and "gate-brand" in home)

        # 0a. 登录门禁：未登录不得拿到后台 DOM（v4.3 起由服务端强制，而非前端事后弹回）
        st_anon, body_anon = call("GET", "/app")
        check("0a. 未登录访问 /app 被服务端拦回登录页",
              st_anon in (301, 302, 303, 401, 403) and "kbSubnav" not in body_anon,
              f"-> HTTP {st_anon}，后台 DOM 未下发")

        st_authed, html, admin_token = fetch_page_with_session("/app")
        check("0b. 登录后 /app 正常下发后台页面",
              st_authed == 200 and "kbSubnav" in html,
              f"-> HTTP {st_authed} / {len(html)} 字节")
        for marker, label in [
            ("kbSubnav", "知识库五合一子导航"),
            ("kb-pane-overview", "资产总览面板"),
            ("kb-pane-profiles", "物理灯库面板"),
            ("kb-pane-venues", "场地拓扑面板"),
            ("kb-pane-presets", "美学预设面板"),
            ("kb-pane-airag", "AI解析与RAG实测面板"),
            ("modalProfile", "灯库编辑器模态窗"),
            ("modalVenue", "场地编辑器模态窗"),
            ("modalPreset", "预设详情双模式编辑器"),
            ("modalCategories", "分类与属性分组管理"),
            ("modalPanelEdit", "主控面板组装器"),
            ("modalNode", "解码器节点与掉线策略"),
            ("presetChips", "预设自定义分类筛选条"),
            ("nodeTree", "四层节点拓扑树"),
            ("ctrlPortSelect", "接口级通道选择器"),
            ("dmxGrid", "端口通道电平阵列"),
            ("alarmList", "设备告警中心"),
            ("diagSubnav", "告警/日志双页签"),
        ]:
            check(f"0. 前端资产 · {label}", marker in html)

        # 1. 鉴权
        _, res = call("POST", "/api/auth/login", {"username": "admin", "password": "admin123"})
        check("1. 管理员登录鉴权", res.get("status") == "ok" and "token" in res.get("session", {}))
        token = res["session"]["token"]

        # 2. 未授权拦截（只读接口同样必须鉴权）
        st, _ = call("GET", "/api/kb/summary")
        check("2. 未持令牌访问只读接口被 401 拒绝", st == 401, f"-> HTTP {st}")

        # 3. GET 全景
        for path, label, key in [
            ("/api/kb/summary", "资产总览", "profiles_count"),
            ("/api/kb/profiles", "灯库列表", None),
            ("/api/kb/venues", "场地列表", None),
            ("/api/kb/presets", "美学预设读取", None),
            ("/api/kb/conflicts", "冲突检测", "has_conflict"),
        ]:
            st, r = call("GET", path, token=token)
            ok = st == 200 and (key is None or key in r)
            check(f"3. GET {path} · {label}", ok, f"-> {st}")

        # 3b. v4.3 新增只读路由
        st, r = call("GET", "/api/kb/categories", token=token)
        check("3b. GET /api/kb/categories · 自定义分类注册表",
              st == 200 and isinstance(r.get("categories"), list) and len(r["categories"]) >= 1,
              f"-> {len(r.get('categories', []))} 个分类")

        st, r = call("GET", "/api/kb/attribute_groups", token=token)
        check("3b. GET /api/kb/attribute_groups · 属性分组（出厂四组）",
              st == 200 and isinstance(r.get("groups"), list) and len(r["groups"]) == 4,
              f"-> {[g['name'] for g in r.get('groups', [])]}")

        st, r = call("GET", "/api/kb/profile_attributes?id=gtdlighting_gtd450iibeam_13ch", token=token)
        attrs = r.get("attributes", [])
        check("3b. GET /api/kb/profile_attributes · 灯库属性全集",
              st == 200 and len(attrs) >= 5 and any(c in r.get("locked_channels", []) for c in ("macro", "reset", "lampcontrol", "control"))
              and all("range" in a for a in attrs),
              f"-> {len(attrs)} 个可调属性 / 锁定 {len(r.get('locked_channels', []))} 个危险通道")

        st, r = call("GET", "/api/panel/layout", token=token)
        check("3b. GET /api/panel/layout · 主控面板布局", st == 200 and "groups" in r,
              f"-> {len(r.get('groups', []))} 个面板块 / 已组装={r.get('configured')}")

        st, r = call("GET", "/api/alarms", token=token)
        check("3b. GET /api/alarms · 设备告警中心", st == 200 and "alarms" in r and "open_count" in r,
              f"-> {r.get('total')} 条告警 / 未处理 {r.get('open_count')}")

        st, r = call("GET", "/api/nodes/discovered", token=token)
        check("3b. GET /api/nodes/discovered · 被动发现与看门狗",
              st == 200 and "discovered" in r and "watchdog" in r,
              f"-> 被动发现 {len(r.get('discovered', []))} 个 IP / "
              f"看门狗 {len(r.get('watchdog', {}))} 个节点")

        st, r = call("GET", "/api/dmx/universe/0", token=token)
        check("3b. GET /api/dmx/universe/<n> · 按 Universe 取帧",
              st == 200 and r.get("universe") == 0 and len(r.get("channels", [])) == 512,
              f"-> Universe 0 / {len(r.get('channels', []))} 通道")

        # 4. 灯库全生命周期
        pid = "api_verify_fixture_2ch"
        st, r = call("POST", "/api/kb/save_profile", {
            "profile_id": pid, "manufacturer": "接口验证", "model": "V-Test",
            "channels": [
                {"ch": 1, "type": "dimmer", "name": "调光", "is_safe": True, "default": 0},
                {"ch": 2, "type": "macro", "name": "内置宏(危险)", "is_safe": False, "default": 0},
            ], "channel_count": 2
        }, token)
        check("4. POST /api/kb/save_profile", st == 200 and r.get("status") == "ok", f"-> {r}")

        st, r = call("GET", f"/api/kb/profile_detail?id={pid}", token=token)
        check("5. GET /api/kb/profile_detail", st == 200 and r.get("profile_id") == pid)

        # 6. 冲突检测（草稿）：甲占 CH1~2，乙占 CH2~3 -> 重叠 1 处；
        #    丙占 CH512~513 -> 越界 1 处。合计应检出 2 处。
        st, r = call("POST", "/api/kb/check_conflicts", {
            "_draft": {
                "fixtures": [
                    {"id": "a", "name": "甲", "universe": 0, "address": 1, "profile_id": pid},
                    {"id": "b", "name": "乙", "universe": 0, "address": 2, "profile_id": pid},
                    {"id": "c", "name": "丙", "universe": 0, "address": 512, "profile_id": pid},
                ]
            }
        }, token)
        kinds = {c["type"] for c in r.get("conflicts", [])}
        check("6. POST /api/kb/check_conflicts (草稿)", st == 200 and r.get("has_conflict") and {"overlap", "overflow"} <= kinds,
              f"-> 检出 {len(r.get('conflicts', []))} 处，类型={sorted(kinds)}")

        # 7. RAG 检索
        st, r = call("POST", "/api/kb/rag_test", {"query": "把左前一号面光调成暖阳金，3秒慢推"}, token)
        check("7. POST /api/kb/rag_test", st == 200 and r.get("matched_count", 0) >= 1,
              f"-> 命中 {r.get('matched_count')} 台 / 预设={r.get('preset_hint', {}).get('preset_name') if r.get('preset_hint') else '无'}")

        # 8. 场地切换 + 场地列表
        st, venues = call("GET", "/api/kb/venues", token=token)
        active = [v for v in venues if v.get("is_active")]
        st, r = call("POST", "/api/kb/switch_venue", {"venue_id": active[0]["venue_id"]}, token)
        check("8. POST /api/kb/switch_venue 热切换", st == 200 and r.get("status") == "ok",
              f"-> {r.get('venue_name')} ({r.get('fixture_count')} 台灯具)")

        # 9. 场地保存（引用不存在的灯库应被拦截）
        st, r = call("POST", "/api/kb/save_venue", {
            "venue_id": "api_verify_venue", "venue_name": "验证场地",
            "fixtures": [{"id": "x", "name": "错误灯", "profile_id": "不存在的灯库", "universe": 0, "address": 1}]
        }, token)
        check("9. 场地引用校验拦截", st == 400 and r.get("status") == "error", f"-> {r.get('message')}")

        # 10. 美学预设：单条新增（属性驱动 + 强制分类）
        st, cats = call("GET", "/api/kb/categories", token=token)
        cat_id = cats["categories"][0]["id"]
        st, r = call("POST", "/api/kb/save_preset", {
            "preset_id": "__api_verify",
            "preset": {"name": "接口验证色", "category_id": cat_id, "profile_ref": None,
                       "channel_values": {"red": 10, "green": 20, "blue": 30, "white": 0},
                       "transition_ms": 777, "summary": "接口回归", "tags": ["验证", "临时"]},
        }, token)
        check("10. POST /api/kb/save_preset 单条新增",
              st == 200 and r.get("status") == "ok" and r.get("created") is True,
              f"-> {r.get('preset', {}).get('name')} / 派生 desc={r.get('preset', {}).get('desc')}")

        # 11. 强制分类：缺分类必须被 400 拒绝
        st, r = call("POST", "/api/kb/save_preset", {
            "preset_id": "__api_no_cat",
            "preset": {"name": "无分类预设", "channel_values": {"red": 1}},
        }, token)
        check("11. 强制分类拦截（缺分类 → 400）",
              st == 400 and r.get("status") == "error", f"-> {r.get('message')}")

        # 12. 预设更新（同 ID 二次保存应 created=False）
        st, r = call("POST", "/api/kb/save_preset", {
            "preset_id": "__api_verify",
            "preset": {"name": "接口验证色-改", "category_id": cat_id,
                       "channel_values": {"red": 11}, "transition_ms": 500},
        }, token)
        check("12. 预设同 ID 覆盖更新", st == 200 and r.get("created") is False,
              f"-> 名称={r.get('preset', {}).get('name')}")

        # 13. 分类 CRUD
        st, r = call("POST", "/api/kb/save_category",
                     {"id": "cat_api_tmp", "name": "接口临时分类", "color": "#22d3ee",
                      "icon": {"mode": "upload", "upload": "data:image/svg+xml;base64,PHN2Zy8+"}}, token)
        check("13. POST /api/kb/save_category 新增（含上传图标）",
              st == 200 and r.get("created") is True and r.get("category", {}).get("icon", {}).get("mode") == "upload",
              f"-> {r.get('category', {}).get('name')}")

        # 14. 分类删除保护：分类下仍有预设 → 拒绝
        call("POST", "/api/kb/save_preset", {
            "preset_id": "__api_in_cat",
            "preset": {"name": "分类内预设", "category_id": "cat_api_tmp", "channel_values": {"red": 5}},
        }, token)
        st, r = call("POST", "/api/kb/delete_category", {"category_id": "cat_api_tmp"}, token)
        check("14. 分类删除保护（下有预设 → 拒绝）",
              st == 400 and r.get("status") == "error", f"-> {r.get('message')}")

        # 15. 清空后分类可删
        call("POST", "/api/kb/delete_preset", {"preset_id": "__api_in_cat"}, token)
        st, r = call("POST", "/api/kb/delete_category", {"category_id": "cat_api_tmp"}, token)
        check("15. 清空后分类删除成功", st == 200 and r.get("status") == "ok", f"-> {r.get('deleted')}")

        # 16. 属性分组注册表保存
        st, r = call("GET", "/api/kb/attribute_groups", token=token)
        groups = r["groups"]
        backup_groups = json.loads(json.dumps(groups))
        groups[0]["name"] = "亮度(回归)"
        st, r = call("POST", "/api/kb/save_attribute_groups", {"groups": groups}, token)
        check("16. POST /api/kb/save_attribute_groups",
              st == 200 and r["groups"][0]["name"] == "亮度(回归)", f"-> {r.get('status')}")
        call("POST", "/api/kb/save_attribute_groups", {"groups": backup_groups}, token)

        # 17. 面板布局保存与读回
        st, r = call("POST", "/api/panel/save_layout", {
            "groups": [{"group_id": "g1", "title": "常用", "columns": 4,
                        "item_ids": ["preset:__api_verify"]}]
        }, token)
        st2, r2 = call("GET", "/api/panel/layout", token=token)
        check("17. POST /api/panel/save_layout + 读回",
              st == 200 and st2 == 200 and r2["configured"] is True
              and r2["groups"][0]["columns"] == 4,
              f"-> {len(r2.get('groups', []))} 个面板块 / 列数={r2['groups'][0]['columns']}")

        # 18. 删除单条预设
        st, r = call("POST", "/api/kb/delete_preset", {"preset_id": "__api_verify"}, token)
        check("18. POST /api/kb/delete_preset", st == 200 and r.get("status") == "ok", f"-> {r.get('deleted')}")

        # 19. 预设直通执行：属性与目标灯库受控通道无交集时必须被拦截
        st, r = call("POST", "/api/presets/apply", {"preset_id": "__not_exist"}, token)
        check("19. POST /api/presets/apply 不存在预设 → 404", st == 404, f"-> HTTP {st}")

        # 20. 节点连接测试三态（对不可达 IP 必须返回 no_response 而不是抛异常）
        st, r = call("POST", "/api/nodes/test_connection", {"ip": "10.255.255.1"}, token)
        check("20. POST /api/nodes/test_connection 三态判定",
              st == 200 and r.get("state") in ("online", "traffic_only", "no_response")
              and isinstance(r.get("hint"), str),
              f"-> state={r.get('state')}")

        # 21. ArtPoll 扫描：非法网段必须被安全拒绝（断言是"主机数超限"，而非 AttributeError）
        st, r = call("POST", "/api/nodes/scan", {"subnet": "10.0.0.0/8"}, token)
        msg = str(r.get("message", ""))
        check("21. 网段超限保护（/8 因主机数超限被拒绝）",
              st == 400 and r.get("status") == "error" and "超过上限" in msg and "has no attribute" not in msg,
              f"-> {msg[:60]}")

        # 21b. 合法网段可正常展开（实际只扫描，不要求有节点应答）
        st, r = call("POST", "/api/nodes/scan", {"subnet": "127.0.0.1/32"}, token)
        check("21b. 合法网段可正常展开扫描",
              st == 200 and r.get("status") == "ok" and r.get("scanned") == 1,
              f"-> 探测 {r.get('scanned')} 个地址 / 应答 {r.get('responded')}")

        # 22. 看门狗同步
        st, r = call("POST", "/api/nodes/sync_watchdog", {}, token)
        check("22. POST /api/nodes/sync_watchdog", st == 200 and r.get("registered", 0) >= 1,
              f"-> 接管 {r.get('registered')} 个节点")

        # 23. 权限拦截：观察员不得写知识库
        _, g = call("POST", "/api/auth/login", {"username": "guest", "password": "guest"})
        gtoken = g["session"]["token"]
        st, r = call("POST", "/api/kb/save_preset",
                     {"preset_id": "x", "preset": {"name": "x", "category_id": cat_id,
                                                   "channel_values": {"red": 1}}}, gtoken)
        check("23. RBAC 拦截：观察员写预设 → 403", st == 403, f"-> HTTP {st}")

        # 24. 清理
        st, r = call("POST", "/api/kb/delete_profile", {"profile_id": pid}, token)
        # 还原面板布局配置文件，避免测试残留影响实际界面
        panel_cfg = os.path.join(BASE_DIR, "config", "control_panel_layout.json")
        if os.path.exists(panel_cfg):
            os.remove(panel_cfg)
        check("24. 测试数据清理", st == 200 and r.get("status") == "ok")

        # 25. 被引用灯库删除拦截
        st, venues = call("GET", "/api/kb/venues", token=token)
        ref_pid = [v for v in venues if v.get("is_active")][0]["fixtures"][0]["profile_id"]
        st, r = call("POST", "/api/kb/delete_profile", {"profile_id": ref_pid}, token)
        check("25. 被引用灯库删除安全拦截", st == 400 and r.get("status") == "error", f"-> {r.get('message')}")

    finally:
        srv.shutdown()
        # 移除本套件创建的一次性观察员 fixture，保证 config/users.json 净零变化
        if _guest_created:
            try:
                cs.auth.delete_user("guest")
            except Exception as e:
                print(f"[WARN] 观察员 fixture 清理失败: {e}")

    print("=" * 70)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 70)
    return 0 if FAIL == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
