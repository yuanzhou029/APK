# -*- coding: utf-8 -*-
"""
AI-MA 5.3 鉴权噪音抑制与安全信号保真验证

背景（本测试的由来）：
    用户主动注销后，日志里出现了这样的内容——4 条"用户已主动注销会话凭证"，
    紧接着 4 条 ERROR 级故障告警：
        【故障告警 - 代码 ERR-AUTH-DENIED】: 未授权只读接口访问被拒绝: /api/logs/stream
        【故障告警 - 代码 ERR-AUTH-DENIED】: 未授权只读接口访问被拒绝: /api/alarms
        【故障告警 - 代码 ERR-AUTH-DENIED】: 未授权只读接口访问被拒绝: /api/system/status
        【故障告警 - 代码 ERR-AUTH-DENIED】: 未授权只读接口访问被拒绝: /api/dmx/universe/0

    这是三方缺陷叠加：
      前端①：forceLogout() 无幂等闩锁 —— 多个在途轮询各自收到 401 后又各自触发注销
      前端②：setInterval 从不 clearInterval —— 注销过程中轮询仍在继续
      后端③：把"未携带令牌/令牌已吊销"一律记为 ERROR 级 ERR-AUTH-DENIED
             造成日志刷屏、告警面板污染，且**告警文案是错的**
             （真因是"用户已注销"，却提示"请切换为管理员账号"）

    最严重的后果是安全性反而下降：真正的令牌爆破与一次日常注销
    在告警面板上完全无法区分。

验证目标：
    阶段一：还原注销场景，确认不再产生 ERR-AUTH-DENIED 噪音
    阶段二：确认突发未授权访问仍能触发 ERR-AUTH-BRUTEFORCE（安全信号保真）
    阶段三：确认真实的安全事件（登录失败）仍然告警
    阶段四：前端静态核验（幂等闩锁 / 定时器清理 / 轮询统一登记）
"""

import os
import re
import sys
import json
import time
import socket
import subprocess
import urllib.request
import urllib.error

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTROL_STATION = os.path.join(SYS_ROOT, "control_station.py")
LOG_FILE = os.path.join(SYS_ROOT, "logs", "ai_ma_system.log")
APP_JS = os.path.join(SYS_ROOT, "web", "assets", "app.js")

HOST = "127.0.0.1"
PORT = 9000
BASE = f"http://{HOST}:{PORT}"

# 前端五个轮询定时器命中的真实只读接口（取自用户日志中的实际路径）
POLL_ENDPOINTS = [
    "/api/logs/stream",
    "/api/alarms",
    "/api/system/status",
    "/api/dmx/universe/0",
]

_results = []


def check(name, ok, detail=""):
    _results.append((name, ok, detail))
    print(f"    -> [{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))
    return ok


def port_busy():
    try:
        with socket.create_connection((HOST, PORT), timeout=1.0):
            return True
    except OSError:
        return False


def find_kernel_pids():
    try:
        out = subprocess.run(
            ["wmic", "process", "where", "name='aima-rt-daemon.exe'", "get", "ProcessId"],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace"
        ).stdout
        return sorted(int(x) for x in out.split() if x.strip().isdigit())
    except Exception:
        return []


def wait_port(timeout=40.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((HOST, PORT), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.3)
    return False


def read_new_log(pre_len):
    """按字节偏移读取新增日志（中文日志不得按字符切片）"""
    if not os.path.exists(LOG_FILE):
        return ""
    with open(LOG_FILE, "rb") as f:
        f.seek(pre_len)
        return f.read().decode("utf-8", errors="replace")


def get(path, token=None):
    """返回 (status, body)；4xx/5xx 是要断言的有效结果，必须捕获而非抛出"""
    req = urllib.request.Request(BASE + path, method="GET")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


def post(path, token=None, payload=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else b"{}"
    req = urllib.request.Request(BASE + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


def main():
    print("=" * 74)
    print("   AI-MA 5.3 鉴权噪音抑制与安全信号保真验证")
    print("=" * 74)

    # ---------------- 阶段零：独占性 ----------------
    print("\n[阶段零] 独占性前置检查")
    if port_busy() or find_kernel_pids():
        print(f"    [SKIP] 已有 AI-MA 实例在运行 (端口占用={port_busy()}, "
              f"内核={find_kernel_pids()})，本测试需要独占环境，拒绝执行。")
        print("           请先关闭正在运行的控制台再重试。")
        sys.exit(2)
    check("环境独占可用", True)

    proc = None
    boot_log = None
    try:
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["AIMA_NO_BROWSER"] = "1"
        boot_log = open(os.path.join(SYS_ROOT, "logs", "_authnosie_boot.log"), "w",
                        encoding="utf-8", errors="replace")
        proc = subprocess.Popen([sys.executable, CONTROL_STATION], cwd=SYS_ROOT, env=env,
                                stdout=boot_log, stderr=subprocess.STDOUT)
        print(f"    -> 控制台已启动 (PID: {proc.pid})")
        if not wait_port(40):
            check("控制台就绪", False)
            return
        check("控制台就绪", True)

        # ---------------- 阶段一：还原注销场景 ----------------
        print("\n[阶段一] 还原用户注销场景（这曾产生 4 条虚假 ERROR 告警）")
        st, body = post("/api/auth/login", payload={"username": "admin", "password": "admin123"})
        token = json.loads(body).get("session", {}).get("token", "") if st == 200 else ""
        check("管理员登录成功", bool(token), f"HTTP {st}")
        if not token:
            return

        # 注销前：携带有效令牌轮询（应为 200）
        pre_ok = sum(1 for ep in POLL_ENDPOINTS if get(ep, token)[0] == 200)
        check("注销前轮询正常返回 200", pre_ok == len(POLL_ENDPOINTS),
              f"{pre_ok}/{len(POLL_ENDPOINTS)}")

        mark = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0

        # 执行注销（修正后的前端只发一次）
        st, _ = post("/api/auth/logout", token=token)
        check("注销接口返回成功", st == 200, f"HTTP {st}")

        # 注销后：模拟"已在途/卸载前仍发出的"轮询（令牌已吊销，全部 401）
        codes = [get(ep, token)[0] for ep in POLL_ENDPOINTS]
        check("注销后轮询被正确拒绝为 401",
              all(c == 401 for c in codes), f"返回码={codes}")

        time.sleep(0.5)
        log_txt = read_new_log(mark)

        check("正常注销不再产生 ERR-AUTH-DENIED 噪音告警",
              "ERR-AUTH-DENIED" not in log_txt,
              next((l.strip() for l in log_txt.splitlines() if "ERR-AUTH-DENIED" in l), "无"))
        check("注销后的 401 被降级为 INFO 级说明",
              "已失效或已注销的会话令牌" in log_txt,
              next((l.strip() for l in log_txt.splitlines()
                    if "已失效或已注销的会话令牌" in l), ""))
        check("注销记录本身仍保留",
              "用户已主动注销会话凭证" in log_txt)
        check("未误报令牌爆破告警",
              "ERR-AUTH-BRUTEFORCE" not in log_txt)

        # ---------------- 阶段二：安全信号保真（突发仍要告警） ----------------
        print("\n[阶段二] 验证突发未授权访问仍能触发安全告警（安全信号不得被削弱）")
        mark2 = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0
        # 以远超正常轮询的频率发起无令牌请求
        for _ in range(30):
            get("/api/system/status")
        time.sleep(0.8)
        burst_log = read_new_log(mark2)

        check("突发未授权访问触发 ERR-AUTH-BRUTEFORCE 告警",
              "ERR-AUTH-BRUTEFORCE" in burst_log,
              next((l.strip() for l in burst_log.splitlines()
                    if "ERR-AUTH-BRUTEFORCE" in l), "")[:160])
        check("突发场景下仍不产生 ERR-AUTH-DENIED",
              "ERR-AUTH-DENIED" not in burst_log)
        # 未携带令牌的访问刻意使用 DEBUG 级。生产日志的持久化级别是 INFO，
        # 因此这类"未登录页面轮询"根本不会进入文件/控制台/告警面板。
        # 注意：这里必须断言它"不在"日志里——第一版断言写反了，
        # 把它当成"应当可见"来检查，反而误判了本来就正确的设计。
        check("未携带令牌的访问不进入 INFO 及以上日志（不污染告警面板）",
              "未携带会话令牌" not in burst_log)
        check("30 次突发只产生 1 条告警（证明靠计数而非逐条打日志）",
              burst_log.count("ERR-AUTH-BRUTEFORCE") == 1,
              f"出现 {burst_log.count('ERR-AUTH-BRUTEFORCE')} 次")
        with open(CONTROL_STATION, encoding="utf-8") as f:
            cs_src = f.read()
        check("代码中该分支确实使用 DEBUG 级",
              'logger.debug(f"只读接口未携带会话令牌' in cs_src)
        with open(os.path.join(SYS_ROOT, "core", "diagnostics_logger.py"), encoding="utf-8") as f:
            dl_src = f.read()
        check("日志持久化级别为 INFO（DEBUG 按设计被抑制）",
              "logger.setLevel(logging.INFO)" in dl_src
              and "file_handler.setLevel(logging.INFO)" in dl_src)

        # ---------------- 阶段三：真实安全事件仍要告警 ----------------
        print("\n[阶段三] 验证真实安全事件（登录失败）仍然产生告警")
        mark3 = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0
        st, _ = post("/api/auth/login", payload={"username": "admin", "password": "wrong-password"})
        check("错误密码登录被拒绝", st == 401, f"HTTP {st}")
        time.sleep(0.5)
        fail_log = read_new_log(mark3)
        check("登录失败触发 ERR-AUTH-LOGIN-FAIL 告警",
              "ERR-AUTH-LOGIN-FAIL" in fail_log,
              next((l.strip() for l in fail_log.splitlines()
                    if "ERR-AUTH-LOGIN-FAIL" in l), "")[:160])
        check("登录失败告警文案准确（不再误报为权限不足）",
              "账号或密码校验未通过" in fail_log)

        # 故障码知识库：三个鉴权码必须各自独立且有准确文案
        print("\n[阶段三·补] 鉴权类故障码知识库独立性")
        sys.path.insert(0, os.path.join(SYS_ROOT, "core"))
        from diagnostics_logger import ERROR_DIAGNOSTICS_DB as DB
        for code in ("ERR-AUTH-DENIED", "ERR-AUTH-LOGIN-FAIL", "ERR-AUTH-BRUTEFORCE"):
            e = DB.get(code, {})
            check(f"知识库收录 {code} 且文案非占位",
                  bool(e) and e.get("title") != "未知系统异常",
                  e.get("title", "未收录"))

    finally:
        # ---------------- 阶段五：前端静态核验 ----------------
        print("\n[阶段四] 前端静态核验（幂等闩锁 / 定时器清理）")
        with open(APP_JS, encoding="utf-8") as f:
            js = f.read()

        check("forceLogout 具备幂等闩锁",
              "if (LOGGING_OUT) { return; }" in js)
        check("注销第一时间停止全部轮询",
              "stopAllPolling();" in js and "clearInterval(POLL_TIMERS[i])" in js)
        check("轮询定时器统一经 poll() 登记",
              "function poll(fn, ms)" in js and js.count("poll(function ()") >= 4,
              f"poll() 登记处={js.count('poll(function ()')}")
        check("轮询处不再有裸 setInterval",
              not re.search(r"\n\s*setInterval\(function \(\) \{ (refreshPortDmx|loadSystemStatus|refreshAlarms)",
                            js))
        check("401 处理仍会触发注销（安全兜底未丢失）",
              "forceLogout('会话已过期，请重新登录。')" in js)

        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=12)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=5)
        if boot_log:
            boot_log.close()
        time.sleep(2.0)
        leftover = find_kernel_pids()
        check("控制台退出后无残留微内核",
              len(leftover) == 0, f"残留={leftover}" if leftover else "已干净退出")

    print("\n" + "=" * 74)
    passed = sum(1 for _, ok, _ in _results if ok)
    total = len(_results)
    if passed == total:
        print(f"  [ALL PASSED] 鉴权噪音抑制与安全信号保真 {passed}/{total} 全部通过！")
    else:
        print(f"  [FAILED] 通过 {passed}/{total}，未通过项：")
        for n, ok, d in _results:
            if not ok:
                print(f"      - {n} | {d}")
    print("=" * 74)
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
