# -*- coding: utf-8 -*-
"""
设备掉线告警处置方案 · 端到端回归验证

验证链路：
  场地节点拓扑 → 同步看门狗 → 阈值判定 → 告警中心登记 → 人工确认 → 真实 ArtDmx 恢复 → 自动销警

关键点：
  · 用真实 UDP 6454 ArtDmx 报文驱动恢复，而不是直接调用看门狗内部方法，
    以证明「被动发现 → 心跳 → 恢复事件」这条链路是真正打通的。
  · 严格区分「阈值触发 / 忽略 / 手动」三种策略的行为差异。
"""

import os
import sys
import json
import time
import socket
import struct
import threading
import urllib.request
import urllib.error
from http.server import HTTPServer

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.append(os.path.join(BASE_DIR, "core"))
sys.path.append(BASE_DIR)

PORT = 9097
PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")


def call(method, path, body=None, token=None):
    url = f"http://127.0.0.1:{PORT}{path}"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            raw = r.read().decode("utf-8")
            return r.status, (json.loads(raw) if raw.strip().startswith(("{", "[")) else raw)
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8")
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, raw


def build_artdmx(universe: int, sequence: int, values: dict) -> bytes:
    """构造标准 Art-Net ArtDmx 报文（18 字节头 + 512 通道）"""
    payload = bytearray(512)
    for ch, val in values.items():
        if 1 <= ch <= 512:
            payload[ch - 1] = val & 0xFF
    header = (b"Art-Net\x00" + struct.pack("<H", 0x5000) +
              struct.pack(">H", 14) + bytes([sequence & 0xFF, 0]) +
              struct.pack("<H", universe) + struct.pack(">H", 512))
    return bytes(header) + bytes(payload)


def send_artdmx(universe=0, seq=1, values=None, times=1, gap=0.25, src_ip=None):
    """
    发送 ArtDmx，模拟一台真实解码器在持续输出。

    :param src_ip: 绑定本机某个回环地址作为**源 IP**。
                   Windows 上整个 127.0.0.0/8 都路由到回环，
                   因此可以用 127.0.0.2 伪装成"另一台设备"来验证被动发现链路。
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        if src_ip:
            s.bind((src_ip, 0))
        for i in range(times):
            s.sendto(build_artdmx(universe, seq + i, values or {1: 255, 2: 128}), ("127.0.0.1", 6454))
            if gap:
                time.sleep(gap)
    finally:
        s.close()


def main():
    print("=" * 74)
    print(" 设备掉线告警处置方案 · 端到端回归验证")
    print("=" * 74)

    import control_station as cs

    # 观察员 fixture：出厂默认用户库含 guest(viewer)，但交付的 config/users.json
    # 里只有 admin 与 root。第 24b 项要验证"观察员无权人工标记掉线"，
    # 缺少观察员账号会登录失败并拿到 401 而非 403。
    # 按需创建，跑完在 finally 中删除，不污染交付配置。
    _guest_created = False
    if "guest" not in cs.auth.users:
        cs.auth.add_or_update_user("guest", "viewer", "guest", "现场观察员")
        _guest_created = True

    srv = HTTPServer(("127.0.0.1", PORT), cs.UnifiedControlStationServer)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.8)

    tmp_vid = "venue_alarm_verify"
    original = None

    try:
        _, res = call("POST", "/api/auth/login", {"username": "admin", "password": "admin123"})
        token = res["session"]["token"]
        check("1. 管理员登录", res.get("status") == "ok")

        # 备份当前激活场地，便于最后还原
        _, venues = call("GET", "/api/kb/venues", token=token)
        act = [v for v in venues if v.get("is_active")][0]
        original = {"venue_id": act["venue_id"], "nodes": act["nodes"]}

        # 构造三节点测试场地，覆盖三种策略
        st, r = call("POST", "/api/kb/save_venue", {
            "venue_id": tmp_vid, "venue_name": "告警回归验证场地", "default_target_ip": "127.0.0.1",
            "nodes": [
                {
                    "node_id": "nd_threshold", "name": "阈值触发节点", "ip": "127.0.0.2",
                    "source": "manual",
                    "offline_policy": {"mode": "threshold", "liveness_source": "artdmx",
                                       "threshold_sec": 3, "grace_period_sec": 0,
                                       "severity": "critical", "actions": ["log", "banner", "toast"],
                                       "auto_recover": True},
                    "ports": [{"port_id": "p1", "label": "A", "label_style": "alpha",
                               "universe": 0, "fixtures": []}],
                },
                {
                    # 关键回归项：该节点从来没有任何回传流量，判据是"被动数据帧"。
                    # 这是调音台现场最典型的形态（只发不收），绝不能被误判为掉线。
                    "node_id": "nd_never_seen", "name": "只发不收的常规解码器", "ip": "10.99.99.97",
                    "source": "manual",
                    "offline_policy": {"mode": "threshold", "liveness_source": "artdmx",
                                       "threshold_sec": 1, "grace_period_sec": 0,
                                       "alarm_when_never_seen": False,
                                       "severity": "critical", "actions": ["log", "banner"],
                                       "auto_recover": True},
                    "ports": [{"port_id": "p1", "label": "A", "label_style": "alpha",
                               "universe": 7, "fixtures": []}],
                },
                {
                    # 反过来：显式要求"从未上线也要报警"的节点，必须真的报警
                    "node_id": "nd_never_seen_strict", "name": "要求从未上线也告警的节点", "ip": "10.99.99.96",
                    "source": "manual",
                    "offline_policy": {"mode": "threshold", "liveness_source": "artpoll",
                                       "threshold_sec": 1, "grace_period_sec": 0,
                                       "alarm_when_never_seen": True,
                                       "severity": "critical", "actions": ["log", "banner"],
                                       "auto_recover": True},
                    "ports": [{"port_id": "p1", "label": "A", "label_style": "alpha",
                               "universe": 8, "fixtures": []}],
                },
                {
                    "node_id": "nd_ignore", "name": "忽略策略节点", "ip": "10.99.99.99",
                    "source": "manual",
                    "offline_policy": {"mode": "ignore", "threshold_sec": 1, "grace_period_sec": 0},
                    "ports": [{"port_id": "p1", "label": "A", "label_style": "alpha",
                               "universe": 5, "fixtures": []}],
                },
                {
                    "node_id": "nd_manual", "name": "手动标记节点", "ip": "10.99.99.98",
                    "source": "manual",
                    "offline_policy": {"mode": "manual", "severity": "warning",
                                       "actions": ["log", "banner"], "auto_recover": True},
                    "ports": [{"port_id": "p1", "label": "1", "label_style": "numeric",
                               "universe": 6, "fixtures": []}],
                },
            ],
        }, token)
        check("2. 三策略测试场地保存", st == 200 and r.get("status") == "ok",
              f"-> {r.get('node_count')} 解码器")

        st, r = call("POST", "/api/kb/switch_venue", {"venue_id": tmp_vid}, token)
        check("3. 切换到告警测试场地", st == 200 and r.get("status") == "ok", f"-> {r.get('venue_name')}")

        st, r = call("POST", "/api/nodes/sync_watchdog", {}, token)
        check("4. 同步掉线监测（接管 5 个节点）", st == 200 and r.get("registered") == 5,
              f"-> 接管 {r.get('registered')} 个节点")

        # 先清干净历史告警，避免干扰判定
        call("POST", "/api/alarms/ack", {"all": True}, token)

        # === 阶段一：先让节点真正上线（真实 UDP 报文驱动被动发现） ===
        # 这一步是必需的：在"从未收到过心跳"时，系统按设计报「未监测」而非「掉线」，
        # 因此必须先建立"曾经在线"的事实，才能验证"后来掉线"能被发现。
        print("      [注入] 以源地址 127.0.0.2 发送真实 ArtDmx，让阈值节点先建立在线事实 …")
        send_artdmx(universe=0, seq=1, values={1: 255, 2: 64, 3: 200},
                    times=6, gap=0.3, src_ip="127.0.0.2")
        time.sleep(2.0)

        st, disc1 = call("GET", "/api/nodes/discovered", token=token)
        wd1 = disc1.get("watchdog", {})
        thr1 = wd1.get("nd_threshold", {})
        check("5. 收到真实报文后节点判定为在线",
              thr1.get("state") == "online" and thr1.get("online") is True,
              f"-> state={thr1.get('state')} / 距上次心跳 {thr1.get('source_age_sec')}s")
        check("6. 被动发现表已登记该来源", 
              any(d.get("ip") == "127.0.0.2" for d in disc1.get("discovered", [])),
              f"-> 被动表={[d.get('ip') for d in disc1.get('discovered', [])]}")

        # === 阶段二：停止回传，等待阈值触发 ===
        print("      [等待] 停止回传，静默 7s 观察阈值触发与各策略的行为差异 …")
        time.sleep(7.0)

        st, al = call("GET", "/api/alarms", token=token)
        codes = [(a["code"], a["node_id"], a["state"], a["severity"]) for a in al.get("alarms", [])]
        offline_ids = {a["node_id"] for a in al.get("alarms", [])
                       if a["code"] == "ERR-NODE-OFFLINE" and a["state"] != "recovered"}

        check("7. 曾经在线而后静默的节点正确触发掉线告警",
              "nd_threshold" in offline_ids,
              f"-> 离线节点={sorted(offline_ids)}")
        check("8. 忽略策略节点绝不产生告警",
              "nd_ignore" not in offline_ids and "nd_ignore" not in {c[1] for c in codes},
              "-> ignore 模式被正确跳过")
        check("9. 手动策略节点在未人工标记前不误报",
              "nd_manual" not in offline_ids,
              "-> 人工标记前保持沉默")
        check("10. 告警严重级别取自节点策略",
              any(a["node_id"] == "nd_threshold" and a["severity"] == "critical"
                  for a in al.get("alarms", [])),
              f"-> severity={[a['severity'] for a in al.get('alarms', []) if a['node_id'] == 'nd_threshold']}")
        check("11. 告警中心未处理计数 > 0", al.get("open_count", 0) > 0,
              f"-> 未处理 {al.get('open_count')} 条")

        # === 关键回归：只发不收的解码器不得因"从未收到回传"被误判掉线 ===
        check("12. 从未有回传流量的解码器不被误报掉线（防告警脱敏）",
              "nd_never_seen" not in offline_ids,
              "-> 误报防护生效，状态应为「未监测」而非「掉线」")
        st, disc0 = call("GET", "/api/nodes/discovered", token=token)
        nv = disc0.get("watchdog", {}).get("nd_never_seen", {})
        check("13. 该节点状态呈三态中的「未监测」",
              nv.get("state") == "unknown" and nv.get("online") is None and nv.get("never_seen") is True,
              f"-> state={nv.get('state')} / online={nv.get('online')} / never_seen={nv.get('never_seen')}")
        check("14. 显式要求「从未上线也告警」的节点确实报警",
              "nd_never_seen_strict" in offline_ids,
              "-> 策略开关双向生效")

        # 去重：再等一轮不应重复登记
        n_before = len(al.get("alarms", []))
        time.sleep(2.5)
        st, al2 = call("GET", "/api/alarms", token=token)
        check("15. 同节点同错误码不重复登记",
              len(al2.get("alarms", [])) == n_before,
              f"-> 告警条数稳定在 {n_before}")

        # 人工确认（若阈值节点因时序原因尚未触发，这里给出明确失败而不是抛异常）
        pending = [a for a in al2["alarms"]
                   if a["node_id"] == "nd_threshold" and a["state"] == "open"]
        check("16. 单条告警人工确认",
              len(pending) == 1,
              f"-> 待确认告警 {len(pending)} 条")
        if not pending:
            raise SystemExit("[ABORT] 阈值节点未产生告警，后续恢复链路无法验证。")
        st, r = call("POST", "/api/alarms/ack", {"alarm_id": pending[0]["id"]}, token)
        check("17. 确认后状态转为 acked", st == 200 and r["alarm"]["state"] == "acked",
              f"-> {pending[0]['id']} → {r['alarm']['state']}")

        # 用真实 ArtDmx 恢复：以 127.0.0.2 为源地址发帧，等价于"那台设备重新上线"
        print("      [注入] 以源地址 127.0.0.2 发送真实 ArtDmx 到 UDP 6454，验证被动发现 → 自动销警 …")
        send_artdmx(universe=0, seq=1, values={1: 255, 2: 64, 3: 200},
                    times=8, gap=0.3, src_ip="127.0.0.2")
        time.sleep(1.5)

        st, al3 = call("GET", "/api/alarms", token=token)
        thr = [a for a in al3.get("alarms", []) if a["node_id"] == "nd_threshold"
               and a["code"] == "ERR-NODE-OFFLINE"]
        recovered = [a for a in thr if a["state"] == "recovered"]
        check("18. 真实 ArtDmx 恢复后告警自动销警",
              len(recovered) >= 1,
              f"-> 状态={[a['state'] for a in thr]}"
              + (f" / 恢复于 {recovered[0]['recovered_at']}" if recovered else ""))

        disc = call("GET", "/api/nodes/discovered", token=token)[1]
        wd = disc.get("watchdog", {}).get("nd_threshold", {})
        check("19. 看门狗状态已完成恢复闭环",
              wd.get("state") == "online",
              f"-> state={wd.get('state')} / 距上次心跳 {wd.get('source_age_sec')}s")

        # 手动策略：人工标记掉线 → 产生告警 → 人工标记恢复 → 销警
        st, r = call("POST", "/api/nodes/set_manual_state",
                     {"node_id": "nd_manual", "offline": True}, token)
        check("20. 手动模式可人工标记掉线", st == 200 and r.get("manual_offline") is True,
              f"-> {r.get('node_id')}")
        time.sleep(2.5)
        st, al4 = call("GET", "/api/alarms", token=token)
        manual_alarms = [a for a in al4.get("alarms", [])
                         if a["node_id"] == "nd_manual" and a["state"] != "recovered"]
        check("21. 人工标记后产生掉线告警", len(manual_alarms) >= 1,
              f"-> {[(a['code'], a['state']) for a in manual_alarms]}")

        st, r = call("POST", "/api/nodes/set_manual_state",
                     {"node_id": "nd_manual", "offline": False}, token)
        time.sleep(2.5)
        st, al5 = call("GET", "/api/alarms", token=token)
        manual_rec = [a for a in al5.get("alarms", [])
                      if a["node_id"] == "nd_manual" and a["state"] == "recovered"]
        check("22. 人工标记恢复后告警销警", len(manual_rec) >= 1,
              f"-> {[a['state'] for a in manual_rec]}")

        # 全部确认
        st, r = call("POST", "/api/alarms/ack", {"all": True}, token)
        st, al6 = call("GET", "/api/alarms", token=token)
        check("23. 一键全部确认", st == 200 and al6.get("open_count") == 0,
              f"-> 剩余未处理 {al6.get('open_count')} 条")

        # 未注册节点的手动标记必须被拒绝
        st, r = call("POST", "/api/nodes/set_manual_state",
                     {"node_id": "nd_not_registered", "offline": True}, token)
        check("24. 未纳管节点手动标记被拒绝", st == 400 and r.get("status") == "error",
              f"-> {r.get('message')}")

        # 观察员无权标记
        _, g = call("POST", "/api/auth/login", {"username": "guest", "password": "guest"})
        st, r = call("POST", "/api/nodes/set_manual_state",
                     {"node_id": "nd_manual", "offline": True}, g["session"]["token"])
        check("24b. RBAC：观察员无权人工标记掉线", st == 403, f"-> HTTP {st}")

        # 还原原始场地并清理
        st, r = call("POST", "/api/kb/switch_venue", {"venue_id": original["venue_id"]}, token)
        call("POST", "/api/nodes/sync_watchdog", {}, token)
        st, r = call("POST", "/api/kb/delete_venue", {"venue_id": tmp_vid}, token)
        check("25. 测试场地删除并还原工作场地",
              r.get("status") == "ok" and not os.path.exists(
                  os.path.join(BASE_DIR, "knowledge_base", "venues", f"{tmp_vid}.json")),
              f"-> 已还原为 {original['venue_id']}")

    finally:
        srv.shutdown()
        # 移除本套件创建的一次性观察员 fixture，保证 config/users.json 净零变化
        if _guest_created:
            try:
                cs.auth.delete_user("guest")
            except Exception as e:
                print(f"[WARN] 观察员 fixture 清理失败: {e}")

    print("=" * 74)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 74)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
