# -*- coding: utf-8 -*-
"""
tests/test_artnet_event_hub_dispatch.py
Art-Net 网络抓包与 EventHub 事件分发协同专项测试套件
覆盖小申架构审计要求的 5 项核心指标：
(a) 宿主环境联动：传入 CoreContext(hosted=True, event_hub=hub)，on_enable 后 _using_event_hub is True 且 _sock is None；
(b) 事件广播与数据解析：向 hub.publish("network.artnet.packet", ...) 注入合法 ArtDmx 报文，stats 正确累加；
(c) 生命周期回收：on_disable 后退订，再次 publish 数据 stats 不再自增，且 _sock is None、无残留后台线程；
(d) 脱机降级分支：传入脱机 CoreContext(hosted=False)，on_enable 走独立 socket 监听分支（_using_event_hub is False）；
(e) 端口冲突优雅容错：预先占用端口，脱机 on_enable 捕获 OSError 记录 warning 且不崩溃，安全清理 _sock。
"""

import os
import sys
import time
import socket
import unittest

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from core.plugin_sdk import CoreContext, EventHub
from plugins.adapters.artnet_dashboard_adapter import ArtNetDashboardAdapter


class TestArtNetEventHubDispatch(unittest.TestCase):

    def setUp(self):
        self.hub = EventHub()
        self.context_hosted = CoreContext(event_hub=self.hub, hosted=True)
        self.context_standalone = CoreContext(event_hub=self.hub, hosted=False)

    def _build_mock_artdmx_packet(self, universe: int = 1, sequence: int = 1, dmx_data: bytes = None) -> bytes:
        if dmx_data is None:
            dmx_data = bytes([255, 128, 64, 0] * 128)  # 512 bytes
        header = b"Art-Net\x00"
        opcode = (0x5000).to_bytes(2, byteorder="little")  # OpDmx = 0x5000
        protver = (14).to_bytes(2, byteorder="big")
        seq = bytes([sequence & 0xFF])
        phys = b"\x00"
        uni = universe.to_bytes(2, byteorder="little")
        length = len(dmx_data).to_bytes(2, byteorder="big")
        return header + opcode + protver + seq + phys + uni + length + dmx_data

    def test_01_hosted_event_hub_subscription(self):
        """验证宿主环境下优先订阅 EventHub，不创建 socket"""
        adapter = ArtNetDashboardAdapter()
        adapter.on_init(self.context_hosted)
        adapter.on_enable()

        self.assertTrue(getattr(adapter, "_using_event_hub", False), "宿主环境下必须标记 _using_event_hub 为 True")
        self.assertIsNone(getattr(adapter, "_sock", None), "宿主环境下绝不能创建独立 socket 监听")

        adapter.on_disable()
        self.assertFalse(getattr(adapter, "_using_event_hub", True), "on_disable 后 _using_event_hub 应为 False")
        print("\n[PASS] 断言 1: 宿主环境下优先走 EventHub 订阅，免物理 socket 冲突通过")

    def test_02_event_dispatch_and_packet_accumulation(self):
        """验证通过 EventHub 广播的 Art-Net 报文能被正确解析与统计"""
        adapter = ArtNetDashboardAdapter()
        adapter.on_init(self.context_hosted)
        adapter.on_enable()

        packet = self._build_mock_artdmx_packet(universe=2, sequence=10)
        self.hub.publish("network.artnet.packet", "ArtNetPacketMonitor", {
            "data": packet,
            "addr": ("127.0.0.1", 6454),
            "universe": 2,
            "seq": 10,
            "payload": list(packet[18:])
        })

        stats = adapter.get_stats()
        self.assertGreaterEqual(stats.get("total_packets", 0), 1, "total_packets 应自增")
        universes = stats.get("universes", [])
        self.assertIn(2, universes, "统计的宇宙列表中应包含宇宙 2")

        adapter.on_disable()
        print("[PASS] 断言 2: EventHub 报文广播流精准分发与指标累加解析通过")

    def test_03_lifecycle_cleanup_and_unsubscribe(self):
        """验证 on_disable 后成功注销订阅，不再接收报文，且后台线程零泄漏"""
        adapter = ArtNetDashboardAdapter()
        adapter.on_init(self.context_hosted)
        adapter.on_enable()

        packet = self._build_mock_artdmx_packet(universe=1, sequence=1)
        self.hub.publish("network.artnet.packet", "ArtNetPacketMonitor", {"data": packet})
        stats_before = adapter.get_stats().get("total_packets", 0)
        self.assertEqual(stats_before, 1)

        adapter.on_disable()

        # 再次发布报文
        self.hub.publish("network.artnet.packet", "ArtNetPacketMonitor", {"data": packet})
        stats_after = adapter.get_stats().get("total_packets", 0)
        self.assertEqual(stats_after, stats_before, "on_disable 注销后不应再处理新发布的报文")
        self.assertIsNone(getattr(adapter, "_thread", None), "后台抓包线程引用必须清空")
        print("[PASS] 断言 3: 生命周期注销退订与并发线程零残留回收通过")

    def test_04_standalone_mode_falls_back_to_socket(self):
        """验证在脱机模式 (hosted=False) 下降级尝试创建并绑定 socket 监听"""
        adapter = ArtNetDashboardAdapter()
        # 配置一个未被占用的高位测试端口
        test_port = 16454
        adapter.on_init(self.context_standalone)
        adapter.update_config({"listen_port": test_port, "bind_ip": "127.0.0.1"})

        adapter.on_enable()
        self.assertFalse(getattr(adapter, "_using_event_hub", True), "脱机模式下 _using_event_hub 必须为 False")
        self.assertIsNotNone(getattr(adapter, "_sock", None), "脱机模式下应尝试创建 socket")
        self.assertTrue(getattr(adapter, "_running", False), "脱机工作线程应处于 running 状态")

        adapter.on_disable()
        self.assertIsNone(getattr(adapter, "_sock", None), "脱机模式 on_disable 后 socket 应关闭并置 None")
        print("[PASS] 断言 4: 脱机自包含模式 (hosted=False) 精准降级走独立 socket 监听通过")

    def test_05_port_conflict_graceful_handling(self):
        """验证脱机模式下若端口被抢占，能捕获异常并优雅降级，绝不崩溃抛出"""
        test_port = 16455
        occupier_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        occupier_sock.bind(("127.0.0.1", test_port))

        try:
            adapter = ArtNetDashboardAdapter()
            adapter.on_init(self.context_standalone)
            adapter.update_config({"listen_port": test_port, "bind_ip": "127.0.0.1"})

            # 故意触发端口占用
            adapter.on_enable()
            # 断言系统不崩溃，且 _sock 最终被安全回收为 None
            self.assertIsNone(getattr(adapter, "_sock", None), "端口占用时 _sock 应安全关闭并设为 None")
            adapter.on_disable()
        finally:
            occupier_sock.close()

        print("[PASS] 断言 5: 脱机模式端口争抢异常捕获与优雅降级容错通过")


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestArtNetEventHubDispatch)
    runner = unittest.TextTestRunner(verbosity=2)
    res = runner.run(suite)
    if res.wasSuccessful():
        print(f"\n结果: {res.testsRun} 项全部通过 / 0 项失败")
        sys.exit(0)
    else:
        print(f"\n结果: 失败 {len(res.failures)} 项, 错误 {len(res.errors)} 项")
        sys.exit(1)
