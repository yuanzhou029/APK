# -*- coding: utf-8 -*-
"""
验证 AI-MA v5.0 管理员自由设定/不可删除机制，以及 root 隐藏与动态 32 位 Hex Key 应急准入
"""

import os
import sys
import time
import json
import hashlib
import tempfile
import unittest

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(BASE_DIR, "core"))

from auth_manager import AuthManager, Role, EMERGENCY_ROOT_SEED

class TestAdminAndRootEmergency(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp_dir.name, "users.json")
        self.auth = AuthManager(user_db_path=self.db_path)

    def tearDown(self):
        try:
            self.tmp_dir.cleanup()
        except Exception:
            pass

    def test_01_root_is_hidden_in_user_list(self):
        """测试 1: 普通用户列表严格隐藏 root"""
        users_resp = self.auth.list_users()
        user_list = users_resp.get("users", [])
        usernames = [u["username"] for u in user_list]
        self.assertNotIn("root", usernames, "root 必须在用户列表中严格隐藏！")
        self.assertIn("admin", usernames, "初始系统主管理员 admin 必须在列表中")

    def test_02_admin_rename_and_password_change(self):
        """测试 2: 用户可以自行设定主管理员的账号名与密码"""
        # 1. 重命名管理员为 custom_admin
        res = self.auth.rename_admin("admin", "custom_admin")
        self.assertEqual(res["status"], "ok")
        self.assertIn("custom_admin", self.auth.users)
        self.assertNotIn("admin", self.auth.users)
        self.assertTrue(self.auth.users["custom_admin"].get("is_primary_admin"))

        # 2. 修改密码
        p_res = self.auth.change_password("custom_admin", "MyNewSecret2026!")
        self.assertEqual(p_res["status"], "ok")

        # 3. 验证使用新账号名和新密码登录
        sess = self.auth.authenticate("custom_admin", "MyNewSecret2026!")
        self.assertIsNotNone(sess)
        self.assertEqual(sess["username"], "custom_admin")
        self.assertEqual(sess["role"], Role.ADMIN)
        self.assertTrue(self.auth.check_permission(sess["token"], "manage_users"))

    def test_03_primary_admin_cannot_be_deleted(self):
        """测试 3: 系统主管理员绝对不可被删除 (改名后依然受保护)"""
        # 未改名时尝试删除
        with self.assertRaises(ValueError) as cm:
            self.auth.delete_user("admin")
        self.assertIn("受保护", str(cm.exception))

        # 改名后尝试删除
        self.auth.rename_admin("admin", "stage_master")
        with self.assertRaises(ValueError) as cm2:
            self.auth.delete_user("stage_master")
        self.assertIn("受保护", str(cm2.exception))

        # 尝试删除 root 也必然失败
        with self.assertRaises(ValueError):
            self.auth.delete_user("root")

    def test_04_dynamic_root_emergency_key(self):
        """测试 4: 32 位 Hex 动态 Key 计算与应急准入验证"""
        today_str = time.strftime("%Y-%m-%d")
        expected_raw = f"{EMERGENCY_ROOT_SEED}:{today_str}"
        expected_key = hashlib.md5(expected_raw.encode("utf-8")).hexdigest()

        # 验证是 32 位十六进制
        self.assertEqual(len(expected_key), 32)
        self.assertEqual(expected_key, self.auth.generate_emergency_key())

        # 验证校验机制
        self.assertTrue(self.auth.verify_emergency_key(expected_key))
        self.assertFalse(self.auth.verify_emergency_key("invalid_fake_key_12345678901234"))
        self.assertFalse(self.auth.verify_emergency_key("00000000000000000000000000000000"))

        # 验证通过 Key 直通签发最高特权 root 会话
        sess = self.auth.authenticate_emergency_root(expected_key)
        self.assertIsNotNone(sess)
        self.assertEqual(sess["username"], "root")
        self.assertEqual(sess["role"], Role.SUPERADMIN)
        self.assertTrue(sess.get("is_emergency_root"))
        # 验证 root 拥有全权穿透权限
        self.assertTrue(self.auth.check_permission(sess["token"], "any_arbitrary_permission"))

if __name__ == "__main__":
    unittest.main()
