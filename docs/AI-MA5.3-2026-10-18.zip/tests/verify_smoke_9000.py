# -*- coding: utf-8 -*-
"""
真机烟雾测试：在真实端口 9000 上启动完整总控台，逐条打真实 HTTP 请求。

与其它测试套件的区别：
  · 其它套件用 9097/9098/9099 等测试端口，且大多只验证服务层；
  · 本脚本打的是**生产端口 9000**上真正跑起来的那个服务，覆盖前端资产、
    鉴权、以及一条真正会驱动 DMX 引擎的直通执行链路。

注意：脚本不会修改知识库内容，只做读取与一次"全零安全帧"的执行验证。
"""

import http.cookiejar
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
PORT = 9000
BASE_URL = f"http://127.0.0.1:{PORT}"

PASS = 0
FAIL = 0

# 真实浏览器行为：会话 Cookie 由浏览器自动携带，因此测试也必须用 CookieJar；
# 同时禁用自动跟随 302，否则"未登录访问 /app 被重定向"会被跟到登录页而误判为 200。
_COOKIE_JAR = http.cookiejar.CookieJar()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OPENER = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(_COOKIE_JAR), _NoRedirect)


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")


def call(method, path, body=None, token=None, timeout=20):
    req = urllib.request.Request(
        BASE_URL + path,
        data=json.dumps(body).encode("utf-8") if body is not None else None,
        headers=({"Content-Type": "application/json"} |
                 ({"Authorization": "Bearer " + token} if token else {})),
        method=method)
    try:
        with _OPENER.open(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def jload(raw):
    try:
        return json.loads(raw)
    except Exception:
        return {}


def main():
    print("=" * 74)
    print(" 真机烟雾测试 · 生产端口 9000")
    print("=" * 74)

    py = sys.executable

    # 观察员 fixture：出厂默认用户库含 guest(viewer)，但交付的 config/users.json
    # 里只有 admin 与 root。第 14 项要验证"观察员写知识库被 403 拒绝"，
    # 缺少观察员账号会登录失败并拿到 401 而非 403。
    # 本套件以子进程方式启动真实服务，故须在启动前把账号写入同一份 config/users.json，
    # 跑完在 finally 中删除，保证配置净零变化。
    sys.path.insert(0, os.path.join(BASE, "core"))
    from auth_manager import AuthManager as _AuthManager

    _users_path = os.path.join(BASE, "config", "users.json")
    _am = _AuthManager(user_db_path=_users_path)
    _guest_created = False
    if "guest" not in _am.users:
        _am.add_or_update_user("guest", "viewer", "guest", "现场观察员")
        _guest_created = True

    # 以子进程方式启动真实服务，验证「用户双击 bat 启动」这条路径本身是否可用。
    # 注意：控制台启动时会打印数十行横幅，若用 PIPE 接收会被 64KB 管道缓冲写满而阻塞，
    # 导致 serve_forever() 永远执行不到。这里改为落盘到日志文件，既不阻塞也便于排错。
    boot_log = os.path.join(BASE, "logs", "_smoke_boot.log")
    os.makedirs(os.path.dirname(boot_log), exist_ok=True)
    logf = open(boot_log, "wb")
    proc = subprocess.Popen(
        [py, os.path.join(BASE, "control_station.py")],
        cwd=BASE, stdout=logf, stderr=subprocess.STDOUT)

    try:
        # 等服务真正开始监听
        up = False
        for _ in range(40):
            time.sleep(0.5)
            st, _raw = call("GET", "/", timeout=3)
            if st in (200, 302):
                up = True
                break
        check("1. 服务在端口 9000 正常拉起", up, f"-> {BASE_URL}")
        if not up:
            logf.flush()
            with open(boot_log, "r", encoding="utf-8", errors="replace") as f:
                print("  ── 启动日志尾部 ──")
                for line in f.read().splitlines()[-25:]:
                    print("   | " + line)
            return 1

        # 2. 登录门头页
        st, html = call("GET", "/")
        check("2. 首页为登录门头页（未登录不得进入后台）",
              st == 200 and "控制台登录" in html and "gate-brand" in html,
              f"-> HTTP {st} / {len(html)} 字节")

        # 3. 未登录访问 /app 必须被服务端拦截（而不是先下发后台 DOM 再靠前端弹回）
        st, html2 = call("GET", "/app")
        check("3. 未登录访问后台被服务端拦截",
              st in (301, 302, 303, 401, 403),
              f"-> HTTP {st}（后台 DOM 未下发）")
        st, html2b = call("GET", "/app", token="bogus-token-xxxx")
        check("3b. 伪造令牌访问后台同样被拦截", st in (301, 302, 303, 401, 403),
              f"-> HTTP {st}")

        # 4. 静态资产可正常获取
        for asset, marker in [("/assets/theme.css", "--brand"),
                              ("/assets/app.js", "State")]:
            st, body = call("GET", asset)
            check(f"4. 静态资产 {asset}", st == 200 and marker in body,
                  f"-> HTTP {st} / {len(body)} 字节")

        # 5. 路径穿越防护
        st, _ = call("GET", "/assets/../../control_station.py")
        check("5. /assets 路径穿越被阻断", st in (400, 403, 404), f"-> HTTP {st}")

        # 6. 鉴权
        st, raw = call("POST", "/api/auth/login",
                       {"username": "admin", "password": "admin123"})
        r = jload(raw)
        token = (r.get("session") or {}).get("token")
        check("6. 管理员登录", st == 200 and token, f"-> HTTP {st}")

        # 6b. 登录后 /app 放行
        st, body = call("GET", "/app")
        check("6b. 登录后后台页面放行", st == 200 and "kbSubnav" in body,
              f"-> HTTP {st}")

        # 7. 未持令牌的只读接口必须 401
        st, _ = call("GET", "/api/kb/summary")
        check("7. 只读接口强制鉴权（401）", st == 401, f"-> HTTP {st}")

        # 8. 核心只读接口全线可用
        for path, key in [("/api/kb/summary", "profiles_count"),
                          ("/api/kb/profiles", None),
                          ("/api/kb/venues", None),
                          ("/api/kb/presets", None),
                          ("/api/kb/categories", "categories"),
                          ("/api/kb/attribute_groups", "groups"),
                          ("/api/panel/layout", "groups"),
                          ("/api/alarms", "alarms"),
                          ("/api/nodes/discovered", "discovered"),
                          ("/api/dmx/universe/0", "channels")]:
            st, raw = call("GET", path, token=token)
            d = jload(raw)
            ok_ = st == 200 and (key is None or key in d)
            check(f"8. GET {path}", ok_, f"-> HTTP {st}")

        # 9. 掉线看门狗在真机环境下已完成接管
        st, raw = call("GET", "/api/nodes/discovered", token=token)
        wd = jload(raw).get("watchdog", {})
        check("9. 掉线看门狗已接管当前场地节点", len(wd) >= 1,
              f"-> 监测 {len(wd)} 个节点 / 状态={ {k: v.get('state') for k, v in wd.items()} }")

        # 9b. 真实环境下，只发不收的解码器不得被误判为掉线
        #     （这是本系统最容易被误用的一点：调音台只发不收，若无脑按静默时长判掉线，
        #       每台正常设备都会报警，运维人员很快就会对告警脱敏）
        bad = {k: v for k, v in wd.items() if v.get("state") == "offline"}
        check("9b. 无回传流量的解码器不被误报掉线", len(bad) == 0,
              f"-> 误报 {len(bad)} 个" + (f"：{list(bad)}" if bad else "（均为 未监测/在线）"))

        # 10. 直通执行链路：真实走一次「快捷场景 0ms 直达 DMX」，验证 API → 合并器 → 协议插件
        st, raw = call("GET", "/api/scenes/list", token=token)
        scenes = jload(raw)
        sid = scenes[0]["id"] if isinstance(scenes, list) and scenes else None
        check("10a. 快捷场景库可读", bool(sid), f"-> 共 {len(scenes) if isinstance(scenes, list) else 0} 条")

        # 先确保输出归零，避免烟雾测试在现场留下灯光
        call("POST", "/api/lighting/panic", {}, token)

        if sid:
            st, raw = call("POST", "/api/scenes/trigger_direct", {"id": sid}, token)
            d = jload(raw)
            check("10b. 快捷场景 0ms 直通下发（不经大模型）",
                  st == 200 and d.get("status") == "ok",
                  f"-> HTTP {st} / {str(d)[:70]}")
        else:
            check("10b. 快捷场景 0ms 直通下发（不经大模型）", False, "-> 场景库为空")

        # 10c. 烟雾测试不得在现场留下灯光，最后必须收黑
        st, raw = call("POST", "/api/lighting/panic", {}, token)
        check("10c. 测试收尾触发 PANIC 归零（不留灯光）", st == 200, f"-> HTTP {st}")

        # 11. Universe 帧读取与执行结果一致
        st, raw = call("GET", "/api/dmx/universe/0", token=token)
        d = jload(raw)
        ch = d.get("channels") or []
        check("11. Universe 0 帧为 512 通道",
              st == 200 and len(ch) == 512, f"-> {len(ch)} 通道")

        # 12. DMX 输出监视器在真实端口上确实收到了流量
        st, raw = call("GET", "/api/monitor/stats", token=token)
        d = jload(raw)
        check("12. Art-Net 监视器运行中",
              st == 200 and "current_fps" in d and "total_frames" in d,
              f"-> {d.get('current_fps')} fps / 累计 {d.get('total_frames')} 帧")

        # 13. 诊断日志与告警页可用
        st, raw = call("GET", "/api/logs/stream", token=token)
        check("13. 运行日志接口可用", st == 200, f"-> HTTP {st}")

        # 14. 权限隔离：观察员不得写知识库
        st, raw = call("POST", "/api/auth/login", {"username": "guest", "password": "guest"})
        g = jload(raw)
        gtok = (g.get("session") or {}).get("token")
        st, _ = call("POST", "/api/kb/save_preset",
                     {"preset_id": "smoke", "preset": {"name": "x", "category_id": "cat_general",
                                                       "channel_values": {"red": 1}}}, gtok)
        check("14. RBAC：观察员写知识库被 403 拒绝", st == 403, f"-> HTTP {st}")

        # 15. 确认没有留下测试残留
        st, raw = call("GET", "/api/kb/presets", token=token)
        check("15. 知识库未被烟雾测试污染", "smoke" not in jload(raw),
              "-> 无残留预设")

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:
            proc.kill()
        try:
            logf.close()
        except Exception:
            pass
        # 子进程完全退出后再清理 fixture——否则服务端退出时的配置落盘会把删除覆盖掉
        if _guest_created:
            try:
                _am2 = _AuthManager(user_db_path=_users_path)
                _am2.delete_user("guest")
            except Exception as e:
                print(f"[WARN] 观察员 fixture 清理失败: {e}")

    print("=" * 74)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 74)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
