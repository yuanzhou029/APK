# -*- coding: utf-8 -*-
"""
AI-MA 预设分类管理与全量预设审计套件 (verify_categories_management.py)
验证内容：
1. 全量预设审计：检查每个预设的 category_id 必须归属于已注册分类，严禁存在 __status 污染键
2. 分类批量保存接口 POST /api/kb/save_categories：支持创建新分类、修改分类名、更新颜色/图标
3. 分类标签计数精准性：验证各个分类预设数统计一致，待归类数必须为 0
4. 分类删除保护：有预设引用的分类严禁删除，无预设分类允许安全移除
"""

import os
import sys
import json

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from kb_service import KnowledgeBaseService

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：RAG 知识库分类管理与美学预设全量审计")
print("==============================================================================")

kb_path = os.path.join(BASE_DIR, "knowledge_base")
svc = KnowledgeBaseService(kb_path)

# 1. 全量审计当前美学预设
presets = svc.get_presets()
check("预设字典非空且是标准 dict", isinstance(presets, dict) and len(presets) >= 4, f"count={len(presets)}")
check("预设库中绝无 __status 污染键", "__status" not in presets, f"keys={list(presets.keys())}")

# 2. 检查分类注册表
cat_res = svc.get_categories()
cats = cat_res.get("categories", [])
check("分类注册表包含有效分类", len(cats) >= 1)
cat_ids = {c["id"]: c["name"] for c in cats}
check("分类注册表中每个分类包含有效 ID 与名称", all(c.get("id") and c.get("name") for c in cats))

# 3. 逐条审计所有预设的分类归属
orphan_count = 0
for pid, pdata in presets.items():
    cid = pdata.get("category_id")
    is_valid_cat = cid in cat_ids
    if not is_valid_cat:
        orphan_count += 1
    check(f"预设 [{pid}] ({pdata.get('name')}) 归属于合法分类 [{cid}]",
          is_valid_cat, f"cid={cid}, valid_cats={list(cat_ids.keys())}")

check("待归类预设计数严格为 0 (分类标签计数准确)", orphan_count == 0, f"actual_orphans={orphan_count}")

# 4. 验证批量保存分类接口 save_categories
original_cats = json.loads(json.dumps(cats))
first_id = cats[0]["id"]
first_orig_name = cats[0]["name"]

test_cats = json.loads(json.dumps(cats))
test_cats[0]["name"] = first_orig_name + "-改"
test_cats.append({"id": "cat_stage_fx", "name": "舞台特效分类", "color": "#ec4899", "order": len(test_cats), "icon": {"mode": "none"}})

save_res = svc.save_categories({"categories": test_cats})
check("save_categories 批量保存返回 ok", save_res.get("status") == "ok" and save_res.get("count") == len(test_cats))

# 读取最新分类表
new_cats = svc.get_categories().get("categories", [])
new_cat_ids = {c["id"]: c["name"] for c in new_cats}
check("新建分类 cat_stage_fx 已成功持久化", "cat_stage_fx" in new_cat_ids)
check("分类名称修改生效", new_cat_ids.get(first_id) == first_orig_name + "-改")

# 5. 恢复原始分类配置
restore_res = svc.save_categories({"categories": original_cats})
check("分类配置已干净恢复初始状态", restore_res.get("status") == "ok")

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
