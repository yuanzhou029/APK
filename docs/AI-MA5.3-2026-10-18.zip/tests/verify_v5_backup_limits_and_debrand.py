# -*- coding: utf-8 -*-
"""
验证 AI-MA v5.0 容灾备份严格上限、循环覆盖、删除与名称脱敏专项套件
(verify_v5_backup_limits_and_debrand.py)
"""

import os
import sys
import json
import time
import shutil

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 项目根（本套件位于 tests/ 下）
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from backup_manager import BackupManager

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：v5.0 备份上限(5份)、循环覆盖、快照删除与脱敏展示审计")
print("==============================================================================")

backup_mgr = BackupManager(BASE_DIR)

# 1. 验证系统快照上限与循环覆盖 (最多 5 份)
for i in range(7):
    backup_mgr.create_system_snapshot(tag="auto", description=f"循环压测自动快照 #{i}")
    time.sleep(0.01)

auto_dirs = [d for d in os.listdir(backup_mgr.auto_backup_dir) if os.path.isdir(os.path.join(backup_mgr.auto_backup_dir, d))]
check("系统自动快照严格循环覆盖，磁盘保留不超过 5 份", len(auto_dirs) <= 5, f"实际: {len(auto_dirs)}")

# 2. 验证手动快照创建与删除
man_res = backup_mgr.create_system_snapshot(tag="manual", description="待删除手动快照")
snap_id = man_res["snapshot_id"]
check("手动快照创建成功", snap_id in os.listdir(backup_mgr.manual_backup_dir))

del_ok = backup_mgr.delete_system_snapshot(snap_id)
check("手动快照成功被安全物理删除", del_ok and snap_id not in os.listdir(backup_mgr.manual_backup_dir))

# 3. 验证用户工作区备份上限 (最多 5 份)
test_user = "test_limiter_user"
# 先清空该测试用户的旧备份
for f in backup_mgr.get_user_backup_files(test_user):
    os.remove(f)

# 连续创建 5 份
for i in range(5):
    res = backup_mgr.export_user_package(test_user, {"idx": i}, include_kb_presets=False)
    check(f"用户备份 #{i+1} 成功入库", res.get("status") == "ok")
    time.sleep(0.01)

# 创建第 6 份（未允许强制覆盖）
res_6_block = backup_mgr.export_user_package(test_user, {"idx": 6}, include_kb_presets=False, force_rotate=False)
check("达到 5 份上限后，系统返回 quota_full 保护拦截与提示", res_6_block.get("status") == "quota_full")

# 创建第 6 份（允许强制覆盖）
res_6_rotate = backup_mgr.export_user_package(test_user, {"idx": 6}, include_kb_presets=False, force_rotate=True)
check("用户确认后，第 6 份成功循环淘汰最旧备份", res_6_rotate.get("status") == "ok")
check("用户备份总数始终锁定在 5 份", len(backup_mgr.get_user_backup_files(test_user)) == 5)

# 4. 验证备份文件脱敏展示 (不显示 .json 后缀)
pkgs = backup_mgr.list_user_packages()
check("用户备份列表成功读取", len(pkgs) > 0)
target_pkg = next((p for p in pkgs if p["exported_by"] == test_user), None)
check("脱敏安全名称 safe_name 存在", target_pkg is not None and "safe_name" in target_pkg)
check("脱敏名称不含 .json 后缀", not target_pkg["safe_name"].endswith(".json"))

# 5. 验证按脱敏名称进行读取与删除
loaded_pkg = backup_mgr.get_user_package(target_pkg["safe_name"])
check("使用无后缀脱敏名称能正常读取备份数据", loaded_pkg is not None)

# 清理测试用户的 5 份备份
for f in backup_mgr.get_user_backup_files(test_user):
    os.remove(f)
check("测试用户测试备份已干净销毁", len(backup_mgr.get_user_backup_files(test_user)) == 0)

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
