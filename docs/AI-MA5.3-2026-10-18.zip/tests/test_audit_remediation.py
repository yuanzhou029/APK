# -*- coding: utf-8 -*-
"""
AI-MA 5.3 四项整改自测验证套件 (Audit Remediation Verification Suite)
覆盖项：
1. [严重漏洞修复 - RCE 路径穿越]：验证 /api/plugins/community/upload 过滤恶意路径 ../ 与非法字符
2. [高危缺陷修复 - 实时控制暗场失效]：验证 DmxMerger.get_controlled_channels_mask 及暗场置 0 掩码生成
3. [高危缺陷修复 - 业务渲染跨 Universe 宏截断]：验证 CoreEngine._update_macro 跨 Universe 聚类循环渲染
4. [中高危隐患修复 - 看门狗重启后共享内存重新连接]：验证 AimaKernelBridge.reconnect()/reset()
"""

import os
import sys
import unittest
import base64
from unittest.mock import MagicMock, patch

# 注入项目根路径
SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)
CORE_DIR = os.path.join(SYS_ROOT, "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from core.dmx_merger import DmxMerger, PriorityLevel
from core.engine import CoreEngine
from core.kernel_bridge import AimaKernelBridge

class TestAuditRemediation(unittest.TestCase):

    def test_01_upload_path_traversal_sanitization(self):
        """测试 1: 验证插件上传接口文件名清洗与路径穿越防护逻辑"""
        # 测试路径清洗逻辑与各种恶意注入
        malicious_filenames = [
            ("../../core/engine.py", "engine"),
            ("..\\..\\core\\engine.py", "engine"),
            ("/etc/passwd.py", "passwd"),
            ("foo/bar/baz.py", "baz"),
            ("valid_plugin.py", "valid_plugin"),
        ]
        
        for raw, expected_stem in malicious_filenames:
            safe_filename = os.path.basename(raw.replace("\\", "/"))
            name_without_ext, ext = os.path.splitext(safe_filename)
            self.assertEqual(name_without_ext, expected_stem)
            self.assertEqual(ext, ".py")
            # 确保不会穿越到上级目录
            self.assertNotIn("/", safe_filename)
            self.assertNotIn("\\", safe_filename)
            self.assertNotIn("..", safe_filename)

        # 测试非法字符/非合法标识符拒绝
        invalid_filenames = [
            "bad-name.py",       # 连字符非 Python 标识符
            "bad name.py",      # 含空格
            "123plugin.py",     # 数字开头
            "plugin.sh",        # 非 .py
            "plugin.py.txt",    # 双重后缀
            "$(calc).py",       # 命令注入尝试
            "../../bad.py",     # 提取后虽为 bad.py，但若包含恶意穿越需确保被截断为纯文件名
        ]
        for fn in invalid_filenames:
            safe_fn = os.path.basename(fn.replace("\\", "/"))
            name_no_ext, ext = os.path.splitext(safe_fn)
            is_valid = (ext == ".py" and name_no_ext.isidentifier())
            if fn in ["bad-name.py", "bad name.py", "123plugin.py", "plugin.sh", "plugin.py.txt", "$(calc).py"]:
                self.assertFalse(is_valid, f"文件名 [{fn}] 应被拒绝但被放行！")
            elif fn == "../../bad.py":
                self.assertTrue(is_valid)
                self.assertEqual(safe_fn, "bad.py")

    def test_02_blackout_and_active_mask(self):
        """测试 2: 验证暗场(电平 0)下的受控通道掩码穿透生成逻辑"""
        merger = DmxMerger(universe_count=2)
        
        # 初始无任何信号源时，掩码全 0 (退让)
        mask_u0 = merger.get_controlled_channels_mask(0)
        self.assertEqual(mask_u0, bytearray(512), "无源激活时掩码应全 0")
        self.assertFalse(merger.has_active_sources(0))

        # 配置通道映射: U0 上的灯具占 CH1~CH4
        merger.configure_fixture_channels(0, 1, [
            {"ch": 1, "type": "dimmer"},
            {"ch": 2, "type": "red"},
            {"ch": 3, "type": "green"},
            {"ch": 4, "type": "blue"},
        ])

        # 提交全 0 帧 (暗场 / 关死 / 拉低推杆)
        blackout_frame = bytearray(512)
        merger.submit_frame("cue_blackout", 0, blackout_frame, priority=PriorityLevel.AI_CUE)

        # 验证有信号源激活
        self.assertTrue(merger.has_active_sources(0))
        
        # 核心断言：即使所有通道值为 0，受控通道的掩码必须为 1，确保 0 值穿透
        mask_active = merger.get_controlled_channels_mask(0)
        for ch in range(1, 5):
            self.assertEqual(mask_active[ch - 1], 1, f"CH{ch} 暗场状态下掩码必须置 1，确保 0 电平穿透！")
        for ch in range(5, 513):
            self.assertEqual(mask_active[ch - 1], 0, f"非受控 CH{ch} 掩码应为 0")

        # 验证清除信号源后掩码恢复为全 0
        merger.clear_source("cue_blackout", 0)
        mask_cleared = merger.get_controlled_channels_mask(0)
        self.assertEqual(mask_cleared, bytearray(512), "清除信号源后掩码应恢复为全 0")

    def test_03_multi_universe_macro_dispatch(self):
        """测试 3: 验证跨 Universe 宏渲染聚类分发与提交"""
        mock_kb = MagicMock()
        mock_kb.current_venue = {"fixtures": []}
        mock_kb.profiles = {}
        
        engine = CoreEngine(kb_manager=mock_kb, config={"fps": 30, "plugins_dir": "plugins"})
        
        # 构造跨越 U0, U1, U2 三个 Universe 的灯具列表
        fixtures = [
            {"universe": 0, "address": 1, "dimmer_ch": 1},
            {"universe": 0, "address": 10, "dimmer_ch": 10},
            {"universe": 1, "address": 5, "dimmer_ch": 5},
            {"universe": 2, "address": 20, "dimmer_ch": 20},
        ]
        
        mock_macro = MagicMock()
        def mock_render(elapsed_ms, params, base_frame):
            # 将该 Universe 包含的灯具通道置为 255
            frame = bytearray(base_frame)
            for fix in params.get("fixtures", []):
                frame[fix["dimmer_ch"] - 1] = 255
            return frame
        mock_macro.render.side_effect = mock_render
        
        engine._active_macro_job = {
            "macro_id": "macro_test",
            "macro": mock_macro,
            "params": {"fixtures": fixtures},
            "start_time": 0.0
        }
        
        # 触发一次宏更新
        engine._update_macro(now=1.0)
        
        # 核心断言：U0, U1, U2 必须均收到 active_macro 信号源的帧
        frame_u0 = engine.dmx_merger.get_final_frame(0)
        frame_u1 = engine.dmx_merger.get_final_frame(1)
        frame_u2 = engine.dmx_merger.get_final_frame(2)
        
        self.assertEqual(frame_u0[0], 255, "Universe 0 灯具 1 应被宏渲染")
        self.assertEqual(frame_u0[9], 255, "Universe 0 灯具 2 应被宏渲染")
        self.assertEqual(frame_u1[4], 255, "Universe 1 灯具应被宏渲染（已消除跨宇宙截断）")
        self.assertEqual(frame_u2[19], 255, "Universe 2 灯具应被宏渲染（已消除跨宇宙截断）")
        
        # 验证 macro.render 被调用了 3 次 (3 个 Universe 各 1 次)
        self.assertEqual(mock_macro.render.call_count, 3)

    def test_04_kernel_bridge_reconnect(self):
        """测试 4: 验证 AimaKernelBridge 的 reconnect 与 reset 机制"""
        bridge = AimaKernelBridge.get_instance()
        self.assertTrue(hasattr(bridge, "reconnect"), "AimaKernelBridge 必须提供 reconnect 方法")
        self.assertTrue(hasattr(bridge, "reset"), "AimaKernelBridge 必须提供 reset 方法")
        
        # 模拟执行一次重连
        ok = bridge.reconnect()
        # 检查是否成功执行重连且状态一致
        self.assertEqual(ok, bridge.is_available)
        
        # reset 应作为 reconnect 的别名正常工作
        ok2 = bridge.reset()
        self.assertEqual(ok2, bridge.is_available)


if __name__ == "__main__":
    unittest.main()
