# -*- coding: utf-8 -*-
"""
AI 说明书 → 结构化灯库 完整功能测试
覆盖：
  1. parse_document_content - TXT / DOCX / PDF 文本提取
  2. search_dmx_sections    - DMX 通道表智能检索切片
  3. ai_extract_profile     - 纯文本路径 / 文件路径 / 自定义 Prompt 路径（大模型 Mock）
"""

import sys, os, io
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from kb_service import KnowledgeBaseService

PASS = 0; FAIL = 0

def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        print(f"  [PASS] {name}")
        PASS += 1
    else:
        print(f"  [FAIL] {name}  {detail}")
        FAIL += 1

# ---------------------------------------------------------------------------
# 1. parse_document_content — TXT
# ---------------------------------------------------------------------------
print("\n=== 1. 文档解析：TXT ===")
txt_bytes = "CH1 调光\nCH2 频闪\nCH3 红".encode("utf-8")
result = KnowledgeBaseService.parse_document_content(txt_bytes, "manual.txt")
check("TXT UTF-8 正常提取", "CH1" in result and "CH3" in result, repr(result[:80]))

# GBK 编码
gbk_bytes = "CH1 总调光\nCH2 频闪".encode("gbk")
result_gbk = KnowledgeBaseService.parse_document_content(gbk_bytes, "manual.txt")
check("TXT GBK 自动识别编码", "CH1" in result_gbk, repr(result_gbk[:80]))

# ---------------------------------------------------------------------------
# 2. parse_document_content — DOCX（内存构建）
# ---------------------------------------------------------------------------
print("\n=== 2. 文档解析：DOCX ===")
try:
    from docx import Document as DocxDoc
    doc = DocxDoc()
    doc.add_heading("Test Fixture DMX 说明书", 0)
    doc.add_paragraph("通道功能表")
    tbl = doc.add_table(rows=3, cols=2)
    tbl.rows[0].cells[0].text = "CH"
    tbl.rows[0].cells[1].text = "功能"
    tbl.rows[1].cells[0].text = "1"
    tbl.rows[1].cells[1].text = "总调光 Dimmer"
    tbl.rows[2].cells[0].text = "2"
    tbl.rows[2].cells[1].text = "频闪 Strobe"
    buf = io.BytesIO()
    doc.save(buf)
    docx_bytes = buf.getvalue()
    docx_text = KnowledgeBaseService.parse_document_content(docx_bytes, "beam_test.docx")
    check("DOCX 段落文本提取", "通道功能表" in docx_text, repr(docx_text[:120]))
    check("DOCX 表格提取（表头）", "CH" in docx_text and "功能" in docx_text, repr(docx_text[:120]))
    check("DOCX 表格提取（内容）", "总调光" in docx_text, repr(docx_text[:200]))
except Exception as e:
    check("DOCX 解析（python-docx 可用）", False, str(e))

# ---------------------------------------------------------------------------
# 3. parse_document_content — PDF
# ---------------------------------------------------------------------------
print("\n=== 3. 文档解析：PDF ===")
try:
    import pypdf
    from pypdf import PdfWriter
    writer = PdfWriter()
    page = writer.add_blank_page(width=595, height=842)
    buf = io.BytesIO()
    writer.write(buf)
    pdf_bytes = buf.getvalue()
    pdf_text = KnowledgeBaseService.parse_document_content(pdf_bytes, "dummy.pdf")
    check("PDF 解析不崩溃（pypdf 可用）", isinstance(pdf_text, str), "")
except ImportError:
    # 工业降级路径验证：当缺少 pypdf 模块时，parse_document_content 应准确捕获并抛出清晰的 ValueError
    try:
        KnowledgeBaseService.parse_document_content(b"%PDF-1.4...", "dummy.pdf")
        check("缺少 pypdf 时的错误捕获", False, "未按预期抛出异常")
    except ValueError as e:
        check("缺少 pypdf 时正确抛出带有原因的 ValueError", "No module named 'pypdf'" in str(e) or "PDF 文档解析失败" in str(e), str(e))
except Exception as e:
    check("PDF 解析异常", False, str(e))

# ---------------------------------------------------------------------------
# 4. search_dmx_sections — 短文本直通
# ---------------------------------------------------------------------------
print("\n=== 4. DMX 通道表切片检索 ===")
short = "CH1 调光\nCH2 频闪\nCH3 红\nCH4 绿"
sliced, meta = KnowledgeBaseService.search_dmx_sections(short)
check("短文本直接全量送检", meta.get("strategy") == "full_pass" and "CH1" in sliced, str(meta))

# ---------------------------------------------------------------------------
# 5. search_dmx_sections — 长文本智能切片
# ---------------------------------------------------------------------------
noise_before = "\n".join([f"安全规程第 {i} 条：保持机器散热口通畅，严禁遮挡风扇出口，否则可能导致过热保护触发或设备损坏，请严格遵守。" for i in range(60)])
dmx_table = "\nDMX Channel Function Table\nCH1 Dimmer\nCH2 Strobe\nCH3 Red\nCH4 Green\nCH5 Blue\n"
noise_after = "\n".join([f"保修条款第 {i} 条：人为损坏、液体进入、超压使用均不在三包范围之内，请妥善保管购买凭证。" for i in range(60)])
long_doc = noise_before + dmx_table + noise_after

sliced, meta = KnowledgeBaseService.search_dmx_sections(long_doc)
check("长文本策略为 smart_slice", meta.get("strategy") == "smart_slice", str(meta))
check("命中数 > 0", meta.get("hit_count", 0) > 0, str(meta))
check("切片包含 DMX 通道关键词", "CH1" in sliced or "Dimmer" in sliced, sliced[:200])
check("切片长度合理 < 12000 字符", len(sliced) < 12000, f"len={len(sliced)}")

# 自定义关键词优先
sliced2, meta2 = KnowledgeBaseService.search_dmx_sections(long_doc, custom_keywords=["Strobe"])
check("自定义关键词命中", meta2.get("hit_count", 0) > 0, str(meta2))

# ---------------------------------------------------------------------------
# 6. ai_extract_profile — Mock LLM，纯文本路径
# ---------------------------------------------------------------------------
print("\n=== 5. ai_extract_profile（Mock LLM） ===")

SAMPLE_PROFILE_JSON = '''{
  "profile_id": "test_beam_4ch",
  "manufacturer": "TestLight",
  "model": "Beam-4CH",
  "channel_count": 4,
  "channels": [
    {"ch": 1, "type": "dimmer", "name": "总调光", "default": 0, "is_safe": true, "range": [0, 255], "slots": []},
    {"ch": 2, "type": "shutter", "name": "频闪", "default": 0, "is_safe": true, "range": [0, 255], "slots": []},
    {"ch": 3, "type": "red", "name": "红色", "default": 0, "is_safe": true, "range": [0, 255], "slots": []},
    {"ch": 4, "type": "control", "name": "设备复位", "default": 0, "is_safe": false, "range": [0, 255], "slots": [{"v":85,"label":"复位"}]}
  ]
}'''

class MockLLM:
    def chat_completion(self, messages, temperature=0.2):
        # 验证系统提示词包含关键内容
        sys_msg = messages[0]["content"]
        user_msg = messages[1]["content"]
        assert "profile_id" in sys_msg, "系统提示词缺少 profile_id 指示"
        assert "is_safe" in sys_msg, "系统提示词缺少 is_safe 安全标注指示"
        return f"```json\n{SAMPLE_PROFILE_JSON}\n```"

mock_llm = MockLLM()

# 路径 A：纯文本
result_a = KnowledgeBaseService(
    os.path.join(os.path.dirname(__file__), '..', 'knowledge_base'),
).ai_extract_profile(raw_text="CH1 总调光\nCH2 频闪\nCH3 红\nCH4 设备复位(危险)", llm_plugin=mock_llm)
check("纯文本路径返回有效灯库", result_a.get("profile_id") == "test_beam_4ch", str(result_a.get("profile_id")))
check("通道数正确（4）", len(result_a.get("channels", [])) == 4, str(len(result_a.get("channels", []))))
check("危险通道 is_safe=False 保留", result_a["channels"][3]["is_safe"] is False, str(result_a["channels"][3]))
check("元数据挂载（_extract_meta）", "_extract_meta" in result_a, str(list(result_a.keys())))
check("source_type 为 raw_text", result_a["_extract_meta"]["source_type"] == "raw_text", str(result_a["_extract_meta"]))

# 路径 B：自定义 Prompt
result_b = KnowledgeBaseService(
    os.path.join(os.path.dirname(__file__), '..', 'knowledge_base'),
).ai_extract_profile(
    raw_text="CH1 总调光 CH2 频闪",
    custom_prompt="提取16通道扩展模式，型号为 Beam 230W",
    llm_plugin=mock_llm
)
check("自定义 Prompt 路径成功", result_b.get("profile_id") == "test_beam_4ch", "")
check("has_custom_prompt=True", result_b["_extract_meta"]["has_custom_prompt"] is True, str(result_b["_extract_meta"]))

# 路径 C：文件字节（构造一个 TXT 字节流）
txt_manual = b"DMX Channel Table\nCH1 Dimmer\nCH2 Strobe\nCH3 Red\nCH4 Reset (DANGER)"
result_c = KnowledgeBaseService(
    os.path.join(os.path.dirname(__file__), '..', 'knowledge_base'),
).ai_extract_profile(
    file_bytes=txt_manual,
    filename="beam_manual.txt",
    llm_plugin=mock_llm
)
check("文件字节路径成功", result_c.get("profile_id") == "test_beam_4ch", "")
check("source_type 为 file", result_c["_extract_meta"]["source_type"] == "file", str(result_c["_extract_meta"]))
check("filename 记录正确", result_c["_extract_meta"]["filename"] == "beam_manual.txt", str(result_c["_extract_meta"]))

# 路径 D：无 LLM 时抛出 RuntimeError
try:
    KnowledgeBaseService(
        os.path.join(os.path.dirname(__file__), '..', 'knowledge_base'),
    ).ai_extract_profile(raw_text="test", llm_plugin=None)
    check("无 LLM 时正确抛出异常", False, "未抛出异常")
except RuntimeError as e:
    check("无 LLM 时正确抛出 RuntimeError", "未启用" in str(e), str(e))

# 路径 E：两个输入都为空时抛出 ValueError
try:
    KnowledgeBaseService(
        os.path.join(os.path.dirname(__file__), '..', 'knowledge_base'),
    ).ai_extract_profile(llm_plugin=mock_llm)
    check("空输入时正确抛出异常", False, "未抛出异常")
except ValueError as e:
    check("空输入时正确抛出 ValueError", "未提供" in str(e), str(e))

# ---------------------------------------------------------------------------
print(f"\n{'='*55}")
print(f"  合计：{PASS+FAIL} 项，通过 {PASS}，失败 {FAIL}")
if FAIL == 0:
    print(f"  [SUCCESS] 全部通过！({PASS}/{PASS})")
else:
    print(f"  [FAILED] 有 {FAIL} 项失败，请检查上方日志。")
    sys.exit(1)
