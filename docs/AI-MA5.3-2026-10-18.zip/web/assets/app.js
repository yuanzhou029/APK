/* ============================================================================
   AI-MA 统一总控台 · 应用逻辑层 v4.3
   变更要点：
     · 主控面板改为「自定义组装」——从分类化的预设/场景库手动挑选
     · 场地改为四层节点树 解码器→接口→灯具→通道，接口序号可自定义(A/B/C 或 1/2/3)
     · 预设改为「自定义分类 + 通道属性驱动」，卡片只读，详情内双模式编辑
     · 新增 ArtPoll 节点发现、连接测试三态判定、掉线告警中心
   ========================================================================== */
(function () {
'use strict';

/* ---------------------------------------------------------------- 会话门禁 */
var TOKEN_KEY = 'ai_ma_token';
var TOKEN = localStorage.getItem(TOKEN_KEY) || '';
var SESSION = null;
var PERMS = [];

var VIEWS = {
  control:       { title: '交互控制台',        sub: '自然语言控光 · 自定义面板 · 端口级通道监视' },
  scenes_studio: { title: '快捷场景管理',      sub: '确定性执行级场景资产的增删改查' },
  monitor:       { title: '设备节点与监视',    sub: '解码器拓扑 · ArtPoll 发现 · 掉线告警策略' },
  marketplace:   { title: '插件市场与管理',    sub: '插件安装 · 合规校验 · 参数配置 · 热启停' },
  llm_cfg:       { title: '本地大模型接入',    sub: '端侧推理服务端点与模型标识配置' },
  kb:            { title: 'RAG 知识库管理',    sub: '灯库 · 场地节点拓扑 · 美学预设 · 冲突检测' },
  diagnostics:   { title: '告警与诊断',        sub: '设备告警中心 · 结构化运行日志与错误码处置' },
  users_mgr:     { title: '用户与角色分配',    sub: '系统超级管理员专属 · 子用户指派 · 空白工作区隔离' },
  backups_mgr:   { title: '容灾备份与交互',    sub: '系统级实时自动快照 · SHA-256完整性校验回滚 · 跨用户配置包交互' }
};

/* 全局运行态 */
var State = {
  layout: { groups: [], configured: false },
  scenes: [],
  sceneMap: {},
  presets: {},
  categories: [],
  attrGroups: [],
  profiles: [],
  venues: [],
  activeVenue: null,
  ports: [],              // 当前场地扁平接口列表
  activePortIdx: 0,
  dmx: new Array(512).fill(0),
  activePresetCat: '__all__',
  editingPreset: null,
  presetMode: 'form',
  editingProfileId: null,
  profileDraft: null,
  slotsTarget: null,
  venueDraft: null,
  pickerGroups: [],
  alarms: [],
  lastAlarmId: null,
  logSince: 0
};

/* ---------------------------------------------------------------- 工具函数 */
function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function q(s) { return document.querySelector(s); }
function qa(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }
function faIcon(name) {
  var n = String(name || 'fa-bolt').trim();
  return /^fa-(solid|regular|brands)\b/.test(n) ? n : ('fa-solid ' + n);
}
function clamp255(v) { v = parseInt(v, 10); return isNaN(v) ? 0 : Math.max(0, Math.min(255, v)); }
function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(function (v) { return clamp255(v).toString(16).padStart(2, '0'); }).join('');
}
function hexToRgb(hex) {
  var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '');
  return m ? { r: parseInt(m[1], 16), g: parseInt(m[2], 16), b: parseInt(m[3], 16) } : { r: 0, g: 0, b: 0 };
}
function can(perm) { return PERMS.indexOf(perm) !== -1; }
function tip(v, n) { v = String(v == null ? '' : v); return v.length > (n || 40) ? v.slice(0, n || 40) + '…' : v; }

/** 通道属性取值 → 色卡颜色（仅用于视觉提示，无 RGB 时给中性灰） */
function valuesToHex(cv) {
  cv = cv || {};
  if (cv.red == null && cv.green == null && cv.blue == null) return '';
  return rgbToHex(cv.red || 0, cv.green || 0, cv.blue || 0);
}

/** 分类图标渲染：none 纯文字 / builtin 内置图标 / upload 上传图标，均内联跟随字色 */
function catIconHTML(icon, colorHex) {
  icon = icon || {};
  if (!icon.mode || icon.mode === 'none') return '';
  if (icon.mode === 'builtin' && icon.builtin) {
    return '<i class="cat-icon ' + esc(faIcon(icon.builtin)) + '"></i> ';
  }
  if (icon.mode === 'upload' && icon.upload) {
    return '<span class="cat-icon" style="--icon:url(' + esc(icon.upload) + ');"></span> ';
  }
  return '';
}
function catByID(id) {
  for (var i = 0; i < State.categories.length; i++) {
    if (State.categories[i].id === id) return State.categories[i];
  }
  return null;
}
function catChipHTML(c, count, active) {
  var col = c.color || '#38bdf8';
  return '<div class="chip' + (active ? ' active' : '') + '" data-cat="' + esc(c.id) + '"' +
         (active ? ' style="border-color:' + esc(col) + '55;background:' + esc(col) + '1f;color:' + esc(col) + ';"' : '') + '>' +
         '<span class="chip-dot" style="background:' + esc(col) + ';"></span>' +
         catIconHTML(c.icon) + esc(c.name) +
         '<span class="chip-count">' + count + '</span></div>';
}

/* ---------------------------------------------------------------- 轻提示 */
function toast(type, title, msg, ms) {
  var icons = { ok: 'fa-circle-check', error: 'fa-circle-exclamation', warn: 'fa-triangle-exclamation', info: 'fa-circle-info' };
  var el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = '<i class="fa-solid ' + (icons[type] || icons.info) + ' ti"></i>' +
                 '<div class="toast-body"><div class="toast-title">' + esc(title) + '</div>' +
                 '<div class="toast-msg">' + esc(msg || '') + '</div></div>';
  $('toastStack').appendChild(el);
  setTimeout(function () {
    el.classList.add('out');
    setTimeout(function () { el.remove(); }, 220);
  }, ms || 3600);
}

/* ---------------------------------------------------------------- 确认框 */
var confirmResolver = null;
function askConfirm(title, msg, okText, danger) {
  $('confirmTitle').textContent = title;
  $('confirmMsg').innerHTML = msg;
  $('confirmIcon').className = danger === false ? 'fa-solid fa-circle-question' : 'fa-solid fa-triangle-exclamation';
  $('confirmIcon').style.color = danger === false ? 'var(--brand)' : 'var(--danger)';
  var ok = $('confirmOk');
  ok.textContent = okText || '确认执行';
  ok.className = 'btn ' + (danger === false ? 'btn-primary' : 'btn-danger');
  openModal('modalConfirm');
  return new Promise(function (resolve) { confirmResolver = resolve; });
}
function settleConfirm(v) {
  closeModal('modalConfirm');
  if (confirmResolver) { confirmResolver(v); confirmResolver = null; }
}

/* ---------------------------------------------------------------- 模态窗 */
function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }
document.addEventListener('click', function (e) {
  var t = e.target.closest('[data-close]');
  if (t) closeModal(t.getAttribute('data-close'));
  if (e.target.classList && e.target.classList.contains('modal')) e.target.classList.remove('open');
});
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Escape') return;
  var open = q('.modal.open');
  if (open) { if (open.id === 'modalConfirm') settleConfirm(false); else open.classList.remove('open'); }
});

/* ---------------------------------------------------------------- API */
async function api(path, body) {
  var headers = { 'Content-Type': 'application/json' };
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;
  var opts = { method: 'GET', headers: headers };
  if (body !== undefined && body !== null) { opts.method = 'POST'; opts.body = JSON.stringify(body); }

  var resp;
  try {
    resp = await fetch(path, opts);
  } catch (err) {
    toast('error', '网络不可达', '无法连接控制台服务端。');
    throw err;
  }
  if (resp.status === 401) { forceLogout('会话已过期，请重新登录。'); throw new Error('unauthorized'); }
  var data = await resp.json().catch(function () { return {}; });
  if (data && typeof data === 'object') {
    try {
      Object.defineProperty(data, '__status', {
        value: resp.status,
        writable: true,
        enumerable: false,
        configurable: true
      });
    } catch (e) {
      // 无法设置不可枚举属性时忽略
    }
  }
  return data;
}
function ok(res) { return res && (res.status === 'ok' || res.valid === true || res.__status === 200); }

/* ---------------------------------------------------------------- 会话与系统关机 */

/* 注销幂等闩锁与轮询定时器登记表。
   问题背景：页面同时存在多个轮询定时器（通道电平 500ms / 系统状态 2s / 告警 5s …）。
   用户点击注销后，这些在途请求陆续收到 401，而 401 处理逻辑又会再次调用 forceLogout，
   于是产生"一次点击 → 多次注销请求 + 大量未授权告警"的自我请求风暴。
   这里用闩锁保证注销只执行一次，并在注销的第一时间清掉全部定时器。 */
var LOGGING_OUT = false;
var POLL_TIMERS = [];
function poll(fn, ms) { POLL_TIMERS.push(setInterval(fn, ms)); }
function stopAllPolling() {
  for (var i = 0; i < POLL_TIMERS.length; i++) { clearInterval(POLL_TIMERS[i]); }
  POLL_TIMERS = [];
}

async function forceLogout(msg) {
  if (LOGGING_OUT) { return; }   // 并发 401 不再重复触发注销
  LOGGING_OUT = true;
  stopAllPolling();              // 先停轮询，杜绝注销过程中的自我请求
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + (TOKEN || '') }
    });
  } catch (e) {}
  try {
    document.cookie = 'ai_ma_token=; Max-Age=0; path=/;';
  } catch (e) {}
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem('ai_ma_session');
  if (msg) { try { sessionStorage.setItem('ai_ma_notice', msg); } catch (e) {} }
  location.replace('/login');
}

async function systemShutdown() {
  if (!await askConfirm(
    '控台总停关机',
    '<div style="line-height:1.7;"><b style="color:var(--danger);font-size:14px;"><i class="fa-solid fa-triangle-exclamation"></i> 警告：此操作类似 MA 控台拉下所有总推杆关机！</b><br>' +
    '系统将立即<b>切断全部 DMX 512 物理输出</b>，强制终止所有运行中的特效宏与序列，广播全通道静音帧并安全退出后端服务。<br>' +
    '确定执行控台关机吗？</div>',
    '拉下总推杆 · 安全关机',
    true
  )) return;

  toast('warn', '控台正在关机', '拉下所有推杆，DMX 512 广播已静音，正在终止系统服务…', 5000);
  try {
    await api('/api/system/shutdown', {});
  } catch (e) {}

  document.body.innerHTML =
    '<div style="position:fixed;inset:0;background:#030712;color:#f3f4f6;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:sans-serif;z-index:99999;user-select:none;">' +
      '<div style="width:76px;height:76px;border-radius:22px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);display:grid;place-items:center;color:#ef4444;font-size:34px;margin-bottom:22px;box-shadow:0 0 40px rgba(239,68,68,.28);">' +
        '<i class="fa-solid fa-power-off"></i>' +
      '</div>' +
      '<h2 style="font-size:24px;font-weight:700;margin:0 0 10px;letter-spacing:1px;">AI-MA 控台系统已安全关机</h2>' +
      '<p style="color:#9ca3af;font-size:14px;margin:0 0 26px;">所有总推杆已全部归零 · DMX 512 工业链路已静音 · 服务进程已正常终止</p>' +
      '<div style="font-family:monospace;font-size:12px;color:#6b7280;background:rgba(255,255,255,.04);padding:10px 18px;border-radius:8px;border:1px solid rgba(255,255,255,.08);">' +
        '如需重新开机，请在主机双击运行 [启动系统总控台.bat]' +
      '</div>' +
    '</div>';
}
function paintSession() {
  var isRoot = SESSION && (SESSION.username === 'root' || SESSION.role === 'superadmin' || SESSION.is_emergency_root);
  $('userName').textContent = isRoot ? '底层架构维护者 (root)' : (SESSION.display_name || SESSION.username);
  $('userSub').textContent = isRoot ? '⚡ 最高全局特权 · 底层应急模式' : ('@' + SESSION.username);
  $('userAvatar').textContent = isRoot ? '⚡' : (SESSION.display_name || SESSION.username).charAt(0).toUpperCase();
  var badge = $('userRole');
  badge.textContent = isRoot ? 'ROOT EMERGENCY' : SESSION.role;
  badge.className = 'role role-' + (isRoot ? 'superadmin' : SESSION.role);
}
var RO_ONLY = ['btnAiSend', 'btnStopSeq', 'btnPanic', 'btnNewScene', 'btnCaptureScene', 'btnAiScene', 'btnEditPanel'];
var KB_WRITE = ['btnNewProfile', 'btnImportMa', 'btnAiExtract', 'btnNewVenue', 'btnNewPreset',
                'btnManageCats', 'btnAiParse', 'btnScanNodes', 'btnAddNode',
                'btnSaveProfile', 'btnSaveVenue', 'btnSavePreset', 'btnDeletePreset',
                'btnSaveCats', 'btnAddCat', 'btnAddAg', 'btnAddCh', 'btnAddSlot',
                'btnSavePanel', 'btnAddGroup', 'btnUploadCommunityPlugin', 'btnUploadSysPatch', 'btnCheckSysUpdate'];
function applyPermissions() {
  var isManager = SESSION && (SESSION.role === 'superadmin' || SESSION.role === 'admin' || SESSION.username === 'admin' || SESSION.username === 'root');

  var nu = $('navUsers');
  if (nu) nu.style.display = isManager ? '' : 'none';

  var nb = $('navBackups');
  if (nb) nb.style.display = isManager ? '' : 'none';

  var ro = !can('operate_lights');
  RO_ONLY.forEach(function (id) { var el = $(id); if (el) el.style.display = ro ? 'none' : ''; });
  if (!can('edit_kb')) {
    KB_WRITE.forEach(function (id) { var el = $(id); if (el) el.style.display = 'none'; });
  }
  if (!can('panic_control')) { var p = $('btnPanic'); if (p) p.style.display = 'none'; }
  if (!can('manage_plugins')) {
    $('marketList').innerHTML = '<div class="empty"><i class="fa-solid fa-lock"></i><div class="t">权限不足</div><div class="d">插件管理需要管理员权限。</div></div>';
    $('installedTbody').innerHTML = '<tr><td colspan="5"><div class="empty"><i class="fa-solid fa-lock"></i><div class="t">需要 manage_plugins 权限</div></div></td></tr>';
  }
  if (!can('edit_kb')) {
    var b = $('btnEditPanel'); if (b) b.style.display = 'none';
  }
}

/* ---------------------------------------------------------------- 导航 */
function go(view) {
  if (!VIEWS[view]) return;
  qa('.nav-item').forEach(function (n) { n.classList.toggle('active', n.getAttribute('data-view') === view); });
  qa('.view').forEach(function (v) { v.classList.toggle('active', v.id === 'view-' + view); });
  $('crumbTitle').textContent = VIEWS[view].title;
  $('crumbSub').textContent = VIEWS[view].sub;
  try { localStorage.setItem('ai_ma_view', view); } catch (e) {}
  if (view === 'monitor') { refreshMonitor(); }
  if (view === 'diagnostics') { refreshLogs(); refreshAlarms(); }
  if (view === 'users_mgr') { loadUsersList(); }
  if (view === 'backups_mgr') { loadSnapshots(); loadHostUserPkgs(); }
}

/* ============================================================================
   1. 主控台自定义面板（从分类化预设 / 场景库手动挑选组装）
   ========================================================================== */
function collectPanelItems() {
  var items = [];
  State.scenes.forEach(function (s) {
    items.push({
      key: 'scene:' + s.id, kind: 'scene', id: s.id,
      name: s.name || s.id, color: s.color || '#6366f1',
      icon: s.icon || 'fa-bolt', sub: s.desc || s.design_intent || '确定性执行场景',
      cat: '__scene__'
    });
  });
  validPresetKeys().forEach(function (k) {
    var p = State.presets[k];
    var c = p.color || valuesToHex(p.channel_values) || '#38bdf8';
    items.push({
      key: 'preset:' + k, kind: 'preset', id: k,
      name: p.name || k, color: c,
      icon: p.icon || 'fa-palette',
      sub: p.summary || (p.tags || []).slice(0, 3).join('、') || '美学预设',
      cat: p.category_id || '__none__'
    });
  });
  return items;
}
function itemByKey(key) {
  var all = collectPanelItems();
  for (var i = 0; i < all.length; i++) if (all[i].key === key) return all[i];
  return null;
}

async function loadPanelLayout() {
  var res = await api('/api/panel/layout');
  State.layout = (res && res.groups) ? res : { groups: [], configured: false };
}

function renderScenePanel() {
  var box = $('scenePanel');
  var groups = State.layout.groups || [];

  /* 未组装过布局 → 给出引导而不是塞满全部内容 */
  if (!groups.length) {
    box.innerHTML =
      '<div class="empty"><i class="fa-solid fa-table-cells-large"></i>' +
      '<div class="t">面板尚未组装</div>' +
      '<div class="d">点击右上角「编辑面板」，从预设与场景库中按分类手动挑选条目，组成你自己的现场操作面板。' +
      '每个面板块可单独命名、设定列数并调整顺序。</div></div>';
    return;
  }

  var html = '';
  groups.forEach(function (g) {
    var items = (g.item_ids || []).map(itemByKey).filter(Boolean);
    var cols = Math.max(1, Math.min(8, parseInt(g.columns, 10) || 3));
    html += '<div class="pgroup">' +
      '<div class="pgroup-head"><i class="fa-solid fa-grip-lines" style="color:var(--txt-3);"></i>' +
      '<span class="t">' + esc(g.title || '面板块') + '</span>' +
      '<span class="n">' + items.length + ' 项</span></div>';
    if (!items.length) {
      html += '<div class="fs-12 dim" style="padding:8px 2px;">该面板块暂无条目，请在「编辑面板」中添加。</div>';
    } else {
      html += '<div class="pgroup-grid" style="grid-template-columns:repeat(' + cols + ',minmax(0,1fr));">';
      items.forEach(function (it) {
        html += '<button class="tile" data-key="' + esc(it.key) + '" style="--tile-accent:' + esc(it.color) + ';">' +
          '<span class="tile-ico" style="background:' + esc(it.color) + ';box-shadow:0 0 14px ' + esc(it.color) + '88;color:#04121f;"><i class="' + esc(faIcon(it.icon)) + '"></i></span>' +
          '<span class="tile-txt"><span class="tile-name">' + esc(it.name) + '</span>' +
          '<span class="tile-sub">' + esc(tip(it.sub, 26)) + '</span></span>' +
          '<span class="tile-kind ' + it.kind + '">' + (it.kind === 'scene' ? '场景' : '预设') + '</span>' +
          '</button>';
      });
      html += '</div>';
    }
    html += '</div>';
  });
  box.innerHTML = html;

  qa('#scenePanel .tile').forEach(function (b) {
    b.addEventListener('click', function () { firePanelItem(b.getAttribute('data-key'), b); });
  });
}

async function firePanelItem(key, btn) {
  var it = itemByKey(key);
  if (!it) { toast('error', '条目已失效', '该条目可能已被删除。'); return; }
  if (!can('operate_lights')) { toast('warn', '权限不足', '观察员账号无控灯权限。'); return; }
  btn.style.transform = 'scale(.97)';
  setTimeout(function () { btn.style.transform = ''; }, 120);
  try {
    if (it.kind === 'scene') {
      var r = await api('/api/scenes/trigger_direct', { id: it.id });
      toast(ok(r) ? 'ok' : 'error', ok(r) ? '场景已下发' : '下发失败', ok(r) ? (r.scene_name || it.name) : (r.message || ''));
    } else {
      var r2 = await api('/api/presets/apply', { preset_id: it.id });
      if (ok(r2)) {
        toast('ok', '预设已下发', (r2.preset_name || it.name) + ' → ' + r2.applied_fixtures + ' 台灯具');
      } else {
        toast('error', '下发失败', r2.message || '未知错误');
      }
    }
  } catch (e) { /* api 已提示 */ }
}

/* ------------------------------ 面板编辑器 ------------------------------ */
function openPanelEditor() {
  State.pickerGroups = JSON.parse(JSON.stringify(State.layout.groups || []));
  if (!State.pickerGroups.length) {
    State.pickerGroups = [{ group_id: 'g1', title: '常用场景', columns: 3, order: 0, item_ids: [] }];
  }
  renderPickerCatalog();
  renderPickerGroups();
  openModal('modalPanelEdit');
}

function renderPickerCatalog() {
  var box = $('pickerCatalog');
  var items = collectPanelItems();
  $('pickerCount').textContent = items.length + ' 项';
  if (!items.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-inbox"></i><div class="t">库中暂无条目</div></div>';
    return;
  }
  var chosen = {};
  State.pickerGroups.forEach(function (g) { (g.item_ids || []).forEach(function (k) { chosen[k] = 1; }); });

  var html = '';
  /* 场景区 */
  var scenes = items.filter(function (i) { return i.kind === 'scene'; });
  if (scenes.length) {
    html += '<div class="eyebrow" style="padding:6px 8px 4px;">快捷场景库</div>';
    scenes.forEach(function (it) { html += pickerItemHTML(it, chosen[it.key]); });
  }
  /* 预设区：按自定义分类分组 */
  State.categories.forEach(function (c) {
    var list = items.filter(function (i) { return i.kind === 'preset' && i.cat === c.id; });
    if (!list.length) return;
    html += '<div class="eyebrow" style="padding:10px 8px 4px;color:' + esc(c.color || '#38bdf8') + ';">' +
            catIconHTML(c.icon) + esc(c.name) + '</div>';
    list.forEach(function (it) { html += pickerItemHTML(it, chosen[it.key]); });
  });
  var orphan = items.filter(function (i) {
    return i.kind === 'preset' && !catByID(i.cat);
  });
  if (orphan.length) {
    html += '<div class="eyebrow" style="padding:10px 8px 4px;color:var(--warn);">未归类 / 待归类</div>';
    orphan.forEach(function (it) { html += pickerItemHTML(it, chosen[it.key]); });
  }
  box.innerHTML = html;

  qa('#pickerCatalog .picker-item').forEach(function (el) {
    el.addEventListener('click', function () { addToPicker(el.getAttribute('data-key')); });
  });
}
function pickerItemHTML(it, on) {
  return '<div class="picker-item' + (on ? ' on' : '') + '" data-key="' + esc(it.key) + '">' +
    '<span class="sw" style="background:' + esc(it.color) + ';"></span>' +
    '<span class="nm">' + esc(it.name) + '</span>' +
    '<span class="fs-11 dim">' + (it.kind === 'scene' ? '场景' : '预设') + '</span>' +
    '<i class="fa-solid ' + (on ? 'fa-check' : 'fa-plus') + '" style="color:' + (on ? 'var(--ok)' : 'var(--txt-3)') + ';"></i>' +
    '</div>';
}

function renderPickerGroups() {
  var box = $('pickerGroups');
  if (!State.pickerGroups.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-plus"></i><div class="t">还没有面板块</div>' +
                    '<div class="d">点击上方「添加面板块」，再从左侧挑选条目。</div></div>';
    return;
  }
  var html = '';
  State.pickerGroups.forEach(function (g, gi) {
    var items = (g.item_ids || []).map(itemByKey).filter(Boolean);
    html += '<div class="pgroupcard col" data-gi="' + gi + '">' +
      '<div class="row" style="gap:8px;">' +
        '<i class="fa-solid fa-grip-vertical drag"></i>' +
        '<input type="text" class="nm" value="' + esc(g.title || '') + '" data-gi="' + gi + '" data-f="title" style="height:26px;font-size:12px;">' +
        '<select data-gi="' + gi + '" data-f="columns" style="width:66px;height:26px;font-size:11px;">';
    [1, 2, 3, 4, 5, 6, 7, 8].forEach(function (n) {
      html += '<option value="' + n + '"' + ((parseInt(g.columns, 10) || 3) === n ? ' selected' : '') + '>' + n + ' 列</option>';
    });
    html += '</select>' +
        '<button class="btn btn-xs btn-ghost" data-gi="' + gi + '" data-act="up" title="上移"><i class="fa-solid fa-arrow-up"></i></button>' +
        '<button class="btn btn-xs btn-ghost" data-gi="' + gi + '" data-act="down" title="下移"><i class="fa-solid fa-arrow-down"></i></button>' +
        '<button class="btn btn-xs btn-danger-ghost" data-gi="' + gi + '" data-act="del" title="删除面板块"><i class="fa-solid fa-trash"></i></button>' +
      '</div>';
    if (!items.length) {
      html += '<div class="dropzone" data-gi="' + gi + '"><i class="fa-solid fa-hand-pointer"></i> 从左侧点击条目加入此面板块</div>';
    } else {
      html += '<div class="col" style="gap:4px;">';
      items.forEach(function (it) {
        html += '<div class="picker-item on" style="min-height:30px;">' +
          '<span class="sw" style="background:' + esc(it.color) + ';"></span>' +
          '<span class="nm">' + esc(it.name) + '</span>' +
          '<button class="btn btn-xs btn-ghost" data-gi="' + gi + '" data-act="rm" data-key="' + esc(it.key) + '">' +
          '<i class="fa-solid fa-xmark"></i></button></div>';
      });
      html += '</div>';
    }
    html += '</div>';
  });
  box.innerHTML = html;

  qa('#pickerGroups input[data-f="title"]').forEach(function (el) {
    el.addEventListener('input', function () { State.pickerGroups[+el.getAttribute('data-gi')].title = el.value; });
  });
  qa('#pickerGroups select[data-f="columns"]').forEach(function (el) {
    el.addEventListener('change', function () { State.pickerGroups[+el.getAttribute('data-gi')].columns = +el.value; });
  });
  qa('#pickerGroups .dropzone').forEach(function (el) {
    el.addEventListener('click', function () { el.classList.add('over'); setTimeout(function () { el.classList.remove('over'); }, 260); });
  });
  qa('#pickerGroups button[data-act]').forEach(function (btn) {
    btn.addEventListener('click', function () { pickerAction(btn.getAttribute('data-act'), +btn.getAttribute('data-gi'), btn.getAttribute('data-key')); });
  });
}
function pickerAction(act, gi, key) {
  var g = State.pickerGroups[gi];
  if (!g) return;
  if (act === 'del') {
    State.pickerGroups.splice(gi, 1);
  } else if (act === 'up' && gi > 0) {
    State.pickerGroups.splice(gi - 1, 0, State.pickerGroups.splice(gi, 1)[0]);
  } else if (act === 'down' && gi < State.pickerGroups.length - 1) {
    State.pickerGroups.splice(gi + 1, 0, State.pickerGroups.splice(gi, 1)[0]);
  } else if (act === 'rm') {
    g.item_ids = (g.item_ids || []).filter(function (k) { return k !== key; });
  }
  renderPickerCatalog();
  renderPickerGroups();
}
function addToPicker(key) {
  if (!State.pickerGroups.length) {
    State.pickerGroups.push({ group_id: 'g1', title: '面板块 1', columns: 3, order: 0, item_ids: [] });
  }
  var g = State.pickerGroups[State.pickerGroups.length - 1];
  if ((g.item_ids || []).indexOf(key) !== -1) { toast('info', '已在面板中', '该条目已存在于最后一个面板块。'); return; }
  g.item_ids = (g.item_ids || []).concat([key]);
  renderPickerCatalog();
  renderPickerGroups();
}
async function savePanel() {
  var payload = {
    groups: State.pickerGroups.map(function (g, i) {
      return { group_id: g.group_id || ('g' + (i + 1)), title: g.title || ('面板块 ' + (i + 1)),
               columns: g.columns || 3, order: i, item_ids: g.item_ids || [] };
    })
  };
  var res = await api('/api/panel/save_layout', payload);
  if (ok(res)) {
    State.layout = res.layout;
    renderScenePanel();
    closeModal('modalPanelEdit');
    toast('ok', '面板布局已保存', payload.groups.length + ' 个面板块已生效');
  } else {
    toast('error', '保存失败', res.message || '');
  }
}

/* ============================================================================
   2. 端口选择与通道电平
   ========================================================================== */
function buildPorts() {
  var v = State.activeVenue;
  State.ports = [];
  if (!v) return;
  (v.nodes || []).forEach(function (n) {
    (n.ports || []).forEach(function (p) {
      State.ports.push({
        nodeId: n.node_id, nodeName: n.name, ip: n.ip,
        portId: p.port_id, label: p.label || 'A', labelStyle: p.label_style || 'alpha',
        universe: p.universe, direction: p.direction || 'out',
        fixtures: p.fixtures || []
      });
    });
  });
  if (State.activePortIdx >= State.ports.length) State.activePortIdx = 0;
}
function portDisplayName(p) {
  return p.label + '口 · Universe ' + p.universe;
}
function buildPortSelect() {
  var sel = $('ctrlPortSelect');
  if (!State.ports.length) {
    sel.innerHTML = '<option value="">当前场地未定义任何接口</option>';
    return;
  }
  var byNode = {};
  State.ports.forEach(function (p, i) {
    var k = p.nodeId + '|' + p.nodeName;
    (byNode[k] = byNode[k] || []).push({ p: p, i: i });
  });
  var html = '';
  Object.keys(byNode).forEach(function (k) {
    html += '<optgroup label="' + esc(k.split('|')[1] + '（' + byNode[k][0].p.ip + '）') + '">';
    byNode[k].forEach(function (o) {
      html += '<option value="' + o.i + '"' + (o.i === State.activePortIdx ? ' selected' : '') + '>' +
              esc(portDisplayName(o.p)) + '　—　' + o.p.fixtures.length + ' 台灯具</option>';
    });
    html += '</optgroup>';
  });
  sel.innerHTML = html;
}
function renderPortInfo() {
  var p = State.ports[State.activePortIdx];
  if (!p) {
    $('ctrlPortMeta').textContent = '—';
    $('ctrlFixtureList').innerHTML = '<div class="fs-12 dim">尚无接口。</div>';
    return;
  }
  $('ctrlPortMeta').innerHTML = '<i class="fa-solid fa-server"></i> ' + esc(p.nodeName) +
    ' <span class="dim" style="font-weight:400;">' + esc(p.ip) + '</span>' +
    ' <span class="mono">· ' + esc(portDisplayName(p)) + ' · ' + esc(p.direction) + '</span>';

  var box = $('ctrlFixtureList');
  if (!p.fixtures.length) {
    box.innerHTML = '<div class="fs-12 dim">该接口下暂无灯具。</div>';
    return;
  }
  var html = '';
  p.fixtures.forEach(function (f) {
    var prof = State.profiles.filter(function (x) { return x.profile_id === f.profile_id; })[0];
    var n = prof ? prof.channel_count : 0;
    var end = n ? (f.address + n - 1) : f.address;
    html += '<div class="row between" style="padding:6px 10px;border:1px solid var(--line);border-radius:var(--r-sm);background:rgba(255,255,255,.02);">' +
      '<span class="fs-12">' + esc(f.name) + (f.allow_shared_address ? ' <span class="badge badge-warn" style="font-size:10px;">共址</span>' : '') + '</span>' +
      '<span class="mono fs-11 dim">CH' + f.address + '–CH' + end + '</span></div>';
  });
  box.innerHTML = html;
}
function renderDmxGrid() {
  var grid = $('dmxGrid');
  if (!grid.children.length) {
    var h = '';
    for (var i = 0; i < 64; i++) h += '<div class="dmx-cell" data-i="' + i + '"><span class="n">' + (i + 1) + '</span><span class="v">0</span></div>';
    grid.innerHTML = h;
  }
  var peak = 0, cells = grid.children;
  for (var j = 0; j < 64; j++) {
    var v = State.dmx[j] || 0;
    if (v > peak) peak = v;
    var c = cells[j];
    c.style.setProperty('--lvl', (v / 255).toFixed(3));
    c.classList.toggle('hot', v > 200);
    c.querySelector('.v').textContent = v;
  }
  $('dmxPeak').textContent = '峰值 ' + peak;
}
async function refreshPortDmx() {
  var p = State.ports[State.activePortIdx];
  var u = p ? p.universe : 0;
  var res = await api('/api/dmx/universe/' + u);
  State.dmx = (res && res.channels) ? res.channels : (Array.isArray(res) ? res : new Array(512).fill(0));
  renderDmxGrid();
}

/* ============================================================================
   3. 快捷场景管理
   ========================================================================== */
async function loadScenes() {
  var list = await api('/api/scenes/list');
  State.scenes = Array.isArray(list) ? list : [];
  State.sceneMap = {};
  State.scenes.forEach(function (s) { State.sceneMap[s.id] = s; });
}
async function loadStudioTable() {
  var tb = $('studioTbody');
  if (!State.scenes.length) {
    tb.innerHTML = '<tr><td colspan="7"><div class="empty"><i class="fa-solid fa-layer-group"></i><div class="t">场景库为空</div><div class="d">点击「新建 / 粘贴 JSON」录入第一个确定性执行场景。</div></div></td></tr>';
    return;
  }
  var html = '';
  State.scenes.forEach(function (s) {
    var p = s.payload || {};
    var chans = 0;
    (p.fixtures || []).forEach(function (f) { chans += Object.keys(f.channels || {}).length; });
    html += '<tr>' +
      '<td><span class="row" style="gap:8px;"><i class="' + esc(faIcon(s.icon || 'fa-bolt')) + '" style="color:' + esc(s.color || '#6366f1') + ';width:14px;"></i>' +
        '<b>' + esc(s.name || s.id) + '</b></span></td>' +
      '<td><code class="mono fs-12">' + esc(s.id) + '</code></td>' +
      '<td><span class="badge ' + (p.mode === 'sequence' ? 'badge-warn' : 'badge-brand') + '">' + (p.mode === 'sequence' ? '多步时序' : '单一 Cue') + '</span></td>' +
      '<td class="mono fs-12">' + (p.transition_ms || 1000) + 'ms</td>' +
      '<td class="fs-12 muted">' + esc(tip(s.desc || s.design_intent || '—', 34)) + '</td>' +
      '<td class="mono fs-12">' + chans + '</td>' +
      '<td class="col-act"><div class="btn-group">' +
        '<button class="btn btn-xs btn-primary" data-act="fire" data-id="' + esc(s.id) + '"><i class="fa-solid fa-bolt"></i> 触发</button>' +
        '<button class="btn btn-xs" data-act="edit" data-id="' + esc(s.id) + '"><i class="fa-solid fa-pen"></i></button>' +
        '<button class="btn btn-xs btn-danger-ghost" data-act="del" data-id="' + esc(s.id) + '"><i class="fa-solid fa-trash"></i></button>' +
      '</div></td></tr>';
  });
  tb.innerHTML = html;
  qa('#studioTbody button[data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      var act = b.getAttribute('data-act'), id = b.getAttribute('data-id');
      if (act === 'fire') fireStudioScene(id);
      else if (act === 'edit') openSceneEditor(id);
      else deleteScene(id);
    });
  });
}
async function fireStudioScene(id) {
  if (!can('operate_lights')) { toast('warn', '权限不足', '观察员账号无控灯权限。'); return; }
  var r = await api('/api/scenes/trigger_direct', { id: id });
  toast(ok(r) ? 'ok' : 'error', ok(r) ? '场景已下发' : '下发失败', ok(r) ? (r.scene_name || '') : (r.message || ''));
}
function openSceneEditor(id) {
  var s = id ? State.sceneMap[id] : null;
  $('sceneTitle').textContent = s ? ('编辑场景 · ' + (s.name || s.id)) : '新建快捷场景';
  $('scName').value = s ? (s.name || '') : '';
  $('scColor').value = s ? (s.color || '#0ea5e9') : '#0ea5e9';
  $('scIcon').value = s ? (s.icon || 'fa-solid fa-sun') : 'fa-solid fa-sun';
  $('scDesc').value = s ? (s.desc || s.design_intent || '') : '';
  $('scPayload').value = s ? JSON.stringify(s.payload || {}, null, 2) : JSON.stringify({
    mode: 'single', transition_ms: 1500,
    fixtures: [{ id: 'fix_01', channels: { dimmer: 255, red: 255, green: 105, blue: 180, white: 20 } }]
  }, null, 2);
  openModal('modalScene');
}
async function saveScene() {
  var id = ($('scName').value || '').trim();
  if (!id) { toast('warn', '缺少名称', '请填写按钮名称。'); return; }
  var payload;
  try { payload = JSON.parse($('scPayload').value); }
  catch (e) { toast('error', 'JSON 语法错误', String(e.message)); return; }
  var sid = id.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '_');
  var res = await api('/api/scenes/save', {
    id: sid, name: id, color: $('scColor').value,
    icon: $('scIcon').value, desc: $('scDesc').value, payload: payload
  });
  if (ok(res)) {
    closeModal('modalScene');
    await loadScenes(); await loadStudioTable(); renderScenePanel();
    toast('ok', '场景已保存', id + ' 已可零延迟触发');
  } else { toast('error', '保存失败', res.message || ''); }
}
async function deleteScene(id) {
  var s = State.sceneMap[id];
  if (!await askConfirm('删除快捷场景', '确定删除 <b>' + esc(s ? s.name : id) + '</b> ？该操作不可撤销。', '删除', true)) return;
  var res = await api('/api/scenes/delete', { id: id });
  if (ok(res)) { await loadScenes(); await loadStudioTable(); renderScenePanel(); toast('ok', '已删除', ''); }
}
function newScene() { openSceneEditor(null); }
async function captureScene() {
  toast('info', '正在抓取', '正在读取现场真实输出通道电平…');
  var res = await api('/api/scenes/capture_current');
  if (ok(res) && res.payload) {
    openSceneEditor(null);
    var nowTime = new Date().toLocaleTimeString();
    $('scName').value = '现场捕获 ' + nowTime;
    $('scColor').value = '#10b981';
    $('scIcon').value = 'fa-solid fa-camera';
    $('scDesc').value = '从当前现场实际输出电平捕获的场景 (共 ' + (res.captured_fixtures || 0) + ' 台灯具)';
    $('scPayload').value = JSON.stringify(res.payload, null, 2);
    toast('ok', '现场画面已捕获', '已将 ' + (res.captured_fixtures || 0) + ' 台灯具的当前物理通道组装为场景载荷，请核对后保存。');
  } else {
    toast('error', '捕获失败', res.message || '未能读取当前通道输出');
  }
}
async function aiComposeScene() {
  var idea = ($('sceneIdea').value || '').trim();
  if (!idea) { toast('warn', '请先描述构想', ''); return; }
  toast('info', '端侧模型编译中', '正在生成确定性 payload…', 6000);
  var res = await api('/api/scenes/ai_assist', { idea: idea });
  if (ok(res) && res.scene) {
    closeModal('modalSceneAi');
    var s = res.scene;
    openSceneEditor(null);
    $('scName').value = s.name || '';
    $('scColor').value = s.color || '#0ea5e9';
    $('scIcon').value = s.icon || 'fa-solid fa-sun';
    $('scDesc').value = s.desc || s.design_intent || '';
    $('scPayload').value = JSON.stringify(s.payload || {}, null, 2);
    toast('ok', '编译完成', '请核对后写入场景库。');
  } else { toast('error', '编译失败', res.message || ''); }
}
async function sendAiCommand() {
  var cmd = ($('ai-cmd-input').value || '').trim();
  if (!cmd) { toast('warn', '请输入指令', ''); return; }
  var res = await api('/api/lighting/execute', { command: cmd });
  if (ok(res)) toast('ok', '推理完成并已下发', res.message || '');
  else toast('error', '推理失败', res.message || '');
}
async function panic() {
  if (!await askConfirm('熔断全黑 PANIC', '将以 <b>最高优先级</b> 立即切断全部输出并压制其他控制源。<br>确定执行？', '立即熔断', true)) return;
  var res = await api('/api/lighting/panic', {});
  toast(ok(res) ? 'ok' : 'error', ok(res) ? '已熔断全黑' : '熔断失败', res.message || '');
}
async function stopSequence() {
  var res = await api('/api/lighting/stop_sequence', {});
  toast(ok(res) ? 'ok' : 'error', '停止时序', res.message || '已请求终止当前序列与宏。');
}

/* ============================================================================
   4. 设备节点与监视
   ========================================================================== */
function nodeStatusOf(nodeId) {
  var wd = State.watchdog || {};
  return wd[nodeId] || null;
}
async function refreshMonitor() {
  var stats = await api('/api/monitor/stats');
  $('monFps').textContent = (stats.current_fps || 0).toFixed(1);
  $('monTotal').textContent = stats.total_frames || 0;

  var venues = await api('/api/kb/venues');
  State.venues = Array.isArray(venues) ? venues : [];
  State.activeVenue = State.venues.filter(function (v) { return v.is_active; })[0] || State.venues[0] || null;
  buildPorts();

  var disc = await api('/api/nodes/discovered');
  State.watchdog = (disc && disc.watchdog) || {};
  State.discovered = (disc && disc.discovered) || [];
  renderDiscovery();

  var v = State.activeVenue;
  $('monNodes').textContent = v ? (v.nodes || []).length : 0;
  $('monPorts').textContent = v ? v.port_count : 0;
  $('monFixtures').textContent = v ? v.fixture_count : 0;
  renderMonitorTree(v);
  refreshPackets();
}
function renderMonitorTree(v) {
  var box = $('nodeTree');
  if (!v || !(v.nodes || []).length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-sitemap"></i><div class="t">当前场地未定义解码器节点</div>' +
      '<div class="d">前往「RAG 知识库管理 → 场地与节点拓扑」编辑场地，或在「插件市场」之外先确认场地文件已加载。</div></div>';
    return;
  }
  var html = '';
  (v.nodes || []).forEach(function (n, ni) {
    var st = nodeStatusOf(n.node_id);
    /* st.state 由后端判定：online / offline / unknown（未监测）。
       unknown 是关键的三态之一——"从未收到过该判据的心跳"不等于"设备掉线"，
       混为一谈会让运维人员对告警脱敏。 */
    var state = st ? (st.state || (st.online === false ? 'offline' : (st.online ? 'online' : 'unknown'))) : 'unknown';
    var dotCls = state === 'online' ? 'dot-live' : (state === 'offline' ? 'dot-dead' : 'dot-idle');
    var stTxt = state === 'online' ? '在线'
              : (state === 'offline' ? ('掉线 ' + Math.round(st.offline_sec || 0) + 's') : '未监测');
    var online = st ? st.online : null;
    var polMode = (n.offline_policy || {}).mode || 'threshold';
    var manualBtn = '';
    if (polMode === 'manual' && st) {
      manualBtn = (state === 'offline')
        ? '<button class="btn btn-xs btn-success" data-manual="' + esc(n.node_id) + '" data-off="0"><i class="fa-solid fa-check"></i> 标记恢复</button>'
        : '<button class="btn btn-xs btn-danger-ghost" data-manual="' + esc(n.node_id) + '" data-off="1"><i class="fa-solid fa-power-off"></i> 标记掉线</button>';
    }
    html += '<div class="tnode open has-children">' +
      '<div class="trow lv1 tgl"><i class="fa-solid fa-chevron-right tcaret"></i>' +
      '<span class="dot ' + dotCls + '"></span>' +
      '<b>' + esc(n.name) + '</b>' +
      '<span class="mono fs-11 dim">' + esc(n.ip) + '</span>' +
      '<span class="badge ' + (state === 'offline' ? 'badge-danger' : (state === 'online' ? 'badge-ok' : 'badge-mute')) + '">' + stTxt + '</span>' +
      '<span class="badge badge-mute">' + esc(n.source === 'discovered' ? '自动发现' : '手动录入') + '</span>' +
      '<span class="badge ' + (polMode === 'ignore' ? 'badge-mute' : (polMode === 'manual' ? 'badge-warn' : 'badge-brand')) + '">' +
        esc({ threshold: '阈值触发', ignore: '忽略', manual: '手动' }[polMode] || polMode) + '</span>' +
      '<span class="fs-11 dim">' + (polMode === 'threshold'
        ? ('阈值 ' + ((n.offline_policy || {}).threshold_sec || 5) + 's · ' +
           esc({ artpoll: '探测应答', ping: '网络可达', artdmx: '被动数据帧' }[(n.offline_policy || {}).liveness_source] || '探测应答'))
        : '—') + '</span>' +
      '<span style="flex:1;"></span>' + manualBtn +
      '</div><div class="tchildren">';
    (n.ports || []).forEach(function (p) {
      var used = 0;
      (p.fixtures || []).forEach(function (f) {
        var pr = State.profiles.filter(function (x) { return x.profile_id === f.profile_id; })[0];
        used += pr ? pr.channel_count : 0;
      });
      html += '<div class="trow lv2">' +
        '<i class="fa-solid fa-ethernet" style="color:var(--brand);"></i>' +
        '<b>' + esc(p.label) + '口</b>' +
        '<span class="mono fs-11 dim">Universe ' + p.universe + '</span>' +
        '<span class="badge badge-mute">' + (p.fixtures || []).length + ' 台灯具</span>' +
        '<span class="levelbar">';
      var lit = Math.round(used / 512 * 20);
      for (var i = 0; i < 20; i++) html += '<span class="' + (i < lit ? 'on' : '') + '"></span>';
      html += '</span><span class="fs-11 dim">' + used + '/512 通道</span>' +
        '<span class="spacer" style="flex:1;"></span></div>';
      (p.fixtures || []).forEach(function (f) {
        html += '<div class="trow lv3">' +
          '<i class="fa-solid fa-lightbulb" style="color:var(--warn);"></i>' +
          '<span>' + esc(f.name) + '</span>' +
          (f.allow_shared_address ? '<span class="badge badge-warn">允许共址</span>' : '') +
          '<span class="mono fs-11 dim">CH' + f.address + '</span>' +
          '<span class="badge badge-mute">' + esc(f.profile_id) + '</span>' +
          '</div>';
      });
    });
    html += '</div></div>';
  });
  box.innerHTML = html;
  qa('#nodeTree .tgl').forEach(function (r) {
    r.addEventListener('click', function (e) {
      if (e.target.closest('button')) return;
      r.parentNode.classList.toggle('open');
    });
  });
  qa('#nodeTree button[data-manual]').forEach(function (b) {
    b.addEventListener('click', async function (e) {
      e.stopPropagation();
      var r = await api('/api/nodes/set_manual_state', {
        node_id: b.getAttribute('data-manual'),
        offline: b.getAttribute('data-off') === '1'
      });
      if (ok(r)) {
        toast('ok', '已人工标记', '节点 ' + r.node_id + ' 标记为' + (r.manual_offline ? '掉线' : '在线'));
        setTimeout(refreshMonitor, 1600);
        setTimeout(refreshAlarms, 1600);
      } else {
        toast('error', '标记失败', r.message || '');
      }
    });
  });
}
function renderDiscovery() {
  var box = $('discList');
  var list = State.discovered || [];
  $('discCount').textContent = list.length + ' 个';
  if (!list.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-satellite-dish"></i><div class="t">暂无被动发现记录</div>' +
      '<div class="d">系统默认以被动方式登记；需要整网段发现时可点击「主动扫描发现」。</div></div>';
    return;
  }
  var html = '';
  list.forEach(function (d) {
    var st = State.watchdog[d.ip];
    var dot = st && st.online === false ? 'dot-dead' : (d.stale ? 'dot-idle' : 'dot-live');
    html += '<div class="row between" style="padding:9px 12px;border:1px solid var(--line);border-radius:var(--r-sm);margin-bottom:6px;background:rgba(255,255,255,.02);">' +
      '<div class="col" style="gap:2px;">' +
        '<span class="fs-12"><span class="dot ' + dot + '"></span> <b class="mono">' + esc(d.ip) + '</b></span>' +
        '<span class="fs-11 dim">Universe ' + esc((d.universes || []).join(' / ') || '—') + ' · ' + (d.stale ? '已静默' : '活跃中') + '</span>' +
      '</div>' +
      '<button class="btn btn-xs" data-add="' + esc(d.ip) + '"><i class="fa-solid fa-plus"></i> 纳管</button>' +
      '</div>';
  });
  box.innerHTML = html;
  qa('#discList button[data-add]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var ip = b.getAttribute('data-add');
      var r = await api('/api/nodes/test_connection', { ip: ip });
      renderNodeTest(r, $('discList'));
      toast(r.state === 'online' ? 'ok' : 'info', '连接测试 · ' + ip, r.hint || '');
    });
  });
}
async function refreshPackets() {
  var box = $('pktList');
  var stats = await api('/api/monitor/stats');
  var pkts = stats.recent_packets || [];
  if (!pkts.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-inbox"></i><div class="t">暂无 Art-Net 报文</div>' +
      '<div class="d">确认解码器或控制台已在 UDP 6454 上发送数据。</div></div>';
    return;
  }
  var html = '';
  pkts.slice(0, 40).forEach(function (p) {
    var chans = (p.active_channels || []).slice(0, 6).join(' ');
    html += '<div class="pkt">' +
      '<span class="pkt-time">' + esc(p.time || '') + '</span>' +
      '<span class="mono brand-t">U' + esc(p.universe) + '</span>' +
      '<span class="mono dim">' + esc(p.from_ip || '') + '</span>' +
      '<span class="mono fs-11">seq ' + esc(p.seq) + '</span>' +
      '<span class="pkt-ch mono fs-11" style="flex:1;text-align:left;overflow:hidden;text-overflow:ellipsis;">' +
        esc(chans || '全零帧') + '</span>' +
      '<span class="badge badge-mute">' + (p.active_count || 0) + ' 活跃</span>' +
      '</div>';
  });
  box.innerHTML = html;
}
async function scanNodes() {
  /* 优先使用当前场地已有节点的 /24 网段；没有已知节点时退回整网段广播发现 */
  var ips = [];
  ((State.activeVenue || {}).nodes || []).forEach(function (n) { if (n.ip) ips.push(n.ip); });
  ips = ips.filter(function (ip) { return /^\d+\.\d+\.\d+\.\d+$/.test(ip) && ip !== '127.0.0.1'; });

  var body, label;
  if (ips.length) {
    var p = ips[0].split('.');
    var cidr = p[0] + '.' + p[1] + '.' + p[2] + '.0/24';
    body = { subnet: cidr };
    label = cidr;
  } else {
    body = { broadcast: true };
    label = '受限广播地址（整网段自动发现）';
  }

  toast('info', '正在扫描', '通过 ArtPoll 探测 ' + label + ' …', 9000);
  var res = await api('/api/nodes/scan', body);
  if (ok(res)) {
    toast(res.responded ? 'ok' : 'warn', '扫描完成',
          '探测 ' + res.scanned + ' 个地址，应答 ' + res.responded + ' 个节点');
    openNodeResultModal(res, label);
  } else {
    toast('error', '扫描失败', res.message || '');
  }
}
function openNodeResultModal(res, label) {
  var html = '<div class="eyebrow mb-2">ArtPoll 探测结果 · ' + esc(label || '') + '</div>';
  if (!(res.results || []).length) {
    html += '<div class="empty"><i class="fa-solid fa-inbox"></i><div class="t">无应答</div>' +
            '<div class="d">请确认本机与解码器处于同一网段，且防火墙未拦截 UDP 6454。' +
            '也可能是解码器不支持 ArtPoll —— 这类设备请改为手动录入节点，再用「测试连接」核对。</div></div>';
  } else {
    (res.results || []).forEach(function (r) {
      html += '<div class="row between" style="padding:8px 12px;border:1px solid var(--line);border-radius:var(--r-sm);margin-bottom:6px;">' +
        '<div class="col" style="gap:2px;">' +
          '<span class="fs-12"><span class="dot ' + (r.reply ? 'dot-live' : 'dot-dead') + '"></span> <b class="mono">' + esc(r.ip) + '</b></span>' +
          '<span class="fs-11 dim">' + esc(r.node_name || r.error || '无应答') + '</span>' +
        '</div>' +
        (r.reply ? '<span class="badge badge-brand mono">' + (r.num_ports || 0) + ' 口 · ' +
                    esc((r.port_universes || []).join('/')) + ' · ' + (r.rtt_ms || 0) + 'ms</span>' : '') +
        '</div>';
    });
  }
  $('discList').innerHTML = html;
}
async function syncWatchdog() {
  var res = await api('/api/nodes/sync_watchdog', {});
  if (ok(res)) toast('ok', '已同步掉线监测', '接管 ' + res.registered + ' 个解码器节点');
  else toast('error', '同步失败', res.message || '');
}
function renderNodeTest(r, target) {
  var map = {
    online:       { cls: 'alert-ok',   ic: 'fa-circle-check',        t: '节点在线（收到 ArtPollReply）' },
    traffic_only: { cls: 'alert-warn', ic: 'fa-triangle-exclamation', t: '仅检测到流量（该设备不响应 ArtPoll）' },
    no_response:  { cls: 'alert-danger', ic: 'fa-circle-xmark',      t: '无任何响应' }
  };
  var m = map[r.state] || map.no_response;
  var extra = '';
  if (r.reply) {
    extra = '<div class="fs-12 mono" style="margin-top:6px;">名称 ' + esc(r.node_name || '—') +
      '<br>短名 ' + esc(r.short_name || '—') +
      '<br>端口 ' + (r.num_ports || 0) + ' 个 · Universe ' + esc((r.port_universes || []).join(' / ') || '—') +
      '<br>MAC ' + esc(r.mac || '—') + ' · 往返 ' + (r.rtt_ms || 0) + 'ms</div>';
  }
  var html = '<div class="alert ' + m.cls + '"><i class="fa-solid ' + m.ic + '"></i><div>' +
             '<b>' + m.t + '</b><br>' + esc(r.hint || '') + extra + '</div></div>';
  if (target) { target.insertAdjacentHTML('afterbegin', html); }
  else { $('ndTestResult').innerHTML = html; }
}
async function testConnection() {
  var ip = ($('ndIp').value || '').trim();
  if (!ip) { toast('warn', '请先填写 IP', ''); return; }
  $('ndTestResult').innerHTML = '<div class="fs-12 dim"><span class="spinner" style="display:inline-block;vertical-align:-2px;"></span> 正在探测 ' + esc(ip) + ' …</div>';
  var r = await api('/api/nodes/test_connection', { ip: ip });
  renderNodeTest(r, null);
}

/* 节点 / 接口 / 灯具 编辑（作用于场地草稿） */
var nodeCtx = { nodeIdx: -1, portIdx: -1, fixIdx: -1 };
function draft() { return State.venueDraft || { nodes: [] }; }
function openNodeEditor(ni) {
  nodeCtx.nodeIdx = ni;
  var n = ni >= 0 ? draft().nodes[ni] : null;
  $('nodeTitle').textContent = n ? ('编辑解码器 · ' + n.name) : '新增解码器';
  $('ndName').value = n ? (n.name || '') : ('解码器 ' + (draft().nodes.length + 1));
  $('ndIp').value = n ? (n.ip || '') : '';
  $('ndSource').value = n ? (n.source || 'manual') : 'manual';
  $('ndGroups').value = n ? (n.groups || []).join(',') : '';
  var p = (n && n.offline_policy) || { mode: 'threshold', liveness_source: 'artpoll', threshold_sec: 5, grace_period_sec: 2, severity: 'warning', actions: ['log', 'banner', 'toast'], auto_recover: true, alarm_when_never_seen: false };
  $('ndPolicyMode').value = p.mode || 'threshold';
  $('ndLiveness').value = p.liveness_source || 'artpoll';
  $('ndSeverity').value = p.severity || 'warning';
  $('ndThreshold').value = p.threshold_sec || 5;
  $('ndGrace').value = p.grace_period_sec || 2;
  $('ndAutoRecover').value = p.auto_recover === false ? '0' : '1';
  $('ndNeverSeen').value = p.alarm_when_never_seen ? '1' : '0';
  qa('#ndActions input[data-act]').forEach(function (cb) {
    var a = cb.getAttribute('data-act');
    if (a === 'log') { cb.checked = true; return; }
    cb.checked = (p.actions || []).indexOf(a) !== -1;
  });
  $('ndTestResult').innerHTML = '';
  openModal('modalNode');
}
function applyNode() {
  var name = ($('ndName').value || '').trim();
  var ip = ($('ndIp').value || '').trim();
  if (!name || !ip) { toast('warn', '信息不完整', '节点名称与 IP 均为必填。'); return; }
  var actions = ['log'];
  qa('#ndActions input[data-act]').forEach(function (cb) {
    if (cb.checked && cb.getAttribute('data-act') !== 'log') actions.push(cb.getAttribute('data-act'));
  });
  var node = {
    node_id: nodeCtx.nodeIdx >= 0 ? draft().nodes[nodeCtx.nodeIdx].node_id : ('node_' + Date.now().toString(36)),
    name: name, ip: ip, protocol: 'artnet',
    source: $('ndSource').value,
    groups: ($('ndGroups').value || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean),
    discovery: (nodeCtx.nodeIdx >= 0 ? draft().nodes[nodeCtx.nodeIdx].discovery : null) ||
               { online: null, artpoll_reply: null, rtt_ms: null, first_seen: null, last_seen: null },
    offline_policy: {
      mode: $('ndPolicyMode').value,
      liveness_source: $('ndLiveness').value,
      threshold_sec: parseInt($('ndThreshold').value, 10) || 5,
      grace_period_sec: parseInt($('ndGrace').value, 10) || 0,
      severity: $('ndSeverity').value,
      alarm_when_never_seen: $('ndNeverSeen').value === '1',
      actions: actions,
      auto_recover: $('ndAutoRecover').value === '1'
    },
    ports: (nodeCtx.nodeIdx >= 0 ? draft().nodes[nodeCtx.nodeIdx].ports : null) ||
           [{ port_id: 'p1', label: 'A', label_style: 'alpha', universe: 0, direction: 'out', fixtures: [] }]
  };
  if (nodeCtx.nodeIdx >= 0) draft().nodes[nodeCtx.nodeIdx] = node;
  else draft().nodes.push(node);
  closeModal('modalNode');
  renderVenueDraft();
  toast('ok', '已应用到草稿', '记得点击「保存场地」才会写入知识库。');
}
function openPortEditor(ni, pi) {
  nodeCtx.nodeIdx = ni; nodeCtx.portIdx = pi;
  var p = draft().nodes[ni].ports[pi];
  $('ptLabelStyle').value = p.label_style || 'alpha';
  $('ptLabel').value = p.label || 'A';
  $('ptUniverse').value = p.universe != null ? p.universe : 0;
  $('ptDirection').value = p.direction || 'out';
  openModal('modalPort');
}
function applyPort() {
  var p = draft().nodes[nodeCtx.nodeIdx].ports[nodeCtx.portIdx];
  p.label_style = $('ptLabelStyle').value;
  p.label = ($('ptLabel').value || 'A').trim();
  p.universe = parseInt($('ptUniverse').value, 10) || 0;
  p.direction = $('ptDirection').value;
  closeModal('modalPort');
  renderVenueDraft();
}
function openFixtureEditor(ni, pi, fi) {
  nodeCtx.nodeIdx = ni; nodeCtx.portIdx = pi; nodeCtx.fixIdx = fi;
  var f = fi >= 0 ? draft().nodes[ni].ports[pi].fixtures[fi] : null;
  $('fxSub').textContent = draft().nodes[ni].name + ' / ' + draft().nodes[ni].ports[pi].label + '口 · Universe ' + draft().nodes[ni].ports[pi].universe;
  $('fxId').value = f ? f.id : ('fix_' + Date.now().toString(36).slice(-4));
  $('fxName').value = f ? f.name : '';
  $('fxAddress').value = f ? f.address : 1;
  $('fxTags').value = f ? (f.tags || []).join(',') : '';
  $('fxSemantic').value = f ? (f.semantic_desc || '') : '';
  $('fxShared').checked = f ? !!f.allow_shared_address : false;
  var sel = $('fxProfile');
  sel.innerHTML = State.profiles.map(function (p) {
    return '<option value="' + esc(p.profile_id) + '"' + (f && f.profile_id === p.profile_id ? ' selected' : '') + '>' +
           esc(p.profile_id) + '（' + esc(p.model || '') + ' · ' + p.channel_count + 'CH）</option>';
  }).join('');
  updateFootprint();
  openModal('modalFixture');
}
function updateFootprint() {
  var pid = $('fxProfile').value;
  var pr = State.profiles.filter(function (x) { return x.profile_id === pid; })[0];
  var a = parseInt($('fxAddress').value, 10) || 1;
  if (!pr) { $('fxFootprint').textContent = '—'; return; }
  var end = a + pr.channel_count - 1;
  $('fxFootprint').innerHTML = '占用通道区间 <code class="mono">CH' + a + ' – CH' + end + '</code>（共 ' + pr.channel_count + ' 通道）' +
    (end > 512 ? ' <span style="color:var(--danger);">已超出单 Universe 上限 512！</span>' : '');
}
function applyFixture() {
  var list = draft().nodes[nodeCtx.nodeIdx].ports[nodeCtx.portIdx].fixtures;
  var f = {
    id: ($('fxId').value || '').trim(), name: ($('fxName').value || '').trim(),
    profile_id: $('fxProfile').value, address: parseInt($('fxAddress').value, 10) || 1,
    tags: ($('fxTags').value || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean),
    semantic_desc: ($('fxSemantic').value || '').trim(),
    allow_shared_address: $('fxShared').checked
  };
  if (!f.id || !f.name) { toast('warn', '信息不完整', '灯具 ID 与名称均为必填。'); return; }
  if (nodeCtx.fixIdx >= 0) list[nodeCtx.fixIdx] = f; else list.push(f);
  closeModal('modalFixture');
  renderVenueDraft();
}

/* ============================================================================
   5. 告警中心
   ========================================================================== */
async function refreshAlarms() {
  var res = await api('/api/alarms?limit=60');
  State.alarms = (res && res.alarms) || [];
  var open = (res && res.open_count) || 0;
  var bell = $('btnBell');
  bell.classList.toggle('has-alarm', open > 0);
  $('bellCount').style.display = open > 0 ? '' : 'none';
  $('bellCount').textContent = open;
  $('navAlarmCount').style.display = open > 0 ? '' : 'none';
  $('navAlarmCount').textContent = open;

  var top = State.alarms.filter(function (a) { return a.state === 'open'; })[0];
  var bar = $('alertbar');
  if (top) {
    bar.classList.add('show');
    $('abText').innerHTML = '<code>' + esc(top.code) + '</code> ' + esc(top.message);
  } else {
    bar.classList.remove('show');
  }

  var box = $('alarmList');
  if (!State.alarms.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-bell-slash"></i><div class="t">暂无设备告警</div>' +
      '<div class="d">掉线看门狗会按每个解码器节点的独立策略判定，触发后在此集中呈现。</div></div>';
    return;
  }
  var map = { open: ['badge-danger', '未处理'], acked: ['badge-warn', '已确认'], recovered: ['badge-ok', '已恢复'] };
  var html = '';
  State.alarms.forEach(function (a) {
    var m = map[a.state] || map.open;
    html += '<div class="row between" style="padding:11px 14px;border:1px solid var(--line);border-radius:var(--r-md);margin-bottom:8px;background:rgba(255,255,255,.02);' +
      (a.state === 'open' ? 'border-left:3px solid var(--danger);' : '') + '">' +
      '<div class="col" style="gap:3px;">' +
        '<span class="fs-13"><code class="mono" style="color:var(--danger);">' + esc(a.code) + '</code> ' +
        '<b>' + esc(a.title) + '</b> <span class="badge ' + m[0] + '">' + m[1] + '</span></span>' +
        '<span class="fs-12 muted">' + esc(a.message) + '</span>' +
        '<span class="fs-11 dim">触发 ' + esc(a.raised_at) + ' · 最近 ' + esc(a.last_at) +
        (a.recovered_at ? ' · 恢复 ' + esc(a.recovered_at) : '') + '</span>' +
      '</div>' +
      (a.state === 'open' ? '<button class="btn btn-xs" data-ack="' + esc(a.id) + '"><i class="fa-solid fa-check"></i> 确认</button>' : '') +
      '</div>';
  });
  box.innerHTML = html;
  qa('#alarmList button[data-ack]').forEach(function (b) {
    b.addEventListener('click', async function () {
      await api('/api/alarms/ack', { alarm_id: b.getAttribute('data-ack') });
      refreshAlarms();
    });
  });
}
async function ackAllAlarms() {
  var r = await api('/api/alarms/ack', { all: true });
  refreshAlarms();
  if (ok(r)) toast('ok', '已全部确认', r.acked + ' 条告警被标记为已确认');
}
async function refreshLogs() {
  var logs = await api('/api/logs/stream');
  var box = $('logBox');
  if (!Array.isArray(logs) || !logs.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-bug"></i><div class="t">暂无日志</div>' +
      '<div class="d">系统运行日志与故障诊断会实时汇聚到这里。</div></div>';
    return;
  }
  var LV = { ERROR: 'lv-ERROR', CRITICAL: 'lv-ERROR', FATAL: 'lv-ERROR',
             WARNING: 'lv-WARNING', WARN: 'lv-WARNING', INFO: 'lv-INFO', DEBUG: 'lv-INFO' };
  var html = '';
  logs.slice().reverse().forEach(function (l) {
    var lv = String(l.level || 'INFO').toUpperCase();
    var diag = l.diagnostics;
    html += '<div class="log-row ' + (LV[lv] || 'lv-INFO') + '">' +
      '<span class="log-time">' + esc(l.timestamp || '') + '</span>' +
      '<span class="log-lv">' + esc(lv) + '</span>' +
      '<div style="flex:1;min-width:0;">' +
        '<div class="log-msg">' + esc(l.message || '') + '</div>' +
        (diag ? '<div class="log-diag"><code>' + esc(l.diag_code || '') + '</code> <b>' +
                esc(diag.title || '') + '</b><br>成因：' + esc(diag.cause || '') +
                '<br>处置：' + esc(diag.solution || '') + '</div>' :
                (l.diag_code ? '<div class="log-diag"><code>' + esc(l.diag_code) + '</code></div>' : '')) +
      '</div></div>';
  });
  box.innerHTML = html;
}

/* ============================================================================
   6. 插件市场与大模型
   ========================================================================== */
var PLUGIN_TYPE_MAP = {
  macro: { label: '动态宏特效', badge: 'badge-brand', icon: 'fa-wand-magic-sparkles' },
  protocol: { label: '通信协议驱动', badge: 'badge-ok', icon: 'fa-network-wired' },
  perception: { label: '传感感知适配', badge: 'badge-accent', icon: 'fa-wave-square' },
  llm: { label: '智能模型推理', badge: 'badge-warn', icon: 'fa-brain' }
};

function getPluginTypeMeta(rawType) {
  var t = (rawType || 'macro').toLowerCase();
  return PLUGIN_TYPE_MAP[t] || { label: rawType || '扩展插件', badge: 'badge-mute', icon: 'fa-cube' };
}

async function loadInstalled() {
  var list = await api('/api/plugins/installed');
  list = Array.isArray(list) ? list : [];
  $('installedCount').textContent = list.length + ' 个';
  if (!list.length) {
    $('installedTbody').innerHTML = '<tr><td colspan="5"><div class="empty"><i class="fa-solid fa-plug"></i><div class="t">尚未装载插件</div></div></td></tr>';
    return;
  }
  var html = '';
  list.forEach(function (p) {
    var info = p.info || {};
    var pid = p.id || info.id || p.plugin_id || '';
    var name = info.name || p.name || pid;
    var rawType = info.type || p.type || p.plugin_type || 'macro';
    var tMeta = getPluginTypeMeta(rawType);
    var ver = info.version || p.version || '1.0.0';
    var author = info.author || p.author || '社区贡献';
    var desc = info.description || p.description || '';
    var isEnabled = Boolean(p.enabled);
    var tier = p.tier || 3;

    var tierBadge = '<span class="badge" style="background:rgba(16,185,129,.15);color:#34d399;border:1px solid rgba(16,185,129,.3);">3类·表现创意</span>';

    html += '<tr><td>' +
        '<div style="display:flex;align-items:flex-start;gap:8px;">' +
          '<i class="fa-solid ' + tMeta.icon + ' dim fs-13" style="margin-top:3px;"></i>' +
          '<div>' +
            '<div class="row" style="gap:6px;align-items:center;"><b class="fs-13">' + esc(name) + '</b>' + tierBadge + '</div>' +
            '<div class="row g2x" style="margin-top:2px;">' +
              '<code class="mono fs-11 dim">' + esc(pid) + '</code>' +
              '<span class="fs-11 dim">· 作者: ' + esc(author) + '</span>' +
            '</div>' +
            (desc ? '<div class="fs-11 muted" style="margin-top:2px;max-width:320px;white-space:normal;line-height:1.3;">' + esc(desc) + '</div>' : '') +
          '</div>' +
        '</div>' +
      '</td>' +
      '<td><span class="badge ' + tMeta.badge + '">' + esc(tMeta.label) + '</span></td>' +
      '<td class="mono fs-12">v' + esc(ver) + '</td>' +
      '<td><span class="badge ' + (isEnabled ? 'badge-ok' : 'badge-mute') + '">' +
        '<span class="dot ' + (isEnabled ? 'dot-live' : '') + '" style="margin-right:4px;"></span>' +
        (isEnabled ? '运行中' : '已停用') + '</span></td>' +
      '<td class="col-act"><div class="btn-group">' +
        '<button class="btn btn-xs ' + (isEnabled ? '' : 'btn-success') + '" data-act="toggle" data-id="' + esc(pid) + '" data-on="' + (isEnabled ? '0' : '1') + '">' +
          (isEnabled ? '停用' : '启用') + '</button>' +
        '<button class="btn btn-xs" data-act="cfg" data-id="' + esc(pid) + '" title="配置参数"><i class="fa-solid fa-gear"></i></button>' +
        (tier === 3 ? '<button class="btn btn-xs btn-danger-ghost" data-act="rm" data-id="' + esc(pid) + '" title="卸载插件"><i class="fa-solid fa-trash"></i></button>' : '') +
      '</div></td></tr>';
  });
  $('installedTbody').innerHTML = html;
  qa('#installedTbody button[data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      var a = b.getAttribute('data-act'), id = b.getAttribute('data-id');
      if (a === 'toggle') togglePlugin(id, b.getAttribute('data-on') === '1');
      else if (a === 'cfg') openPluginCfg(id);
      else uninstallPlugin(id);
    });
  });
}
async function togglePlugin(id, on) {
  try {
    var res = await api('/api/plugins/toggle_enabled', { plugin_id: id, enabled: on });
    if (ok(res)) {
      toast('ok', on ? '插件已启用' : '插件已停用', id);
      await loadInstalled();
      await renderDynamicPluginSlots();
    } else {
      toast('error', '切换失败', res.message || '');
    }
  } catch (e) {
    toast('error', '操作异常', String(e.message || e));
  }
}

async function openPluginCfg(id) {
  var res = await api('/api/plugins/detail?id=' + encodeURIComponent(id));
  var info = res.info || {};
  $('pluginTitle').textContent = '插件参数 · ' + (info.name || res.name || id);
  var rawSchema = res.config_schema || res.schema || {};
  var props = rawSchema.properties ? rawSchema.properties : rawSchema;
  var cur = res.config || {};
  var keys = Object.keys(props).filter(function (k) { return typeof props[k] === 'object' && props[k] !== null; });

  if (!keys.length) {
    $('pluginForm').innerHTML = '<div class="empty"><i class="fa-solid fa-sliders"></i><div class="t">该插件无需额外参数配置</div><div class="d">当前插件使用默认配置即可正常工作。</div></div>';
    $('pluginForm').setAttribute('data-pid', id);
    openModal('modalPlugin');
    return;
  }
  var html = '';
  keys.forEach(function (k) {
    var s = props[k];
    var v = cur[k] != null ? cur[k] : (s.default != null ? s.default : '');
    var labelText = s.label || s.title || k;
    html += '<div class="field"><label>' + esc(labelText) + ' <code class="mono fs-11 dim">(' + esc(k) + ')</code></label>';
    if (s.type === 'boolean') {
      html += '<select data-k="' + esc(k) + '"><option value="1"' + (v ? ' selected' : '') + '>开启 (True)</option><option value="0"' + (!v ? ' selected' : '') + '>关闭 (False)</option></select>';
    } else if (s.enum && Array.isArray(s.enum)) {
      html += '<select data-k="' + esc(k) + '">' + s.enum.map(function (e) {
        return '<option value="' + esc(e) + '"' + (String(v) === String(e) ? ' selected' : '') + '>' + esc(e) + '</option>';
      }).join('') + '</select>';
    } else if (s.type === 'integer' || s.type === 'number') {
      html += '<input type="number" data-k="' + esc(k) + '" value="' + esc(v) + '">';
    } else {
      html += '<input type="text" data-k="' + esc(k) + '" value="' + esc(v) + '">';
    }
    if (s.description) html += '<div class="field-hint">' + esc(s.description) + '</div>';
    html += '</div>';
  });
  $('pluginForm').innerHTML = html;
  $('pluginForm').setAttribute('data-pid', id);
  openModal('modalPlugin');
}

async function savePluginCfg() {
  var pid = $('pluginForm').getAttribute('data-pid');
  var cfg = {};
  qa('#pluginForm [data-k]').forEach(function (el) {
    var k = el.getAttribute('data-k'), v = el.value;
    if (el.tagName === 'SELECT' && (v === '1' || v === '0')) v = (v === '1');
    else if (el.type === 'number') v = Number(v);
    cfg[k] = v;
  });
  try {
    var res = await api('/api/plugins/save_config', { plugin_id: pid, config: cfg });
    if (ok(res)) {
      closeModal('modalPlugin');
      toast('ok', '参数已热更新', '插件 [' + pid + '] 配置已生效');
      await loadInstalled();
      await renderDynamicPluginSlots();
    } else {
      toast('error', '保存失败', res.message || '');
    }
  } catch (e) {
    toast('error', '保存异常', String(e.message || e));
  }
}

async function uninstallPlugin(id) {
  if (!await askConfirm('卸载插件', '确定卸载 <b>' + esc(id) + '</b> ？相关能力将立即失效。', '卸载', true)) return;
  try {
    var res = await api('/api/plugins/uninstall', { plugin_id: id });
    if (ok(res)) {
      toast('ok', '插件已卸载', id);
      await loadInstalled();
      await loadMarket();
      await renderDynamicPluginSlots();
    } else {
      toast('error', '卸载失败', res.message || '');
    }
  } catch (e) {
    toast('error', '卸载异常', String(e.message || e));
  }
}

async function loadMarket() {
  var list = await api('/api/market/packages');
  list = Array.isArray(list) ? list : (list.packages || []);
  var box = $('marketList');
  if (!list.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-store"></i><div class="t">市场暂无可用扩展</div></div>';
    return;
  }
  var html = '';
  list.forEach(function (p) {
    var pid = p.id || p.package_id || '';
    var name = p.name || pid;
    var isInst = Boolean(p.is_installed);
    var rawType = (p.type || 'macro').toLowerCase();
    var tMeta = getPluginTypeMeta(rawType);

    html += '<div style="padding:14px 16px;border:1px solid var(--line);border-radius:var(--r-md);margin-bottom:10px;background:rgba(255,255,255,.02);transition:border-color .2s;">' +
      '<div class="row between" style="align-items:flex-start;">' +
        '<div>' +
          '<div class="row g2x">' +
            '<b class="fs-13">' + esc(name) + '</b>' +
            '<span class="badge ' + tMeta.badge + '">' + esc(tMeta.label) + '</span>' +
          '</div>' +
          '<div class="row g2x fs-11 dim" style="margin-top:3px;">' +
            '<code class="mono">' + esc(pid) + '</code>' +
            '<span>· 作者: ' + esc(p.author || '社区') + '</span>' +
          '</div>' +
        '</div>' +
        '<span class="badge badge-mute mono fs-11">v' + esc(p.version || '1.0.0') + '</span>' +
      '</div>' +
      '<div class="fs-12 muted" style="margin:8px 0 12px;line-height:1.5;">' + esc(p.description || '暂无描述') + '</div>' +
      '<div class="row between">' +
        (isInst
          ? '<span class="badge badge-ok fs-11"><i class="fa-solid fa-circle-check"></i> 本地已装载</span>'
          : '<span class="fs-11 dim"><i class="fa-solid fa-shield-halved"></i> 静态沙箱安全审查已通过</span>') +
        (isInst
          ? '<button class="btn btn-xs" data-inst="' + esc(pid) + '" data-re="1" title="覆盖重装"><i class="fa-solid fa-rotate"></i> 覆盖重装</button>'
          : '<button class="btn btn-xs btn-primary" data-inst="' + esc(pid) + '"><i class="fa-solid fa-download"></i> 一键安装</button>') +
      '</div>' +
    '</div>';
  });
  box.innerHTML = html;
  qa('#marketList button[data-inst]').forEach(function (b) {
    b.addEventListener('click', function () { installPkg(b.getAttribute('data-inst'), b); });
  });
}

async function installPkg(id, btn) {
  var origHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner" style="width:11px;height:11px;border-width:2px;margin-right:4px;"></span> 安装中…';
  try {
    toast('info', '正在安装插件', '正在部署与热激活 ' + id + '…', 3000);
    var res = await api('/api/market/install', { package_id: id });
    if (ok(res)) {
      toast('ok', '安装成功', (res.message || ('插件 [' + id + '] 已成功装载并激活！')));
      await loadInstalled();
      await loadMarket();
      await renderDynamicPluginSlots();
    } else {
      var err = res.message || res.error || '安装未通过合规审查';
      toast('error', '安装失败', err);
      btn.disabled = false;
      btn.innerHTML = origHtml;
    }
  } catch (e) {
    toast('error', '安装异常', String(e.message || e));
    btn.disabled = false;
    btn.innerHTML = origHtml;
  }
}
async function runVerify() {
  var code = $('verifyCode').value || '';
  if (!code.trim()) { toast('warn', '请先粘贴源码', ''); return; }
  var res = await api('/api/market/verify_code', { code: code });
  var box = $('verifyResult');
  if (res.valid) {
    box.innerHTML = '<div class="alert alert-ok"><i class="fa-solid fa-circle-check"></i><div><b>校验通过</b><br>' +
      esc((res.checks || []).join('　·　') || '全部合规性检查通过') + '</div></div>';
  } else {
    box.innerHTML = '<div class="alert alert-danger"><i class="fa-solid fa-circle-xmark"></i><div><b>校验未通过</b><ul style="margin:6px 0 0 18px;">' +
      (res.errors || ['未知错误']).map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div></div>';
  }
}
async function loadLlm() {
  var c = await api('/api/llm/config');
  $('llmUrl').value = c.api_url || '';
  $('llmModel').value = c.model_name || '';
}
async function testLlm() {
  toast('info', '正在测试连通性', '向端侧推理服务发送探测请求…', 6000);
  var res = await api('/api/llm/test_connection', {
    api_url: $('llmUrl').value, model_name: $('llmModel').value
  });
  var b = $('llmBadge');
  if (ok(res)) { b.className = 'badge badge-ok'; b.textContent = '连通 ' + (res.latency_ms || '?') + 'ms'; toast('ok', '连通正常', '往返 ' + (res.latency_ms || '?') + 'ms'); }
  else { b.className = 'badge badge-danger'; b.textContent = '不可达'; toast('error', '连通失败', res.message || ''); }
}
async function saveLlm() {
  var res = await api('/api/llm/save_config', { api_url: $('llmUrl').value, model_name: $('llmModel').value });
  toast(ok(res) ? 'ok' : 'error', ok(res) ? '已保存并热更新' : '保存失败', res.message || '');
}

/* ============================================================================
   6.5 通用插件动态插槽与自包含视窗宿主 (Generic Plugin View Host)
   ========================================================================== */
var activeGenericPluginTimer = null;

async function renderDynamicPluginSlots() {
  try {
    var supportedSlots = ['topbar_actions', 'nav_items', 'kb_profiles_toolbar'];
    for (var i = 0; i < supportedSlots.length; i++) {
      var slotName = supportedSlots[i];
      var slotEl = $('slot-' + slotName);
      if (!slotEl) continue;

      var exts = await api('/api/plugins/ui_extensions?slot=' + encodeURIComponent(slotName));
      exts = Array.isArray(exts) ? exts : [];
      
      slotEl.innerHTML = '';
      if (slotName === 'nav_items') {
        // 支持两级结构：若声明 group_label 则归组，并在组下支持折叠/子条目
        var groupMap = {};
        exts.forEach(function (ext) {
          var groupName = ext.group_label || ext.category || '';
          if (!groupMap[groupName]) groupMap[groupName] = [];
          groupMap[groupName].push(ext);
        });

        Object.keys(groupMap).forEach(function (gName) {
          if (gName) {
            var gTitle = document.createElement('div');
            gTitle.className = 'nav-group';
            gTitle.style.paddingTop = '10px';
            gTitle.textContent = gName;
            slotEl.appendChild(gTitle);
          }

          var subWrap = document.createElement('div');
          subWrap.className = 'nav-subgroup';

          groupMap[gName].forEach(function (ext) {
            var navItem = document.createElement('div');
            navItem.className = gName ? 'nav-sub-item' : 'nav-item';
            navItem.id = ext.id || ('ext_nav_' + Math.random().toString(36).substr(2, 6));
            navItem.innerHTML = (ext.icon ? '<i class="fa-solid ' + esc(ext.icon) + '"></i>' : '<i class="fa-solid fa-cube"></i>') +
                                '<span>' + esc(ext.label || '插件功能') + '</span>' +
                                (ext.badge ? ('<span class="sub-tag">' + esc(ext.badge) + '</span>') : '');
            navItem.addEventListener('click', function () {
              if (ext.view_html || ext.plugin_id) {
                openGenericPluginModal(ext);
              } else if (typeof window[ext.action] === 'function') {
                window[ext.action](ext);
              }
            });
            subWrap.appendChild(navItem);
          });
          slotEl.appendChild(subWrap);
        });
      } else {
        // 渲染为工具栏/顶栏操作按钮
        exts.forEach(function (ext) {
          var btn = document.createElement('button');
          btn.className = 'btn ' + (slotName === 'topbar_actions' ? 'btn-xs ' : 'btn-sm ') + (ext.btn_class || 'btn-brand');
          btn.id = ext.id || ('ext_btn_' + Math.random().toString(36).substr(2, 6));
          btn.title = ext.tooltip || ext.label || '';
          btn.innerHTML = (ext.icon ? '<i class="fa-solid ' + esc(ext.icon) + '"></i> ' : '') + esc(ext.label || '扩展');
          
          btn.addEventListener('click', function () {
            if (ext.view_html || ext.plugin_id) {
              openGenericPluginModal(ext);
            } else if (typeof window[ext.action] === 'function') {
              window[ext.action](ext);
            }
          });
          slotEl.appendChild(btn);
        });
      }
    }
  } catch (e) {
    console.warn('加载动态插件插槽失败:', e);
  }
}

async function openGenericPluginModal(ext) {
  var modal = $('modalGenericPluginHost');
  if (!modal) return;

  var pid = ext.plugin_id || '';
  $('genericPluginTitle').textContent = ext.modal_title || ext.label || '插件视窗';
  $('genericPluginSub').textContent = ext.modal_sub || (pid ? ('来自插件: ' + pid) : '自包含扩展组件');
  $('genericPluginIcon').className = 'fa-solid ' + (ext.icon || 'fa-cube');
  $('genericPluginFootLeft').innerHTML = ext.modal_foot || ('宿主状态: <span class="badge badge-ok">运行中</span>');

  var card = $('genericPluginCard');
  if (card) {
    card.className = 'modal-card ' + (ext.modal_size ? ('w-' + ext.modal_size) : 'w-lg');
  }

  var body = $('genericPluginBody');
  body.innerHTML = '<div style="text-align:center;padding:30px;color:var(--txt-3);"><span class="spinner" style="margin-right:8px;"></span>正在装配插件视图…</div>';
  openModal('modalGenericPluginHost');

  if (activeGenericPluginTimer) {
    clearInterval(activeGenericPluginTimer);
    activeGenericPluginTimer = null;
  }

  try {
    var viewHtml = ext.view_html;
    if (!viewHtml && pid) {
      var detail = await api('/api/plugins/detail?id=' + encodeURIComponent(pid));
      var pExts = (detail && detail.ui_extensions) ? detail.ui_extensions : [];
      var matched = pExts.find(function (item) { return item.id === ext.id; }) || pExts[0];
      if (matched && matched.view_html) viewHtml = matched.view_html;
    }

    if (!viewHtml) {
      body.innerHTML = '<div class="empty"><i class="fa-solid fa-triangle-exclamation"></i><div class="t">未提供界面内容</div><div class="d">该插件未声明可渲染的 view_html 片段。</div></div>';
      return;
    }

    body.innerHTML = viewHtml;

    // 如果插件视图内带有 <script> 标签，手动执行它以初始化插件视窗的 JS 逻辑
    var scripts = body.querySelectorAll('script');
    scripts.forEach(function (s) {
      try {
        var fn = new Function('pluginContext', s.textContent);
        fn({
          pluginId: pid,
          api: api,
          esc: esc,
          q: q,
          qa: qa,
          toast: toast,
          setTimer: function (timer) { activeGenericPluginTimer = timer; }
        });
      } catch (err) {
        console.error('插件视图脚本执行失败:', err);
      }
    });

  } catch (err) {
    body.innerHTML = '<div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation"></i><div>加载插件视窗异常: ' + esc(String(err)) + '</div></div>';
  }
}

// 统一监听通用视窗关闭事件，自动销毁运行中的定时器
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-close="modalGenericPluginHost"]').forEach(function (el) {
    el.addEventListener('click', function () {
      closeModal('modalGenericPluginHost');
      if (activeGenericPluginTimer) {
        clearInterval(activeGenericPluginTimer);
        activeGenericPluginTimer = null;
      }
    });
  });
});

/* ============================================================================
   7. 知识库 · 灯库
   ========================================================================== */
async function loadKbProfiles() {
  var list = await api('/api/kb/profiles');
  State.profiles = Array.isArray(list) ? list : [];
  var tb = $('profilesTbody');
  if (!State.profiles.length) {
    tb.innerHTML = '<tr><td colspan="7"><div class="empty"><i class="fa-solid fa-lightbulb"></i><div class="t">知识库中暂无灯库</div><div class="d">点击「新建灯库」或使用「AI 说明书提取」快速录入。</div></div></td></tr>';
    return;
  }
  var html = '';
  State.profiles.forEach(function (p) {
    html += '<tr>' +
      '<td><code class="mono fs-12">' + esc(p.profile_id) + '</code></td>' +
      '<td>' + esc(p.manufacturer || '—') + ' / <b>' + esc(p.model || '—') + '</b></td>' +
      '<td class="mono">' + p.channel_count + '</td>' +
      '<td><span class="badge badge-ok">' + p.safe_channel_count + '</span></td>' +
      '<td><span class="badge ' + (p.ranged_channel_count ? 'badge-brand' : 'badge-mute') + '">' + p.ranged_channel_count + '</span></td>' +
      '<td>' + (p.locked_channel_count ? '<span class="badge badge-danger">' + p.locked_channel_count + ' 锁定</span>' : '<span class="fs-12 dim">无</span>') + '</td>' +
      '<td class="col-act"><div class="btn-group">' +
        '<button class="btn btn-xs" data-act="edit" data-id="' + esc(p.profile_id) + '"><i class="fa-solid fa-pen"></i> 编辑</button>' +
        '<button class="btn btn-xs btn-danger-ghost" data-act="del" data-id="' + esc(p.profile_id) + '"><i class="fa-solid fa-trash"></i></button>' +
      '</div></td></tr>';
  });
  tb.innerHTML = html;
  qa('#profilesTbody button[data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (b.getAttribute('data-act') === 'edit') openProfile(b.getAttribute('data-id'));
      else delProfile(b.getAttribute('data-id'));
    });
  });
}
async function openProfile(pid) {
  var d = pid ? await api('/api/kb/profile_detail?id=' + encodeURIComponent(pid)) : {};
  State.editingProfileId = pid || null;
  $('profileTitle').textContent = pid ? ('编辑灯库 · ' + pid) : '新建灯库';
  $('pfId').value = d.profile_id || '';
  $('pfId').disabled = !!pid;
  $('pfMfr').value = d.manufacturer || '';
  $('pfModel').value = d.model || '';
  $('pfChannels').innerHTML = '';
  var chs = (d.channels || []).slice().sort(function(a, b) { return parseInt(a.ch || 0, 10) - parseInt(b.ch || 0, 10); });
  chs.forEach(function (c, idx) { addChannelRow(c, idx + 1); });
  if (!chs.length) addChannelRow({ ch: 1, type: 'dimmer', name: '总调光', default: 0, is_safe: true }, 1);
  openModal('modalProfile');
}
function addChannelRow(ch, forcedIndex) {
  ch = ch || {};
  var tb = $('pfChannels');
  var rowFallback = (forcedIndex !== undefined && forcedIndex !== null) ? forcedIndex : (tb.children.length + 1);
  
  // 全方位兼容读取大模型或旧灯库里可能出现的各种通道号字段名
  var rawCh = ch.ch !== undefined ? ch.ch : (ch.CH !== undefined ? ch.CH : (ch.channel !== undefined ? ch.channel : (ch.no !== undefined ? ch.no : ch.number)));
  var channelNum = parseInt(rawCh, 10);
  if (isNaN(channelNum) || channelNum <= 0) {
    channelNum = rowFallback;
  }

  var tr = document.createElement('tr');
  var slotTxt = (ch.slots || []).length ? (ch.slots.length + ' 档') : '未定义';
  var rng = ch.range || [0, 255];
  tr.innerHTML =
    '<td><input type="text" inputmode="numeric" class="ch-ch mono" value="' + channelNum + '" style="height:26px;font-size:12px;font-weight:600;text-align:center;padding:0;width:48px;margin:0 auto;display:block;"></td>' +
    '<td><input type="text" class="ch-type mono" value="' + esc(ch.type || '') + '" style="height:26px;font-size:11px;padding:0 6px;"></td>' +
    '<td><input type="text" class="ch-name" value="' + esc(ch.name || '') + '" style="height:26px;font-size:12px;padding:0 6px;"></td>' +
    '<td><input type="number" class="ch-default" value="' + (ch.default || 0) + '" style="height:26px;font-size:12px;text-align:center;padding:0 4px;"></td>' +
    '<td><div class="row" style="gap:3px;">' +
      '<input type="number" class="ch-lo" value="' + rng[0] + '" style="height:26px;font-size:11px;width:44px;text-align:center;padding:0 2px;">' +
      '<span class="dim fs-11">–</span>' +
      '<input type="number" class="ch-hi" value="' + rng[1] + '" style="height:26px;font-size:11px;width:44px;text-align:center;padding:0 2px;">' +
    '</div></td>' +
    '<td><button class="btn btn-xs ch-slots" title="编辑枚举档位">' + slotTxt + '</button></td>' +
    '<td style="text-align:center;"><input type="checkbox" class="ch-safe"' + (ch.is_safe === false ? '' : ' checked') + '></td>' +
    '<td><button class="btn btn-xs btn-ghost ch-del"><i class="fa-solid fa-xmark"></i></button></td>';
  tb.appendChild(tr);
  tr.querySelector('.ch-del').addEventListener('click', function () { tr.remove(); });
  tr.querySelector('.ch-slots').addEventListener('click', function () { openSlots(tr); });
  tr.setAttribute('data-slots', JSON.stringify(ch.slots || []));
}
function openSlots(tr) {
  State.slotsTarget = tr;
  $('slotsSub').textContent = (tr.querySelector('.ch-name').value || tr.querySelector('.ch-type').value || '通道') + ' 的档位定义';
  renderSlots(JSON.parse(tr.getAttribute('data-slots') || '[]'));
  openModal('modalSlots');
}
function renderSlots(slots) {
  var box = $('slotList');
  if (!slots.length) {
    box.innerHTML = '<div class="fs-12 dim" style="padding:10px 2px;">尚未定义档位。连续型通道可留空，改用取值范围。</div>';
    return;
  }
  var html = '';
  slots.forEach(function (s, i) {
    html += '<div class="row mb-2" style="gap:7px;" data-i="' + i + '">' +
      '<input type="number" class="sl-v" value="' + (s.v || 0) + '" style="width:78px;height:28px;font-size:12px;text-align:center;">' +
      '<input type="text" class="sl-l" value="' + esc(s.label || '') + '" placeholder="档位中文名" style="height:28px;font-size:12px;">' +
      '<button class="btn btn-xs btn-ghost sl-rm"><i class="fa-solid fa-xmark"></i></button></div>';
  });
  box.innerHTML = html;
  qa('#slotList .sl-rm').forEach(function (b) {
    b.addEventListener('click', function () { collectSlotsFromDOM(b.closest('[data-i]')); });
  });
}
function collectSlotsFromDOM(removed) {
  var rows = qa('#slotList [data-i]').filter(function (r) { return r !== removed; });
  var out = rows.map(function (r) {
    return { v: parseInt(r.querySelector('.sl-v').value, 10) || 0, label: r.querySelector('.sl-l').value || '' };
  }).filter(function (s) { return s.label; });
  renderSlots(out);
}
function saveSlots() {
  var rows = qa('#slotList [data-i]');
  var out = [];
  rows.forEach(function (r) {
    var v = parseInt(r.querySelector('.sl-v').value, 10) || 0;
    var l = (r.querySelector('.sl-l').value || '').trim();
    if (l) out.push({ v: v, label: l });
  });
  out.sort(function (a, b) { return a.v - b.v; });
  if (State.slotsTarget) {
    State.slotsTarget.setAttribute('data-slots', JSON.stringify(out));
    State.slotsTarget.querySelector('.ch-slots').textContent = out.length ? (out.length + ' 档') : '未定义';
  }
  closeModal('modalSlots');
}
function collectProfile() {
  var channels = [];
  qa('#pfChannels tr').forEach(function (tr, i) {
    var c = {
      ch: parseInt(tr.querySelector('.ch-ch').value, 10) || (i + 1),
      type: (tr.querySelector('.ch-type').value || '').trim(),
      name: (tr.querySelector('.ch-name').value || '').trim(),
      default: clamp255(tr.querySelector('.ch-default').value),
      is_safe: tr.querySelector('.ch-safe').checked,
      range: [clamp255(tr.querySelector('.ch-lo').value), clamp255(tr.querySelector('.ch-hi').value)]
    };
    var sl = JSON.parse(tr.getAttribute('data-slots') || '[]');
    if (sl.length) c.slots = sl;
    if (c.type) channels.push(c);
  });
  return {
    profile_id: ($('pfId').value || '').trim(),
    manufacturer: ($('pfMfr').value || '').trim(),
    model: ($('pfModel').value || '').trim(),
    channel_count: channels.length,
    channels: channels
  };
}
async function saveProfile() {
  var d = collectProfile();
  if (!d.profile_id) { toast('warn', '缺少 Profile ID', ''); return; }
  if (!d.channels.length) { toast('warn', '至少需要 1 个通道', ''); return; }
  var res = await api('/api/kb/save_profile', d);
  if (ok(res)) {
    closeModal('modalProfile');
    await loadKbProfiles(); await loadKbSummary();
    toast('ok', '灯库已保存', d.profile_id + ' · ' + d.channels.length + ' 通道');
  } else { toast('error', '保存失败', res.message || ''); }
}
async function delProfile(id) {
  if (!await askConfirm('删除灯库', '确定删除 <b>' + esc(id) + '</b> ？<br>正在被场地灯具引用的灯库会被拒绝删除。', '删除', true)) return;
  var res = await api('/api/kb/delete_profile', { profile_id: id });
  if (ok(res)) { await loadKbProfiles(); await loadKbSummary(); toast('ok', '已删除', id); }
  else toast('error', '删除被拒绝', res.message || '');
}

/* ============================================================================
   8. 知识库 · 场地与节点拓扑
   ========================================================================== */
async function loadKbVenues() {
  var list = await api('/api/kb/venues');
  State.venues = Array.isArray(list) ? list : [];
  var tb = $('venuesTbody');
  if (!State.venues.length) {
    tb.innerHTML = '<tr><td colspan="8"><div class="empty"><i class="fa-solid fa-map-location-dot"></i><div class="t">暂无场地</div></div></td></tr>';
    return;
  }
  var html = '';
  State.venues.forEach(function (v) {
    html += '<tr>' +
      '<td><code class="mono fs-12">' + esc(v.venue_id) + '</code></td>' +
      '<td><b>' + esc(v.venue_name) + '</b></td>' +
      '<td class="mono fs-12">' + esc(v.default_target_ip) + '</td>' +
      '<td class="mono">' + v.node_count + '</td>' +
      '<td class="mono">' + v.port_count + '</td>' +
      '<td class="mono">' + v.fixture_count + '</td>' +
      '<td>' + (v.is_active ? '<span class="badge badge-ok"><span class="dot dot-live"></span> 使用中</span>' : '<span class="badge badge-mute">待机</span>') + '</td>' +
      '<td class="col-act"><div class="btn-group">' +
        (v.is_active ? '' : '<button class="btn btn-xs btn-primary" data-act="switch" data-id="' + esc(v.venue_id) + '">切换</button>') +
        '<button class="btn btn-xs" data-act="edit" data-id="' + esc(v.venue_id) + '"><i class="fa-solid fa-pen"></i></button>' +
        '<button class="btn btn-xs btn-danger-ghost" data-act="del" data-id="' + esc(v.venue_id) + '"><i class="fa-solid fa-trash"></i></button>' +
      '</div></td></tr>';
  });
  tb.innerHTML = html;
  qa('#venuesTbody button[data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      var a = b.getAttribute('data-act'), id = b.getAttribute('data-id');
      if (a === 'edit') openVenue(id);
      else if (a === 'del') delVenue(id);
      else switchVenue(id);
    });
  });
  State.activeVenue = State.venues.filter(function (v) { return v.is_active; })[0] || State.venues[0] || null;
  buildPorts();
  renderVenueTree();
}
function renderVenueTree() {
  var v = State.activeVenue;
  $('venueTreeBadge').textContent = v ? (v.venue_name + ' · ' + v.node_count + ' 解码器 / ' + v.fixture_count + ' 灯具') : '—';
  var box = $('venueTree');
  if (!v || !(v.nodes || []).length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-sitemap"></i><div class="t">暂无节点拓扑</div></div>';
    return;
  }
  var html = '';
  (v.nodes || []).forEach(function (n) {
    var pol = n.offline_policy || {};
    html += '<div class="tnode open has-children"><div class="trow lv1 tgl">' +
      '<i class="fa-solid fa-chevron-right tcaret"></i>' +
      '<i class="fa-solid fa-server" style="color:var(--brand);"></i>' +
      '<b>' + esc(n.name) + '</b>' +
      '<span class="mono fs-11 dim">' + esc(n.ip) + '</span>' +
      '<span class="badge badge-mute">' + esc(n.source === 'discovered' ? '自动发现' : '手动录入') + '</span>' +
      '<span class="badge ' + (pol.mode === 'ignore' ? 'badge-mute' : (pol.mode === 'manual' ? 'badge-warn' : 'badge-brand')) + '">' +
        esc({ threshold: '阈值触发', ignore: '忽略', manual: '手动' }[pol.mode] || pol.mode) + '</span>' +
      '<span class="fs-11 dim">阈值 ' + (pol.threshold_sec || 5) + 's · ' + esc(pol.liveness_source || 'artdmx') + '</span>' +
      '</div><div class="tchildren">';
    (n.ports || []).forEach(function (p) {
      html += '<div class="trow lv2">' +
        '<i class="fa-solid fa-ethernet" style="color:var(--brand);"></i>' +
        '<b>' + esc(p.label) + '口</b>' +
        '<span class="mono fs-11 dim">Universe ' + p.universe + '</span>' +
        '<span class="badge badge-mute">' + esc(p.direction || 'out') + '</span>' +
        '<span class="fs-11 dim">' + (p.fixtures || []).length + ' 台灯具</span></div>';
      (p.fixtures || []).forEach(function (f) {
        var pr = State.profiles.filter(function (x) { return x.profile_id === f.profile_id; })[0];
        var end = pr ? (f.address + pr.channel_count - 1) : f.address;
        html += '<div class="trow lv3">' +
          '<i class="fa-solid fa-lightbulb" style="color:var(--warn);"></i>' +
          '<span>' + esc(f.name) + '</span>' +
          (f.allow_shared_address ? '<span class="badge badge-warn">允许共址</span>' : '') +
          '<span class="mono fs-11 dim">CH' + f.address + '–' + end + '</span>' +
          '<span class="badge badge-mute mono">' + esc(f.profile_id) + '</span></div>';
      });
    });
    html += '</div></div>';
  });
  box.innerHTML = html;
  qa('#venueTree .tgl').forEach(function (r) {
    r.addEventListener('click', function () { r.parentNode.classList.toggle('open'); });
  });
}
async function openVenue(id) {
  var v = id ? await api('/api/kb/venue_detail?id=' + encodeURIComponent(id)) : { nodes: [] };
  State.venueDraft = JSON.parse(JSON.stringify(v));
  if (!State.venueDraft.nodes || !State.venueDraft.nodes.length) {
    State.venueDraft.nodes = [{
      node_id: 'node_1', name: '主解码器', source: 'manual', ip: '127.0.0.1', protocol: 'artnet', groups: [],
      discovery: { online: null, artpoll_reply: null, rtt_ms: null, first_seen: null, last_seen: null },
      offline_policy: { mode: 'threshold', liveness_source: 'artdmx', threshold_sec: 5, grace_period_sec: 2,
                        severity: 'warning', actions: ['log', 'banner', 'toast'], auto_recover: true },
      ports: [{ port_id: 'p1', label: 'A', label_style: 'alpha', universe: 0, direction: 'out', fixtures: [] }]
    }];
  }
  $('venueTitle').textContent = id ? ('编辑场地 · ' + (v.venue_name || id)) : '新建场地拓扑';
  $('vnId').value = v.venue_id || '';
  $('vnId').disabled = !!id;
  $('vnName').value = v.venue_name || '';
  $('vnIp').value = v.default_target_ip || '127.0.0.1';
  $('vnConflict').innerHTML = '';
  renderVenueDraft();
  openModal('modalVenue');
}
function renderVenueDraft() {
  var box = $('vnNodes');
  var nodes = draft().nodes || [];
  if (!nodes.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-server"></i><div class="t">尚无解码器</div><div class="d">点击「添加解码器」开始构建拓扑。</div></div>';
    return;
  }
  var html = '';
  nodes.forEach(function (n, ni) {
    html += '<div style="border:1px solid var(--line);border-radius:var(--r-md);margin-bottom:10px;background:rgba(255,255,255,.02);">' +
      '<div class="row" style="padding:9px 12px;border-bottom:1px solid var(--line);gap:9px;">' +
        '<i class="fa-solid fa-server" style="color:var(--brand);"></i>' +
        '<input type="text" class="vn-name" data-ni="' + ni + '" value="' + esc(n.name) + '" style="flex:1;height:28px;font-size:12px;">' +
        '<input type="text" class="vn-ip mono" data-ni="' + ni + '" value="' + esc(n.ip) + '" style="width:130px;height:28px;font-size:12px;">' +
        '<span class="badge badge-mute">' + ((n.ports || []).length) + ' 接口</span>' +
        '<button class="btn btn-xs" data-ni="' + ni + '" data-act="cfg"><i class="fa-solid fa-gear"></i> 策略</button>' +
        '<button class="btn btn-xs" data-ni="' + ni + '" data-act="addport"><i class="fa-solid fa-plus"></i> 接口</button>' +
        '<button class="btn btn-xs btn-danger-ghost" data-ni="' + ni + '" data-act="rmnode"><i class="fa-solid fa-trash"></i></button>' +
      '</div>';
    (n.ports || []).forEach(function (p, pi) {
      html += '<div style="padding:7px 12px 7px 24px;border-bottom:1px solid var(--line);background:rgba(0,0,0,.12);">' +
        '<div class="row" style="gap:8px;">' +
          '<i class="fa-solid fa-ethernet" style="color:var(--brand);"></i>' +
          '<input type="text" class="vn-plabel" data-ni="' + ni + '" data-pi="' + pi + '" value="' + esc(p.label) + '" style="width:54px;height:26px;font-size:12px;text-align:center;">' +
          '<span class="dim fs-12">口 · Universe</span>' +
          '<input type="number" class="vn-puni" data-ni="' + ni + '" data-pi="' + pi + '" value="' + p.universe + '" style="width:64px;height:26px;font-size:12px;text-align:center;">' +
          '<select class="vn-pstyle" data-ni="' + ni + '" data-pi="' + pi + '" style="width:96px;height:26px;font-size:11px;">' +
            ['alpha|字母 A/B/C', 'numeric|数字 1/2/3', 'custom|自定义'].map(function (o) {
              var kv = o.split('|');
              return '<option value="' + kv[0] + '"' + ((p.label_style || 'alpha') === kv[0] ? ' selected' : '') + '>' + kv[1] + '</option>';
            }).join('') +
          '</select>' +
          '<span class="fs-11 dim">' + (p.fixtures || []).length + ' 台灯具</span>' +
          '<span style="flex:1;"></span>' +
          '<button class="btn btn-xs btn-primary" data-ni="' + ni + '" data-pi="' + pi + '" data-act="addfix"><i class="fa-solid fa-plus"></i> 灯具</button>' +
          '<button class="btn btn-xs btn-danger-ghost" data-ni="' + ni + '" data-pi="' + pi + '" data-act="rmport"><i class="fa-solid fa-xmark"></i></button>' +
        '</div>';
      (p.fixtures || []).forEach(function (f, fi) {
        html += '<div class="row" style="gap:8px;padding:5px 0 5px 22px;">' +
          '<i class="fa-solid fa-lightbulb" style="color:var(--warn);font-size:11px;"></i>' +
          '<span class="fs-12">' + esc(f.name) + '</span>' +
          '<span class="badge badge-mute mono">' + esc(f.profile_id) + '</span>' +
          '<span class="mono fs-11 dim">CH' + f.address + '</span>' +
          (f.allow_shared_address ? '<span class="badge badge-warn">共址</span>' : '') +
          '<span style="flex:1;"></span>' +
          '<button class="btn btn-xs btn-ghost" data-ni="' + ni + '" data-pi="' + pi + '" data-fi="' + fi + '" data-act="editfix"><i class="fa-solid fa-pen"></i></button>' +
          '<button class="btn btn-xs btn-ghost" data-ni="' + ni + '" data-pi="' + pi + '" data-fi="' + fi + '" data-act="rmfix"><i class="fa-solid fa-xmark"></i></button>' +
          '</div>';
      });
      html += '</div>';
    });
    html += '</div>';
  });
  box.innerHTML = html;

  qa('#vnNodes .vn-name').forEach(function (el) {
    el.addEventListener('input', function () { draft().nodes[+el.getAttribute('data-ni')].name = el.value; });
  });
  qa('#vnNodes .vn-ip').forEach(function (el) {
    el.addEventListener('input', function () { draft().nodes[+el.getAttribute('data-ni')].ip = el.value; });
  });
  qa('#vnNodes .vn-plabel').forEach(function (el) {
    el.addEventListener('input', function () {
      draft().nodes[+el.getAttribute('data-ni')].ports[+el.getAttribute('data-pi')].label = el.value;
    });
  });
  qa('#vnNodes .vn-puni').forEach(function (el) {
    el.addEventListener('input', function () {
      draft().nodes[+el.getAttribute('data-ni')].ports[+el.getAttribute('data-pi')].universe = parseInt(el.value, 10) || 0;
    });
  });
  qa('#vnNodes .vn-pstyle').forEach(function (el) {
    el.addEventListener('change', function () {
      var ni = +el.getAttribute('data-ni'), pi = +el.getAttribute('data-pi');
      var p = draft().nodes[ni].ports[pi];
      p.label_style = el.value;
      if (el.value === 'numeric') p.label = String(pi + 1);
      else if (el.value === 'alpha') p.label = String.fromCharCode(65 + pi);
      /* 立即回填序号输入框，让「A/B/C ⇄ 1/2/3」的切换是可见的 */
      var inp = qa('#vnNodes .vn-plabel').filter(function (x) {
        return +x.getAttribute('data-ni') === ni && +x.getAttribute('data-pi') === pi;
      })[0];
      if (inp) inp.value = p.label;
    });
  });
  qa('#vnNodes button[data-act]').forEach(function (b) {
    b.addEventListener('click', function () {
      var ni = +b.getAttribute('data-ni');
      var pi = b.getAttribute('data-pi') === null ? -1 : +b.getAttribute('data-pi');
      var fi = b.getAttribute('data-fi') === null ? -1 : +b.getAttribute('data-fi');
      var act = b.getAttribute('data-act');
      var node = draft().nodes[ni];
      if (act === 'cfg') openNodeEditor(ni);
      else if (act === 'rmnode') { draft().nodes.splice(ni, 1); renderVenueDraft(); }
      else if (act === 'addport') {
        var idx = (node.ports || []).length;
        node.ports.push({ port_id: 'p' + (idx + 1), label: String.fromCharCode(65 + (idx % 26)),
                          label_style: 'alpha', universe: idx, direction: 'out', fixtures: [] });
        renderVenueDraft();
      } else if (act === 'rmport') { node.ports.splice(pi, 1); renderVenueDraft(); }
      else if (act === 'addfix') openFixtureEditor(ni, pi, -1);
      else if (act === 'editfix') openFixtureEditor(ni, pi, fi);
      else if (act === 'rmfix') { node.ports[pi].fixtures.splice(fi, 1); renderVenueDraft(); }
    });
  });
}
function collectVenue() {
  var d = draft();
  return {
    venue_id: ($('vnId').value || '').trim(),
    venue_name: ($('vnName').value || '').trim(),
    default_target_ip: ($('vnIp').value || '').trim(),
    nodes: d.nodes || []
  };
}
function renderConflict(res, target) {
  var box = target || $('conflictBox');
  if (!res.conflicts || !res.conflicts.length) {
    box.innerHTML = '<div class="alert alert-ok"><i class="fa-solid fa-circle-check"></i><div><b>未发现冲突</b><br>共校验 ' +
      (res.checked_fixtures || 0) + ' 台灯具，覆盖 ' + (res.universe_count || 0) + ' 条 Universe。</div></div>';
    return;
  }
  var html = '<div class="row mb-3" style="gap:8px;">' +
    (res.danger_count ? '<span class="badge badge-danger">' + res.danger_count + ' 项冲突</span>' : '') +
    (res.notice_count ? '<span class="badge badge-warn">' + res.notice_count + ' 项提示</span>' : '') + '</div>';
  res.conflicts.forEach(function (c) {
    var danger = c.severity === 'danger';
    html += '<div class="alert ' + (danger ? 'alert-danger' : 'alert-warn') + '" style="margin-bottom:7px;">' +
      '<i class="fa-solid ' + (danger ? 'fa-circle-xmark' : 'fa-triangle-exclamation') + '"></i>' +
      '<div><b>' + esc({ overflow: '通道越界', underflow: '地址非法', overlap: '地址重叠', shared_address: '共址提示', missing_profile: '灯库缺失' }[c.type] || c.type) + '</b>' +
      ' <span class="mono fs-11 dim">Universe ' + c.universe + '</span><br>' + esc(c.desc) + '</div></div>';
  });
  box.innerHTML = html;
}
async function checkDraft() {
  var res = await api('/api/kb/check_conflicts', { venue: collectVenue() });
  renderConflict(res, $('vnConflict'));
}
async function saveVenue() {
  var d = collectVenue();
  if (!d.venue_id) { toast('warn', '缺少 Venue ID', ''); return; }
  var res = await api('/api/kb/save_venue', d);
  if (ok(res)) {
    closeModal('modalVenue');
    await loadKbVenues(); await loadKbSummary();
    toast('ok', '场地已保存', res.node_count + ' 解码器 / ' + res.fixture_count + ' 台灯具');
  } else { toast('error', '保存失败', res.message || ''); }
}
async function delVenue(id) {
  if (!await askConfirm('删除场地', '确定删除 <b>' + esc(id) + '</b> ？', '删除', true)) return;
  var res = await api('/api/kb/delete_venue', { venue_id: id });
  if (ok(res)) { await loadKbVenues(); await loadKbSummary(); toast('ok', '已删除', id); }
  else toast('error', '删除被拒绝', res.message || '');
}
async function switchVenue(id) {
  var res = await api('/api/kb/switch_venue', { venue_id: id });
  if (ok(res)) {
    await loadKbVenues(); await loadKbSummary(); renderScenePanel();
    toast('ok', '工作场地已切换', res.venue_name + ' · ' + res.fixture_count + ' 台灯具');
  } else toast('error', '切换失败', res.message || '');
}
async function scanConflicts() {
  var res = await api('/api/kb/conflicts');
  renderConflict(res, $('conflictBox'));
  toast(res.has_conflict ? 'warn' : 'ok', '扫描完成',
        res.has_conflict ? (res.danger_count + ' 项冲突需处理') : '全场通道无冲突');
}

/* ============================================================================
   9. 知识库 · 美学预设（自定义分类 + 通道属性驱动）
   ========================================================================== */
async function loadKbPresets() {
  State.presets = (await api('/api/kb/presets')) || {};
  var reg = await api('/api/kb/categories');
  State.categories = (reg && reg.categories) || [];
  var ag = await api('/api/kb/attribute_groups');
  State.attrGroups = (ag && ag.groups) || [];
  renderPresetChips();
  renderPresetGroups();
}
function validPresetKeys() {
  return Object.keys(State.presets || {}).filter(function (k) {
    if (k.startsWith('_')) return false;
    var p = State.presets[k];
    return p && typeof p === 'object' && (p.name || p.channel_values || p.category_id !== undefined);
  });
}

function presetCountOf(catId) {
  var n = 0;
  validPresetKeys().forEach(function (k) {
    var p = State.presets[k];
    var c = p.category_id || '__none__';
    if (catId === '__all__' || c === catId) n++;
  });
  return n;
}
function renderPresetChips() {
  var box = $('presetChips');
  var html = '<div class="chip' + (State.activePresetCat === '__all__' ? ' active' : '') + '" data-cat="__all__">' +
    '<i class="fa-solid fa-border-all"></i> 全部<span class="chip-count">' + presetCountOf('__all__') + '</span></div>';
  State.categories.forEach(function (c) {
    html += catChipHTML(c, presetCountOf(c.id), State.activePresetCat === c.id);
  });
  var orphan = presetCountOf('__none__');
  if (orphan) {
    html += '<div class="chip' + (State.activePresetCat === '__none__' ? ' active' : '') + '" data-cat="__none__" ' +
      'style="border-color:rgba(245,158,11,.45);color:var(--warn);">' +
      '<i class="fa-solid fa-triangle-exclamation"></i> 待归类<span class="chip-count">' + orphan + '</span></div>';
  }
  box.innerHTML = html;
  qa('#presetChips .chip').forEach(function (el) {
    el.addEventListener('click', function () {
      State.activePresetCat = el.getAttribute('data-cat');
      renderPresetChips();
      renderPresetGroups();
    });
  });
}
function renderPresetGroups() {
  var box = $('presetGroups');
  var keys = validPresetKeys();
  if (!keys.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-palette"></i><div class="t">预设库为空</div>' +
      '<div class="d">点击「新增预设」创建第一条。预设内容由基准灯型的通道属性自由定义。</div></div>';
    return;
  }
  var groups = [];
  if (State.activePresetCat === '__all__') {
    State.categories.forEach(function (c) {
      groups.push({ id: c.id, name: c.name, color: c.color, icon: c.icon, keys: [] });
    });
    groups.push({ id: '__none__', name: '待归类', color: '#f59e0b', icon: null, keys: [] });
  } else {
    var c = catByID(State.activePresetCat);
    groups.push({
      id: State.activePresetCat,
      name: c ? c.name : '待归类',
      color: c ? c.color : '#f59e0b',
      icon: c ? c.icon : null,
      keys: []
    });
  }
  var gmap = {};
  groups.forEach(function (g) { gmap[g.id] = g; });
  keys.forEach(function (k) {
    var cid = State.presets[k].category_id || '__none__';
    if (gmap[cid]) {
      gmap[cid].keys.push(k);
    }
  });

  var html = '';
  groups.forEach(function (g) {
    if (!g.keys.length) return;
    html += '<div class="catgroup-head"><span style="color:' + esc(g.color) + ';">' +
      catIconHTML(g.icon) + esc(g.name) + '</span><span class="n">' + g.keys.length + ' 条</span>' +
      '<span class="spacer"></span></div>';
    html += '<div class="preset-grid">';
    g.keys.forEach(function (k) { html += presetCardHTML(k, State.presets[k], g); });
    html += '</div>';
  });
  if (!html) {
    html = '<div class="empty"><i class="fa-solid fa-folder-open"></i><div class="t">该分类下暂无预设</div>' +
      '<div class="d">切换到「全部」查看其他分类，或新增一条预设。</div></div>';
  }
  box.innerHTML = html;
  qa('#presetGroups .pcard').forEach(function (el) {
    el.addEventListener('click', function () { openPreset(el.getAttribute('data-key')); });
  });
}
function presetCardHTML(key, p, g) {
  var cv = p.channel_values || {};
  var hex = p.color || valuesToHex(cv) || '#38bdf8';
  var icon = p.icon || 'fa-palette';
  var attrN = Object.keys(cv).length;
  return '<div class="pcard" data-key="' + esc(key) + '" title="点击进入详情以修改或删除">' +
    '<div class="pcard-swatch" style="background:' + esc(hex) + ';box-shadow:inset 0 0 16px rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;text-shadow:0 0 10px rgba(0,0,0,.7);">' +
      '<i class="' + esc(faIcon(icon)) + '"></i>' +
    '</div>' +
    '<div class="pcard-name">' + esc(p.name || key) + '</div>' +
    '<div class="pcard-meta">' +
      '<span class="pcard-cat" style="color:' + esc(g.color) + ';">' + catIconHTML(g.icon) + esc(g.name) + '</span>' +
      '<span class="pcard-attrs">' + attrN + ' 项 · ' + (p.transition_ms || 1000) + 'ms</span>' +
    '</div>' +
    (p.category_id ? '' : '<span class="pcard-flag">待归类</span>') +
    (p.universal ? '<span class="pcard-universal">通用</span>' : '') +
    '</div>';
}

async function openPreset(key) {
  var isNew = !key;
  State.editingPreset = isNew ? null : key;
  var p = isNew
    ? { name: '', category_id: State.activePresetCat !== '__all__' && State.activePresetCat !== '__none__'
          ? State.activePresetCat : (State.categories[0] ? State.categories[0].id : ''),
        profile_ref: null, channel_values: {}, transition_ms: 1000, summary: '', tags: [], universal: true }
    : JSON.parse(JSON.stringify(State.presets[key]));

  $('presetTitle').textContent = isNew ? '新增美学预设' : ('预设详情 · ' + (p.name || key));
  $('presetSub').textContent = isNew
    ? '内容由基准灯型的通道属性自由定义，属性数量无上限。'
    : '修改与删除均在此完成，列表卡片为只读。';

  var sel = $('pdCategory');
  sel.innerHTML = '<option value="">— 请选择分类（必选）—</option>' + State.categories.map(function (c) {
    return '<option value="' + esc(c.id) + '"' + (p.category_id === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
  }).join('');

  var psel = $('pdProfile');
  psel.innerHTML = '<option value="">— 未指定（跨灯型通用）—</option>' + State.profiles.map(function (x) {
    return '<option value="' + esc(x.profile_id) + '"' + (p.profile_ref === x.profile_id ? ' selected' : '') + '>' +
           esc(x.profile_id) + '（' + esc(x.model || '') + ' · ' + x.channel_count + 'CH）</option>';
  }).join('');

  $('pdName').value = p.name || '';
  $('pdTransition').value = p.transition_ms || 1000;
  $('pdSummary').value = p.summary || '';
  $('pdTags').value = (p.tags || []).join('、');
  var defColor = p.color || valuesToHex(p.channel_values) || '#38bdf8';
  $('pdColor').value = defColor;
  $('pdColorHex').value = defColor;
  $('pdIcon').value = p.icon || 'fa-palette';
  $('pdJson').value = JSON.stringify(p.channel_values || {}, null, 2);
  $('pdSwatch').style.background = defColor;
  $('pdSwatch').style.display = 'flex';
  $('pdSwatch').style.alignItems = 'center';
  $('pdSwatch').style.justifyContent = 'center';
  $('pdSwatch').innerHTML = '<i class="' + esc(faIcon($('pdIcon').value)) + '" style="font-size:32px;color:#fff;text-shadow:0 0 12px rgba(0,0,0,.6);"></i>';
  $('pdSwatchCap').textContent = Object.keys(p.channel_values || {}).length + ' 个属性已赋值';

  setPresetMode(p.profile_ref || isNew ? 'form' : 'json', p);
  $('btnDeletePreset').style.display = isNew ? 'none' : '';
  openModal('modalPreset');
}

function setPresetMode(mode, p) {
  State.presetMode = mode;
  qa('#presetModeSeg .seg-item').forEach(function (s) { s.classList.toggle('active', s.getAttribute('data-mode') === mode); });
  $('pdFormMode').style.display = mode === 'form' ? '' : 'none';
  $('pdJsonMode').style.display = mode === 'json' ? '' : 'none';
  $('pdProfileHint').textContent = mode === 'form'
    ? '属性表单模式下必选；选好灯型后下方会按该灯库的真实通道属性渲染控件。'
    : 'JSON 直输模式下可留空，表示该预设跨灯型通用。';
  if (mode === 'form') renderAttrEditor();
}
function currentFormValues() {
  try { return JSON.parse($('pdJson').value || '{}'); } catch (e) { return {}; }
}
function renderAttrEditor() {
  var box = $('pdAttrGroups');
  var pid = $('pdProfile').value;
  var search = ($('pdSearch').value || '').trim().toLowerCase();
  if (!pid) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-lightbulb"></i><div class="t">请先选择基准灯型</div>' +
      '<div class="d">选定后，这里会列出该灯库全部受控通道属性（危险通道已自动排除）。若要做跨灯型通用预设，请切换到「JSON 直输」。</div></div>';
    $('presetAttrCount').textContent = '—';
    return;
  }
  var prof = State.profiles.filter(function (x) { return x.profile_id === pid; })[0];
  var attrs = (prof && prof.channels) ? prof.channels.filter(function (c) { return c.is_safe !== false; }) : [];
  if (search) {
    attrs = attrs.filter(function (c) {
      return String(c.type).toLowerCase().indexOf(search) >= 0 || String(c.name).indexOf(search) >= 0;
    });
  }
  $('presetAttrCount').textContent = attrs.length + ' 个可调属性';
  if (!attrs.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-filter"></i><div class="t">没有匹配的属性</div></div>';
    return;
  }

  /* 按用户自定义的属性分组归类；未命中分组的落到「其他」 */
  var gmap = {};
  State.attrGroups.forEach(function (g) { gmap[g.id] = { g: g, list: [] }; });
  var other = { g: { id: '_other', name: '其他', color: '#94a3b8' }, list: [] };
  var attr2g = {};
  State.attrGroups.forEach(function (g) { (g.attrs || []).forEach(function (a) { attr2g[a] = g.id; }); });
  attrs.forEach(function (c) {
    var gid = attr2g[c.type];
    if (gid && gmap[gid]) gmap[gid].list.push(c); else other.list.push(c);
  });

  var vals = currentFormValues();
  var html = '';
  var buckets = Object.keys(gmap).map(function (k) { return gmap[k]; }).filter(function (b) { return b.list.length; });
  if (other.list.length) buckets.push(other);

  buckets.forEach(function (b) {
    var open = !!search || true;
    html += '<div class="attr-group' + (open ? ' open' : '') + '">' +
      '<div class="attr-head"><i class="fa-solid fa-chevron-right caret"></i>' +
      '<span class="chip-dot" style="background:' + esc(b.g.color) + ';"></span>' +
      '<span class="name">' + esc(b.g.name) + '</span>' +
      '<span class="n">' + b.list.length + '</span></div><div class="attr-body">';
    b.list.forEach(function (c) {
      var has = vals[c.type] != null;
      var v = has ? vals[c.type] : (c.default || 0);
      var slots = c.slots || [];
      html += '<div class="attr-row' + (has ? '' : ' disabled') + '" data-attr="' + esc(c.type) + '">' +
        '<label class="row" style="gap:7px;"><input type="checkbox" class="ar-on"' + (has ? ' checked' : '') + '>' +
        '<span class="an">' + esc(c.name) + '<span class="ty">' + esc(c.type) + ' · CH' + c.ch + '</span></span></label>';
      var rng = c.range || [0, 255];
      if (slots.length) {
        html += '<select class="ar-val" style="width:180px;">' +
          '<option value="' + v + '">— 保持当前 (' + v + ') —</option>' +
          slots.map(function (s) {
            return '<option value="' + s.v + '"' + (has && Number(v) === Number(s.v) ? ' selected' : '') + '>' +
                   s.v + ' · ' + esc(s.label) + '</option>';
          }).join('') + '</select>';
      } else {
        html += '<div class="row" style="gap:7px;">' +
          '<input type="range" class="ar-range" min="' + rng[0] + '" max="' + rng[1] + '" value="' + v + '" style="width:116px;">' +
          '<input type="number" class="ar-num" min="0" max="255" value="' + v + '" style="width:60px;">' +
          '<span class="fs-11 dim">' + rng[0] + '–' + rng[1] + '</span></div>';
      }
      html += '</div>';
    });
    html += '</div></div>';
  });
  box.innerHTML = html;

  qa('#pdAttrGroups .attr-head').forEach(function (h) {
    h.addEventListener('click', function () { h.parentNode.classList.toggle('open'); });
  });
  qa('#pdAttrGroups .attr-row').forEach(function (row) {
    var attr = row.getAttribute('data-attr');
    var cb = row.querySelector('.ar-on');
    var num = row.querySelector('.ar-num');
    var rng = row.querySelector('.ar-range');
    var sel = row.querySelector('.ar-val');
    function sync() { syncAttrToJson(attr, row, cb.checked); }
    cb.addEventListener('change', function () {
      row.classList.toggle('disabled', !cb.checked);
      if (num) num.disabled = !cb.checked;
      if (rng) rng.disabled = !cb.checked;
      sync();
    });
    if (num) {
      num.addEventListener('input', function () { if (rng) rng.value = num.value; sync(); });
      if (rng) rng.addEventListener('input', function () { num.value = rng.value; sync(); });
    }
    if (sel) sel.addEventListener('change', sync);
  });
}
function syncAttrToJson(attr, row, on) {
  var cur;
  try { cur = JSON.parse($('pdJson').value || '{}'); } catch (e) { cur = {}; }
  if (on) {
    var sel = row.querySelector('.ar-val');
    var num = row.querySelector('.ar-num');
    cur[attr] = clamp255(sel ? sel.value : (num ? num.value : 0));
  } else {
    delete cur[attr];
  }
  $('pdJson').value = JSON.stringify(cur, null, 2);
  $('pdSwatch').style.background = valuesToHex(cur) || 'var(--bg-elev)';
  $('pdSwatchCap').textContent = Object.keys(cur).length + ' 个属性已赋值';
}
async function savePreset() {
  var name = ($('pdName').value || '').trim();
  if (!name) { toast('warn', '缺少预设名称', ''); return; }
  var cid = $('pdCategory').value;
  if (!cid) { toast('warn', '必须选择分类', '每条预设都必须强制归属一个分类。'); return; }

  var cv;
  try { cv = JSON.parse($('pdJson').value || '{}'); }
  catch (e) { toast('error', '通道取值 JSON 语法错误', String(e.message)); return; }
  if (!Object.keys(cv).length) { toast('warn', '未定义任何属性', '请至少为一个通道属性赋值。'); return; }

  var pid = $('pdProfile').value || null;
  if (State.presetMode === 'form' && !pid) {
    toast('warn', '表单模式必须选择基准灯型', '如需跨灯型通用，请切换到「JSON 直输」。');
    return;
  }
  var clean = {};
  Object.keys(cv).forEach(function (k) { clean[k] = clamp255(cv[k]); });

  var chosenColor = ($('pdColorHex').value || $('pdColor').value || '').trim();
  var chosenIcon = ($('pdIcon').value || 'fa-palette').trim();

  var key = State.editingPreset || (name.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '_') + '_' + Date.now().toString(36).slice(-4));
  var res = await api('/api/kb/save_preset', {
    preset_id: key,
    preset: {
      name: name, category_id: cid, profile_ref: pid,
      color: chosenColor, icon: chosenIcon,
      universal: !pid,
      channel_values: clean,
      transition_ms: parseInt($('pdTransition').value, 10) || 1000,
      summary: ($('pdSummary').value || '').trim(),
      tags: ($('pdTags').value || '').split(/[、,，]/).map(function (s) { return s.trim(); }).filter(Boolean)
    }
  });
  if (ok(res)) {
    closeModal('modalPreset');
    await loadKbPresets(); renderScenePanel();
    toast('ok', res.created ? '预设已新增' : '预设已更新', name + ' · ' + Object.keys(clean).length + ' 个属性');
  } else { toast('error', '保存失败', res.message || ''); }
}
async function deletePreset() {
  if (!State.editingPreset) return;
  var p = State.presets[State.editingPreset];
  if (!await askConfirm('删除美学预设', '确定删除 <b>' + esc(p ? p.name : State.editingPreset) + '</b> ？该操作不可撤销。', '删除', true)) return;
  var res = await api('/api/kb/delete_preset', { preset_id: State.editingPreset });
  if (ok(res)) {
    closeModal('modalPreset');
    await loadKbPresets(); renderScenePanel();
    toast('ok', '预设已删除', '');
  } else toast('error', '删除失败', res.message || '');
}

/* --------------------------- 分类 / 属性分组管理 --------------------------- */
var catDraft = [], agDraft = [];
function openCategories() {
  catDraft = JSON.parse(JSON.stringify(State.categories));
  agDraft = JSON.parse(JSON.stringify(State.attrGroups));
  renderCatList();
  renderAgList();
  qa('#catRegSeg .seg-item').forEach(function (s) { s.classList.toggle('active', s.getAttribute('data-reg') === 'cat'); });
  $('reg-pane-cat').style.display = '';
  $('reg-pane-ag').style.display = 'none';
  openModal('modalCategories');
}
function renderCatList() {
  var box = $('catList');
  if (!catDraft.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-tags"></i><div class="t">暂无分类</div><div class="d">至少创建一个分类后，预设才能保存。</div></div>';
    return;
  }
  var html = '';
  catDraft.forEach(function (c, i) {
    var cnt = presetCountOf(c.id);
    html += '<div class="catrow" data-i="' + i + '">' +
      '<input type="color" class="ct-color" value="' + esc(c.color || '#38bdf8') + '" style="width:34px;height:30px;padding:2px;">' +
      '<input type="text" class="ct-name" value="' + esc(c.name || '') + '" style="flex:1;height:30px;font-size:12px;">' +
      '<div class="catrow-preview" style="color:' + esc(c.color || '#38bdf8') + ';">' +
        catIconHTML(c.icon) + esc(c.name || '预览') + '</div>' +
      '<select class="ct-mode" style="width:104px;height:30px;font-size:11px;">' +
        [['none', '纯文字'], ['builtin', '内置图标'], ['upload', '上传图标']].map(function (o) {
          return '<option value="' + o[0] + '"' + (((c.icon || {}).mode || 'none') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
        }).join('') + '</select>' +
      '<input type="text" class="ct-builtin mono" value="' + esc((c.icon || {}).builtin || '') + '" placeholder="fa-solid fa-star"' +
        ' style="width:150px;height:30px;font-size:11px;' + ((((c.icon || {}).mode) === 'builtin') ? '' : 'display:none;') + '">' +
      '<input type="file" class="ct-file" accept="image/svg+xml,image/png" style="width:150px;font-size:11px;' +
        ((((c.icon || {}).mode) === 'upload') ? '' : 'display:none;') + '">' +
      '<span class="badge badge-mute">' + cnt + ' 条预设</span>' +
      '<button class="btn btn-xs btn-danger-ghost ct-del"><i class="fa-solid fa-trash"></i></button>' +
      '</div>';
  });
  box.innerHTML = html;
  qa('#catList .catrow').forEach(function (row) {
    var i = +row.getAttribute('data-i');
    row.querySelector('.ct-name').addEventListener('input', function () {
      catDraft[i].name = this.value;
      row.querySelector('.catrow-preview').innerHTML = catIconHTML(catDraft[i].icon) + esc(this.value || '预览');
    });
    row.querySelector('.ct-name').addEventListener('change', function () {
      catDraft[i].name = this.value.trim() || catDraft[i].id;
    });
    row.querySelector('.ct-color').addEventListener('input', function () {
      catDraft[i].color = this.value;
      row.querySelector('.catrow-preview').style.color = this.value;
    });
    row.querySelector('.ct-mode').addEventListener('change', function () {
      catDraft[i].icon = catDraft[i].icon || { mode: 'none', builtin: '', upload: '', align: 'inline' };
      catDraft[i].icon.mode = this.value;
      row.querySelector('.ct-builtin').style.display = this.value === 'builtin' ? '' : 'none';
      row.querySelector('.ct-file').style.display = this.value === 'upload' ? '' : 'none';
      row.querySelector('.catrow-preview').innerHTML = catIconHTML(catDraft[i].icon) + esc(catDraft[i].name || '预览');
    });
    row.querySelector('.ct-builtin').addEventListener('input', function () {
      catDraft[i].icon = catDraft[i].icon || { mode: 'builtin', builtin: '', upload: '', align: 'inline' };
      catDraft[i].icon.mode = 'builtin';
      catDraft[i].icon.builtin = this.value;
      row.querySelector('.catrow-preview').innerHTML = catIconHTML(catDraft[i].icon) + esc(catDraft[i].name || '预览');
    });
    row.querySelector('.ct-file').addEventListener('change', function () {
      var f = this.files && this.files[0];
      if (!f) return;
      if (f.size > 40 * 1024) { toast('warn', '图标过大', '请使用小于 40KB 的 SVG 或 PNG。'); return; }
      var fr = new FileReader();
      fr.onload = function () {
        catDraft[i].icon = catDraft[i].icon || { mode: 'upload', builtin: '', upload: '', align: 'inline' };
        catDraft[i].icon.mode = 'upload';
        catDraft[i].icon.upload = fr.result;
        row.querySelector('.catrow-preview').innerHTML = catIconHTML(catDraft[i].icon) + esc(catDraft[i].name || '预览');
        renderCatList();
      };
      fr.readAsDataURL(f);
    });
    row.querySelector('.ct-del').addEventListener('click', async function () {
      if (presetCountOf(catDraft[i].id)) {
        toast('error', '无法删除', '该分类下仍有 ' + presetCountOf(catDraft[i].id) + ' 条预设，请先移出。');
        return;
      }
      catDraft.splice(i, 1);
      renderCatList();
    });
  });
}
function addCat() {
  catDraft.push({
    id: 'cat_' + Date.now().toString(36),
    name: '新分类', color: '#38bdf8', order: catDraft.length,
    icon: { mode: 'none', builtin: '', upload: '', align: 'inline' }
  });
  renderCatList();
}
function renderAgList() {
  var box = $('agList');
  if (!agDraft.length) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-layer-group"></i><div class="t">暂无属性分组</div>' +
      '<div class="d">所有属性会集中显示在「其他」分组下。</div></div>';
    return;
  }
  var html = '';
  agDraft.forEach(function (g, i) {
    html += '<div class="catrow" data-i="' + i + '" style="align-items:flex-start;flex-direction:column;padding:11px 13px;">' +
      '<div class="row" style="gap:9px;width:100%;">' +
        '<input type="color" class="ag-color" value="' + esc(g.color || '#38bdf8') + '" style="width:34px;height:30px;padding:2px;">' +
        '<input type="text" class="ag-name" value="' + esc(g.name || '') + '" style="width:170px;height:30px;font-size:12px;">' +
        '<span class="badge badge-mute">' + (g.attrs || []).length + ' 个属性</span>' +
        '<span style="flex:1;"></span>' +
        '<button class="btn btn-xs btn-danger-ghost ag-del"><i class="fa-solid fa-trash"></i></button>' +
      '</div>' +
      '<input type="text" class="ag-attrs mono" value="' + esc((g.attrs || []).join(', ')) + '" ' +
        'placeholder="dimmer, strobe, red, green, blue" style="width:100%;height:30px;font-size:11px;margin-top:7px;">' +
      '</div>';
  });
  box.innerHTML = html;
  qa('#agList .catrow').forEach(function (row) {
    var i = +row.getAttribute('data-i');
    row.querySelector('.ag-name').addEventListener('input', function () { agDraft[i].name = this.value; });
    row.querySelector('.ag-color').addEventListener('input', function () { agDraft[i].color = this.value; });
    row.querySelector('.ag-attrs').addEventListener('input', function () {
      agDraft[i].attrs = this.value.split(/[,，\s]+/).map(function (s) { return s.trim(); }).filter(Boolean);
    });
    row.querySelector('.ag-del').addEventListener('click', function () { agDraft.splice(i, 1); renderAgList(); });
  });
}
function addAg() {
  agDraft.push({ id: 'ag_' + Date.now().toString(36), name: '新分组', color: '#38bdf8', attrs: [] });
  renderAgList();
}
async function saveCats() {
  qa('#catList .catrow').forEach(function (row) {
    var i = +row.getAttribute('data-i');
    if (catDraft[i]) {
      var nameEl = row.querySelector('.ct-name');
      var colorEl = row.querySelector('.ct-color');
      if (nameEl) catDraft[i].name = (nameEl.value || '').trim() || catDraft[i].id;
      if (colorEl) catDraft[i].color = colorEl.value || catDraft[i].color;
    }
  });

  for (var ci = 0; ci < catDraft.length; ci++) {
    if (!catDraft[ci].name || !catDraft[ci].name.trim()) {
      toast('warn', '分类名称不能为空', '请为第 ' + (ci + 1) + ' 个分类填写名称。');
      return;
    }
  }

  var r1 = await api('/api/kb/save_attribute_groups', { groups: agDraft });
  if (!ok(r1)) { toast('error', '属性分组保存失败', r1.message || ''); return; }
  var r2 = await api('/api/kb/save_categories', {
    categories: catDraft.map(function (c, i) {
      return { id: c.id, name: c.name || c.id, color: c.color, order: i, icon: c.icon || { mode: 'none' } };
    })
  });
  if (!ok(r2)) { toast('error', '分类保存失败', r2.message || ''); return; }
  closeModal('modalCategories');
  await loadKbPresets();
  await loadKbSummary();
  renderScenePanel();
  toast('ok', '注册表已保存', catDraft.length + ' 个分类 · ' + agDraft.length + ' 个属性分组已持久化生效');
}

/* ============================================================================
   10. 总览 / AI 解析 / RAG
   ========================================================================== */
async function loadKbSummary() {
  var s = await api('/api/kb/summary');
  $('statProfiles').textContent = s.profiles_count || 0;
  $('statVenues').textContent = s.venues_count || 0;
  $('statPresets').textContent = s.presets_count || 0;
  $('statCats').textContent = s.categories_count || 0;
  $('statVenueName').textContent = s.active_venue_name || '—';
  $('statVenueFixtures').textContent = (s.active_node_count || 0) + ' 解码器 / ' +
    (s.active_port_count || 0) + ' 接口 / ' + (s.active_fixture_count || 0) + ' 灯具';
  $('kbPath').textContent = s.kb_path || '—';
  $('topVenue').textContent = s.active_venue_name || '未加载';
  var sel = $('ragVenue');
  sel.innerHTML = (State.venues || []).map(function (v) {
    return '<option value="' + esc(v.venue_id) + '"' + (v.is_active ? ' selected' : '') + '>' + esc(v.venue_name) + '</option>';
  }).join('');
}
// ===== AI 说明书解析：文件上传 / 拖拽 / 文本粘贴 统一入口 =====
var _aiFileData = null; // { b64: string, name: string, size: number }

function aiUploadInit() {
  var zone = $('aiUploadZone');
  var input = $('aiFileInput');
  if (!zone || !input) return;

  zone.addEventListener('click', function () { input.click(); });
  input.addEventListener('change', function () {
    if (input.files && input.files[0]) aiLoadFile(input.files[0]);
  });
  zone.addEventListener('dragover', function (e) {
    e.preventDefault(); zone.classList.add('drag-over');
  });
  zone.addEventListener('dragleave', function () {
    zone.classList.remove('drag-over');
  });
  zone.addEventListener('drop', function (e) {
    e.preventDefault();
    zone.classList.remove('drag-over');
    var f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) aiLoadFile(f);
  });

  var clearBtn = $('aiFileClear');
  if (clearBtn) clearBtn.addEventListener('click', function (e) {
    e.preventDefault(); aiClearFile();
  });
}

function aiLoadFile(file) {
  var allowed = ['.pdf', '.docx', '.txt', '.md'];
  var ext = file.name.slice(file.name.lastIndexOf('.')).toLowerCase();
  if (!allowed.includes(ext)) {
    toast('warn', '格式不支持', '请上传 PDF / DOCX / TXT / MD 格式说明书');
    return;
  }
  var reader = new FileReader();
  reader.onload = function (e) {
    var raw = e.target.result; // ArrayBuffer
    var bytes = new Uint8Array(raw);
    var binary = '';
    for (var i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    var b64 = btoa(binary);
    _aiFileData = { b64: b64, name: file.name, size: file.size };
    // 更新 UI
    $('aiFileName').textContent = file.name;
    $('aiFileSize').textContent = (file.size / 1024).toFixed(1) + ' KB';
    $('aiFileInfo').style.display = '';
    $('aiUploadZone').classList.add('has-file');
    $('aiSlicePreview').style.display = 'none';
    toast('ok', '文件已加载', file.name + '，点击「开始智能解析」开始提取通道表。');
  };
  reader.readAsArrayBuffer(file);
}

function aiClearFile() {
  _aiFileData = null;
  $('aiFileInput').value = '';
  $('aiFileInfo').style.display = 'none';
  $('aiUploadZone').classList.remove('has-file');
  $('aiSlicePreview').style.display = 'none';
}

async function aiParse() {
  var t = ($('aiText') && $('aiText').value) || '';
  var customPrompt = ($('aiCustomPrompt') && $('aiCustomPrompt').value) || '';

  if (!_aiFileData && !t.trim()) {
    toast('warn', '请先上传说明书文件或粘贴通道文本', '');
    return;
  }

  $('aiStatus').className = 'badge badge-warn';
  $('aiStatus').textContent = '解析中…';
  $('aiSlicePreview').style.display = 'none';
  $('btnAiParse').disabled = true;

  var payload = {};
  if (_aiFileData) {
    payload.file_b64 = _aiFileData.b64;
    payload.filename = _aiFileData.name;
  }
  if (t.trim()) payload.text = t.trim();
  if (customPrompt.trim()) payload.custom_prompt = customPrompt.trim();

  var res = await api('/api/kb/ai_extract_profile', payload);
  $('btnAiParse').disabled = false;

  if (ok(res) && res.data) {
    $('aiStatus').className = 'badge badge-ok';
    $('aiStatus').textContent = '解析完成';

    // 显示切片元数据预览（如果后端返回了）
    var meta = res.data._extract_meta;
    if (meta && meta.slice_meta) {
      var sm = meta.slice_meta;
      var sliceInfo = '';
      if (sm.strategy === 'smart_slice') {
        sliceInfo = '策略：智能切片 · 命中 ' + sm.hit_count + ' 处关键词 · 行 ' + sm.start_line + '→' + sm.end_line + ' · 切片 ' + sm.slice_length + ' 字符';
      } else if (sm.strategy === 'full_pass') {
        sliceInfo = '策略：全文送检（说明书较短，' + sm.slice_length + ' 字符）';
      } else {
        sliceInfo = '策略：' + (sm.strategy || '—') + ' · 切片 ' + (sm.slice_length || 0) + ' 字符';
      }
      $('aiSliceMeta').textContent = sliceInfo;
      $('aiSlicePreview').style.display = '';
    }

    // 填充灯库编辑器弹窗
    State.editingProfileId = null;
    $('profileTitle').textContent = 'AI 提取结果 · 请核对后保存';
    $('pfId').value = res.data.profile_id || '';
    $('pfId').disabled = false;
    $('pfMfr').value = res.data.manufacturer || '';
    $('pfModel').value = res.data.model || '';
    $('pfChannels').innerHTML = '';
    var chsAI = (res.data.channels || []).slice().sort(function(a, b) { return parseInt(a.ch || 0, 10) - parseInt(b.ch || 0, 10); });
    chsAI.forEach(function (c, idx) { addChannelRow(c, idx + 1); });
    openModal('modalProfile');

    var chCount = (res.data.channels || []).length;
    var dangerCount = (res.data.channels || []).filter(function (c) { return c.is_safe === false; }).length;
    var msg = chCount + ' 个通道已提取';
    if (dangerCount) msg += '，其中 ' + dangerCount + ' 个危险通道已自动标记 🔒';
    if (meta && meta.filename) msg += '（来源：' + meta.filename + '）';
    toast('ok', '解析完成', msg);
  } else {
    $('aiStatus').className = 'badge badge-danger';
    $('aiStatus').textContent = '解析失败';
    toast('error', '解析失败', res.message || '大模型未返回有效的 JSON 灯库结构');
  }
}
async function ragTest() {
  var qv = $('ragQuery').value || '';
  var res = await api('/api/kb/rag_test', { query: qv, venue_id: $('ragVenue').value || null });
  $('ragFixtures').textContent = JSON.stringify(res.matched_fixtures || [], null, 2);
  $('ragPreset').textContent = JSON.stringify(res.preset_hint || '未命中任何美学预设', null, 2);
}

/* ============================================================================
   11. 启动
   ========================================================================== */
async function loadSystemStatus() {
  var s = await api('/api/system/status');
  $('topTarget').textContent = s.target_ip || '—';
  $('topVenue').textContent = s.venue_name || '—';
  if ($('topTakeover') && $('topTakeoverBadge')) {
    var mode = s.arbitration_mode || 'ai_active';
    $('topTakeover').textContent = s.arbitration_label || 'AI主控 (30Hz)';
    $('topTakeoverBadge').className = 'badge ' + (
      mode === 'panic' ? 'badge-danger' :
      mode === 'ma_takeover' ? 'badge-warn' : 'badge-ok'
    );
  }
}

/* ============================================================================
   11. 用户管理 (超级管理员专属)
   ========================================================================== */
var currentEditingUser = null;
var currentEditingIsAdmin = false;

async function loadUsersList() {
  var tb = $('userListTbody');
  if (!tb) return;
  tb.innerHTML = '<tr><td colspan="6" class="dim tc">正在拉取角色账户与工作区状态…</td></tr>';
  var res = await api('/api/users/list');
  if (!ok(res) || !res.users) {
    tb.innerHTML = '<tr><td colspan="6" class="danger tc"><i class="fa-solid fa-lock"></i> 无权限查看用户列表（仅管理员可操作）</td></tr>';
    return;
  }
  var html = '';
  res.users.forEach(function (u) {
    var isPrimaryAdmin = Boolean(u.is_primary_admin || u.role === 'admin' && !u.is_superadmin);
    var roleBadge = isPrimaryAdmin ? '<span class="badge badge-brand"><i class="fa-solid fa-crown" style="color:#f59e0b;"></i> 系统主管理员</span>' :
                    u.role === 'engineer' ? '<span class="badge badge-ok">主控灯光师</span>' :
                    '<span class="badge badge-neutral">现场观察员</span>';
    var permDesc = isPrimaryAdmin ? '用户分配 · 插件生态 · 知识库管理 · 容灾备份' :
                   u.role === 'engineer' ? '灯光调控 · 场景编排 · 预设与工作区面板' :
                   '纯只读监控 · DMX通道监视 · 日志诊断';
    var wsStatus = u.has_custom_profile ? '<span class="badge badge-ok">独立工作区已激活</span>' :
                   '<span class="badge badge-neutral">初始空白工作区</span>';

    html += '<tr>' +
      '<td><b class="mono">@' + esc(u.username) + '</b>' + (isPrimaryAdmin ? ' <span class="badge badge-primary fs-11">可改名/改密</span>' : '') + '</td>' +
      '<td>' + esc(u.display_name) + '</td>' +
      '<td>' + roleBadge + '</td>' +
      '<td class="fs-12 dim">' + permDesc + '</td>' +
      '<td>' + wsStatus + '</td>' +
      '<td>' +
        '<button class="btn btn-xs btn-ghost btnEditUser" data-u="' + esc(u.username) + '" data-r="' + esc(u.role) + '" data-n="' + esc(u.display_name) + '" data-primary="' + (isPrimaryAdmin ? '1' : '0') + '"><i class="fa-solid fa-pen-to-square"></i> 修改账号/密码</button> ' +
        (isPrimaryAdmin ? '<span class="dim fs-11" style="margin-left:6px;"><i class="fa-solid fa-lock"></i> 主管理员受保护不可删除</span>' :
          '<button class="btn btn-xs btn-danger-ghost btnDelUser" data-u="' + esc(u.username) + '"><i class="fa-solid fa-trash"></i> 删除</button>') +
      '</td>' +
    '</tr>';
  });
  tb.innerHTML = html;

  qa('.btnEditUser').forEach(function (b) {
    b.addEventListener('click', function () {
      openUserModal(b.getAttribute('data-u'), b.getAttribute('data-r'), b.getAttribute('data-n'), b.getAttribute('data-primary') === '1');
    });
  });
  qa('.btnDelUser').forEach(function (b) {
    b.addEventListener('click', function () {
      deleteUser(b.getAttribute('data-u'));
    });
  });
}

function openUserModal(username, role, displayName, isPrimaryAdmin) {
  currentEditingUser = username || null;
  currentEditingIsAdmin = Boolean(isPrimaryAdmin);
  var isEdit = Boolean(username);
  
  if (isPrimaryAdmin) {
    $('userModalTitle').innerHTML = '<i class="fa-solid fa-crown" style="color:#f59e0b;"></i> 自行设定系统管理员账号名与密码';
  } else {
    $('userModalTitle').textContent = isEdit ? ('修改账户信息 · @' + username) : '创建新角色账户';
  }
  
  $('muUsername').value = username || '';
  // 主管理员支持自行修改用户名！普通编辑暂不可修改账户标识
  $('muUsername').disabled = (isEdit && !isPrimaryAdmin);
  $('muDisplayName').value = displayName || '';
  $('muRole').value = role || 'engineer';
  if (isPrimaryAdmin) {
    $('muRole').value = 'admin';
    $('muRole').disabled = true;
  } else {
    $('muRole').disabled = false;
  }
  $('muPassword').value = '';
  $('muPassword').placeholder = isEdit ? '留空则保持原密码不变，输入新密码即修改' : '设置初始登录密码';
  
  // 主管理员严禁删除
  $('btnDeleteUser').style.display = (isEdit && !isPrimaryAdmin) ? '' : 'none';
  openModal('modalUser');
}

async function saveUser() {
  var u = ($('muUsername').value || '').trim().toLowerCase();
  if (!u) { toast('warn', '缺少用户名', '请输入登录账户名'); return; }
  var r = currentEditingIsAdmin ? 'admin' : $('muRole').value;
  var p = ($('muPassword').value || '').trim();
  var d = ($('muDisplayName').value || '').trim();

  if (!currentEditingUser && !p) {
    toast('warn', '新建用户必须设置初始密码', '');
    return;
  }

  // 若为主管理员且修改了账号名
  if (currentEditingUser && currentEditingIsAdmin && u !== currentEditingUser.toLowerCase()) {
    var rRes = await api('/api/users/rename_admin', { old_username: currentEditingUser, new_username: u });
    if (!ok(rRes)) {
      toast('error', '更名失败', rRes.message || '无法修改管理员账号名');
      return;
    }
    toast('ok', '管理员账号已更名', currentEditingUser + ' -> ' + u);
    // 若当前登录的就是此管理员，更新本地状态
    if (currentUser && currentUser.username && currentUser.username.toLowerCase() === currentEditingUser.toLowerCase()) {
      currentUser.username = u;
    }
    currentEditingUser = u;
  }

  var targetUser = currentEditingUser || u;
  var res = await api('/api/users/save', { username: targetUser, role: r, password: p || null, display_name: d || targetUser });
  if (ok(res)) {
    toast('ok', '用户与安全凭证已保存', '配置已同步并执行安全快照保护');
    closeModal('modalUser');
    loadUsersList();
  } else {
    toast('error', '保存失败', res.message || '');
  }
}

async function deleteUser(username) {
  if (!await askConfirm('删除账户', '确定永久删除用户 <b>@' + esc(username) + '</b> 吗？<br>该用户的独立工作区配置将被安全销毁。', '确认删除', true)) return;
  var res = await api('/api/users/delete', { username: username });
  if (ok(res)) {
    toast('ok', '用户已删除', username);
    loadUsersList();
  } else {
    toast('error', '删除失败', res.message || '');
  }
}

/* ============================================================================
   12. 工业级容灾备份与跨用户交互 (双模式过滤 · 循环淘汰 · 脱敏安全展示)
   ========================================================================== */
var currentSnapMode = 'all'; // 'all' | 'auto' | 'manual'
var cachedSnapshots = [];

async function loadSnapshots() {
  var box = $('snapshotListBox');
  if (!box) return;
  box.innerHTML = '<div class="dim tc" style="padding:20px;">正在读取系统容灾快照…</div>';
  var res = await api('/api/backups/snapshots');
  if (!ok(res) || !res.snapshots) {
    box.innerHTML = '<div class="empty"><i class="fa-solid fa-clock-rotate-left"></i><div class="t">暂无快照数据</div><div class="d">系统将在关键操作时自动执行原子级备份</div></div>';
    return;
  }
  cachedSnapshots = res.snapshots;
  renderSnapshots();
}

function renderSnapshots() {
  var box = $('snapshotListBox');
  if (!box) return;

  var filtered = cachedSnapshots.filter(function (s) {
    if (currentSnapMode === 'auto') return s.type === 'auto';
    if (currentSnapMode === 'manual') return s.type === 'manual';
    return true;
  });

  // 严格限制显示数量：自动与手动各自最新最多 5 份
  if (currentSnapMode === 'all') {
    var autos = cachedSnapshots.filter(function(s){ return s.type === 'auto'; }).slice(0, 5);
    var mans = cachedSnapshots.filter(function(s){ return s.type === 'manual'; }).slice(0, 5);
    filtered = [].concat(mans, autos);
    filtered.sort(function(a, b){ return (b.created_at || 0) - (a.created_at || 0); });
  } else {
    filtered = filtered.slice(0, 5);
  }

  var countLabel = $('snapCountLabel');
  if (countLabel) countLabel.textContent = '共 ' + filtered.length + ' 份快照 (上限5份/类)';

  if (!filtered.length) {
    box.innerHTML = '<div class="dim tc" style="padding:24px;"><i class="fa-solid fa-filter"></i> 当前筛选模式下暂无快照数据</div>';
    return;
  }

  var html = '';
  filtered.forEach(function (s) {
    var isAuto = s.type === 'auto';
    var tagBadge = isAuto ? '<span class="badge badge-neutral"><i class="fa-solid fa-robot"></i> 自动</span>' :
                            '<span class="badge badge-brand"><i class="fa-solid fa-camera"></i> 手动</span>';
    var fileCount = Object.keys(s.files || {}).length;
    var timeStr = s.timestamp_str || new Date(s.created_at * 1000).toLocaleString();
    // 脱敏名称显示 (无任何后缀)
    var safeName = esc(s.snapshot_id);

    html += '<div style="margin-bottom:8px;padding:10px 12px;background:rgba(255,255,255,.025);border:1px solid var(--line);border-radius:var(--r-sm);">' +
      '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">' +
        '<div style="min-width:0;flex:1;">' +
          '<div class="row" style="gap:6px;flex-wrap:wrap;">' +
            tagBadge +
            '<b class="mono fs-12" style="color:var(--txt-0);">' + safeName + '</b>' +
            '<span class="fs-11 dim" style="margin-left:auto;"><i class="fa-solid fa-clock"></i> ' + timeStr + '</span>' +
          '</div>' +
          '<div class="fs-12" style="margin-top:4px;color:var(--txt-1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + esc(s.description || '全系统备份') + '">' +
            esc(s.description || '全系统基准快照') +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;padding-top:6px;border-top:1px dashed rgba(255,255,255,.06);">' +
        '<span class="fs-11 dim"><i class="fa-solid fa-shield-check" style="color:#10b981;"></i> ' + fileCount + ' 关键物模型 · SHA-256已校验</span>' +
        '<div class="btn-group">' +
          '<button class="btn btn-xs btn-primary btnRestoreSnap" data-id="' + safeName + '" title="一键安全回滚"><i class="fa-solid fa-rotate-left"></i> 回滚</button>' +
          '<button class="btn btn-xs btn-danger-ghost btnDeleteSnap" data-id="' + safeName + '" title="删除此快照"><i class="fa-solid fa-trash"></i> 删除</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  });
  box.innerHTML = html;

  qa('.btnRestoreSnap').forEach(function (b) {
    b.addEventListener('click', function () {
      restoreSnapshot(b.getAttribute('data-id'));
    });
  });
  qa('.btnDeleteSnap').forEach(function (b) {
    b.addEventListener('click', function () {
      deleteSnapshot(b.getAttribute('data-id'));
    });
  });
}

async function deleteSnapshot(snapshotId) {
  if (!await askConfirm(
    '删除系统快照',
    '确定永久删除系统快照 <b>' + esc(snapshotId) + '</b> 吗？<br><span class="danger fs-12">此物理快照文件将被彻底移除。</span>',
    '确认删除',
    true
  )) return;

  var res = await api('/api/backups/delete_snapshot', { snapshot_id: snapshotId });
  if (ok(res)) {
    toast('ok', '快照已删除', snapshotId);
    loadSnapshots();
  } else {
    toast('error', '删除失败', res.message || '');
  }
}

async function createManualSnapshot() {
  var desc = ($('snapDesc').value || '').trim();
  if (!desc) { toast('warn', '请填写快照说明', '如：联排前基准快照'); return; }
  var res = await api('/api/backups/create_snapshot', { description: desc });
  if (ok(res)) {
    toast('ok', '全系统快照创建成功', '已执行全量原子拷贝并计算 SHA-256 校验和');
    closeModal('modalSnapshot');
    loadSnapshots();
  } else {
    toast('error', '创建失败', res.message || '');
  }
}

async function restoreSnapshot(snapshotId) {
  if (!await askConfirm(
    '全系统灾备回滚',
    '<div style="line-height:1.7;"><b style="color:var(--danger);font-size:14px;"><i class="fa-solid fa-triangle-exclamation"></i> 警告：即将执行全系统状态回滚！</b><br>' +
    '目标快照：<b class="mono">' + esc(snapshotId) + '</b><br>' +
    '系统在回滚前会<b>自动创建一份回滚前保护快照</b>，确保任何操作均可再次溯源。<br>' +
    '确认立即恢复至该历史版本吗？</div>',
    '确认回滚',
    true
  )) return;

  var res = await api('/api/backups/restore_snapshot', { snapshot_id: snapshotId });
  if (ok(res)) {
    toast('ok', '系统恢复成功', '已按 SHA-256 校验和完成数据覆写与物模型热重载');
    await loadKbPresets();
    await loadPanelLayout();
    renderScenePanel();
    loadSnapshots();
  } else {
    toast('error', '回滚失败', res.message || '');
  }
}

async function saveHostUserBackup(forceRotate) {
  toast('info', '正在备份到主机', '正在封装当前工作区与预设至主机磁盘…');
  var res = await api('/api/backups/save_user_backup', { force_rotate: Boolean(forceRotate) });
  if (res && res.status === 'quota_full') {
    // 达到 5 个上限友好弹窗提示
    if (await askConfirm(
      '主机备份槽位已满 (5/5)',
      '<div style="line-height:1.7;">' +
      '您在主机上的工作区备份已达到<b>最大上限 5 份</b>。<br>' +
      '建议方案：<br>' +
      '1. 点击「导出本地」下载保存历史版本；<br>' +
      '2. 点击下方「自动覆盖最旧」，系统将淘汰您最旧的一份备份并保存当前最新状态。<br>' +
      '是否立即循环覆盖最旧备份？</div>',
      '自动覆盖最旧备份',
      true
    )) {
      saveHostUserBackup(true);
    }
    return;
  }
  if (ok(res)) {
    toast('ok', '工作区已备份至主机', res.safe_name || '');
    loadHostUserPkgs();
  } else {
    toast('error', '备份失败', res.message || '');
  }
}

async function loadHostUserPkgs() {
  var box = $('userPkgListBox');
  if (!box) return;
  box.innerHTML = '<div class="dim tc" style="padding:15px;">正在读取主机用户备份…</div>';
  var res = await api('/api/backups/user_pkgs');
  if (!ok(res) || !res.packages || !res.packages.length) {
    box.innerHTML = '<div class="dim tc" style="padding:15px;"><i class="fa-solid fa-inbox"></i> 主机暂无用户工作区备份，点击上方「备份到主机」立即创建</div>';
    var ind0 = $('userSlotIndicator');
    if (ind0) ind0.textContent = '已用: 0/5 槽位';
    return;
  }

  // 统计当前用户的备份数
  var myCount = 0;
  res.packages.forEach(function (p) {
    if (SESSION && SESSION.username === p.exported_by) myCount++;
  });
  var ind = $('userSlotIndicator');
  if (ind) {
    ind.textContent = '已用: ' + myCount + '/5 槽位';
    ind.className = myCount >= 5 ? 'badge badge-warn fs-11' : 'badge badge-brand fs-11';
  }

  var html = '';
  // 最多展示最新 5 个用户备份
  var displayList = res.packages.slice(0, 5);

  displayList.forEach(function (p) {
    var isSelf = SESSION && SESSION.username === p.exported_by;
    var userTag = isSelf ? '<span class="badge badge-brand">我的备份</span>' : ('<span class="badge badge-neutral">@' + esc(p.exported_by) + '</span>');
    var sizeKb = Math.round((p.size_bytes || 0) / 1024 * 10) / 10;
    // 脱敏名称显示 (坚决不显示 .json 后缀)
    var safeName = esc(p.safe_name || (p.filename ? p.filename.replace(/\.json$/i, '') : ''));

    html += '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:rgba(255,255,255,.03);border:1px solid var(--line);border-radius:var(--r-sm);margin-bottom:6px;">' +
      '<div style="min-width:0;flex:1;margin-right:8px;">' +
        '<div class="row" style="gap:6px;flex-wrap:wrap;">' +
          userTag +
          '<b class="mono fs-12" style="color:var(--txt-0);">' + safeName + '</b>' +
        '</div>' +
        '<div class="fs-11 dim" style="margin-top:3px;">' +
          '<i class="fa-solid fa-clock"></i> ' + esc(p.exported_at_str || '') +
          ' · ' + (p.preset_count || 0) + ' 预设 · ' + (p.group_count || 0) + ' 面板块 · ' + sizeKb + ' KB' +
        '</div>' +
      '</div>' +
      '<div class="btn-group" style="flex:none;">' +
        '<button class="btn btn-xs btn-success btnHostApplyMerge" data-fn="' + safeName + '" title="增量合并到当前工作区"><i class="fa-solid fa-code-merge"></i> 载入</button>' +
        '<button class="btn btn-xs btn-ghost btnHostApplyOverwrite" data-fn="' + safeName + '" title="完全覆写为该备份"><i class="fa-solid fa-arrows-rotate"></i> 覆盖</button>' +
        '<button class="btn btn-xs btn-ghost btnHostDownload" data-fn="' + safeName + '" title="下载本地副本"><i class="fa-solid fa-download"></i></button>' +
        '<button class="btn btn-xs btn-danger-ghost btnHostDelete" data-fn="' + safeName + '" title="删除此备份"><i class="fa-solid fa-trash"></i></button>' +
      '</div>' +
    '</div>';
  });
  box.innerHTML = html;

  qa('.btnHostApplyMerge').forEach(function (b) {
    b.addEventListener('click', function () {
      restoreHostUserBackup(b.getAttribute('data-fn'), 'merge');
    });
  });
  qa('.btnHostApplyOverwrite').forEach(function (b) {
    b.addEventListener('click', function () {
      restoreHostUserBackup(b.getAttribute('data-fn'), 'overwrite');
    });
  });
  qa('.btnHostDownload').forEach(function (b) {
    b.addEventListener('click', function () {
      downloadHostBackup(b.getAttribute('data-fn'));
    });
  });
  qa('.btnHostDelete').forEach(function (b) {
    b.addEventListener('click', function () {
      deleteHostBackup(b.getAttribute('data-fn'));
    });
  });
}

async function restoreHostUserBackup(safeName, mode) {
  var actionName = mode === 'overwrite' ? '完全覆盖当前工作区' : '增量合并到当前工作区';
  if (!await askConfirm(
    actionName,
    '确定从主机备份 <b>' + esc(safeName) + '</b> 载入配置吗？<br>操作模式：<b>' + (mode === 'overwrite' ? '完全覆盖现有设置' : '增量合并保留现有') + '</b>',
    '确认载入',
    mode === 'overwrite'
  )) return;

  var res = await api('/api/backups/restore_user_backup', { filename: safeName, mode: mode });
  if (ok(res)) {
    toast('ok', '工作区载入成功', res.message || '');
    await loadKbPresets();
    await loadPanelLayout();
    renderScenePanel();
  } else {
    toast('error', '载入失败', res.message || '');
  }
}

async function downloadHostBackup(safeName) {
  var res = await api('/api/backups/download_user_backup?filename=' + encodeURIComponent(safeName));
  if (res && res.package_id) {
    var jsonStr = JSON.stringify(res, null, 2);
    var blob = new Blob([jsonStr], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = safeName + '.json';
    a.click();
    URL.revokeObjectURL(url);
    toast('ok', '已下载主机备份', safeName);
  } else {
    toast('error', '下载失败', '未找到对应文件');
  }
}

async function deleteHostBackup(safeName) {
  if (!await askConfirm('从主机删除备份', '确定永久删除主机上的备份 <b>' + esc(safeName) + '</b> 吗？', '确认删除', true)) return;
  var res = await api('/api/backups/delete_user_backup', { filename: safeName });
  if (ok(res)) {
    toast('ok', '已从主机删除', safeName);
    loadHostUserPkgs();
  } else {
    toast('error', '删除失败', res.message || '');
  }
}

async function exportUserPkg() {
  var res = await api('/api/backups/export_user_pkg', {});
  if (ok(res) && res.package) {
    var jsonStr = JSON.stringify(res.package, null, 2);
    $('pkgQuickInput').value = jsonStr;
    var safeName = res.safe_name || 'aimapack_user';
    var blob = new Blob([jsonStr], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = safeName + '.json';
    a.click();
    URL.revokeObjectURL(url);
    toast('ok', '用户配置已导出本地', safeName);
    loadHostUserPkgs();
  } else {
    toast('error', '导出失败', res.message || '');
  }
}

function handleFileUploadBackup(file) {
  if (!file) return;
  var reader = new FileReader();
  reader.onload = async function (e) {
    try {
      var pkg = JSON.parse(e.target.result);
      if (pkg.format !== 'AI_MA_USER_DATA_PACKAGE') {
        toast('error', '文件格式非法', '请上传由本系统导出的 .json 配置包');
        return;
      }
      if (!await askConfirm(
        '从上传文件恢复工作区',
        '已解析本地备份文件：来自灯光师 <b>@' + esc(pkg.exported_by || '外部') + '</b><br>' +
        '包含 ' + Object.keys(pkg.shared_presets || {}).length + ' 个美学预设与面板排布。<br>' +
        '确认将其恢复导入至当前工作区吗？',
        '确认导入恢复'
      )) return;

      var res = await api('/api/backups/import_user_pkg', { package: pkg, mode: 'merge' });
      if (ok(res)) {
        toast('ok', '上传文件恢复成功', res.message || '');
        await loadKbPresets();
        await loadPanelLayout();
        renderScenePanel();
      } else {
        toast('error', '恢复失败', res.message || '');
      }
    } catch (err) {
      toast('error', '文件读取失败', '不是合法的 JSON 文件: ' + err.message);
    }
  };
  reader.readAsText(file, 'utf-8');
}

async function applyPkg(mode) {
  var txt = ($('pkgQuickInput').value || '').trim();
  if (!txt) { toast('warn', '请先粘贴配置包 JSON', ''); return; }
  var pkg;
  try { pkg = JSON.parse(txt); }
  catch (e) { toast('error', 'JSON 格式解析错误', String(e.message)); return; }

  var title = mode === 'overwrite' ? '完全覆盖我的工作区' : '增量合并至我的工作区';
  if (!await askConfirm(title, '确定将配置包导入到当前工作区吗？来源：<b>' + esc(pkg.exported_by || '外部') + '</b>', '确认导入', mode === 'overwrite')) return;

  var res = await api('/api/backups/import_user_pkg', { package: pkg, mode: mode });
  if (ok(res)) {
    toast('ok', '配置包导入成功', res.message || '');
    await loadKbPresets();
    await loadPanelLayout();
    renderScenePanel();
  } else {
    toast('error', '导入失败', res.message || '');
  }
}

function bindEvents() {
  qa('.nav-item').forEach(function (n) {
    n.addEventListener('click', function () { go(n.getAttribute('data-view')); });
  });
  qa('#kbSubnav .tab').forEach(function (t) {
    t.addEventListener('click', function () {
      qa('#kbSubnav .tab').forEach(function (x) { x.classList.remove('active'); });
      t.classList.add('active');
      var p = t.getAttribute('data-pane');
      qa('.kb-pane').forEach(function (x) { x.classList.toggle('active', x.id === 'kb-pane-' + p); });
    });
  });
  qa('#diagSubnav .tab').forEach(function (t) {
    t.addEventListener('click', function () {
      qa('#diagSubnav .tab').forEach(function (x) { x.classList.remove('active'); });
      t.classList.add('active');
      var p = t.getAttribute('data-dpane');
      qa('.diag-pane').forEach(function (x) { x.classList.toggle('active', x.id === 'diag-pane-' + p); });
    });
  });
  /* 关机与会话 */
  $('btnLogout').addEventListener('click', function () { forceLogout(''); });
  var topSd = $('btnTopShutdown');
  if (topSd) topSd.addEventListener('click', systemShutdown);
  var csSd = $('btnConsoleShutdown');
  if (csSd) csSd.addEventListener('click', systemShutdown);

  /* 预设发光色与图标联动 */
  var pdc = $('pdColor'), pdch = $('pdColorHex'), pdi = $('pdIcon');
  if (pdc && pdch) {
    pdc.addEventListener('input', function () {
      pdch.value = this.value;
      $('pdSwatch').style.background = this.value;
    });
    pdch.addEventListener('input', function () {
      if (/^#[0-9a-fA-F]{6}$/.test(this.value)) {
        pdc.value = this.value;
        $('pdSwatch').style.background = this.value;
      }
    });
  }
  if (pdi) {
    pdi.addEventListener('change', function () {
      $('pdSwatch').innerHTML = '<i class="' + esc(faIcon(this.value)) + '" style="font-size:32px;color:#fff;text-shadow:0 0 12px rgba(0,0,0,.6);"></i>';
    });
  }

  /* 主控台 */
  $('btnAiSend').addEventListener('click', sendAiCommand);
  $('btnStopSeq').addEventListener('click', stopSequence);
  $('btnPanic').addEventListener('click', panic);
  $('btnEditPanel').addEventListener('click', openPanelEditor);
  $('btnAddGroup').addEventListener('click', function () {
    State.pickerGroups.push({ group_id: 'g' + (State.pickerGroups.length + 1),
                              title: '面板块 ' + (State.pickerGroups.length + 1), columns: 3, item_ids: [] });
    renderPickerGroups();
  });
  $('btnSavePanel').addEventListener('click', savePanel);
  $('ctrlPortSelect').addEventListener('change', function () {
    State.activePortIdx = parseInt(this.value, 10) || 0;
    renderPortInfo();
    refreshPortDmx();
  });
  $('ai-cmd-input').addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) sendAiCommand();
  });

  /* 场景 */
  $('btnNewScene').addEventListener('click', newScene);
  $('btnCaptureScene').addEventListener('click', captureScene);
  $('btnAiScene').addEventListener('click', function () { openModal('modalSceneAi'); });
  $('btnDoSceneAi').addEventListener('click', aiComposeScene);
  $('btnSaveScene').addEventListener('click', saveScene);

  /* 监视 */
  $('btnScanNodes').addEventListener('click', scanNodes);
  $('btnSyncWatchdog').addEventListener('click', syncWatchdog);
  $('btnRefreshPkt').addEventListener('click', refreshPackets);

  /* 告警 */
  $('btnBell').addEventListener('click', function () { go('diagnostics'); });
  $('btnAbGo').addEventListener('click', function () { go('diagnostics'); });
  $('btnAbAck').addEventListener('click', ackAllAlarms);
  $('btnAckAll').addEventListener('click', ackAllAlarms);
  $('btnRefreshAlarms').addEventListener('click', refreshAlarms);
  $('btnClearLogs').addEventListener('click', function () { $('logBox').innerHTML = ''; });

  /* 插件 / 模型 / 系统更新 */
  $('btnVerifyOpen').addEventListener('click', function () { openModal('modalVerify'); });
  $('btnRunVerify').addEventListener('click', runVerify);
  $('btnSavePluginCfg').addEventListener('click', savePluginCfg);
  $('btnTestLlm').addEventListener('click', testLlm);
  $('btnSaveLlm').addEventListener('click', saveLlm);

  // 3 类创意插件本地上传
  $('btnUploadCommunityPlugin').addEventListener('click', function () { $('communityPluginInput').click(); });
  $('communityPluginInput').addEventListener('change', async function (e) {
    var f = e.target.files[0];
    if (!f) return;
    try {
      toast('info', '安装中', '正在安装 3 类创意插件 ' + f.name + ' ...');
      var reader = new FileReader();
      reader.onload = async function (evt) {
        var b64 = evt.target.result.split(',')[1];
        var res = await api('/api/plugins/community/upload', { file_b64: b64, filename: f.name });
        if (res && res.status === 'ok') {
          toast('ok', '安装成功', res.message || '插件已安装并热激活！');
          loadInstalled();
          loadMarket();
        } else {
          toast('error', '安装失败', res.message || '插件格式校验未通过');
        }
      };
      reader.readAsDataURL(f);
    } catch (err) {
      toast('error', '文件异常', err.message);
    } finally {
      e.target.value = '';
    }
  });

  // 刷新市场
  $('btnRefreshMarket').addEventListener('click', function () {
    toast('info', '市场同步', '已与插件源同步最新 3 类表现级扩展包。');
    loadMarket();
  });

  // 系统更新检测与补丁包上传
  $('btnCheckSysUpdate').addEventListener('click', async function () {
    var res = await api('/api/system/check_update');
    if (res && res.status === 'ok') {
      $('lblSysVersion').textContent = res.current_version;
      $('lblSysUpdateStatus').textContent = res.release_notes || '当前已是最新版本';
      toast('ok', '系统检测', res.release_notes || '当前微内核已是最新版本');
    }
  });
  $('btnUploadSysPatch').addEventListener('click', function () { $('sysPatchInput').click(); });
  $('sysPatchInput').addEventListener('change', async function (e) {
    var f = e.target.files[0];
    if (!f) return;
    toast('info', '补丁校验', '正在校验系统更新补丁 ' + f.name + ' ...');
    setTimeout(async function () {
      var res = await api('/api/system/apply_update_pkg', { filename: f.name });
      if (res && res.status === 'ok') {
        toast('ok', '补丁就绪', res.message);
      } else {
        toast('error', '补丁异常', res.message || '更新包未通过签名校验');
      }
      e.target.value = '';
    }, 800);
  });

  /* 知识库 */
  $('btnScanConflicts').addEventListener('click', scanConflicts);
  $('btnScanConflicts2').addEventListener('click', scanConflicts);
  $('btnNewProfile').addEventListener('click', function () { openProfile(null); });
  $('btnImportMa').addEventListener('click', function () { $('maFileInput').click(); });
  $('maFileInput').addEventListener('change', async function (e) {
    var f = e.target.files[0];
    if (!f) return;
    try {
      toast('info', '解析中', '正在解析 MA 灯库文件 ' + f.name + ' ...');
      var reader = new FileReader();
      reader.onload = async function (evt) {
        try {
          var b64 = evt.target.result.split(',')[1];
          var res = await api('/api/kb/import_ma_xml', { file_b64: b64, filename: f.name });
          if (res && res.status === 'ok') {
            toast('ok', '导入成功', 'MA 灯库解析成功，已自动转换为标准结构！');
            // 填充灯库编辑器弹窗
            State.editingProfileId = null;
            $('profileTitle').textContent = 'MA 灯库导入结果 · 请核对后保存';
            $('pfId').value = res.data.profile_id || '';
            $('pfId').disabled = false;
            $('pfMfr').value = res.data.manufacturer || '';
            $('pfModel').value = res.data.model || '';
            $('pfChannels').innerHTML = '';
            var chsMA = (res.data.channels || []).slice().sort(function(a, b) { return parseInt(a.ch || 0, 10) - parseInt(b.ch || 0, 10); });
            chsMA.forEach(function (c, idx) { addChannelRow(c, idx + 1); });
            openModal('modalProfile');
          } else {
            toast('error', '导入失败', res.message || '未知错误');
          }
        } catch (apiErr) {
          toast('error', '请求失败', apiErr.message || '服务端处理错误');
        }
      };
      reader.readAsDataURL(f);
    } catch (err) {
      toast('error', '文件异常', err.message || '无法读取该文件');
    } finally {
      e.target.value = '';
    }
  });
  $('btnAiExtract').addEventListener('click', function () {
    qa('#kbSubnav .tab').forEach(function (x) { x.classList.toggle('active', x.getAttribute('data-pane') === 'airag'); });
    qa('.kb-pane').forEach(function (x) { x.classList.toggle('active', x.id === 'kb-pane-airag'); });
  });
  $('btnSaveProfile').addEventListener('click', saveProfile);
  $('btnAddCh').addEventListener('click', function () { addChannelRow({}); });
  $('btnAddSlot').addEventListener('click', function () {
    var rows = qa('#slotList [data-i]').map(function (r) {
      return { v: parseInt(r.querySelector('.sl-v').value, 10) || 0, label: r.querySelector('.sl-l').value || '' };
    }).filter(function (s) { return s.label; });
    rows.push({ v: 0, label: '' });
    renderSlots(rows);
  });
  $('btnSaveSlots').addEventListener('click', saveSlots);
  $('btnNewVenue').addEventListener('click', function () { openVenue(null); });
  $('btnSaveVenue').addEventListener('click', saveVenue);
  $('btnCheckDraft').addEventListener('click', checkDraft);
  $('btnAddNode').addEventListener('click', function () { openNodeEditor(-1); });
  $('btnApplyNode').addEventListener('click', applyNode);
  $('btnTestConn').addEventListener('click', testConnection);
  $('btnApplyPort').addEventListener('click', applyPort);
  $('btnApplyFixture').addEventListener('click', applyFixture);
  $('fxProfile').addEventListener('change', updateFootprint);
  $('fxAddress').addEventListener('input', updateFootprint);
  $('ptLabelStyle').addEventListener('change', function () {
    if (this.value === 'alpha') $('ptLabel').value = 'A';
    else if (this.value === 'numeric') $('ptLabel').value = '1';
  });
  $('ndPolicyMode').addEventListener('change', function () {
    var dis = this.value === 'ignore' || this.value === 'manual';
    $('ndThreshold').disabled = dis;
    $('ndGrace').disabled = dis;
    $('ndLiveness').disabled = dis;
    $('ndSeverity').disabled = dis;
    $('ndNeverSeen').disabled = dis;
  });

  /* 预设 */
  $('btnNewPreset').addEventListener('click', function () { openPreset(null); });
  $('btnManageCats').addEventListener('click', openCategories);
  $('btnSavePreset').addEventListener('click', savePreset);
  $('btnDeletePreset').addEventListener('click', deletePreset);
  $('btnAddCat').addEventListener('click', addCat);
  $('btnAddAg').addEventListener('click', addAg);
  $('btnSaveCats').addEventListener('click', saveCats);
  qa('#catRegSeg .seg-item').forEach(function (s) {
    s.addEventListener('click', function () {
      qa('#catRegSeg .seg-item').forEach(function (x) { x.classList.remove('active'); });
      s.classList.add('active');
      var r = s.getAttribute('data-reg');
      $('reg-pane-cat').style.display = r === 'cat' ? '' : 'none';
      $('reg-pane-ag').style.display = r === 'ag' ? '' : 'none';
    });
  });
  qa('#presetModeSeg .seg-item').forEach(function (s) {
    s.addEventListener('click', function () {
      var mode = s.getAttribute('data-mode');
      if (mode === 'form' && !$('pdProfile').value) {
        toast('warn', '请先选择基准灯型', '属性表单需要知道该按哪个灯库的属性渲染。');
        return;
      }
      setPresetMode(mode);
    });
  });
  $('pdProfile').addEventListener('change', function () {
    if (this.value) {
      if (State.presetMode === 'form') renderAttrEditor();
    }
  });
  $('pdSearch').addEventListener('input', renderAttrEditor);

  /* AI / RAG */
  $('btnAiParse').addEventListener('click', aiParse);
  $('btnRagTest').addEventListener('click', ragTest);
  $('btnScanConflicts').addEventListener('click', scanConflicts);
  aiUploadInit(); // 初始化文件上传拖拽区

  /* 用户管理 */
  var bnu = $('btnNewUser');
  if (bnu) bnu.addEventListener('click', function () { openUserModal(null); });
  var bsu = $('btnSaveUser');
  if (bsu) bsu.addEventListener('click', saveUser);
  var bdu = $('btnDeleteUser');
  if (bdu) bdu.addEventListener('click', function () { if (currentEditingUser) deleteUser(currentEditingUser); });

  /* 容灾快照与数据交互 */
  var bms = $('btnManualSnapshot');
  if (bms) bms.addEventListener('click', function () { $('snapDesc').value = ''; openModal('modalSnapshot'); });
  var bds = $('btnDoSnapshot');
  if (bds) bds.addEventListener('click', createManualSnapshot);
  var bep = $('btnExportUserPkg');
  if (bep) bep.addEventListener('click', exportUserPkg);
  var bshb = $('btnSaveHostBackup');
  if (bshb) bshb.addEventListener('click', function () { saveHostUserBackup(false); });
  var bpm = $('btnApplyPkgMerge');
  if (bpm) bpm.addEventListener('click', function () { applyPkg('merge'); });
  var bpo = $('btnApplyPkgOverwrite');
  if (bpo) bpo.addEventListener('click', function () { applyPkg('overwrite'); });

  /* 快照模式分段选择器切换 (全部 / 自动 / 手动) */
  qa('#snapModeSeg .seg-item').forEach(function (btn) {
    btn.addEventListener('click', function () {
      qa('#snapModeSeg .seg-item').forEach(function (x) { x.classList.remove('active'); });
      btn.classList.add('active');
      currentSnapMode = btn.getAttribute('data-mode') || 'all';
      renderSnapshots();
    });
  });

  /* 文件上传恢复监听 */
  var fileInp = $('fileUploadBackup');
  if (fileInp) {
    fileInp.addEventListener('change', function () {
      if (this.files && this.files[0]) {
        handleFileUploadBackup(this.files[0]);
        this.value = '';
      }
    });
  }

  /* 确认框 */
  $('confirmOk').addEventListener('click', function () { settleConfirm(true); });
  $('confirmCancel').addEventListener('click', function () { settleConfirm(false); });
}

async function boot() {
  /* 会话门禁：未通过校验前不渲染任何业务界面 */
  if (!TOKEN) { location.replace('/'); return; }
  var sess = null;
  try { sess = JSON.parse(localStorage.getItem('ai_ma_session') || 'null'); } catch (e) {}
  
  var v;
  try { v = await api('/api/auth/verify'); }
  catch (e) { return; }
  if (!v || v.status !== 'ok') { forceLogout('会话校验未通过，请重新登录。'); return; }

  SESSION = v.session || sess || { username: 'admin', role: 'admin', display_name: '系统主管理员' };
  try { localStorage.setItem('ai_ma_session', JSON.stringify(SESSION)); } catch (e) {}
  PERMS = SESSION.permissions || [];
  paintSession();
  applyPermissions();
  $('bootMask').style.display = 'none';
  $('appShell').style.display = '';

  bindEvents();

  await loadKbProfiles();
  await loadKbVenues();
  await loadKbPresets();
  await loadKbSummary();
  await loadScenes();
  await loadPanelLayout();
  renderScenePanel();
  buildPortSelect();
  renderPortInfo();
  await refreshPortDmx();
  await loadStudioTable();
  await loadInstalled();
  await loadMarket();
  await renderDynamicPluginSlots();
  await loadLlm();
  await loadSystemStatus();
  await refreshAlarms();

  var last = 'control';
  try { last = localStorage.getItem('ai_ma_view') || 'control'; } catch (e) {}
  go(VIEWS[last] ? last : 'control');

  /* 轮询：通道电平 500ms，系统状态 2s，告警 5s
     统一经 poll() 登记，使 forceLogout() 能在注销瞬间一次性全部清除。 */
  poll(function () { refreshPortDmx(); }, 500);
  poll(function () { loadSystemStatus(); }, 2000);
  poll(function () {
    if (q('.view.active') && q('.view.active').id === 'view-control') refreshPortDmx();
  }, 4000);
  poll(function () { refreshAlarms(); }, 5000);
  poll(function () {
    var av = q('.view.active');
    if (av && (av.id === 'view-monitor')) refreshMonitor();
    if (av && av.id === 'view-diagnostics') refreshLogs();
  }, 3000);
}

document.addEventListener('DOMContentLoaded', boot);
})();
