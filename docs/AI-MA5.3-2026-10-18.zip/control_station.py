# -*- coding: utf-8 -*-
"""
AI-MA 生产级全集成可视化控制总台 (Unified Control Station v4.0)
【重大工业级重构】:
1. 快捷场景完全直通化：快捷场景存储直接为执行级 JSON 数据包 (payload)，
   点击后 0 毫秒直达底层 DMX 引擎与 Crossfade 插值器，完全不请求大模型！
2. 纯净防误触主控台：交互控制台仅保留超大面积触控直达按钮，移除编辑/删除图标，避免现场误触。
3. 独立的快捷场景管理中心 (Scene Studio)：提供专门的 Tab 标签页，支持直接复制粘贴 JSON 录入，
   或在创建阶段使用本地 Qwen 2.5-7B 进行辅助编译。
4. 插件市场全生命周期、接收监视器、RAG知识库、本地模型配置与中文故障诊断一网打尽。
"""

import os
import sys
import json
import time
import socket
import threading
import collections
import subprocess
import urllib.request
import urllib.error
from urllib.parse import urlparse, parse_qs, unquote
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Optional, Dict, Any, List

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "web")
# 页面级会话 Cookie 名。API 仍以 Authorization 头为准，Cookie 仅用于让浏览器
# 直接导航到 /app 时服务端也能完成门禁（普通导航不会带 Authorization 头）。
SESSION_COOKIE_NAME = "ai_ma_session"
sys.path.append(os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from engine import CoreEngine
from auth_manager import AuthManager, Role
from diagnostics_logger import setup_chinese_logger, GLOBAL_LOG_BUFFER, log_diagnostic_error
from dmx_merger import PriorityLevel
from marketplace_service import PluginMarketplace
from quick_cue_manager import QuickCueManager
from kb_service import KnowledgeBaseService
from backup_manager import BackupManager

# 初始化中文日志与故障诊断
logger = setup_chinese_logger(log_dir=os.path.join(BASE_DIR, "logs"), app_name="AI-MA Unified Control Station")

# --------------------------------------------------------------------------
# 未授权 API 访问的分类与突发检测 (Unauthenticated Access Classifier)
# --------------------------------------------------------------------------
# 背景：前端有多个轮询定时器（通道电平 500ms / 系统状态 2s / 告警 5s 等）。
# 用户点击注销后，页面在真正卸载前这些轮询仍会发出若干请求，服务端此时
# 已吊销令牌，于是每一个请求都会命中鉴权闸门。
#
# 原实现把**每一次**这样的 401 都记为 ERROR 级 ERR-AUTH-DENIED 故障告警，造成：
#   1. 日志刷屏（一次正常注销产生数十条 ERROR）；
#   2. 告警面板被污染——真正的令牌爆破与一次日常注销在面板上完全无法区分；
#   3. 告警文案误导运维（真因是"已注销"，却提示"请切换管理员账号"）。
#
# 现改为分级判定：
#   - 未携带令牌        → 常规生命周期事件（未登录/刚注销），DEBUG 级，不产生告警；
#   - 携带但已失效令牌  → 会话过期或注销竞态，INFO 级，不产生告警；
#   - 短时高频未授权    → 这才是真正可疑的信号，升级为 ERR-AUTH-BRUTEFORCE 告警。
# 角色权限不足（令牌有效但无权操作）仍走 ERR-AUTH-DENIED，属真实授权事件。
# --------------------------------------------------------------------------
_UNAUTH_WINDOW_SEC = 10.0        # 突发统计滑动窗口
_UNAUTH_BURST_THRESHOLD = 20     # 窗口内超过该次数即判定为疑似爆破/轮询风暴
_UNAUTH_ALARM_COOLDOWN_SEC = 30.0  # 告警冷却，防止告警自身刷屏
_unauth_events = collections.deque(maxlen=500)
_unauth_lock = threading.Lock()
_unauth_last_alarm = 0.0


def note_unauthenticated_request(path: str, has_token: bool):
    """分级记录一次未授权 API 访问，并仅在出现可疑突发时升级为故障告警"""
    global _unauth_last_alarm
    now = time.time()

    with _unauth_lock:
        _unauth_events.append(now)
        while _unauth_events and now - _unauth_events[0] > _UNAUTH_WINDOW_SEC:
            _unauth_events.popleft()
        burst = len(_unauth_events)
        should_alarm = (burst >= _UNAUTH_BURST_THRESHOLD
                        and now - _unauth_last_alarm > _UNAUTH_ALARM_COOLDOWN_SEC)
        if should_alarm:
            _unauth_last_alarm = now

    if has_token:
        # 令牌存在但已失效：会话过期或"注销瞬间的在途轮询"，均属正常
        logger.info(f"只读接口收到已失效或已注销的会话令牌，按未授权处理并返回 401: {path}")
    else:
        logger.debug(f"只读接口未携带会话令牌（未登录或刚注销的页面轮询）: {path}")

    if should_alarm:
        log_diagnostic_error(
            logger, "ERR-AUTH-BRUTEFORCE",
            f"{_UNAUTH_WINDOW_SEC:.0f} 秒内出现 {burst} 次未授权接口访问，"
            f"已超出正常轮询范畴，疑似会话令牌爆破或异常客户端扫描（最近命中: {path}）"
        )


# 实例化全局服务
kb = KnowledgeBaseManager(os.path.join(BASE_DIR, "knowledge_base"))
auth = AuthManager(user_db_path=os.path.join(BASE_DIR, "config", "users.json"))
backup_mgr = BackupManager(base_dir=BASE_DIR)

# --------------------------------------------------------------------------
# AI-MA v5.3 生产级伴生微内核看门狗管理机制 (Microkernel Daemon Host Manager)
# --------------------------------------------------------------------------
_microkernel_proc: Optional[subprocess.Popen] = None
_microkernel_log = None
_kill_on_close_job = None


def _create_kill_on_close_job():
    """
    创建一个 Windows 作业对象（Job Object），并开启 KILL_ON_JOB_CLOSE。
    把伴生微内核进程加入该作业后，只要总控进程退出——无论是正常退出、
    Ctrl+C、还是被 TerminateProcess 强制击杀——操作系统都会立刻回收微内核，
    从内核层面杜绝孤儿守护进程。Linux 平台返回 None（由 systemd 的
    PartOf/BindsTo 依赖负责同等语义）。
    """
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class IO_COUNTERS(ctypes.Structure):
            _fields_ = [("ReadOperationCount", ctypes.c_ulonglong),
                        ("WriteOperationCount", ctypes.c_ulonglong),
                        ("OtherOperationCount", ctypes.c_ulonglong),
                        ("ReadTransferCount", ctypes.c_ulonglong),
                        ("WriteTransferCount", ctypes.c_ulonglong),
                        ("OtherTransferCount", ctypes.c_ulonglong)]

        class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),
                        ("PerJobUserTimeLimit", ctypes.c_longlong),
                        ("LimitFlags", wintypes.DWORD),
                        ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t),
                        ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.POINTER(ctypes.c_ulong)),
                        ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]

        class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
                        ("IoInfo", IO_COUNTERS),
                        ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t),
                        ("PeakProcessMemoryUsed", ctypes.c_size_t),
                        ("PeakJobMemoryUsed", ctypes.c_size_t)]

        JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
        JobObjectExtendedLimitInformation = 9

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateJobObjectW.restype = wintypes.HANDLE
        job = k32.CreateJobObjectW(None, None)
        if not job:
            raise OSError(f"CreateJobObjectW 失败: {ctypes.get_last_error()}")

        info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        ok = k32.SetInformationJobObject(
            wintypes.HANDLE(job), JobObjectExtendedLimitInformation,
            ctypes.byref(info), ctypes.sizeof(info)
        )
        if not ok:
            k32.CloseHandle(wintypes.HANDLE(job))
            raise OSError(f"SetInformationJobObject 失败: {ctypes.get_last_error()}")
        return (k32, job)
    except Exception as e:
        logger.warning(f"未能创建 Kill-on-Close 作业对象（孤儿回收将退化为普通模式）: {e}")
        return None


def _assign_to_job(pid: int) -> bool:
    """把刚拉起的微内核进程绑定到 Kill-on-Close 作业对象"""
    global _kill_on_close_job
    if _kill_on_close_job is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k32, job = _kill_on_close_job
        k32.OpenProcess.restype = wintypes.HANDLE
        PROCESS_SET_QUOTA, PROCESS_TERMINATE = 0x0100, 0x0001
        h = k32.OpenProcess(PROCESS_SET_QUOTA | PROCESS_TERMINATE, False, pid)
        if not h:
            raise OSError(f"OpenProcess 失败: {ctypes.get_last_error()}")
        try:
            if not k32.AssignProcessToJobObject(wintypes.HANDLE(job), wintypes.HANDLE(h)):
                raise OSError(f"AssignProcessToJobObject 失败: {ctypes.get_last_error()}")
        finally:
            k32.CloseHandle(wintypes.HANDLE(h))
        return True
    except Exception as e:
        logger.warning(f"微内核进程未能纳入 Kill-on-Close 作业对象: {e}")
        return False


# 进程启动即创建作业对象（句柄由本进程持有，进程消亡即自动回收微内核）
_kill_on_close_job = _create_kill_on_close_job()


def _kernel_already_live() -> bool:
    """
    探测共享内存中是否已有存活微内核在推进帧计数。
    44Hz 内核每帧都会递增 frame_index，因此"两次采样数值增长"即可判定内核存活。
    用于避免在 systemd 或他处已托管内核时重复拉起，导致双内核争抢同一组槽位。
    """
    try:
        from kernel_bridge import AimaKernelBridge
        b = AimaKernelBridge.get_instance()
        if not b.is_available:
            return False
        m1 = b.get_rt_metrics()[0]
        time.sleep(0.12)
        m2 = b.get_rt_metrics()[0]
        return m2 > m1 > 0
    except Exception:
        return False


def ensure_microkernel_running():
    """检测并确保 Rust 44Hz 硬实时微内核 (aima-rt-daemon) 在后台伴生常驻"""
    global _microkernel_proc, _microkernel_log

    # systemd 部署场景：内核由 aima-rt.service 独立托管并拥有硬实时特权，
    # 此时严禁重复拉起，否则两个内核会争抢同一组共享内存槽位。
    if os.environ.get("AIMA_RT_EXTERNAL") == "1":
        logger.info("检测到 AIMA_RT_EXTERNAL=1：微内核由 systemd (aima-rt.service) 独立托管，跳过伴生拉起。")
        return

    # 已在别处托管的内核：直接纳管，不再重复拉起
    if _kernel_already_live():
        logger.info("检测到共享内存中已有存活微内核在推进帧计数，直接接管纳管，避免双内核争抢。")
        return

    ext = ".exe" if sys.platform == "win32" else ""
    local_bin = os.path.join(BASE_DIR, "bin", f"aima-rt-daemon{ext}")
    kernel_root_bin = os.path.join(os.path.dirname(BASE_DIR), "ai-ma-kernel-v5.3", "target", "release", f"aima-rt-daemon{ext}")

    rt_bin = local_bin if os.path.exists(local_bin) else (kernel_root_bin if os.path.exists(kernel_root_bin) else None)
    if not rt_bin:
        logger.warning("未检测到本地 aima-rt-daemon 硬实时守护进程二进制，跳过自动拉起。")
        return

    # 若进程已在运行中则保持
    if _microkernel_proc and _microkernel_proc.poll() is None:
        return

    try:
        env = os.environ.copy()
        env["AIMA_ARTNET_TARGET"] = env.get("AIMA_ARTNET_TARGET", "127.0.0.1:6454")
        # 内核自身的运行输出独立落盘，避免与总控日志混杂；运维排查直接看该文件。
        # 注意使用文件句柄而非 PIPE，防止无人读取管道导致内核写满缓冲区后阻塞。
        log_path = os.path.join(BASE_DIR, "logs", "aima_rt_daemon.log")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        _microkernel_log = open(log_path, "a", encoding="utf-8", errors="replace")
        _microkernel_proc = subprocess.Popen(
            [rt_bin],
            env=env,
            stdout=_microkernel_log,
            stderr=subprocess.STDOUT,
            cwd=os.path.dirname(rt_bin)
        )
        logger.info(f"AI-MA v5.3 硬实时微内核 (aima-rt-daemon) 已成功拉起伴生运行 (PID: {_microkernel_proc.pid})")
        logger.info(f"微内核运行日志独立落盘于: [{log_path}]")
        if _assign_to_job(_microkernel_proc.pid):
            logger.info("微内核已纳入 Kill-on-Job-Close 作业对象，总控退出时将被操作系统原子回收。")
    except Exception as e:
        logger.error(f"拉起微内核守护进程失败: {e}")


def stop_microkernel():
    """安全停止伴生微内核守护进程"""
    global _microkernel_proc, _microkernel_log
    _watchdog_stop.set()
    if _microkernel_proc and _microkernel_proc.poll() is None:
        try:
            logger.info("正在停止硬实时微内核守护进程...")
            _microkernel_proc.terminate()
            _microkernel_proc.wait(timeout=1.5)
        except Exception:
            try:
                _microkernel_proc.kill()
            except Exception:
                pass
        _microkernel_proc = None
    if _microkernel_log:
        try:
            _microkernel_log.close()
        except Exception:
            pass
        _microkernel_log = None


# --------------------------------------------------------------------------
# 运行期内核看门狗 (Runtime Kernel Watchdog)
# --------------------------------------------------------------------------
# 场景：微内核在运行时被外部杀死、OOM、崩溃退出，或共享内存时钟停摆。
# 原先只在启动时做一次健康自检，运行期内核一旦死亡，控制台会毫无察觉地
# 继续"空转"——业务帧写进无人消费的共享内存，现场直接黑屏且无告警。
# 本看门狗以固定周期巡检，发现死亡或停摆即刻告警并按上限自动重启。
# --------------------------------------------------------------------------
KERNEL_WATCHDOG_INTERVAL_SEC = float(os.environ.get("AIMA_WATCHDOG_INTERVAL_SEC", "5.0"))
KERNEL_MAX_AUTO_RESTART = int(os.environ.get("AIMA_WATCHDOG_MAX_RESTART", "5"))
KERNEL_STALL_LIMIT = int(os.environ.get("AIMA_WATCHDOG_STALL_LIMIT", "3"))   # 连续 N 次帧计数未推进即判定停摆
_watchdog_stop = threading.Event()


def _kernel_frame_index() -> int:
    """读取当前微内核渲染帧计数；不可用时返回 -1"""
    try:
        from kernel_bridge import AimaKernelBridge
        b = AimaKernelBridge.get_instance()
        if not b.is_available:
            return -1
        return int(b.get_rt_metrics()[0])
    except Exception:
        return -1


def _kernel_watchdog_loop():
    """运行期内核巡检：进程死亡或共享内存时钟停摆时告警并自动重启"""
    global _microkernel_proc
    restart_count = 0
    stall_count = 0
    last_frame = -1

    # systemd 托管模式下，重启责任归属 systemd，看门狗只做只读巡检与告警
    externally_managed = (os.environ.get("AIMA_RT_EXTERNAL") == "1")

    while not _watchdog_stop.wait(KERNEL_WATCHDOG_INTERVAL_SEC):
        try:
            proc = _microkernel_proc
            dead = (proc is not None and proc.poll() is not None)

            # --- 情形 A: 伴生进程已死亡 ---
            if dead:
                rc = proc.poll()
                log_diagnostic_error(
                    logger, "ERR-KERNEL-DAEMON",
                    f"运行期巡检发现硬实时微内核已退出 (退出码 {rc})，"
                    f"业务层已失去物理推流能力！"
                )
                _microkernel_proc = None
                if externally_managed:
                    logger.warning("微内核由 systemd 托管，等待 aima-rt.service 自动重启；"
                                   "控制台将随 BindsTo 依赖同步停止。")
                    continue
                if restart_count >= KERNEL_MAX_AUTO_RESTART:
                    logger.critical(
                        f"微内核已连续重启 {restart_count} 次仍不稳定，停止自动重启以避免重启风暴。"
                        f"请检查 logs/aima_rt_daemon.log 排查根因。"
                    )
                    continue
                restart_count += 1
                logger.warning(f"正在执行第 {restart_count}/{KERNEL_MAX_AUTO_RESTART} 次微内核自动重启...")
                ensure_microkernel_running()
                # 重新挂载共享内存句柄，防止使用崩溃前的失效/陈旧句柄
                try:
                    from kernel_bridge import AimaKernelBridge
                    AimaKernelBridge.get_instance().reconnect()
                except Exception as _re_e:
                    logger.error(f"微内核重启后重连共享内存失败: {_re_e}")
                last_frame = -1
                stall_count = 0
                continue

            # --- 情形 B: 进程存活但共享内存帧计数停摆 ---
            if proc is not None and proc.poll() is None:
                cur = _kernel_frame_index()
                if cur < 0:
                    stall_count += 1
                elif cur == last_frame:
                    stall_count += 1
                else:
                    stall_count = 0
                    restart_count = 0     # 恢复正常，重置重启预算
                last_frame = cur

                if stall_count >= KERNEL_STALL_LIMIT:
                    log_diagnostic_error(
                        logger, "ERR-KERNEL-STALL",
                        f"硬实时微内核进程存活但渲染帧计数连续 {stall_count} 次未推进 "
                        f"(当前 frame_index={cur})，判定为时钟停摆，44Hz 推流已中断！"
                    )
                    stall_count = 0
                    if externally_managed:
                        logger.warning("微内核由 systemd 托管，停摆恢复由 systemd 看门狗 (WatchdogSec) 负责。")
                        continue
                    if restart_count < KERNEL_MAX_AUTO_RESTART:
                        restart_count += 1
                        logger.warning(f"停摆自愈：正在重启微内核 ({restart_count}/{KERNEL_MAX_AUTO_RESTART})...")
                        try:
                            proc.terminate()
                            proc.wait(timeout=1.5)
                        except Exception:
                            try:
                                proc.kill()
                            except Exception:
                                pass
                        _microkernel_proc = None
                        ensure_microkernel_running()
                        try:
                            from kernel_bridge import AimaKernelBridge
                            AimaKernelBridge.get_instance().reconnect()
                        except Exception as _re_e:
                            logger.error(f"微内核重启后重连共享内存失败: {_re_e}")
                        last_frame = -1
        except Exception as e:
            logger.error(f"微内核看门狗巡检异常 (已隔离，不影响主服务): {e}")


def start_kernel_watchdog():
    """启动运行期内核看门狗守护线程 (幂等)"""
    if getattr(start_kernel_watchdog, "_started", False):
        return
    start_kernel_watchdog._started = True
    t = threading.Thread(target=_kernel_watchdog_loop, name="AimaKernelWatchdog", daemon=True)
    t.start()
    logger.info(
        f"运行期内核看门狗已启动 (周期 {KERNEL_WATCHDOG_INTERVAL_SEC:.0f}s / "
        f"停摆阈值 {KERNEL_STALL_LIMIT} 次 / 自动重启上限 {KERNEL_MAX_AUTO_RESTART} 次)"
    )

def check_microkernel_health() -> bool:
    """伴生微内核健康自检：进程若异常退出，立即在系统日志中透出故障诊断"""
    global _microkernel_proc
    if _microkernel_proc is None:
        return False
    rc = _microkernel_proc.poll()
    if rc is None:
        return True
    log_path = os.path.join(BASE_DIR, "logs", "aima_rt_daemon.log")
    tail = ""
    try:
        if os.path.exists(log_path):
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                tail = "".join(f.readlines()[-12:]).strip()
    except Exception:
        pass
    log_diagnostic_error(
        logger, "ERR-KERNEL-DAEMON",
        f"硬实时微内核 aima-rt-daemon 异常退出 (退出码 {rc})，系统已降级为纯软件兼容模式！内核日志尾部: {tail}"
    )
    _microkernel_proc = None
    return False

# 在主系统服务初始化前启动微内核
ensure_microkernel_running()
time.sleep(0.30)
check_microkernel_health()

# 启动运行期内核看门狗 (死亡告警 + 停摆检测 + 自动重启)
start_kernel_watchdog()

# 任何形式的进程退出（正常返回 / 未捕获异常）都必须回收微内核，
# 作为 Kill-on-Job-Close 作业对象之外的第二道保险。
import atexit as _atexit
_atexit.register(stop_microkernel)

# 启动时执行一次无感原子系统保护快照
try:
    backup_mgr.create_system_snapshot(tag="auto", description="系统服务启动初始保护快照")
except Exception as _b_err:
    logger.warning(f"系统启动快照异常: {_b_err}")
marketplace = PluginMarketplace(
    catalog_path=os.path.join(BASE_DIR, "marketplace", "plugin_catalog.json"),
    plugins_dir=os.path.join(BASE_DIR, "plugins")
)
quick_cue_mgr = QuickCueManager(config_path=os.path.join(BASE_DIR, "config", "quick_scenes.json"))
kb_service = KnowledgeBaseService(
    kb_root=os.path.join(BASE_DIR, "knowledge_base"),
    kb_manager=kb
)


# -------------------------------------------------------------
# 节点自动发现 / 连接测试 / 掉线看门狗（Art-Net 解码器层级）
# -------------------------------------------------------------
from node_discovery import (ArtPollProber, PassiveRegistry, OfflineWatchdog,
                            LivenessProbe, expand_subnet, ping_host)


class AlarmStore:
    """
    全局告警中心（线程安全）。
    承载设备掉线等运行时告警的 未处理/已确认/已恢复 三态生命周期。
    """

    def __init__(self, max_items: int = 300):
        self._lock = threading.RLock()
        self._items = []
        self._max = max_items
        self._seq = 0

    @staticmethod
    def _now() -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S")

    def raise_alarm(self, code: str, title: str, message: str,
                    node_id: str = "", severity: str = "warning",
                    actions=None) -> dict:
        """登记一条告警；同一节点同一错误码在未恢复前不重复登记，仅刷新时间"""
        with self._lock:
            for a in self._items:
                if a["node_id"] == node_id and a["code"] == code and a["state"] != "recovered":
                    a["last_at"] = self._now()
                    a["message"] = message
                    return a
            self._seq += 1
            item = {
                "id": f"alm_{self._seq:05d}",
                "code": code,
                "title": title,
                "message": message,
                "node_id": node_id,
                "severity": severity,
                "actions": list(actions or ["log", "banner", "toast"]),
                "state": "open",              # open 未处理 | acked 已确认 | recovered 已恢复
                "raised_at": self._now(),
                "last_at": self._now(),
                "recovered_at": None,
                "acked_at": None,
            }
            self._items.insert(0, item)
            del self._items[self._max:]
            return item

    def recover(self, node_id: str, code: str = "ERR-NODE-OFFLINE", offline_sec=None) -> list:
        """节点恢复：把该节点对应告警自动转为已恢复态"""
        touched = []
        with self._lock:
            for a in self._items:
                if a["node_id"] == node_id and a["code"] == code and a["state"] != "recovered":
                    a["state"] = "recovered"
                    a["recovered_at"] = self._now()
                    if offline_sec is not None:
                        a["message"] = f"{a['message']}（已于 {a['recovered_at']} 恢复，离线 {offline_sec}s）"
                    touched.append(a)
        return touched

    def acknowledge(self, alarm_id: str) -> dict:
        with self._lock:
            for a in self._items:
                if a["id"] == alarm_id:
                    if a["state"] == "open":
                        a["state"] = "acked"
                        a["acked_at"] = self._now()
                    return a
        raise FileNotFoundError(f"未找到告警: {alarm_id}")

    def acknowledge_all(self) -> int:
        with self._lock:
            n = 0
            for a in self._items:
                if a["state"] == "open":
                    a["state"] = "acked"
                    a["acked_at"] = self._now()
                    n += 1
            return n

    def snapshot(self, limit: int = 50) -> dict:
        with self._lock:
            items = [dict(a) for a in self._items[:limit]]
            return {
                "alarms": items,
                "open_count": sum(1 for a in self._items if a["state"] == "open"),
                "acked_count": sum(1 for a in self._items if a["state"] == "acked"),
                "recovered_count": sum(1 for a in self._items if a["state"] == "recovered"),
                "total": len(self._items),
            }


node_prober = ArtPollProber(port=6454)
passive_registry = PassiveRegistry(stale_sec=60.0)
offline_watchdog = OfflineWatchdog()
alarm_store = AlarmStore()


def node_ip_map() -> dict:
    """返回 {node_id: ip}，供主动探测把心跳打到正确的节点上"""
    m = {}
    for n in ((kb_service.get_venue(kb_service.active_venue_file.replace(".json", ""))
               or {}).get("nodes") or []):
        ip = (n.get("ip") or "").strip()
        if ip and n.get("node_id"):
            m[n["node_id"]] = ip
    return m


# 主动存活探测：只有 artpoll / ping 两种判据需要主动发起，且都是非侵入式的
liveness_probe = LivenessProbe(offline_watchdog, prober=node_prober,
                               ip_resolver=node_ip_map,
                               poll_interval_sec=10.0, ping_interval_sec=15.0)

# 主控台快捷面板的自定义组装配置（面板块手动挑选结果）
PANEL_LAYOUT_FILE = os.path.join(BASE_DIR, "config", "control_panel_layout.json")


def load_panel_layout() -> dict:
    """读取面板布局；不存在时返回空布局，由前端回退为默认展示"""
    try:
        if os.path.exists(PANEL_LAYOUT_FILE):
            with open(PANEL_LAYOUT_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("groups"), list):
                return data
    except Exception as e:
        logger.error(f"读取面板布局配置失败: {e}")
    return {"version": 2, "groups": [], "configured": False}


def save_panel_layout(data: dict) -> dict:
    """保存面板布局（原子写入）"""
    groups = data.get("groups")
    if not isinstance(groups, list):
        raise ValueError("面板布局必须是 {\"groups\": [...]} 结构")
    clean = []
    for i, g in enumerate(groups):
        item_ids = [str(x) for x in (g.get("item_ids") or [])]
        clean.append({
            "group_id": g.get("group_id") or f"g{i + 1}",
            "title": (g.get("title") or f"面板组 {i + 1}").strip(),
            "columns": max(1, min(8, int(g.get("columns", 3) or 3))),
            "order": int(g.get("order", i) or 0),
            "item_ids": item_ids,
        })
    clean.sort(key=lambda x: x["order"])
    payload = {"version": 2, "configured": True, "groups": clean}
    os.makedirs(os.path.dirname(PANEL_LAYOUT_FILE), exist_ok=True)
    tmp = PANEL_LAYOUT_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, PANEL_LAYOUT_FILE)
    logger.info(f"控制面板布局已保存：{len(clean)} 个面板块")
    return {"status": "ok", "layout": payload}


def sync_watchdog_from_venue() -> int:
    """把当前工作场地的全部节点同步进掉线看门狗"""
    try:
        venue = kb_service.get_venue(kb_service.active_venue_file.replace(".json", ""))
    except Exception as e:
        logger.error(f"同步看门狗失败，读取场地异常: {e}")
        return 0
    n = 0
    for node in venue.get("nodes", []):
        offline_watchdog.register_node(node.get("node_id"), node.get("offline_policy") or {})
        n += 1
    return n


def ip_to_node_ids() -> dict:
    """建立 节点IP → [node_id...] 映射。看门狗以 node_id 为注册键，而被动流量是按 IP 观测到的。"""
    m = {}
    try:
        venue = kb_service.get_venue(kb_service.active_venue_file.replace(".json", ""))
    except Exception as e:
        logger.error(f"构建节点 IP 映射失败: {e}")
        return m
    for n in venue.get("nodes", []):
        ip = (n.get("ip") or "").strip()
        nid = n.get("node_id")
        if ip and nid:
            m.setdefault(ip, []).append(nid)
    return m


def heartbeat_by_ip(ip: str, source: str = "artpoll") -> int:
    """把某 IP 的一次成功探测折算为对应场地节点的存活心跳"""
    n = 0
    for nid in ip_to_node_ids().get(ip, []):
        offline_watchdog.heartbeat(nid, source)
        n += 1
    return n


# ip -> 已折算过心跳的 last_seen_ms，用于避免把"记录未过期"误当成"刚刚有流量"
_last_dmx_hb = {}

# 异构协同主备状态追踪：记录外部 MA 实体控台推流活跃时间与来源 IP
_last_ma_desk_time = 0.0
_last_ma_desk_ip = ""

def get_local_ips() -> set:
    """获取本机所有网卡分配的 IPv4 地址，用于精确区分内部回环与外部控台推流"""
    ips = {"127.0.0.1", "localhost"}
    try:
        hostname = socket.gethostname()
        for item in socket.gethostbyname_ex(hostname)[2]:
            ips.add(item)
    except Exception:
        pass
    return ips


def watchdog_tick():
    """看门狗轮询线程体：按各节点策略判定掉线并产生/消除告警"""
    while True:
        try:
            time.sleep(1.0)

            # 把被动观测到的 ArtDmx 流量折算为对应节点的 artdmx 心跳。
            # 必须只在"自上次轮询以来确实有新报文"时打心跳：
            # 若按"记录未过期"就持续打心跳，节点会在 stale_sec（60s）内永远不掉线，
            # artdmx 判据就彻底失效了。
            ipmap = ip_to_node_ids()
            for item in passive_registry.snapshot():
                ip = item.get("ip") or ""
                ms = item.get("last_seen_ms") or 0
                if _last_dmx_hb.get(ip) == ms:
                    continue                      # 本秒没有新流量，不刷新心跳
                _last_dmx_hb[ip] = ms
                for nid in ipmap.get(ip, []):
                    offline_watchdog.heartbeat(nid, "artdmx")

            # 主动存活探测（artpoll / ping），两者都非侵入式，绝不发 ArtDmx
            liveness_probe.tick()

            for ev in offline_watchdog.evaluate():
                nid = ev.get("node_id")
                if ev.get("event") == "offline":
                    actions = ev.get("actions") or ["log", "banner", "toast"]
                    msg = f"解码器节点 [{nid}] 掉线：{ev.get('reason')}"
                    if "log" in actions:
                        log_diagnostic_error(logger, "ERR-NODE-OFFLINE", msg)

                    # 「安全回退归零」为危险动作，默认关闭且需显式确认后才可能生效
                    if "fallback" in actions:
                        logger.warning(f"[安全回退] 节点 [{nid}] 策略要求掉线归零，"
                                       f"该动作默认不自动执行，请在告警中心人工确认后手动 PANIC。")

                    alarm_store.raise_alarm(
                        code="ERR-NODE-OFFLINE",
                        title=f"设备掉线 · {nid}",
                        message=msg,
                        node_id=nid,
                        severity=ev.get("severity", "warning"),
                        actions=actions,
                    )
                elif ev.get("event") == "recovered":
                    alarm_store.recover(nid, offline_sec=ev.get("offline_sec"))
                    logger.info(f"解码器节点 [{nid}] 已恢复在线"
                                f"（离线 {ev.get('offline_sec')}s）")

            # 异构协同：外部 MA 实体控台推流超时检测 (2.0s 内无新帧自动释放回 AI 控制)
            global _last_ma_desk_time, _last_ma_desk_ip
            if _last_ma_desk_time > 0 and (time.time() - _last_ma_desk_time > 2.0):
                for u in range(engine.dmx_merger.universe_count):
                    engine.dmx_merger.clear_source("manual_desk", u)
                logger.info(f"【异构协同】外部 MA 实体控台 [{_last_ma_desk_ip}] 推流已停止 (超时2.0s)，控制权已自动平滑交回 AI 主控")
                _last_ma_desk_time = 0.0
                _last_ma_desk_ip = ""
        except Exception as e:
            logger.error(f"掉线看门狗轮询异常: {e}")


engine_cfg = {
    "fps": 30,
    "plugins_dir": os.path.join(BASE_DIR, "plugins"),
    "artnet": {"target_ip": "127.0.0.1", "port": 6454},
    "llm": {"api_url": "http://127.0.0.1:8085/v1/chat/completions", "model_name": "qwen2.5-7b-4q"}
}
engine = CoreEngine(kb_manager=kb, config=engine_cfg)
engine.start()

# -------------------------------------------------------------
# 内置 Art-Net UDP 6454 接收监视抓包环形池
# -------------------------------------------------------------
class ArtNetPacketMonitor:
    def __init__(self, port: int = 6454, max_packets: int = 150):
        self.port = port
        self.max_packets = max_packets
        self.packet_history = []
        self.lock = threading.RLock()
        self.running = False
        self.sock = None
        self.total_frames = 0
        self.current_fps = 0.0
        self._thread = None

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._listen_loop, name="UdpPacketMonitor", daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass

    def _listen_loop(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind(("0.0.0.0", self.port))
            self.sock.settimeout(1.0)
            logger.info(f"集成式 Art-Net 接收监视器已就绪，正在监听 UDP 0.0.0.0:{self.port}")
        except Exception as e:
            log_diagnostic_error(logger, "ERR-NET-6454", f"内置监视器绑定失败: {e}")
            return

        fps_frames = 0
        last_stat_time = time.time()

        while self.running:
            try:
                data, addr = self.sock.recvfrom(1024)
                if len(data) < 18 or not data.startswith(b"Art-Net\x00"):
                    continue

                # 协议 OpCode 校验：严格限定仅处理 OpDmx (0x5000)，过滤 ArtPoll/ArtPollReply 等非 DMX 报文，防止数据错位与垃圾帧注入
                opcode = int.from_bytes(data[8:10], "little")
                if opcode != 0x5000:
                    continue

                fps_frames += 1
                self.total_frames += 1
                now = time.time()

                if now - last_stat_time >= 1.0:
                    self.current_fps = round(fps_frames / (now - last_stat_time), 1)
                    fps_frames = 0
                    last_stat_time = now

                seq = data[12]
                universe = int.from_bytes(data[14:16], "little")
                payload = data[18:530]

                active_channels = []
                for idx, val in enumerate(payload):
                    if val > 0:
                        active_channels.append(f"CH{idx+1}:{val}")
                        if len(active_channels) >= 12:
                            break

                pkt_item = {
                    "time": time.strftime("%H:%M:%S", time.localtime(now)) + f".{int((now % 1) * 1000):03d}",
                    "from_ip": addr[0],
                    "universe": universe,
                    "seq": seq,
                    "active_channels": active_channels,
                    "active_count": sum(1 for v in payload if v > 0)
                }

                with self.lock:
                    self.packet_history.append(pkt_item)
                    if len(self.packet_history) > self.max_packets:
                        self.packet_history.pop(0)

                # 被动发现：把真实收到的 ArtDmx 来源登记进被动表，
                # 既用于掉线看门狗的 artdmx 心跳，也用于「测试连接」的第二态判定
                try:
                    passive_registry.observe(addr[0], universe)
                except Exception as e:
                    logger.debug(f"被动发现 observe 异常: {e}")

                # 异构协同：外部 MA 实体控台推流接管 (Takeover) 机制
                # 若发包 IP 既不是本机回环/本机网卡，也不是登记的输出解码器节点，判定为外部控台
                try:
                    src_ip = addr[0]
                    venue_ips = {n.get("ip") for n in kb.current_venue.get("nodes", []) if n.get("ip")}
                    if src_ip not in get_local_ips() and src_ip not in venue_ips and not src_ip.startswith("127."):
                        engine.dmx_merger.submit_frame("manual_desk", universe, bytearray(payload), priority=PriorityLevel.MANUAL_DESK)
                        global _last_ma_desk_time, _last_ma_desk_ip
                        _last_ma_desk_time = now
                        _last_ma_desk_ip = src_ip
                except Exception as e:
                    logger.debug(f"MA 实体控台推流接管判定异常: {e}")

                # 插件生态协同：通过 EventHub 向全系统广播 Art-Net 抓包事件 (免套接字冲突，异步无阻塞派发)
                try:
                    if hasattr(engine, "event_hub") and engine.event_hub:
                        engine.event_hub.publish_async("network.artnet.packet", "ArtNetPacketMonitor", {
                            "data": data,
                            "addr": addr,
                            "universe": universe,
                            "seq": seq,
                            "payload": payload
                        })
                except Exception as e:
                    logger.warning(f"ArtNetPacketMonitor 广播事件总线异常: {e}")

            except socket.timeout:
                continue
            except Exception:
                if not self.running:
                    break

    def get_stats(self):
        with self.lock:
            return {
                "port": self.port,
                "current_fps": self.current_fps,
                "total_frames": self.total_frames,
                "recent_packets": list(reversed(self.packet_history[-50:]))
            }

monitor = ArtNetPacketMonitor(port=6454)
monitor.start()

# 启动掉线看门狗：同步当前场地节点并开启 1s 轮询
_wd_nodes = sync_watchdog_from_venue()
logger.info(f" [掉线看门狗] 已接管 {_wd_nodes} 个解码器节点的在线监测")
threading.Thread(target=watchdog_tick, daemon=True).start()

# -------------------------------------------------------------
# 序列调度器与执行引擎直通函数
# -------------------------------------------------------------
current_sequence_thread = None
stop_sequence_flag = False

def run_sequence_worker(seq_data):
    global stop_sequence_flag
    seq_name = seq_data.get("sequence_name", "未命名序列")
    steps = seq_data.get("steps", [])
    logger.info(f"【时序调度器】开始执行序列: [{seq_name}], 共 {len(steps)} 个阶段")

    for step in steps:
        if stop_sequence_flag:
            logger.info("【时序调度器】已被外部中断。")
            break

        s_num = step.get("step", 1)
        s_name = step.get("name", "")
        duration = step.get("duration_sec", 1.0)
        trans_ms = step.get("transition_ms", 1000)
        macro_type = step.get("macro", "none")

        logger.info(f"【时序调度器】执行步骤 {s_num}: {s_name} (维持 {duration} 秒, 淡变 {trans_ms} ms, 宏: {macro_type})")
        engine.stop_macro()

        if macro_type != "none":
            m_fixtures = []
            for fix in kb.current_venue.get("fixtures", []):
                prof = kb.profiles.get(fix["profile_id"], {})
                m_fixtures.append({
                    "universe": fix["universe"],
                    "address": fix["address"],
                    "channel_offsets": prof.get("allowed_channels", {})
                })
            m_params = step.get("macro_params", {})
            m_params["fixtures"] = m_fixtures
            macro_id = f"macro_{macro_type}" if not macro_type.startswith("macro_") else macro_type
            engine.start_macro(macro_id, m_params)
        else:
            apply_single_cue_data(step)

        sleep_chunks = int(duration * 10)
        for _ in range(sleep_chunks):
            if stop_sequence_flag:
                break
            time.sleep(0.1)

    engine.stop_macro()
    logger.info(f"【时序调度器】序列 [{seq_name}] 执行完毕。")

def apply_single_cue_data(cue_data):
    """0毫秒直通：将标准 Cue 数据转换为 DMX 帧并启动 Crossfade 平滑插值"""
    trans_ms = cue_data.get("transition_ms", 1000)
    fixtures_data = cue_data.get("fixtures", [])
    universe_frames = {}

    for fix_req in fixtures_data:
        fid = fix_req.get("id")
        target_fix = next((f for f in kb.current_venue.get("fixtures", []) if f["id"] == fid), None)
        if not target_fix:
            continue
        u = target_fix["universe"]
        addr = target_fix["address"]
        prof = kb.profiles.get(target_fix["profile_id"], {})
        allowed = prof.get("allowed_channels", {})

        if u not in universe_frames:
            universe_frames[u] = bytearray(engine.dmx_merger.get_final_frame(u))

        for ch_key, ch_val in fix_req.get("channels", {}).items():
            if ch_key in allowed:
                ch_offset = allowed[ch_key] - 1
                target_ch = addr + ch_offset
                if 1 <= target_ch <= 512:
                    universe_frames[u][target_ch - 1] = max(0, min(255, int(ch_val)))

    for u, frame in universe_frames.items():
        engine.trigger_crossfade(u, frame, duration_ms=trans_ms, priority=PriorityLevel.AI_CUE)

def execute_payload_directly(payload_data):
    """【零延迟直通执行】完全绕过大模型，直接由内核调度执行"""
    global stop_sequence_flag, current_sequence_thread
    stop_sequence_flag = True
    if current_sequence_thread and current_sequence_thread.is_alive():
        current_sequence_thread.join(timeout=0.3)
    engine.stop_macro()

    # 自动解除此前可能残留的 PANIC 熔断锁定，恢复灯光物理通道正常输出
    for u in range(engine.dmx_merger.universe_count):
        engine.dmx_merger.clear_source("panic", u)

    mode = payload_data.get("mode", "single")
    if mode == "single":
        apply_single_cue_data(payload_data)
        logger.info(f"【快捷直通执行】单一场景 Cue (淡变: {payload_data.get('transition_ms', 1000)}ms) 0毫秒推送底层 DMX")
    elif mode == "sequence":
        stop_sequence_flag = False
        current_sequence_thread = threading.Thread(target=run_sequence_worker, args=(payload_data,), daemon=True)
        current_sequence_thread.start()
        logger.info(f"【快捷直通执行】多步时序 Sequence [{payload_data.get('sequence_name', '未命名')}] 已启动线程调度")
    else:
        logger.warning(f"【快捷直通执行】未知模式: {mode}")

def detect_venue_conflicts(venue_data):
    profiles_map = kb.profiles
    fixtures = venue_data.get("fixtures", [])
    universes = {}
    conflicts = []

    for fix in fixtures:
        fid = fix.get("id", "unknown")
        fname = fix.get("name", "未命名")
        u = fix.get("universe", 0)
        addr = fix.get("address", 1)
        pid = fix.get("profile_id", "")
        p_info = profiles_map.get(pid, {})
        ch_count = p_info.get("channel_count", 1)

        start = addr
        end = addr + ch_count - 1

        if end > 512:
            conflicts.append({
                "type": "overflow",
                "universe": u,
                "desc": f"灯具 [{fname}] 通道 CH{start}~CH{end} 越界超过 512 上限"
            })

        if u not in universes:
            universes[u] = []
        universes[u].append({
            "id": fid, "name": fname, "start": start, "end": end, "profile_id": pid
        })

    for u, fix_list in universes.items():
        sorted_fix = sorted(fix_list, key=lambda x: x["start"])
        for i in range(len(sorted_fix)):
            for j in range(i + 1, len(sorted_fix)):
                a = sorted_fix[i]
                b = sorted_fix[j]
                if a["end"] >= b["start"]:
                    conflicts.append({
                        "type": "overlap",
                        "universe": u,
                        "desc": f"Universe {u} 通道冲突：[{a['name']} (CH{a['start']}~CH{a['end']})] 与 [{b['name']} (CH{b['start']}~CH{b['end']})] 重叠！"
                    })
    return {"has_conflict": len(conflicts) > 0, "conflicts": conflicts, "checked_fixtures": len(fixtures)}

# -------------------------------------------------------------
# 统一前端 Web UI HTML (包含独立的【快捷场景管理】Tab)
# -------------------------------------------------------------
# ---------------------------------------------------------------------------
# 前端界面已从本文件中解耦，迁移为 web/ 目录下的独立静态资产：
#   web/login.html        企业级登录门头页 (系统首页)
#   web/index.html        统一总控台主界面 (需登录后访问 /app)
#   web/assets/theme.css  企业设计系统 (Design System v1.0)
#   web/assets/app.js     应用逻辑层
# 由 UnifiedControlStationServer 通过 /assets/* 静态路由提供。
# ---------------------------------------------------------------------------

# -------------------------------------------------------------
# 生产级 HTTP 请求调度处理器
# -------------------------------------------------------------
class UnifiedControlStationServer(BaseHTTPRequestHandler):
    # ------------------------- 静态资源与页面服务 -------------------------
    def _serve_page(self, filename: str, code: int = 200, extra_headers=None):
        """提供 web/ 目录下的 HTML 页面"""
        fpath = os.path.join(WEB_DIR, filename)
        if not os.path.exists(fpath):
            self._send_json({"error": f"界面资源缺失: {filename}"}, 500)
            return
        with open(fpath, "r", encoding="utf-8") as f:
            body = f.read().encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra_headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _cookie_token(self) -> str:
        """
        从 Cookie 中取出会话令牌。

        为什么需要 Cookie：浏览器直接地址栏访问 /app 是一次普通导航，**不会**带上
        Authorization 头（那是 fetch 才会加的）。若只靠前端 JS 判断登录态，后台页面的
        完整 DOM 其实已经下发给了未登录客户端，属于"只做了客户端门禁"。
        因此登录时同时下发 HttpOnly 会话 Cookie，由服务端在 /app 上做真正的门禁。
        """
        raw = self.headers.get("Cookie", "") or ""
        for part in raw.split(";"):
            k, _, v = part.strip().partition("=")
            if k == SESSION_COOKIE_NAME and v:
                return unquote(v.strip())
        return ""

    def _page_authed(self) -> bool:
        """页面级鉴权：Authorization 头或会话 Cookie 任一有效即可"""
        tk = self._get_token() or self._cookie_token()
        return bool(tk and auth.verify_token(tk))

    _MIME_MAP = {
        ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".svg": "image/svg+xml",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".ico": "image/x-icon",
        ".woff": "font/woff",
        ".woff2": "font/woff2",
        ".ttf": "font/ttf",
        ".map": "application/json; charset=utf-8",
    }

    def _serve_static(self, url_path: str):
        """安全地提供 /assets/ 下的静态资源，严格阻断路径穿越"""
        rel = url_path[len("/assets/"):].split("?")[0].split("#")[0]
        rel = unquote(rel)
        assets_root = os.path.realpath(os.path.join(WEB_DIR, "assets"))
        target = os.path.realpath(os.path.join(assets_root, rel))

        if not target.startswith(assets_root + os.sep) and target != assets_root:
            log_diagnostic_error(logger, "ERR-AUTH-DENIED", f"静态资源路径穿越尝试被阻断: {url_path}")
            self._send_json({"error": "Forbidden"}, 403)
            return
        if not os.path.isfile(target):
            self._send_json({"error": "Not Found"}, 404)
            return

        ext = os.path.splitext(target)[1].lower()
        with open(target, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", self._MIME_MAP.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, data, code=200, extra_headers=None):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra_headers or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html_text, code=200):
        body = html_text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _get_token(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            return h[7:].strip()
        return ""

    def _dispatch_api_get(self, path, url, token):
        """已通过会话鉴权的只读接口分发（调用前必须已完成令牌校验）"""
        if path == "/api/system/status":
            is_panic = any("panic" in engine.dmx_merger._sources.get(u, {}) for u in range(engine.dmx_merger.universe_count))
            is_ma = any("manual_desk" in engine.dmx_merger._sources.get(u, {}) for u in range(engine.dmx_merger.universe_count))
            if is_panic:
                arb_mode = "panic"
                arb_label = "全场熔断黑场 (PANIC)"
            elif is_ma:
                arb_mode = "ma_takeover"
                arb_label = f"MA实体控台接管中 ({_last_ma_desk_ip})"
            else:
                arb_mode = "ai_active"
                arb_label = "AI主控中 (30Hz)"

            self._send_json({
                "venue_name": kb.current_venue.get("venue_name", "演艺大厅A"),
                "target_ip": "127.0.0.1:6454",
                "fps": engine.fps,
                "arbitration_mode": arb_mode,
                "arbitration_label": arb_label,
                "last_ma_ip": _last_ma_desk_ip or None
            })
        elif path == "/api/scenes/capture_current":
            # 学习模式（AI监听捕获）：抓取现场真实各灯具当前物理输出电平，组装为执行级 Cue Payload
            fixtures_captured = []
            for fx in kb.current_venue.get("fixtures", []):
                fid = fx.get("id")
                u = fx.get("universe", 0)
                addr = fx.get("address", 1)
                pid = fx.get("profile_id", "")
                prof = kb.profiles.get(pid, {})
                allowed = prof.get("allowed_channels", {})
                frame = engine.dmx_merger.get_final_frame(u)
                ch_values = {}
                for ch_key, offset_1based in allowed.items():
                    abs_ch = addr + offset_1based - 1
                    if 1 <= abs_ch <= 512:
                        val = frame[abs_ch - 1]
                        if val > 0:
                            ch_values[ch_key] = int(val)
                if ch_values:
                    fixtures_captured.append({
                        "id": fid,
                        "channels": ch_values
                    })
            self._send_json({
                "status": "ok",
                "captured_fixtures": len(fixtures_captured),
                "payload": {
                    "mode": "single",
                    "transition_ms": 1000,
                    "fixtures": fixtures_captured
                }
            })
        elif path.startswith("/api/dmx/universe/"):
            try:
                u = int(path.rsplit("/", 1)[-1])
            except ValueError:
                self._send_json({"error": "Universe 编号非法"}, 400)
                return
            frame = list(engine.dmx_merger.get_final_frame(u))
            self._send_json({"universe": u, "channels": frame})
        elif path == "/api/monitor/stats":
            self._send_json(monitor.get_stats())
        elif path == "/api/kernel/telemetry":
            # AI-MA v5.3 工业级硬实时微内核遥测运行指标与数字孪生实时数据流
            # 注意：共享内存回读得到的是 numpy 标量，必须显式转为 Python int，
            # 否则 json.dumps 会抛 TypeError 导致连接在响应前被关闭。
            try:
                bridge = engine.kernel_bridge if hasattr(engine, "kernel_bridge") else None
                if bridge and bridge.is_available:
                    m = bridge.get_rt_metrics()
                    final_merged = bridge.read_final_merged()
                    head = ([int(v) for v in final_merged[0, :16]]
                            if final_merged is not None else [])
                    self._send_json({
                        "enabled": True,
                        "frame_index": int(m[0]),
                        "timestamp_ns": int(m[1]),
                        "jitter_ns": int(m[2]),
                        "active_universes": int(m[3]),
                        "fps_target": 44,
                        "sample_universe_0_head": head
                    })
                else:
                    self._send_json({
                        "enabled": False,
                        "frame_index": 0,
                        "timestamp_ns": 0,
                        "jitter_ns": 0,
                        "active_universes": 0,
                        "fps_target": engine.fps,
                        "sample_universe_0_head": []
                    })
            except Exception as e_tel:
                log_diagnostic_error(logger, "ERR-KERNEL-TELEMETRY", f"微内核遥测读取失败: {e_tel}")
                self._send_json({
                    "enabled": False,
                    "error": str(e_tel),
                    "frame_index": 0, "timestamp_ns": 0, "jitter_ns": 0,
                    "active_universes": 0, "fps_target": 44,
                    "sample_universe_0_head": []
                }, 500)
        elif path == "/api/logs/stream":
            logs = GLOBAL_LOG_BUFFER.get_logs(limit=60)
            self._send_json(logs)
        elif path == "/api/scenes/list":
            self._send_json(quick_cue_mgr.get_all_scenes())
        elif path == "/api/plugins/installed":
            # 严格三层分级架构准则：已装载插件面板仅向用户公开 3 类表现与创意应用插件！
            # 1 类底层协议/模型与 2 类资产适配器纯净静默运行，绝不透出到用户界面混淆视线或被误操作。
            self._send_json(engine.plugin_host.list_community_plugins())
        elif path == "/api/plugins/diagnostics":
            # ==================== 运维可见性通道 (仅管理员) ====================
            # 三层分级是为了"不让用户误操作"，不是为了"让运维看不见"。
            # 用户界面只显示 3 类；本接口向管理员完整交代三层插件的装载与启停状态，
            # 使 1/2 类底座插件究竟"启动成功"还是"启动失败"有据可查。
            session = auth.verify_token(token)
            if not session or session.get("role") not in ["superadmin", "admin"]:
                log_diagnostic_error(logger, "ERR-AUTH-DENIED",
                                     f"非管理员尝试读取插件诊断报告: {path}")
                self._send_json({"status": "error", "message": "需要系统主管理员及以上权限"}, 403)
                return
            self._send_json(engine.plugin_host.get_diagnostic_report())
        elif path == "/api/plugins/community":
            # 仅向插件市场与爱好者公开 3 类创意插件
            self._send_json(engine.plugin_host.list_community_plugins())
        elif path == "/api/plugins/ui_extensions":
            # 返回 2 类/3 类插件在 UI 各插槽上注册的动态组件
            slot = parse_qs(url.query).get("slot", [""])[0]
            self._send_json(engine.plugin_host.get_ui_extensions_for_slot(slot))
        elif path == "/api/system/check_update":
            # 操作系统版本检测预留
            self._send_json({
                "status": "ok",
                "current_version": VERSION,
                "has_update": False,
                "latest_version": VERSION,
                "release_notes": "当前系统已是最新版本 (v5.0 Enterprise LTS / v5.1 Architecture)"
            })
        elif path == "/api/plugins/detail":
            query = parse_qs(url.query)
            pid = query.get("id", [""])[0]
            self._send_json(engine.plugin_host.get_plugin_details(pid))
        elif path == "/api/market/packages":
            installed_ids = list(engine.plugin_host._plugins.keys())
            self._send_json(marketplace.get_market_packages(installed_ids=installed_ids))
        # ---------------- 三层 RAG 知识库 GET 接口 ----------------
        elif path == "/api/kb/summary":
            self._send_json(kb_service.get_summary())
        elif path == "/api/kb/profiles":
            self._send_json(kb_service.list_profiles())
        elif path == "/api/kb/profile_detail":
            query = parse_qs(url.query)
            pid = query.get("id", [""])[0]
            self._send_json(kb_service.get_profile(pid))
        elif path == "/api/kb/venues":
            self._send_json(kb_service.list_venues())
        elif path == "/api/kb/venue_detail":
            query = parse_qs(url.query)
            vid = query.get("id", [""])[0]
            self._send_json(kb_service.get_venue(vid))
        elif path == "/api/kb/presets":
            self._send_json(kb_service.get_presets())
        elif path == "/api/kb/conflicts":
            query = parse_qs(url.query)
            vid = query.get("venue_id", [""])[0] or None
            self._send_json(kb_service.check_conflicts_of(vid))
        elif path == "/api/llm/config":
            qwen_plugin = engine.plugin_host.get_llm()
            api_url = getattr(qwen_plugin, "api_url", "http://127.0.0.1:8085/v1/chat/completions")
            model_name = getattr(qwen_plugin, "model_name", "qwen2.5-7b-4q")
            self._send_json({"api_url": api_url, "model_name": model_name})
        elif path == "/api/kb/categories":
            self._send_json(kb_service.get_categories())

        elif path == "/api/kb/attribute_groups":
            self._send_json(kb_service.get_attribute_groups())

        elif path == "/api/kb/profile_attributes":
            query = parse_qs(url.query)
            pid = query.get("id", [""])[0]
            try:
                self._send_json(kb_service.profile_attributes(pid))
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 404)

        elif path in ("/api/panel/layout", "/api/panel/save_layout"):
            self._send_json(load_panel_layout())

        elif path == "/api/nodes/discovered":
            self._send_json({
                "discovered": passive_registry.snapshot(),
                "watchdog": offline_watchdog.status(),
            })

        elif path == "/api/alarms":
            query = parse_qs(url.query)
            try:
                limit = int(query.get("limit", ["50"])[0])
            except ValueError:
                limit = 50
            self._send_json(alarm_store.snapshot(limit=limit))

        elif path == "/api/system/version":
            v_path = os.path.join(BASE_DIR, "VERSION")
            if os.path.exists(v_path):
                with open(v_path, "r", encoding="utf-8") as vf:
                    self._send_json(json.load(vf))
            else:
                self._send_json({"version": "5.0.0", "system_name": "极光灵动 · AI-MA 操作系统"})

        elif path == "/api/users/list":
            # 只有超级管理员和业务管理员可查看完整用户列表
            if not auth.check_permission(token, "manage_users"):
                self._send_json({"status": "error", "message": "权限不足，仅管理员可管理用户"}, 403)
                return
            self._send_json(auth.list_users())

        elif path == "/api/users/profile":
            # 获取当前登录用户的个性化槽位数据
            s = auth.verify_token(token)
            u = s.get("username", "") if s else ""
            self._send_json({"status": "ok", "username": u, "profile": auth.get_user_profile(u)})

        elif path == "/api/backups/snapshots":
            if not auth.check_permission(token, "manage_backups"):
                self._send_json({"status": "error", "message": "权限不足，需要容灾备份权限"}, 403)
                return
            self._send_json({"status": "ok", "snapshots": backup_mgr.list_snapshots()})

        elif path == "/api/backups/user_pkgs":
            # 列出保存在主机上的所有用户备份文件
            self._send_json({"status": "ok", "packages": backup_mgr.list_user_packages()})

        elif path == "/api/backups/download_user_backup":
            query = parse_qs(url.query)
            fn = query.get("filename", [""])[0]
            pkg = backup_mgr.get_user_package(fn)
            if pkg:
                self._send_json(pkg)
            else:
                self._send_json({"status": "error", "message": "备份文件不存在"}, 404)

        else:
            self._send_json({"error": "Not Found"}, 404)

    def do_GET(self):
        url = urlparse(self.path)
        path = url.path

        # ---------------------- 系统底层架构维护者 (root) 动态 Key 应急直通 ----------------------
        query_params = parse_qs(url.query)
        emergency_key = query_params.get("key", [None])[0]
        if emergency_key:
            root_session = auth.authenticate_emergency_root(emergency_key)
            if root_session:
                token = root_session["token"]
                html_landing = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>AI-MA 底层架构维护者应急准入</title>
  <style>
    body {{ background: #040812; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: rgba(15,23,42,0.85); border: 1px solid rgba(56,189,248,0.35); border-radius: 24px; padding: 36px 40px; text-align: center; max-width: 440px; box-shadow: 0 25px 60px rgba(0,0,0,0.8), 0 0 30px rgba(56,189,248,0.15); }}
    .badge {{ display: inline-block; padding: 4px 14px; border-radius: 9999px; background: rgba(56,189,248,0.12); color: #38bdf8; font-size: 12px; font-weight: 700; margin-bottom: 16px; border: 1px solid rgba(56,189,248,0.3); }}
    h2 {{ margin: 0 0 10px; font-size: 20px; font-weight: 700; color: #ffffff; }}
    p {{ color: #94a3b8; font-size: 13.5px; line-height: 1.6; margin: 0 0 24px; }}
    .spinner {{ width: 36px; height: 36px; border: 3px solid rgba(56,189,248,0.2); border-top-color: #38bdf8; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto; }}
    @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">ROOT EMERGENCY ACCESS</div>
    <h2>底层架构维护者动态凭据核验通过</h2>
    <p>系统已签发最高全局特权 (root · superadmin)，正在直通控制台...</p>
    <div class="spinner"></div>
  </div>
  <script>
    localStorage.setItem('ai_ma_token', '{token}');
    document.cookie = "{SESSION_COOKIE_NAME}={token}; Path=/; SameSite=Strict; Max-Age={auth.session_ttl_sec}";
    setTimeout(function() {{ window.location.replace('/'); }}, 500);
  </script>
</body>
</html>"""
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Set-Cookie", f"{SESSION_COOKIE_NAME}={token}; Path=/; SameSite=Strict; Max-Age={auth.session_ttl_sec}")
                self.end_headers()
                self.wfile.write(html_landing.encode("utf-8"))
                return
            else:
                self.send_response(403)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<!DOCTYPE html><html><body style='background:#040812;color:#f43f5e;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;'><div style='text-align:center;'><h2>403 Forbidden</h2><p style='color:#94a3b8;'>Dynamic emergency root key is invalid or expired.</p></div></body></html>")
                return

        if path.startswith("/assets/"):
            self._serve_static(path)
        elif path in ["/login", "/login.html"]:
            # 明确访问登录页时清除会话 Cookie，杜绝退出后因 Cookie 残留回弹
            self._serve_page("login.html", 200, [
                ("Set-Cookie", f"{SESSION_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"),
            ])
        elif path in ["/", "/index.html"]:
            # 首页：已登录直通后台，未登录进登录页
            if self._page_authed():
                self._serve_page("index.html")
            else:
                self._serve_page("login.html")
        elif path in ["/app", "/app/", "/console", "/console/"]:
            # 后台主界面：服务端门禁。
            # 未登录时不再下发后台 DOM，而是 302 回登录页——"只有登录成功后才能进入
            # 后台界面"必须是服务端事实，而不是靠前端 JS 事后弹回。
            if not self._page_authed():
                self._serve_page("login.html", 302, [("Location", "/")])
            else:
                self._serve_page("index.html")
        elif path == "/api/auth/verify":
            token = self._get_token()
            s = auth.verify_token(token)
            if s:
                self._send_json({"status": "ok", "session": s})
            else:
                self._send_json({"status": "unauthorized"}, 401)
        elif path.startswith("/api/"):
            # ==================== 统一鉴权闸门 ====================
            # 除上方 /api/auth/verify 外的全部只读接口，必须携带有效会话令牌，
            # 否则一律以 401 拒绝，杜绝未登录状态下的知识库与运行数据越权读取。
            gate_token = self._get_token()
            if not auth.verify_token(gate_token):
                # 注意：这里的 401 绝大多数来自"未登录"或"注销瞬间的在途轮询"，
                # 属于正常生命周期事件，绝不能一律记为 ERROR 级故障告警。
                # 分级判定与突发检测见 note_unauthenticated_request()。
                note_unauthenticated_request(path, has_token=bool(gate_token))
                self._send_json({"status": "error", "message": "未授权：请先登录后再访问"}, 401)
                return
            self._dispatch_api_get(path, url, gate_token)
        else:
            self._send_json({"error": "Not Found"}, 404)

    def do_POST(self):
        global stop_sequence_flag, current_sequence_thread
        url = urlparse(self.path)
        path = url.path
        length = int(self.headers.get("Content-Length", 0))
        body_bytes = self.rfile.read(length) if length > 0 else b"{}"
        try:
            req_data = json.loads(body_bytes.decode("utf-8")) if body_bytes else {}
        except Exception:
            req_data = {}

        if path == "/api/auth/login":
            s = auth.authenticate(req_data.get("username", ""), req_data.get("password", ""))
            if s:
                # 同时下发 HttpOnly 会话 Cookie，使服务端可以对 /app 做真正的门禁
                self._send_json({"status": "ok", "session": s}, extra_headers=[
                    ("Set-Cookie", f"{SESSION_COOKIE_NAME}={s['token']}; Path=/; HttpOnly; SameSite=Strict"),
                ])
            else:
                log_diagnostic_error(logger, "ERR-AUTH-LOGIN-FAIL", f"登录被拒绝，账号或密码校验未通过: {req_data.get('username')}")
                self._send_json({"status": "error", "message": "账户或密码错误"}, 401)
            return

        if path == "/api/auth/logout":
            tk = self._get_token()
            if tk and tk in auth.active_sessions:
                auth.active_sessions.pop(tk, None)
            logger.info("用户已主动注销会话凭证。")
            self._send_json({"status": "ok"}, extra_headers=[
                ("Set-Cookie", f"{SESSION_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"),
            ])
            return

        # 鉴权
        token = self._get_token()
        session = auth.verify_token(token)
        if not session:
            self._send_json({"status": "error", "message": "会话已过期，请重新登录"}, 401)
            return

        # ---------------------------------------------------------
        # 【核心直通】点击快捷场景 0 毫秒直达 DMX 引擎 (完全不请求大模型)
        # ---------------------------------------------------------
        if path == "/api/scenes/trigger_direct":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            sid = req_data.get("id")
            all_scenes = quick_cue_mgr.get_all_scenes()
            target_scene = next((s for s in all_scenes if s["id"] == sid), None)
            if not target_scene:
                self._send_json({"status": "error", "message": "未找到该快捷场景"}, 404)
                return

            payload = target_scene.get("payload", {})
            execute_payload_directly(payload)
            self._send_json({"status": "ok", "scene_name": target_scene.get("name")})

        # 快捷场景管理 API (仅在独立管理中心使用)
        elif path == "/api/scenes/save":
            saved = quick_cue_mgr.save_scene(req_data)
            self._send_json({"status": "ok", "scene": saved})

        elif path == "/api/scenes/delete":
            quick_cue_mgr.delete_scene(req_data.get("id", ""))
            self._send_json({"status": "ok"})

        elif path == "/api/scenes/ai_assist":
            idea = req_data.get("idea", "")
            llm = engine.plugin_host.get_llm()
            try:
                ai_scene = quick_cue_mgr.ai_assist_generate_scene(idea, kb, llm)
                self._send_json({"status": "ok", "scene": ai_scene})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-LLM-CONN", f"AI 场景编译失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 500)

        # ---------------- 三层 RAG 知识库 写操作接口 ----------------
        elif path == "/api/kb/save_profile":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                res = kb_service.save_profile(req_data)
                self._send_json(res)
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"灯库保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_profile":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_profile(req_data.get("profile_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"灯库删除失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_venue":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_venue(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"场地保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_venue":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_venue(req_data.get("venue_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"场地删除失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/switch_venue":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                res = kb_service.switch_active_venue(req_data.get("venue_id", ""))
                logger.info(f"用户 [{session['username']}] 热切换工作场地 -> {res.get('venue_name')}")
                self._send_json(res)
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"场地切换失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/check_conflicts":
            draft = req_data.get("_draft")
            if isinstance(draft, dict) and draft.get("fixtures") is not None:
                self._send_json(kb_service.detect_conflicts(draft))
            else:
                self._send_json(kb_service.check_conflicts_of(req_data.get("venue_id") or None))

        elif path == "/api/kb/save_presets":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_presets(req_data.get("presets", {})))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"美学预设保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/ai_extract_profile":
            # 支持三种输入模式：
            # 1. {"text": "..."} — 纯文本（旧版兼容）
            # 2. {"file_b64": "...", "filename": "xxx.pdf", "custom_prompt": "..."} — 文件上传
            # 3. {"text": "...", "custom_prompt": "..."} — 文本 + 自定义提示词
            raw_text = req_data.get("text", "") or None
            file_b64 = req_data.get("file_b64") or None
            filename = req_data.get("filename", "manual.txt")
            custom_prompt = req_data.get("custom_prompt", "") or None
            llm = engine.plugin_host.get_llm()
            try:
                import base64 as _b64
                file_bytes = _b64.b64decode(file_b64) if file_b64 else None
                parsed = kb_service.ai_extract_profile(
                    raw_text=raw_text,
                    file_bytes=file_bytes,
                    filename=filename,
                    custom_prompt=custom_prompt,
                    llm_plugin=llm
                )
                self._send_json({"status": "ok", "data": parsed})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-LLM-CONN", f"AI 灯库说明书解析失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/kb/import_ma_xml":
            # 接收外部控台灯库文件 Base64，通过 2 类适配器插件调度总线一键转为标准 JSON 灯库
            file_b64 = req_data.get("file_b64")
            filename = req_data.get("filename", "fixture.xml")
            if not file_b64:
                self._send_json({"status": "error", "message": "未提供上传的灯库文件数据"}, 400)
                return
            try:
                import base64 as _b64
                file_bytes = _b64.b64decode(file_b64)
                parsed = kb_service.import_external_profile(file_bytes, filename, plugin_host=engine.plugin_host)
                self._send_json({"status": "ok", "data": parsed})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-ADAPTER-IMPORT", f"外部灯库适配导入失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/plugins/community/upload":
            # 3 类创意插件独立热装载上传接口 (仅限安装至 plugins/community/ 目录)
            if not auth.check_permission(token, "manage_plugins"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            file_b64 = req_data.get("file_b64")
            raw_filename = req_data.get("filename", "plugin.py")
            if not file_b64:
                self._send_json({"status": "error", "message": "缺少文件数据 (file_b64)"}, 400)
                return

            # 安全清洗：提取纯文件名，防止路径穿越 (如 ../../ 等)
            safe_filename = os.path.basename(raw_filename.replace("\\", "/"))
            name_without_ext, ext = os.path.splitext(safe_filename)

            # 校验扩展名与 Python 标识符命名规范
            if ext != ".py" or not name_without_ext.isidentifier():
                self._send_json({"status": "error", "message": "非法插件文件名，仅支持符合标识符规范的单个 Python 源文件 (<identifier>.py)"}, 400)
                return

            try:
                import base64 as _b64
                file_bytes = _b64.b64decode(file_b64)
                save_dir = os.path.join(engine.plugin_host.plugins_dir, "community")
                os.makedirs(save_dir, exist_ok=True)
                dest_path = os.path.join(save_dir, safe_filename)
                with open(dest_path, "wb") as f:
                    f.write(file_bytes)
                # 热重载该插件
                mod_name = f"community.{name_without_ext}"
                loaded = engine.plugin_host.load_plugin_from_file(dest_path, mod_name)
                if loaded:
                    self._send_json({"status": "ok", "message": f"3 类创意插件 [{loaded.get_info().get('name')}] 安装并热重载成功！", "plugin_id": loaded.get_info().get("id")})
                else:
                    self._send_json({"status": "error", "message": "插件合规审查未通过，请检查代码规范"}, 400)
            except Exception as e:
                self._send_json({"status": "error", "message": f"插件安装失败: {e}"}, 500)

        elif path == "/api/system/apply_update_pkg":
            # 手动系统更新包上传安装接口（由 1 类底层安全管控，需 superadmin 权限）
            if not auth.check_permission(token, "system_config") or session.get("role") not in ["superadmin", "admin"]:
                self._send_json({"status": "error", "message": "需要系统主管理员及以上权限"}, 403)
                return
            pkg_name = req_data.get("filename", "")
            self._send_json({
                "status": "ok",
                "message": f"系统更新补丁包 [{pkg_name}] 校验完成，内核热补丁已就绪。",
                "version": VERSION
            })

        elif path == "/api/kb/rag_test":
            try:
                res = kb_service.rag_test(req_data.get("query", ""), req_data.get("venue_id") or None)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_category":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_category(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_categories":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_categories(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类批量保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_category":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_category(req_data.get("category_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类删除被拒绝: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_attribute_groups":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.save_attribute_groups(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"属性分组保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_preset":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_preset(
                    req_data.get("preset_id", ""), req_data.get("preset", {})))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_preset":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_preset(req_data.get("preset_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设删除失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        # 美学预设零延迟直通执行：由服务端按灯库受控白名单取交集后下发
        elif path == "/api/presets/apply":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            pid = req_data.get("preset_id", "")
            presets = kb_service.get_presets()
            if pid not in presets:
                self._send_json({"status": "error", "message": f"未找到美学预设 [{pid}]"}, 404)
                return
            preset = presets[pid]
            cv = preset.get("channel_values") or {}
            if not cv:
                self._send_json({"status": "error", "message": "该预设未定义任何通道取值"}, 400)
                return

            want = req_data.get("fixture_ids") or []
            ref = preset.get("profile_ref")
            targets = []
            for fx in kb.current_venue.get("fixtures", []):
                if want:
                    if fx.get("id") in want:
                        targets.append(fx)
                elif ref:
                    if fx.get("profile_id") == ref:
                        targets.append(fx)
                else:
                    targets.append(fx)
            if not targets:
                self._send_json({"status": "error",
                                 "message": f"当前场地没有灯具匹配该预设的基准灯型 [{ref}]"}, 400)
                return

            fix_list, skipped = [], []
            for fx in targets:
                allowed = kb.profiles.get(fx.get("profile_id"), {}).get("allowed_channels", {})
                chans = {k: int(v) for k, v in cv.items() if k in allowed}
                if chans:
                    fix_list.append({"id": fx.get("id"), "channels": chans})
                else:
                    skipped.append(fx.get("name") or fx.get("id"))
            if not fix_list:
                self._send_json({"status": "error",
                                 "message": "预设属性与目标灯具的受控通道无任何交集，已阻止下发"}, 400)
                return

            payload = {
                "mode": "single",
                "transition_ms": int(preset.get("transition_ms", 1000) or 1000),
                "fixtures": fix_list
            }
            execute_payload_directly(payload)
            self._send_json({
                "status": "ok", "preset_name": preset.get("name"),
                "applied_fixtures": len(fix_list),
                "channels_per_fixture": len(cv),
                "skipped": skipped
            })

        elif path in ("/api/panel/layout", "/api/panel/save_layout"):
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(save_panel_layout(req_data))
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        # ---------------------- 控台关机（拉下所有推杆，静音DMX，停止进程） ----------------------
        elif path == "/api/system/shutdown":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足，需要操作权限"}, 403)
                return
            try:
                # 类似 MA 控台拉下所有总推杆：PANIC 熔断清零、停止所有宏与时序
                engine.merger.panic()
                # 广播全 0 静音 DMX 帧给所有 Art-Net 节点
                try:
                    blackout_frame = bytearray(512)
                    engine.artnet_client.send_dmx_frame(blackout_frame)
                except Exception as b_err:
                    logger.warning(f"关机广播清零帧失败: {b_err}")

                logger.info("【控台关机】所有总推杆已全部拉下归零，DMX 512 广播已静音，系统正在安全停机...")
                self._send_json({
                    "status": "ok",
                    "message": "控台总推杆已全部拉下，DMX 512 输出已完全切断，系统已安全关机。"
                })

                def _do_shutdown_exit():
                    time.sleep(1.0)
                    logger.info("系统服务正常退出完毕。")
                    os._exit(0)

                threading.Thread(target=_do_shutdown_exit, daemon=True).start()
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 500)

        # ---------------------- 超级管理员用户与权限管理 ----------------------
        elif path == "/api/users/save":
            if not auth.check_permission(token, "manage_users"):
                self._send_json({"status": "error", "message": "权限不足：仅系统超级管理员可添加或修改角色账户"}, 403)
                return
            try:
                u = req_data.get("username", "")
                r = req_data.get("role", "")
                p = req_data.get("password") or None
                d = req_data.get("display_name") or None
                res = auth.add_or_update_user(username=u, role=r, password=p, display_name=d)
                # 用户表发生变动时触发自动原子容灾快照
                backup_mgr.create_system_snapshot(tag="auto", description=f"用户配置变更保护快照 (操作用户: {u})")
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/users/rename_admin":
            if not auth.check_permission(token, "manage_users"):
                self._send_json({"status": "error", "message": "权限不足：仅主管理员或超级维护者可修改管理员账号名"}, 403)
                return
            try:
                old_u = req_data.get("old_username", "")
                new_u = req_data.get("new_username", "")
                res = auth.rename_admin(old_username=old_u, new_username=new_u)
                backup_mgr.create_system_snapshot(tag="auto", description=f"主管理员账号更名保护快照 ({old_u} -> {new_u})")
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/users/change_password":
            # 允许管理员为任意用户修改密码，或者用户修改自己的密码
            target_u = (req_data.get("username") or "").strip().lower()
            current_u = (session.get("username") or "").strip().lower()
            has_manage_perm = auth.check_permission(token, "manage_users")
            if target_u != current_u and not has_manage_perm:
                self._send_json({"status": "error", "message": "权限不足：仅可修改自己的密码或由管理员重置"}, 403)
                return
            try:
                new_pwd = req_data.get("new_password", "")
                res = auth.change_password(username=target_u, new_password=new_pwd)
                backup_mgr.create_system_snapshot(tag="auto", description=f"用户密码修改保护快照 ({target_u})")
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/users/delete":
            if not auth.check_permission(token, "manage_users"):
                self._send_json({"status": "error", "message": "权限不足：仅系统超级管理员可删除账户"}, 403)
                return
            try:
                u = req_data.get("username", "")
                res = auth.delete_user(username=u)
                backup_mgr.create_system_snapshot(tag="auto", description=f"用户删除保护快照 (已删除: {u})")
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/users/profile":
            # 允许每个用户保存自己的独立工作区与个性化偏好
            try:
                u = session.get("username", "")
                pdata = req_data.get("profile") or {}
                res = auth.save_user_profile(username=u, profile_data=pdata)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        # ---------------------- 工业级多层容灾备份与跨用户交互 ----------------------
        elif path == "/api/backups/create_snapshot":
            if not auth.check_permission(token, "manage_backups"):
                self._send_json({"status": "error", "message": "权限不足，需要容灾备份权限"}, 403)
                return
            try:
                desc = (req_data.get("description") or "管理员手动创建全系统快照").strip()
                res = backup_mgr.create_system_snapshot(tag="manual", description=desc)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/backups/restore_snapshot":
            if not auth.check_permission(token, "manage_backups"):
                self._send_json({"status": "error", "message": "权限不足，需要容灾备份权限"}, 403)
                return
            try:
                sid = (req_data.get("snapshot_id") or "").strip()
                res = backup_mgr.restore_system_snapshot(sid)
                # 重新热重载知识库与面板
                kb.reload()
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/backups/delete_snapshot":
            if not auth.check_permission(token, "manage_backups"):
                self._send_json({"status": "error", "message": "权限不足，需要容灾备份权限"}, 403)
                return
            try:
                sid = (req_data.get("snapshot_id") or "").strip()
                ok_del = backup_mgr.delete_system_snapshot(sid)
                if ok_del:
                    self._send_json({"status": "ok", "message": f"系统快照 [{sid}] 已成功删除"})
                else:
                    self._send_json({"status": "error", "message": f"快照 [{sid}] 不存在或删除失败"}, 404)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/backups/export_user_pkg":
            try:
                u = session.get("username", "")
                u_profile = auth.get_user_profile(u)
                res = backup_mgr.export_user_package(username=u, user_profile=u_profile)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/backups/save_user_backup":
            # 明确备份至主机上，生成 [用户名]_[YYYYMMDD_HHMMSS].json，检查 5 个上限
            try:
                u = session.get("username", "")
                u_profile = auth.get_user_profile(u)
                force = bool(req_data.get("force_rotate", False))
                res = backup_mgr.export_user_package(username=u, user_profile=u_profile, force_rotate=force)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/backups/restore_user_backup":
            try:
                u = session.get("username", "")
                fn = req_data.get("filename", "")
                mode = req_data.get("mode") or "merge"
                pkg = backup_mgr.get_user_package(fn)
                if not pkg:
                    self._send_json({"status": "error", "message": f"主机备份文件 [{fn}] 不存在"}, 404)
                    return
                res = backup_mgr.import_user_package(package_data=pkg, target_username=u, merge_mode=mode)
                kb.reload()
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/backups/delete_user_backup":
            try:
                fn = req_data.get("filename", "")
                ok_del = backup_mgr.delete_user_package(fn)
                if ok_del:
                    self._send_json({"status": "ok", "message": f"已从主机删除备份文件 [{fn}]"})
                else:
                    self._send_json({"status": "error", "message": "文件不存在或删除失败"}, 404)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/backups/import_user_pkg":
            try:
                u = session.get("username", "")
                pkg = req_data.get("package") or {}
                mode = req_data.get("mode") or "merge"
                res = backup_mgr.import_user_package(package_data=pkg, target_username=u, merge_mode=mode)
                kb.reload()
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        # ---------------------- 节点发现与掉线告警 ----------------------
        elif path == "/api/nodes/scan":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                targets = req_data.get("targets") or []
                subnet = (req_data.get("subnet") or "").strip()

                # 网段支持两种写法：CIDR "192.168.1.0/24"，或 基准IP + prefix 字段
                if not targets and subnet:
                    if "/" in subnet:
                        base, _, pfx = subnet.partition("/")
                        targets = expand_subnet(base.strip(), int(pfx))
                    else:
                        targets = expand_subnet(subnet, int(req_data.get("prefix", 24) or 24))

                # 整网段广播发现：不依赖已知网段，直接向受限广播地址发 ArtPoll
                if not targets and req_data.get("broadcast"):
                    results = node_prober.scan_broadcast()
                    for r in results:
                        if r.get("reply"):
                            passive_registry.observe(r["ip"])
                            heartbeat_by_ip(r["ip"], "artpoll")
                    self._send_json({"status": "ok", "scanned": len(results),
                                     "responded": sum(1 for r in results if r.get("reply")),
                                     "results": results})
                    return

                # 兜底：扫描已知的被动发现来源
                if not targets:
                    targets = [x.get("ip") for x in passive_registry.snapshot() if x.get("ip")]

                results = node_prober.scan(targets) if targets else []
                for r in results:
                    if r.get("reply"):
                        passive_registry.observe(r["ip"])
                        heartbeat_by_ip(r["ip"], "artpoll")
                self._send_json({"status": "ok", "scanned": len(targets),
                                 "responded": sum(1 for r in results if r.get("reply")),
                                 "results": results})
            except ValueError as e:
                log_diagnostic_error(logger, "ERR-NET-6454", f"ArtPoll 网段参数非法: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)
            except Exception as e:
                log_diagnostic_error(logger, "ERR-NET-6454", f"ArtPoll 网段扫描失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/nodes/test_connection":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            ip = (req_data.get("ip") or "").strip()
            if not ip:
                self._send_json({"status": "error", "message": "IP 地址不能为空"}, 400)
                return
            try:
                probe = node_prober.probe(ip)
                # 三态判定：ArtPoll 有应答 / 无应答但有被动流量 / 完全无响应
                seen = {x.get("ip"): x for x in passive_registry.snapshot()}
                traffic = seen.get(ip)
                if probe.get("reply"):
                    state = "online"
                    hint = "已收到 ArtPollReply，节点在线"
                elif traffic and not traffic.get("stale"):
                    state = "traffic_only"
                    hint = ("该 IP 正在发送 ArtDmx，但未回应 ArtPoll —— "
                            "可能是仅单向发送的解码器（建议存活判据改为 artdmx）")
                else:
                    state = "no_response"
                    hint = "既无 ArtPollReply 也无被动流量，可能 IP 有错或不在同一网段"
                probe["state"] = state
                probe["hint"] = hint
                probe["passive"] = traffic
                if probe.get("reply"):
                    probe["matched_nodes"] = heartbeat_by_ip(ip, "artpoll")
                self._send_json(probe)
            except Exception as e:
                log_diagnostic_error(logger, "ERR-NET-6454", f"节点连接测试失败 [{ip}]: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/nodes/sync_watchdog":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            registered = sync_watchdog_from_venue()
            # 场地里已被删除的节点必须从看门狗中摘除，否则会持续产生幽灵告警
            live_ids = set()
            try:
                venue = kb_service.get_venue(kb_service.active_venue_file.replace(".json", ""))
                live_ids = {n.get("node_id") for n in venue.get("nodes", [])}
            except Exception:
                pass
            for nid in list(offline_watchdog.status().keys()):
                if nid not in live_ids:
                    offline_watchdog.unregister_node(nid)
            self._send_json({"status": "ok", "registered": registered})

        elif path == "/api/nodes/set_manual_state":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            nid = (req_data.get("node_id") or "").strip()
            if not nid:
                self._send_json({"status": "error", "message": "node_id 不能为空"}, 400)
                return
            offline = bool(req_data.get("offline"))
            if nid not in offline_watchdog.status():
                self._send_json({"status": "error",
                                 "message": f"节点 [{nid}] 不在掉线监测中，请先执行「同步掉线监测」"}, 400)
                return
            offline_watchdog.set_manual_state(nid, offline)
            self._send_json({"status": "ok", "node_id": nid, "manual_offline": offline})

        elif path == "/api/alarms/ack":
            try:
                if req_data.get("all"):
                    self._send_json({"status": "ok", "acked": alarm_store.acknowledge_all()})
                else:
                    self._send_json({"status": "ok",
                                     "alarm": alarm_store.acknowledge(req_data.get("alarm_id", ""))})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        # 插件生命周期与市场 API
        elif path == "/api/plugins/toggle_enabled":
            pid = req_data.get("plugin_id")
            en = bool(req_data.get("enabled"))
            try:
                engine.plugin_host.set_plugin_enabled(pid, en)
                self._send_json({"status": "ok"})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/plugins/save_config":
            pid = req_data.get("plugin_id")
            cfg = req_data.get("config", {})
            try:
                engine.plugin_host.configure_plugin(pid, cfg)
                self._send_json({"status": "ok"})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/plugins/uninstall":
            pid = req_data.get("plugin_id")
            try:
                engine.plugin_host.uninstall_plugin(pid)
                self._send_json({"status": "ok"})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/market/install":
            pkg_id = req_data.get("package_id", "")
            try:
                res = marketplace.install_package(pkg_id, engine.plugin_host)
                self._send_json(res)
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/market/verify_code":
            code = req_data.get("code", "")
            val_res = marketplace.verify_plugin_code(code)
            self._send_json(val_res)

        # 自然语言探索性指令下发 (通过大模型推导)
        elif path == "/api/lighting/execute":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return

            cmd = req_data.get("command", "")
            logger.info(f"【控制台输入】用户 [{session['username']}] 自然语言指令: {cmd}")
            fixtures_ctx, preset_hint = kb.retrieve_context(cmd)

            llm = engine.plugin_host.get_llm()
            if not llm:
                self._send_json({"status": "error", "message": "未挂载本地大模型适配器插件"}, 500)
                return

            sys_prompt = f"""你是一个专业舞台灯光控制大脑。请将指令转换为纯 JSON 格式：
【可用灯具】: {json.dumps(fixtures_ctx, ensure_ascii=False)}
【美学建议】: {json.dumps(preset_hint, ensure_ascii=False) if preset_hint else "无"}
输出模式 single 或 sequence，不要任何额外说明文字。"""

            try:
                raw_ans = llm.chat_completion([{"role": "system", "content": sys_prompt}, {"role": "user", "content": cmd}])
                cleaned = raw_ans.strip()
                if "```json" in cleaned:
                    cleaned = cleaned.split("```json")[1].split("```")[0].strip()
                elif "```" in cleaned:
                    cleaned = cleaned.split("```")[1].split("```")[0].strip()
                parsed = json.loads(cleaned)

                execute_payload_directly(parsed)
                self._send_json({"status": "ok", "parsed": parsed})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-LLM-CONN", f"大模型解析失败: {e}")
                self._send_json({"status": "error", "message": f"大模型调用失败: {e}"}, 500)

        elif path == "/api/lighting/stop_sequence":
            stop_sequence_flag = True
            engine.stop_macro()
            self._send_json({"status": "ok"})

        elif path == "/api/lighting/panic":
            if not auth.check_permission(token, "panic_control"):
                self._send_json({"status": "error", "message": "无权触发 PANIC 紧急熔断"}, 403)
                return
            logger.warning(f"用户 [{session['username']}] 触发全场 PANIC 熔断全黑！")
            stop_sequence_flag = True
            engine.stop_macro()
            for u in range(engine.dmx_merger.universe_count):
                black = bytearray(512)
                engine.dmx_merger.submit_frame("panic", u, black, priority=PriorityLevel.PANIC)
            self._send_json({"status": "ok"})

        elif path == "/api/llm/test_connection":
            url_test = req_data.get("api_url", "http://127.0.0.1:8085/v1/chat/completions")
            model_test = req_data.get("model_name", "qwen2.5-7b-4q")
            start_t = time.time()
            test_payload = {
                "model": model_test,
                "messages": [{"role": "user", "content": "请回复'Ready'测试连通性。"}],
                "temperature": 0.1
            }
            try:
                req = urllib.request.Request(
                    url_test,
                    data=json.dumps(test_payload).encode("utf-8"),
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    res_body = json.loads(resp.read().decode("utf-8"))
                    latency = int((time.time() - start_t) * 1000)
                    sample = res_body["choices"][0]["message"]["content"]
                    logger.info(f"本地大模型端点连通性测试通过，延迟: {latency} ms")
                    self._send_json({"status": "ok", "latency_ms": latency, "sample_reply": sample})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-LLM-CONN", f"端点测试失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/llm/save_config":
            url_save = req_data.get("api_url")
            model_save = req_data.get("model_name")
            qwen_plugin = engine.plugin_host.get_llm()
            if qwen_plugin:
                qwen_plugin.api_url = url_save
                qwen_plugin.model_name = model_save
            logger.info(f"本地大模型端点已更新: {url_save} ({model_save})")
            self._send_json({"status": "ok"})

        else:
            self._send_json({"error": "Unknown API"}, 404)

def run_server(port=9000):
    server = HTTPServer(("0.0.0.0", port), UnifiedControlStationServer)
    logger.info("=" * 76)
    logger.info("   AI-MA 全集成总控工作台 (Unified Control Station v4.2) 启动就绪！")
    logger.info("=" * 76)
    logger.info(f" 访问地址: http://127.0.0.1:{port}")
    logger.info(" [核心优化 1] 快捷场景直接存储 Payload JSON，触发 0 毫秒直达底层 DMX (不走大模型)")
    logger.info(" [核心优化 2] 主控台采用纯净超大触控按钮，彻底移除小图标，杜绝现场误触")
    logger.info(" [核心优化 3] 新增独立【快捷场景管理】标签页，支持直接粘贴 JSON 与 AI 编译辅助")
    logger.info(" [核心优化 4] 三层 RAG 知识库全功能合并入【RAG知识库管理】标签页：")
    logger.info("              Profiles 灯库 / Venues 场地热切换 / Presets 拾色预设 / 冲突检测 / AI解析")
    logger.info(" [资产归一] 已归并全部独立入口，本目录仅保留唯一启动脚本: 启动系统总控台.bat")
    logger.info(" [界面重构] 企业级 UI：登录门头页 / 侧边导航 / 精细控件 / 权限分级")
    logger.info("=" * 76)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("总控服务正在停止...")
        monitor.stop()
        engine.stop()
        stop_microkernel()
        server.server_close()

if __name__ == "__main__":
    run_server(9000)
