@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "SYSROOT=%~dp0"

echo ========================================================
echo   AI-MA Enterprise Lighting Control Station   v5.3
echo   Hybrid Microkernel Architecture (Rust 44Hz + Python)
echo --------------------------------------------------------
echo   Web Console : http://127.0.0.1:9000
echo   Default user: admin / admin123
echo ========================================================
echo.

rem ============================================================
rem  Interpreter discovery.
rem  The control station REQUIRES numpy (core\kernel_bridge.py).
rem  A python without numpy makes the service crash on startup,
rem  so every candidate is probed for numpy before being accepted.
rem ============================================================
set "PYEXE="

rem ---- 0) Explicit override always wins ----------------------
if defined AIMA_PYTHON (
    if exist "%AIMA_PYTHON%" (
        echo [probe] AIMA_PYTHON override: %AIMA_PYTHON%
        "%AIMA_PYTHON%" -c "import numpy" >nul 2>nul
        if not errorlevel 1 set "PYEXE=%AIMA_PYTHON%"
    )
)

rem ---- 1) Bundled DSH runtime (known-good with numpy) -------
if not defined PYEXE (
    set "CAND=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    if exist "!CAND!" (
        "!CAND!" -c "import numpy" >nul 2>nul
        if not errorlevel 1 set "PYEXE=!CAND!"
    )
)

rem ---- 2) Any python on PATH that satisfies numpy ----------
if not defined PYEXE (
    for /f "delims=" %%P in ('where python 2^>nul') do (
        if not defined PYEXE (
            "%%P" -c "import numpy" >nul 2>nul
            if not errorlevel 1 set "PYEXE=%%P"
        )
    )
)

rem ---- 3) py launcher, any registered 3.x ------------------
if not defined PYEXE (
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 -c "import numpy" >nul 2>nul
        if not errorlevel 1 (
            for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
        )
    )
)

rem ---- 4) Common install locations ------------------------
if not defined PYEXE (
    for %%C in (
        "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
        "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
        "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
        "C:\Python314\python.exe"
        "C:\Python312\python.exe"
    ) do (
        if not defined PYEXE if exist "%%~C" (
            "%%~C" -c "import numpy" >nul 2>nul
            if not errorlevel 1 set "PYEXE=%%~C"
        )
    )
)

if not defined PYEXE (
    echo [ERROR] No Python interpreter with numpy was found.
    echo.
    echo         The control station requires numpy ^(used by the
    echo         shared-memory microkernel bridge^).
    echo.
    echo         Fix with either of these:
    echo           1^) Install numpy into your Python:
    echo                python -m pip install numpy
    echo           2^) Point this script at a working interpreter:
    echo                set AIMA_PYTHON=C:\path\to\python.exe
    echo.
    pause
    exit /b 1
)

echo [1/3] Interpreter : %PYEXE%

rem ---- Report which kernel mode the service will enter ------
"%PYEXE%" -c "import aima_shm_sdk" >nul 2>nul
if errorlevel 1 (
    echo [2/3] Microkernel : NOT AVAILABLE - will run in Python software mode
    echo       ^(aima_shm_sdk is missing next to control_station.py^)
) else (
    echo [2/3] Microkernel : aima_shm_sdk OK - hardware offload mode
)

if not exist "%SYSROOT%bin\aima-rt-daemon.exe" (
    if not exist "%SYSROOT%..\ai-ma-kernel-v5.3\target\release\aima-rt-daemon.exe" (
        echo       WARNING: aima-rt-daemon binary not found; the 44Hz
        echo                real-time kernel cannot be started.
    )
)

echo [3/3] Starting service, the browser will open in 2 seconds.
echo.
echo       Press Ctrl+C to stop the service.
echo.

rem ---- Open the console once the service has had time to bind ------
rem      Set AIMA_NO_BROWSER=1 for headless / server / CI deployment.
if not defined AIMA_NO_BROWSER (
    start "" cmd /c "timeout /t 2 /nobreak >nul && start http://127.0.0.1:9000"
) else (
    echo       Headless mode ^(AIMA_NO_BROWSER^): browser auto-open skipped.
)

"%PYEXE%" control_station.py

echo.
echo Service stopped.
pause
