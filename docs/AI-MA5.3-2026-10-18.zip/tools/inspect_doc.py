import os
import sys
from docx import Document

doc_path = r"C:\Users\Administrator\Desktop\AI-MA异构协同与自适应灯光控制系统技术方案.docx"
print("File exists:", os.path.exists(doc_path))
if os.path.exists(doc_path):
    doc = Document(doc_path)
    print("Paragraphs count:", len(doc.paragraphs))
    print("Tables count:", len(doc.tables))
    print("Sections count:", len(doc.sections))
    print("--- Heading paragraphs ---")
    for i, p in enumerate(doc.paragraphs):
        if p.style and p.style.name.startswith("Heading"):
            print(f"[{i}] {p.style.name}: {p.text.strip()}")
        elif i < 10 and p.text.strip():
            print(f"[{i}] ({p.style.name}): {p.text.strip()[:60]}")
