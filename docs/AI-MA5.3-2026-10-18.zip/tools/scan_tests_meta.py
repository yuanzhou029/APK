import os, glob

test_files = glob.glob('tests/*.py')
print(f'Total test files: {len(test_files)}')

for f in sorted(test_files):
    name = os.path.basename(f)
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        lines = [fp.readline() for _ in range(30)]
    
    first_comment = []
    in_docstring = False
    for line in lines:
        s = line.strip()
        if '"""' in s or "'''" in s:
            if not in_docstring:
                in_docstring = True
                cleaned = s.replace('"""', '').replace("'''", '').strip()
                if cleaned:
                    first_comment.append(cleaned)
                continue
            else:
                cleaned = s.replace('"""', '').replace("'''", '').strip()
                if cleaned:
                    first_comment.append(cleaned)
                break
        if in_docstring:
            if s:
                first_comment.append(s)
        elif s.startswith('#'):
            c = s.lstrip('#').strip()
            if c:
                first_comment.append(c)
        elif s and not s.startswith('import') and not s.startswith('from'):
            pass

    summary = ' '.join(first_comment)[:120]
    print(f'{name:<42} | {summary}')
