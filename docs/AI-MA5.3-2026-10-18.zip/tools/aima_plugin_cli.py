# -*- coding: utf-8 -*-
"""
AI-MA 插件体系二次开发与 CLI 脚手架工具 (AIMA Plugin CLI v1.0)
使用方法：
  python tools/aima_plugin_cli.py create --tier 3 --type macro --name my_macro --id custom_macro_effect
  python tools/aima_plugin_cli.py verify --file plugins/community/breathing_plugin.py
  python tools/aima_plugin_cli.py benchmark --file plugins/community/breathing_plugin.py --frames 100
"""

import os
import sys
import argparse
import importlib.util
import inspect
import json
from typing import Optional

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
CORE_DIR = os.path.join(BASE_DIR, "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from plugin_sdk import (
    BasePlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseCreativePlugin,
    BaseAdapterPlugin, BaseTransportPlugin, BaseProtocolPlugin, BaseLLMPlugin,
    PluginTier, PluginType, PluginValidator
)
from mock_host import MockHost

# 模板生成器
TEMPLATE_TIER_1_TRANSPORT = '''# -*- coding: utf-8 -*-
"""
{name} ({plugin_id})
AI-MA 1 类 · 底层物理总线与传输协议插件
"""

from core.plugin_sdk import BaseTransportPlugin, PluginType, CoreContext
from typing import Dict, Any

class {class_name}(BaseTransportPlugin):
    def get_info(self) -> Dict[str, Any]:
        return {{
            "id": "{plugin_id}",
            "name": "{name}",
            "version": "1.0.0",
            "author": "AIMA Developer",
            "type": PluginType.TRANSPORT,
            "description": "自定义 1 类底层传输通道插件"
        }}

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def open_channel(self, channel_id: str, config: Dict[str, Any]) -> bool:
        return True

    def send_raw(self, channel_id: str, payload: bytes) -> bool:
        return True

    def register_raw_receiver(self, channel_id: str, callback) -> None:
        pass
'''

TEMPLATE_TIER_2_ADAPTER = '''# -*- coding: utf-8 -*-
"""
{name} ({plugin_id})
AI-MA 2 类 · 控台与外部生态适配器插件
"""

from core.plugin_sdk import BaseAdapterPlugin, PluginType, CoreContext
from typing import Dict, Any, List

class {class_name}(BaseAdapterPlugin):
    def get_info(self) -> Dict[str, Any]:
        return {{
            "id": "{plugin_id}",
            "name": "{name}",
            "version": "1.0.0",
            "author": "AIMA Developer",
            "type": PluginType.ADAPTER,
            "description": "自定义 2 类数据与格式适配器插件"
        }}

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def supported_extensions(self) -> List[str]:
        return [".json", ".xml"]

    def convert_to_profile(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        return {{"profile_name": filename, "channels": []}}

    def get_provided_capabilities(self) -> List[str]:
        return ["{plugin_id}.capability", "adapter.custom_format"]
'''

TEMPLATE_TIER_3_MACRO = '''# -*- coding: utf-8 -*-
"""
{name} ({plugin_id})
AI-MA 3 类 · 表现与创意宏特效插件
"""

from core.plugin_sdk import BaseMacroPlugin, PluginType, CoreContext
from typing import Dict, Any, List

class {class_name}(BaseMacroPlugin):
    def get_info(self) -> Dict[str, Any]:
        return {{
            "id": "{plugin_id}",
            "name": "{name}",
            "version": "1.0.0",
            "author": "AIMA Developer",
            "type": PluginType.MACRO,
            "description": "自定义 3 类表现宏插件"
        }}

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {{
            "speed": {{
                "type": "number",
                "label": "渲染速率",
                "default": 1.0,
                "description": "速度倍率"
            }}
        }}

    def get_required_adapters(self) -> List[str]:
        return []

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def render(self, elapsed_ms: float, params: Dict[str, Any], current_frame: bytearray) -> bytearray:
        speed = params.get("speed", 1.0)
        output = bytearray(current_frame)
        val = int((elapsed_ms * 0.1 * speed) % 256)
        output[0] = val
        return output
'''


def to_pascal_case(s: str) -> str:
    parts = s.replace("-", "_").split("_")
    return "".join(p.capitalize() for p in parts if p)


def cmd_create(args):
    # 支持 --tier 或 --type 参数，以及二者之间的映射
    tier = getattr(args, "tier", None)
    p_type = getattr(args, "type", None)
    if tier is None:
        if p_type:
            p_type_lower = str(p_type).lower()
            if p_type_lower in ["1", "transport", "protocol", "system"]:
                tier = 1
            elif p_type_lower in ["2", "adapter"]:
                tier = 2
            else:
                tier = 3
        else:
            tier = 3
    else:
        tier = int(tier)

    name = args.name or f"Plugin_{args.id}"
    plugin_id = args.id.lower()
    class_name = to_pascal_case(plugin_id) + "Plugin"

    target_dir = getattr(args, "target_dir", None)
    if not target_dir:
        if tier == 1:
            target_dir = os.path.join(BASE_DIR, "plugins", "system")
            template = TEMPLATE_TIER_1_TRANSPORT
        elif tier == 2:
            target_dir = os.path.join(BASE_DIR, "plugins", "adapters")
            template = TEMPLATE_TIER_2_ADAPTER
        else:
            target_dir = os.path.join(BASE_DIR, "plugins", "community")
            template = TEMPLATE_TIER_3_MACRO
    else:
        if tier == 1:
            template = TEMPLATE_TIER_1_TRANSPORT
        elif tier == 2:
            template = TEMPLATE_TIER_2_ADAPTER
        else:
            template = TEMPLATE_TIER_3_MACRO

    os.makedirs(target_dir, exist_ok=True)
    out_file = os.path.join(target_dir, f"{plugin_id}.py")
    if os.path.exists(out_file) and not getattr(args, "force", False):
        print(f"[ERROR] 目标插件文件已存在: {out_file} (使用 --force 覆盖)")
        return 1

    content = template.format(name=name, plugin_id=plugin_id, class_name=class_name)
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"[OK] 成功根据模板生成 {tier} 类插件: {out_file}")
    return 0


def load_plugin_from_file(file_path: str) -> Optional[BasePlugin]:
    if not os.path.exists(file_path):
        return None
    mod_name = os.path.splitext(os.path.basename(file_path))[0]
    spec = importlib.util.spec_from_file_location(mod_name, file_path)
    if not spec or not spec.loader:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    for attr_name in dir(mod):
        attr = getattr(mod, attr_name)
        if (inspect.isclass(attr) and
            any(base.__name__ == "BasePlugin" or issubclass(base, BasePlugin) for base in attr.__mro__ if base is not object) and
            not inspect.isabstract(attr) and
            attr.__name__ not in ["BasePlugin", "BaseProtocolPlugin", "BaseMacroPlugin", "BasePerceptionPlugin",
                                  "BaseLLMPlugin", "BaseAdapterPlugin", "BaseCreativePlugin", "BaseTransportPlugin"]):
            return attr()
    return None


def cmd_verify(args):
    file_path = os.path.abspath(args.file)
    if not os.path.exists(file_path):
        print(f"[ERROR] 文件未找到: {file_path}")
        return 1

    instance = load_plugin_from_file(file_path)
    if not instance:
        print(f"[FAIL] 文件中未找到符合规范的 BasePlugin 派生类: {file_path}")
        return 1

    res = PluginValidator.validate_plugin_instance(instance)
    if res["valid"]:
        print(f"[PASS] 插件合规静态审查通过！元数据: {json.dumps(res['plugin_info'], ensure_ascii=False, indent=2)}")
        return 0
    else:
        print(f"[FAIL] 插件合规性审查未通过！错误明细:")
        for err in res["errors"]:
            print(f"  - {err}")
        return 1


def cmd_benchmark(args):
    file_path = os.path.abspath(args.file)
    instance = load_plugin_from_file(file_path)
    if not instance:
        print(f"[FAIL] 无法从 {file_path} 加载插件类")
        return 1

    mock_host = MockHost(universe_count=4)
    if not mock_host.load_plugin(instance):
        print(f"[FAIL] 插件在 Mock 沙盒环境中 on_init 初始化失败")
        return 1

    info = instance.get_info()
    pid = info.get("id")
    print(f"[*] 启动离线 Mock 基准压力测试: [{info.get('name')}] (ID: {pid})...")
    res = mock_host.run_benchmark(pid, frames=args.frames)
    print(f"--- 基准评测结果 ---")
    print(f"  执行帧数: {res['total_frames_executed']} / {res['target_frames']}")
    print(f"  平均单帧耗时: {res['avg_frame_time_ms']:.3f} ms (标准门禁: <= 3.5ms)")
    print(f"  最大单帧耗时: {res['max_frame_time_ms']:.3f} ms (熔断门禁: 连续 5 次 > 4.0ms)")
    print(f"  内存增量: {res['memory_delta_kb']:.2f} KB")
    print(f"  是否被性能门禁探针降级: {'是 (已熔断)' if res['degraded_by_probe'] else '否 (性能优良)'}")

    if res['degraded_by_probe']:
        print(f"[FAIL] 性能违规触发门禁熔断！")
        return 1
    return 0


def main():
    parser = argparse.ArgumentParser(description="AI-MA 插件体系二次开发与 CLI 脚手架工具")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # create (支持 --tier 与 --type 别名)
    p_create = subparsers.add_parser("create", help="根据模板生成 1/2/3 类插件")
    p_create.add_argument("--tier", type=int, choices=[1, 2, 3], help="插件分级 (1:系统/2:适配/3:创意)")
    p_create.add_argument("--type", type=str, help="插件类型/分级别名 (如 transport/adapter/macro 或 1/2/3)")
    p_create.add_argument("--id", type=str, required=True, help="插件全局 ID (小写英文数字下划线)")
    p_create.add_argument("--name", type=str, help="插件中文显示名称")
    p_create.add_argument("--force", action="store_true", help="如果存在则强制覆盖")

    # verify / validate 子命令别名
    p_verify = subparsers.add_parser("verify", help="合规静态检查")
    p_verify.add_argument("--file", type=str, required=True, help="插件源码路径")

    p_validate = subparsers.add_parser("validate", help="合规静态检查 (verify 的别名)")
    p_validate.add_argument("--file", type=str, required=True, help="插件源码路径")

    # benchmark / test-sandbox 子命令别名
    p_bench = subparsers.add_parser("benchmark", help="离线 Mock 压力测试")
    p_bench.add_argument("--file", type=str, required=True, help="插件源码路径")
    p_bench.add_argument("--frames", type=int, default=100, help="运行模拟帧数 (默认 100 帧)")

    p_sandbox = subparsers.add_parser("test-sandbox", help="离线 Mock 压力测试 (benchmark 的别名)")
    p_sandbox.add_argument("--file", type=str, required=True, help="插件源码路径")
    p_sandbox.add_argument("--frames", type=int, default=100, help="运行模拟帧数 (默认 100 帧)")

    args = parser.parse_args()
    if args.command == "create":
        sys.exit(cmd_create(args))
    elif args.command in ["verify", "validate"]:
        sys.exit(cmd_verify(args))
    elif args.command in ["benchmark", "test-sandbox"]:
        sys.exit(cmd_benchmark(args))


if __name__ == "__main__":
    main()
