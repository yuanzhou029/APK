# -*- coding: utf-8 -*-
"""
一次性重构脚本：将 control_station.py 中内嵌的旧版 UI 字符串剥离，
改为从 web/ 目录以静态资源方式提供企业级新界面，并新增 /app 登录门禁与登出接口。

脚本对每一处替换都做断言校验，任一锚点缺失即抛错中止，绝不产生半成品文件。
"""

import io
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TARGET = os.path.join(BASE_DIR, "control_station.py")


def must_replace(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"[ABORT] 锚点 [{label}] 期望出现 1 次，实际 {n} 次。")
    print(f"[OK] 替换锚点: {label}")
    return text.replace(old, new, 1)


def main():
    with io.open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    original_len = len(src)

    # ------------------------------------------------------------------
    # 1) 剥离内嵌的旧版 UI 巨型字符串
    # ------------------------------------------------------------------
    start_marker = 'UNIFIED_UI_HTML = r"""<!DOCTYPE html>'
    start = src.find(start_marker)
    if start == -1:
        raise SystemExit("[ABORT] 未找到内嵌 UI 字符串起始锚点。")
    end = src.find('\n"""\n', start)
    if end == -1:
        raise SystemExit("[ABORT] 未找到内嵌 UI 字符串结束锚点。")

    legacy_block = src[start:end + len('\n"""\n')]
    print(f"[OK] 定位到内嵌旧版 UI 字符串，长度 {len(legacy_block)} 字符，将被剥离。")

    stripped_note = (
        '# ---------------------------------------------------------------------------\n'
        '# 前端界面已从本文件中解耦，迁移为 web/ 目录下的独立静态资产：\n'
        '#   web/login.html        企业级登录门头页 (系统首页)\n'
        '#   web/index.html        统一总控台主界面 (需登录后访问 /app)\n'
        '#   web/assets/theme.css  企业设计系统 (Design System v1.0)\n'
        '#   web/assets/app.js     应用逻辑层\n'
        '# 由 UnifiedControlStationServer 通过 /assets/* 静态路由提供。\n'
        '# ---------------------------------------------------------------------------\n'
    )
    src = src[:start] + stripped_note + src[end + len('\n"""\n'):]

    # ------------------------------------------------------------------
    # 2) 注入 WEB_DIR 常量
    # ------------------------------------------------------------------
    src = must_replace(
        src,
        'BASE_DIR = os.path.dirname(os.path.abspath(__file__))\nsys.path.append(os.path.join(BASE_DIR, "core"))',
        'BASE_DIR = os.path.dirname(os.path.abspath(__file__))\n'
        'WEB_DIR = os.path.join(BASE_DIR, "web")\n'
        'sys.path.append(os.path.join(BASE_DIR, "core"))',
        "BASE_DIR -> 追加 WEB_DIR"
    )

    # ------------------------------------------------------------------
    # 3) 补充 unquote 导入（静态资源安全解码）
    # ------------------------------------------------------------------
    src = must_replace(
        src,
        "from urllib.parse import urlparse, parse_qs",
        "from urllib.parse import urlparse, parse_qs, unquote",
        "补充 unquote 导入"
    )

    # ------------------------------------------------------------------
    # 4) 为处理器注入静态资源服务方法
    # ------------------------------------------------------------------
    static_methods = '''    # ------------------------- 静态资源与页面服务 -------------------------
    def _serve_page(self, filename: str, code: int = 200):
        """提供 web/ 目录下的 HTML 页面"""
        fpath = os.path.join(WEB_DIR, filename)
        if not os.path.exists(fpath):
            self._send_json({"error": f"界面资源缺失: {filename}"}, 500)
            return
        with open(fpath, "r", encoding="utf-8") as f:
            body = f.read().encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    _MIME_MAP = {
        ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".svg": "image/svg+xml",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".ico": "image/x-icon",
        ".woff": "font/woff",
        ".woff2": "font/woff2",
        ".ttf": "font/ttf",
        ".map": "application/json; charset=utf-8",
    }

    def _serve_static(self, url_path: str):
        """安全地提供 /assets/ 下的静态资源，严格阻断路径穿越"""
        rel = url_path[len("/assets/"):].split("?")[0].split("#")[0]
        rel = unquote(rel)
        assets_root = os.path.realpath(os.path.join(WEB_DIR, "assets"))
        target = os.path.realpath(os.path.join(assets_root, rel))

        if not target.startswith(assets_root + os.sep) and target != assets_root:
            log_diagnostic_error(logger, "ERR-AUTH-DENIED", f"静态资源路径穿越尝试被阻断: {url_path}")
            self._send_json({"error": "Forbidden"}, 403)
            return
        if not os.path.isfile(target):
            self._send_json({"error": "Not Found"}, 404)
            return

        ext = os.path.splitext(target)[1].lower()
        with open(target, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", self._MIME_MAP.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

'''
    src = must_replace(
        src,
        "class UnifiedControlStationServer(BaseHTTPRequestHandler):\n    def _send_json(self, data, code=200):",
        "class UnifiedControlStationServer(BaseHTTPRequestHandler):\n" + static_methods +
        "    def _send_json(self, data, code=200):",
        "注入静态资源服务方法"
    )

    # ------------------------------------------------------------------
    # 4) 重写首页路由：登录页 + /app 门禁 + 静态资源
    # ------------------------------------------------------------------
    src = must_replace(
        src,
        '        if path in ["/", "/index.html"]:\n            self._send_html(UNIFIED_UI_HTML)\n',
        '        if path.startswith("/assets/"):\n'
        '            self._serve_static(path)\n'
        '        elif path in ["/", "/index.html", "/login", "/login.html"]:\n'
        '            # 系统首页 = 企业级登录门头页\n'
        '            self._serve_page("login.html")\n'
        '        elif path in ["/app", "/app/", "/console", "/console/"]:\n'
        '            # 后台主界面：前端会先行校验会话令牌，无效则立即弹回登录页；\n'
        '            # 真正的安全边界在全部 /api/* 路由上（无有效 Token 一律 401）。\n'
        '            self._serve_page("index.html")\n',
        "首页路由 -> 登录门禁 + 静态资源"
    )

    # ------------------------------------------------------------------
    # 5) 新增登出接口（置于鉴权之前，允许过期会话也能正常登出）
    # ------------------------------------------------------------------
    src = must_replace(
        src,
        '                self._send_json({"status": "error", "message": "账户或密码错误"}, 401)\n            return\n\n        # 鉴权\n',
        '                self._send_json({"status": "error", "message": "账户或密码错误"}, 401)\n'
        '            return\n\n'
        '        if path == "/api/auth/logout":\n'
        '            tk = self._get_token()\n'
        '            if tk and tk in auth.active_sessions:\n'
        '                auth.active_sessions.pop(tk, None)\n'
        '            logger.info("用户已主动注销会话凭证。")\n'
        '            self._send_json({"status": "ok"})\n'
        '            return\n\n'
        '        # 鉴权\n',
        "新增 /api/auth/logout 接口"
    )

    # ------------------------------------------------------------------
    # 6) 更新启动横幅
    # ------------------------------------------------------------------
    src = must_replace(
        src,
        '    logger.info(" [资产归一] 已归并全部独立入口，本目录仅保留唯一启动脚本: 启动系统总控台.bat")',
        '    logger.info(" [资产归一] 已归并全部独立入口，本目录仅保留唯一启动脚本: 启动系统总控台.bat")\n'
        '    logger.info(" [界面重构] 企业级 UI：登录门头页 / 侧边导航 / 精细控件 / 权限分级")',
        "启动横幅 -> 追加界面重构说明"
    )

    src = src.replace("Unified Control Station v4.1", "Unified Control Station v4.2")

    # ------------------------------------------------------------------
    # 写回
    # ------------------------------------------------------------------
    with io.open(TARGET, "w", encoding="utf-8") as f:
        f.write(src)

    print("=" * 68)
    print(f"[DONE] control_station.py 重构完成: {original_len} -> {len(src)} 字符 "
          f"(净削减约 {(original_len - len(src)) // 1024} KB 内嵌前端)")
    print("=" * 68)
    return 0


if __name__ == "__main__":
    sys.exit(main())
