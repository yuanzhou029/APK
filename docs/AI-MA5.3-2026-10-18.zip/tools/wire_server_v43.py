# -*- coding: utf-8 -*-
"""
v4.3 服务端接入手术：
  1. 引入节点发现与掉线看门狗模块，并新增全局告警中心 AlarmStore
  2. 新增面板布局配置读写
  3. 在 _dispatch_api_get 追加只读路由（分类/属性分组/灯库属性/面板布局/节点/告警）
  4. 在 do_POST 追加写路由（分类/属性分组/单条预设/面板布局/节点探测/告警确认）
所有替换均带断言校验，锚点缺失即中止，不产生半成品文件。
"""

import io
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TARGET = os.path.join(BASE_DIR, "control_station.py")


def must_replace(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"[ABORT] 锚点 [{label}] 期望 1 次，实际 {n} 次。")
    print(f"[OK] {label}")
    return text.replace(old, new, 1)


# ===========================================================================
# 1. 模块级：导入 + 全局对象 + 告警中心
# ===========================================================================
MODULE_INSERT = '''

# -------------------------------------------------------------
# 节点自动发现 / 连接测试 / 掉线看门狗（Art-Net 解码器层级）
# -------------------------------------------------------------
from node_discovery import ArtPollProber, PassiveRegistry, OfflineWatchdog


class AlarmStore:
    """
    全局告警中心（线程安全）。
    承载设备掉线等运行时告警的 未处理/已确认/已恢复 三态生命周期。
    """

    def __init__(self, max_items: int = 300):
        self._lock = threading.RLock()
        self._items = []
        self._max = max_items
        self._seq = 0

    @staticmethod
    def _now() -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S")

    def raise_alarm(self, code: str, title: str, message: str,
                    node_id: str = "", severity: str = "warning",
                    actions=None) -> dict:
        """登记一条告警；同一节点同一错误码在未恢复前不重复登记，仅刷新时间"""
        with self._lock:
            for a in self._items:
                if a["node_id"] == node_id and a["code"] == code and a["state"] != "recovered":
                    a["last_at"] = self._now()
                    a["message"] = message
                    return a
            self._seq += 1
            item = {
                "id": f"alm_{self._seq:05d}",
                "code": code,
                "title": title,
                "message": message,
                "node_id": node_id,
                "severity": severity,
                "actions": list(actions or ["log", "banner", "toast"]),
                "state": "open",              # open 未处理 | acked 已确认 | recovered 已恢复
                "raised_at": self._now(),
                "last_at": self._now(),
                "recovered_at": None,
                "acked_at": None,
            }
            self._items.insert(0, item)
            del self._items[self._max:]
            return item

    def recover(self, node_id: str, code: str = "ERR-NODE-OFFLINE", offline_sec=None) -> list:
        """节点恢复：把该节点对应告警自动转为已恢复态"""
        touched = []
        with self._lock:
            for a in self._items:
                if a["node_id"] == node_id and a["code"] == code and a["state"] != "recovered":
                    a["state"] = "recovered"
                    a["recovered_at"] = self._now()
                    if offline_sec is not None:
                        a["message"] = f"{a['message']}（已于 {a['recovered_at']} 恢复，离线 {offline_sec}s）"
                    touched.append(a)
        return touched

    def acknowledge(self, alarm_id: str) -> dict:
        with self._lock:
            for a in self._items:
                if a["id"] == alarm_id:
                    if a["state"] == "open":
                        a["state"] = "acked"
                        a["acked_at"] = self._now()
                    return a
        raise FileNotFoundError(f"未找到告警: {alarm_id}")

    def acknowledge_all(self) -> int:
        with self._lock:
            n = 0
            for a in self._items:
                if a["state"] == "open":
                    a["state"] = "acked"
                    a["acked_at"] = self._now()
                    n += 1
            return n

    def snapshot(self, limit: int = 50) -> dict:
        with self._lock:
            items = [dict(a) for a in self._items[:limit]]
            return {
                "alarms": items,
                "open_count": sum(1 for a in self._items if a["state"] == "open"),
                "acked_count": sum(1 for a in self._items if a["state"] == "acked"),
                "recovered_count": sum(1 for a in self._items if a["state"] == "recovered"),
                "total": len(self._items),
            }


node_prober = ArtPollProber(port=6454)
passive_registry = PassiveRegistry(stale_sec=60.0)
offline_watchdog = OfflineWatchdog()
alarm_store = AlarmStore()

# 主控台快捷面板的自定义组装配置（面板块手动挑选结果）
PANEL_LAYOUT_FILE = os.path.join(BASE_DIR, "config", "control_panel_layout.json")


def load_panel_layout() -> dict:
    """读取面板布局；不存在时返回空布局，由前端回退为默认展示"""
    try:
        if os.path.exists(PANEL_LAYOUT_FILE):
            with open(PANEL_LAYOUT_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("groups"), list):
                return data
    except Exception as e:
        logger.error(f"读取面板布局配置失败: {e}")
    return {"version": 2, "groups": [], "configured": False}


def save_panel_layout(data: dict) -> dict:
    """保存面板布局（原子写入）"""
    groups = data.get("groups")
    if not isinstance(groups, list):
        raise ValueError("面板布局必须是 {\\"groups\\": [...]} 结构")
    clean = []
    for i, g in enumerate(groups):
        item_ids = [str(x) for x in (g.get("item_ids") or [])]
        clean.append({
            "group_id": g.get("group_id") or f"g{i + 1}",
            "title": (g.get("title") or f"面板组 {i + 1}").strip(),
            "columns": max(1, min(8, int(g.get("columns", 3) or 3))),
            "order": int(g.get("order", i) or 0),
            "item_ids": item_ids,
        })
    clean.sort(key=lambda x: x["order"])
    payload = {"version": 2, "configured": True, "groups": clean}
    os.makedirs(os.path.dirname(PANEL_LAYOUT_FILE), exist_ok=True)
    tmp = PANEL_LAYOUT_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, PANEL_LAYOUT_FILE)
    logger.info(f"控制面板布局已保存：{len(clean)} 个面板块")
    return {"status": "ok", "layout": payload}


def sync_watchdog_from_venue() -> int:
    """把当前工作场地的全部节点同步进掉线看门狗"""
    try:
        venue = kb_service.get_venue(kb_service.active_venue_file.replace(".json", ""))
    except Exception as e:
        logger.error(f"同步看门狗失败，读取场地异常: {e}")
        return 0
    n = 0
    for node in venue.get("nodes", []):
        offline_watchdog.register_node(node.get("node_id"), node.get("offline_policy") or {})
        n += 1
    return n


def watchdog_tick():
    """看门狗轮询线程体：按各节点策略判定掉线并产生/消除告警"""
    while True:
        try:
            time.sleep(1.0)
            # 被动发现的数据同步进看门狗
            for item in passive_registry.snapshot():
                if not item.get("stale"):
                    offline_watchdog.heartbeat(item.get("ip"), "artdmx")
            for ev in offline_watchdog.evaluate():
                nid = ev.get("node_id")
                if ev.get("event") == "offline":
                    actions = ev.get("actions") or ["log", "banner", "toast"]
                    msg = f"解码器节点 [{nid}] 掉线：{ev.get('reason')}"
                    if "log" in actions:
                        log_diagnostic_error(logger, "ERR-NODE-OFFLINE", msg)
                    alarm_store.raise_alarm(
                        code="ERR-NODE-OFFLINE",
                        title=f"设备掉线 · {nid}",
                        message=msg,
                        node_id=nid,
                        severity=ev.get("severity", "warning"),
                        actions=actions,
                    )
                elif ev.get("event") == "recovered":
                    alarm_store.recover(nid, offline_sec=ev.get("offline_sec"))
                    logger.info(f"解码器节点 [{nid}] 已恢复在线"
                                f"（离线 {ev.get('offline_sec')}s）")
        except Exception as e:
            logger.error(f"掉线看门狗轮询异常: {e}")

'''

# ===========================================================================
# 2. 只读路由
# ===========================================================================
GET_ROUTES = '''        elif path == "/api/kb/categories":
            self._send_json(kb_service.get_categories())

        elif path == "/api/kb/attribute_groups":
            self._send_json(kb_service.get_attribute_groups())

        elif path == "/api/kb/profile_attributes":
            query = parse_qs(url.query)
            pid = query.get("id", [""])[0]
            try:
                self._send_json(kb_service.profile_attributes(pid))
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 404)

        elif path == "/api/panel/layout":
            self._send_json(load_panel_layout())

        elif path == "/api/nodes/discovered":
            self._send_json({
                "discovered": passive_registry.snapshot(),
                "watchdog": offline_watchdog.status(),
            })

        elif path == "/api/alarms":
            query = parse_qs(url.query)
            try:
                limit = int(query.get("limit", ["50"])[0])
            except ValueError:
                limit = 50
            self._send_json(alarm_store.snapshot(limit=limit))

'''

# ===========================================================================
# 3. 写路由
# ===========================================================================
POST_ROUTES = '''        elif path == "/api/kb/save_category":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_category(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_categories":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_categories(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类批量保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_category":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_category(req_data.get("category_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设分类删除被拒绝: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_attribute_groups":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.save_attribute_groups(req_data))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"属性分组保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/save_preset":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                self._send_json(kb_service.save_preset(
                    req_data.get("preset_id", ""), req_data.get("preset", {})))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设保存失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/kb/delete_preset":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(kb_service.delete_preset(req_data.get("preset_id", "")))
            except Exception as e:
                log_diagnostic_error(logger, "ERR-KB-WRITE", f"预设删除失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/panel/save_layout":
            if not auth.check_permission(token, "operate_lights"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            try:
                self._send_json(save_panel_layout(req_data))
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

        # ---------------------- 节点发现与掉线告警 ----------------------
        elif path == "/api/nodes/scan":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足，需要工程师以上权限"}, 403)
                return
            try:
                targets = req_data.get("targets") or []
                if not targets and req_data.get("subnet"):
                    targets = node_prober.expand_subnet(
                        req_data.get("subnet"), int(req_data.get("prefix", 24) or 24))
                if not targets:
                    targets = [x.get("ip") for x in passive_registry.snapshot() if x.get("ip")]
                results = node_prober.scan(targets) if targets else []
                for r in results:
                    if r.get("reply"):
                        passive_registry.observe(r["ip"])
                self._send_json({"status": "ok", "scanned": len(targets),
                                 "responded": sum(1 for r in results if r.get("reply")),
                                 "results": results})
            except Exception as e:
                log_diagnostic_error(logger, "ERR-NET-6454", f"ArtPoll 网段扫描失败: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/nodes/test_connection":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            ip = (req_data.get("ip") or "").strip()
            if not ip:
                self._send_json({"status": "error", "message": "IP 地址不能为空"}, 400)
                return
            try:
                probe = node_prober.probe(ip)
                # 三态判定：ArtPoll 有应答 / 无应答但有被动流量 / 完全无响应
                seen = {x.get("ip"): x for x in passive_registry.snapshot()}
                traffic = seen.get(ip)
                if probe.get("reply"):
                    state = "online"
                    hint = "已收到 ArtPollReply，节点在线"
                elif traffic and not traffic.get("stale"):
                    state = "traffic_only"
                    hint = ("该 IP 正在发送 ArtDmx，但未回应 ArtPoll —— "
                            "可能是仅单向发送的解码器（建议存活判据改为 artdmx）")
                else:
                    state = "no_response"
                    hint = "既无 ArtPollReply 也无被动流量，可能 IP 有错或不在同一网段"
                probe["state"] = state
                probe["hint"] = hint
                probe["passive"] = traffic
                self._send_json(probe)
            except Exception as e:
                log_diagnostic_error(logger, "ERR-NET-6454", f"节点连接测试失败 [{ip}]: {e}")
                self._send_json({"status": "error", "message": str(e)}, 400)

        elif path == "/api/nodes/sync_watchdog":
            if not auth.check_permission(token, "edit_kb"):
                self._send_json({"status": "error", "message": "权限不足"}, 403)
                return
            self._send_json({"status": "ok", "registered": sync_watchdog_from_venue()})

        elif path == "/api/alarms/ack":
            try:
                if req_data.get("all"):
                    self._send_json({"status": "ok", "acked": alarm_store.acknowledge_all()})
                else:
                    self._send_json({"status": "ok",
                                     "alarm": alarm_store.acknowledge(req_data.get("alarm_id", ""))})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, 400)

'''


def main():
    with io.open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    if "AlarmStore" in src:
        raise SystemExit("[ABORT] 已存在 AlarmStore，疑似重复执行，已中止。")

    # 1) 模块级插入（放在 kb_service 实例化之后）
    src = must_replace(
        src,
        'kb_service = KnowledgeBaseService(\n'
        '    kb_root=os.path.join(BASE_DIR, "knowledge_base"),\n'
        '    kb_manager=kb\n'
        ')\n',
        'kb_service = KnowledgeBaseService(\n'
        '    kb_root=os.path.join(BASE_DIR, "knowledge_base"),\n'
        '    kb_manager=kb\n'
        ')\n' + MODULE_INSERT,
        "模块级：节点发现 / 告警中心 / 面板布局"
    )

    # 2) 只读路由：插到 _dispatch_api_get 的兜底 404 之前
    # 2) 只读路由：插到 _dispatch_api_get 的兜底 404 之前
    src = must_replace(
        src,
        '        elif path == "/api/llm/config":\n'
        '            qwen_plugin = engine.plugin_host.get_llm()\n'
        '            api_url = getattr(qwen_plugin, "api_url", "http://127.0.0.1:8085/v1/chat/completions")\n'
        '            model_name = getattr(qwen_plugin, "model_name", "qwen2.5-7b-4q")\n'
        '            self._send_json({"api_url": api_url, "model_name": model_name})\n'
        '        else:\n'
        '            self._send_json({"error": "Not Found"}, 404)\n',
        '        elif path == "/api/llm/config":\n'
        '            qwen_plugin = engine.plugin_host.get_llm()\n'
        '            api_url = getattr(qwen_plugin, "api_url", "http://127.0.0.1:8085/v1/chat/completions")\n'
        '            model_name = getattr(qwen_plugin, "model_name", "qwen2.5-7b-4q")\n'
        '            self._send_json({"api_url": api_url, "model_name": model_name})\n'
        + GET_ROUTES +
        '        else:\n'
        '            self._send_json({"error": "Not Found"}, 404)\n',
        "只读路由：分类 / 属性分组 / 灯库属性 / 面板 / 节点 / 告警"
    )

    # 3) 写路由：插到插件生命周期 API 之前
    src = must_replace(
        src,
        '        # 插件生命周期与市场 API\n',
        POST_ROUTES + '        # 插件生命周期与市场 API\n',
        "写路由：分类 / 属性分组 / 单条预设 / 面板 / 节点探测 / 告警确认"
    )

    # 4) 启动时同步看门狗 + 启动轮询线程
    src = must_replace(
        src,
        '\nmonitor.start()\n',
        '\nmonitor.start()\n\n'
        '# 启动掉线看门狗：同步当前场地节点并开启 1s 轮询\n'
        '_wd_nodes = sync_watchdog_from_venue()\n'
        'logger.info(f" [掉线看门狗] 已接管 {_wd_nodes} 个解码器节点的在线监测")\n'
        'threading.Thread(target=watchdog_tick, daemon=True).start()\n',
        "启动掉线看门狗"
    )

    with io.open(TARGET, "w", encoding="utf-8") as f:
        f.write(src)

    print("=" * 70)
    print("[DONE] control_station.py 已完成 v4.3 服务端接入。")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
