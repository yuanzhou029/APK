# -*- coding: utf-8 -*-
"""
快速单独测试单个脚本并打印详细耗时与结果
"""
import sys, subprocess, os, time

script = sys.argv[1]
APP = r"D:\python项目文件\AI-MA5.3"
PY = sys.executable
env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1", AIMA_LOG_CONSOLE="1")

t0 = time.time()
try:
    p = subprocess.run([PY, os.path.join(APP, "tests", script)], cwd=APP, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15)
    dur = time.time() - t0
    out = (p.stdout or "") + "\n" + (p.stderr or "")
    print(f"=== {script} (code: {p.returncode}, dur: {dur:.1f}s) ===")
    lines = [l for l in out.splitlines() if l.strip()]
    for l in lines[-10:]:
        print("  ", l)
except subprocess.TimeoutExpired:
    print(f"=== {script} TIMEOUT (15s) ===")
except Exception as e:
    print(f"=== {script} ERROR: {e} ===")
