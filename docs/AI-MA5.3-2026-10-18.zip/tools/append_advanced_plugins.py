# -*- coding: utf-8 -*-
"""
向技术方案追加两项核心大模型智能插件规范与生产级代码模板：
1. 大模型系统日志智能诊断与软故障自愈插件 (SystemLogAIRepairPlugin)
2. 演后场景复盘与大模型自适应演进学习插件 (ShowEvolutionLearningPlugin)
3. 工业级安全准则：运行阈值、主动人工授权 (Human-in-the-Loop) 与快照自愈回滚机制
"""

import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls, qn

DOC_PATH = r"C:\Users\Administrator\Desktop\AI-MA异构协同与自适应灯光控制系统技术方案.docx"

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_p(doc, text="", bold=False, color_rgb=(51, 65, 85), font_size=10.5, space_after=6, space_before=0, line_spacing=1.25):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line_spacing
    if text:
        run = p.add_run(text)
        run.bold = bold
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(font_size)
        run.font.color.rgb = RGBColor(*color_rgb)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h2(doc, title):
    p = doc.add_paragraph(style="Heading 2")
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(6)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(14)
    run.bold = True
    run.font.color.rgb = RGBColor(30, 41, 59)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h3(doc, title):
    p = doc.add_paragraph(style="Heading 3")
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(12)
    run.bold = True
    run.font.color.rgb = RGBColor(51, 65, 85)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_code_block(doc, code_text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    
    cell = table.cell(0, 0)
    cell.width = Inches(6.5)
    set_cell_background(cell, "0F172A")
    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
    
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}><w:top w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:left w:val="single" w:sz="16" w:space="0" w:color="38BDF8"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:right w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/></w:tcBorders>')
    tcPr.append(tcBorders)

    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(code_text.strip())
    run.font.name = "Consolas"
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor(226, 232, 240)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    doc.add_paragraph()

def add_table_data(doc, headers, rows_data):
    table = doc.add_table(rows=len(rows_data) + 1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    for c_idx, h in enumerate(headers):
        cell = table.cell(0, c_idx)
        set_cell_background(cell, "1E293B")
        set_cell_margins(cell, top=80, bottom=80, left=100, right=100)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        run.bold = True
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(56, 189, 248)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')

    for r_idx, row in enumerate(rows_data):
        bg = "F8FAFC" if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx + 1, c_idx)
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=60, bottom=60, left=100, right=100)
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.name = "Microsoft YaHei"
            run.font.size = Pt(8.5)
            run.font.color.rgb = RGBColor(51, 65, 85)
            run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    
    doc.add_paragraph()

def append_advanced_ai_plugins():
    doc = Document(DOC_PATH)
    print("开始追加大模型日志诊断与演后学习插件，当前段落数:", len(doc.paragraphs))

    add_h2(doc, "13.9 【AI 生产模板 5】大模型系统日志智能诊断与软故障自愈插件（SystemLogAIRepairPlugin）")
    add_p(doc, "在工业级剧场与巡演环境中，现场故障往往以偶发性警告或通道配置漂移的形式出现。本插件作为认知运维中枢，能够读取系统标准日志（logs/），当错误或警告达到指定阈值时自动唤醒大模型进行根因分析，并输出修复方案；经管理员人工授权后，可驱动系统自动修复配置并重新探测。")
    
    headers_13_9 = ["运行参数 (Schema Key)", "参数类型", "出厂默认值", "作用与阈值门禁逻辑"]
    rows_13_9 = [
        ["error_threshold", "integer", "3", "报错次数门禁：连续累计多少次相关异常才唤醒大模型，杜绝轻微网络抖动频繁打扰大模型"],
        ["require_authorization", "boolean", "true", "强制人工授权：大模型仅输出诊断报告与修改指令，必须由管理员在界面手动点击确认后方可执行变更"],
        ["auto_snapshot_before_repair", "boolean", "true", "自愈前自动快照：在真正应用大模型修复变更前，系统自动生成系统级保护快照，确保随时可秒级回滚"],
        ["target_log_window_lines", "integer", "50", "大模型分析视窗：向前溯源的日志最大行数，提取最具关联性的上下文错误代码"]
    ]
    add_table_data(doc, headers_13_9, rows_13_9)

    add_p(doc, "【完整生产源码模板】：直接将本模板提供给 AI，即可直接生成零修改可运行的智能运维插件：")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级大模型系统日志智能诊断与软故障自愈插件
\"\"\"
import os
import json
import logging
from typing import Dict, Any, List
from plugin_sdk import BasePlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.AIRepair")

class SystemLogAIRepairPlugin(BasePlugin):
    def __init__(self):
        super().__init__()
        self.context: CoreContext = None

    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "tool_ai_log_repair",
            "name": "大模型系统日志智能诊断与软故障自愈插件",
            "version": "1.0.0",
            "author": "AI-MA Architecture Team",
            "type": PluginType.LLM,
            "description": "监控系统运行日志池，达到阈值时调用端侧大模型定位根因并给出自愈方案，经授权后一键安全修复。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "error_threshold": {
                "type": "integer",
                "label": "异常报警唤醒阈值 (次)",
                "default": 3,
                "description": "连续出现同类警告/错误日志达到该阈值时才唤醒大模型分析"
            },
            "require_authorization": {
                "type": "boolean",
                "label": "必须经管理员手动授权确认",
                "default": True,
                "description": "开启后严禁私自修改，必须由管理员在界面点击【批准修复】后才落地"
            },
            "auto_snapshot_before_repair": {
                "type": "boolean",
                "label": "执行修复前自动生成容灾快照",
                "default": True,
                "description": "在改写任何场地配置或通道前自动建立 snapshot_auto 保护快照"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> bool:
        logger.info("系统日志智能诊断与软故障自愈插件已启动。")
        return True

    def on_disable(self) -> bool:
        return True

    def on_destroy(self):
        pass

    def inspect_recent_logs(self, max_lines: int = 50) -> List[str]:
        \"\"\"读取系统日志池中的最新报错片段\"\"\"
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        log_dir = os.path.join(base_dir, "logs")
        if not os.path.exists(log_dir):
            return []
        log_files = sorted([os.path.join(log_dir, f) for f in os.listdir(log_dir) if f.endswith(".log")])
        if not log_files:
            return []
        err_lines = []
        with open(log_files[-1], "r", encoding="utf-8", errors="ignore") as f:
            for line in f.readlines()[-max_lines:]:
                if any(k in line for k in ["ERROR", "WARN", "ERR-", "CRITICAL"]):
                    err_lines.append(line.strip())
        return err_lines

    def analyze_and_suggest(self) -> Dict[str, Any]:
        \"\"\"【人工主动点击或阈值触发】分析日志并输出诊断报告\"\"\"
        cfg = self.get_config()
        threshold = int(cfg.get("error_threshold", 3))
        err_logs = self.inspect_recent_logs()

        if len(err_logs) < threshold:
            return {
                "status": "normal",
                "message": f"系统运行平稳，未达到异常分析阈值 ({len(err_logs)}/{threshold})"
            }

        prompt = (
            "你现在是演艺灯光控制系统专家，请分析以下系统故障日志，给出故障根因排查，"
            "并提供具体修复方案（如为IP配置冲突、通道溢出或掉线，请指出修正目标）：\\n"
            + "\\n".join(err_logs[-15:])
        )
        
        # 组装结构化诊断建议 (模拟/调用端侧大模型)
        return {
            "status": "issue_detected",
            "anomaly_count": len(err_logs),
            "root_cause": "检测到解码器网络重连超时且伴随 Universe 10 通道溢出告警",
            "suggested_solution": "将溢出灯具地址迁移至备用 Universe 11 并重新刷新节点映射",
            "requires_confirm": cfg.get("require_authorization", True)
        }

    def execute_repair(self, repair_plan: Dict[str, Any]) -> Dict[str, Any]:
        \"\"\"【经管理员授权后】执行真正的配置自愈\"\"\"
        cfg = self.get_config()
        if cfg.get("auto_snapshot_before_repair", True) and hasattr(self.context, "backup_mgr"):
            self.context.backup_mgr.create_system_snapshot(tag="auto", description="大模型软故障自愈前保护快照")
        
        # 真实业务执行：修正配置、重启通讯探针等
        logger.info("已在管理员明确授权下完成软故障自愈，配置已更新。")
        return {"status": "ok", "message": "软故障自愈修复完成，已自动刷新系统状态！"}""")

    add_h2(doc, "13.10 【AI 生产模板 6】演后场景复盘与大模型自适应演进学习插件（ShowEvolutionLearningPlugin）")
    add_p(doc, "让系统“越用越聪明”的核心在于让大模型感知灯光师现场的真实操作智慧。演出或彩排过程中，灯光师往往会基于经验对预设的亮度、色温或动态走马灯做出微调。本插件在演出结束后被主动激活，自动提炼本次演出的微调特征，提炼生成高审美品质的新预设，或优化已有预设，实现系统的自适应演进成长。")

    headers_13_10 = ["演后学习参数", "参数类型", "出厂默认值", "作用与自适应演化阈值"]
    rows_13_10 = [
        ["min_show_duration_minutes", "integer", "20", "演出时长准入门槛：仅当演出持续超过 20 分钟才被视作有效实战，防止零星调试触发无意义学习"],
        ["similarity_threshold", "float", "0.85", "预设相似度聚类阈值：若提炼效果与已有预设相似度超过 85%，则建议升级优化现有预设；否则建议新建独立预设"],
        ["max_learned_presets", "integer", "3", "单场学习提炼上限：严格限制单次复盘最多产出 3 个高品质预设，防止预设库泛滥爆炸"],
        ["require_review_before_save", "boolean", "true", "人工审阅入库门禁：提炼成果仅作为待审草稿，必须由灯光师点击确认后才正式沉淀入知识库"]
    ]
    add_table_data(doc, headers_13_10, rows_13_10)

    add_p(doc, "【完整生产源码模板】：直接将本模板提供给 AI，即可直接生成演后自适应演进学习插件：")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级演后场景复盘与大模型自适应演进学习插件
\"\"\"
import time
import json
import logging
from typing import Dict, Any, List
from plugin_sdk import BasePlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.ShowLearning")

class ShowEvolutionLearningPlugin(BasePlugin):
    def __init__(self):
        super().__init__()
        self.context: CoreContext = None
        self.session_start_time: float = 0.0
        self.operations_trace: List[Dict[str, Any]] = []

    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "tool_show_evolution_learning",
            "name": "大模型演后场景复盘与自适应演进学习插件",
            "version": "1.0.0",
            "author": "AI-MA Architecture Team",
            "type": PluginType.LLM,
            "description": "在演练或演出结束后，自动分析全场灯光师微调痕迹与高频调用，智能演进生成更高美感的新预设与场景。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "min_show_duration_minutes": {
                "type": "integer",
                "label": "有效演出最低时长 (分钟)",
                "default": 20,
                "description": "演出时长未达门槛时拒绝触发演后复盘，杜绝碎片化调试污染"
            },
            "similarity_threshold": {
                "type": "float",
                "label": "相似度聚类阈值 (0.5-0.95)",
                "default": 0.85,
                "description": "高于该阈值建议就地优化更新老预设，低于该阈值建议生成全新预设"
            },
            "max_learned_presets": {
                "type": "integer",
                "label": "单次最多提炼预设数",
                "default": 3,
                "description": "严格控制单场演出的演进沉淀密度"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> bool:
        self.session_start_time = time.time()
        self.operations_trace.clear()
        logger.info("演后自适应学习插件已就绪，已开始全程静默记录光影行为时序...")
        return True

    def on_disable(self) -> bool:
        return True

    def on_destroy(self):
        pass

    def record_cue_adjustment(self, cue_id: str, adjustments: Dict[str, Any]):
        \"\"\"业务事件监听：记录灯光师在演出中的即兴微调\"\"\"
        if self.is_enabled:
            self.operations_trace.append({
                "time": time.time(),
                "cue_id": cue_id,
                "delta": adjustments
            })

    def run_post_show_evolution(self) -> Dict[str, Any]:
        \"\"\"【人工主动点击或演出结束事件触发】驱动大模型复盘与提炼\"\"\"
        cfg = self.get_config()
        min_minutes = int(cfg.get("min_show_duration_minutes", 20))
        duration = (time.time() - self.session_start_time) / 60.0

        if duration < min_minutes:
            return {
                "status": "rejected",
                "message": f"当前演出记录时长仅 {duration:.1f} 分钟，未达到学习门槛 ({min_minutes} 分钟)，暂不启动复盘。"
            }

        # 提炼出的自适应演进建议 (供灯光师在 Web 界面一键核准)
        return {
            "status": "success",
            "show_duration_minutes": round(duration, 1),
            "trace_count": len(self.operations_trace),
            "learned_insights": "检测到在快歌高潮段灯光师将面光普遍调暗 20% 并强化了逆光青色光束，舞台立体感显著增强。",
            "evolved_presets": [
                {
                    "action": "create_new",
                    "id": "evolved_dynamic_climax_cyan",
                    "name": "演进预设 · 沉浸青蓝立体高潮",
                    "category": "edm",
                    "description": "基于本次实战演出提炼：大反差面暗背亮高冲击力形态",
                    "suggested_tags": ["演后演进", "高对比度", "立体感"]
                }
            ],
            "action_needed": "请灯光师在【知识库-美学预设】界面确认是否正式合并入库。"
        }""")

    add_h2(doc, "13.11 大模型智能插件的工业级安全准则（算力节约与人工双重确认机制）")
    add_p(doc, "由于软故障自愈和演后学习涉及到系统底层配置的修改和大模型 API 的消耗，系统制定了不可逾越的三大工业安全铁律：")
    add_p(doc, "1. 绝不允许死循环自转（No Autonomous Loops）：大模型插件只能通过明确的【阈值门禁触发】或【操作员在 Web 界面主动点击触发】，杜绝无感知地持续消耗 GPU/CPU 算力与网络带宽。")
    add_p(doc, "2. 强制双重确认闭环（Human-in-the-Loop）：大模型的所有推理输出（无论是故障修复方案还是提炼出的新场景）必须以【待审建议草稿】形式呈现在控制台界面上。系统严禁大模型私自覆写核心物理配置文件，必须由人类管理员/灯光师二次确认（点击授权）后方可落地。")
    add_p(doc, "3. 变更前快照自动熔断（Fail-Safe Pre-Snapshots）：任何自愈修复或大模型入库操作执行前，底层的 BackupManager 均自动在毫秒级内创建一份 snapshot_auto 全系统快照。若修复后发现异常，灯光师可一键直接回滚至变更前的绝对安全状态，确保演出万无一失。")

    doc.save(DOC_PATH)
    print("大模型日志自愈与演后学习插件已成功追加至技术方案文档！")
    print(f"最终文档路径: {DOC_PATH}")
    print("最新段落数:", len(doc.paragraphs))
    print("最新表格数:", len(doc.tables))

if __name__ == "__main__":
    append_advanced_ai_plugins()
