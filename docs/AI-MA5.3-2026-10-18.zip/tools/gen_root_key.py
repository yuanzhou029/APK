#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI-MA OS v5.0 系统底层架构维护者 (root) 动态应急 Key 生成器
运行在 Linux / Debian 系统或 Windows 控制台：
直接生成当天的 32 位 Hex 动态密钥以及浏览器一键直通 URL。

Debian 原生 Bash 单行命令 (无需 Python):
echo -n "AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026:$(date +%F)" | md5sum | cut -d' ' -f1
"""

import sys
import os
import time
import hashlib

SECRET_SEED = os.environ.get("AURA_ROOT_SEED", "AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026")

def generate_key(date_str=None):
    if not date_str:
        date_str = time.strftime("%Y-%m-%d")
    raw = f"{SECRET_SEED}:{date_str}"
    return hashlib.md5(raw.encode("utf-8")).hexdigest()

def main():
    date_str = time.strftime("%Y-%m-%d")
    key = generate_key(date_str)
    
    if "--raw" in sys.argv:
        print(key)
        return
    
    if "--url" in sys.argv:
        port = os.environ.get("AI_MA_PORT", "9000")
        print(f"http://127.0.0.1:{port}/?key={key}")
        return

    port = os.environ.get("AI_MA_PORT", "9000")
    print("=" * 68)
    print(" 极光灵动 · AI-MA OS v5.0 底层架构维护者 (root) 动态应急准入")
    print("=" * 68)
    print(f" [系统当前日期] : {date_str}")
    print(f" [32位动态Key]  : {key}")
    print(f" [Debian命令]   : echo -n \"{SECRET_SEED}:$(date +%F)\" | md5sum | cut -d' ' -f1")
    print("-" * 68)
    print(" [浏览器直通URL]:")
    print(f" http://127.0.0.1:{port}/?key={key}")
    print("=" * 68)
    print(" 提示: 该账号为底层架构维护者，具备系统全局最高特权，不到万不得已请勿启用。")

if __name__ == "__main__":
    main()
