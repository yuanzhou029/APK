# -*- coding: utf-8 -*-
"""
分批快速检测每个脚本，打印详细结果与报错
"""
import os, sys, glob, subprocess, time

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")
PY = sys.executable

files = sorted(glob.glob(os.path.join(TESTS, "*.py")))
env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1", AIMA_LOG_CONSOLE="1")

print(f"Total: {len(files)} files")

for f in files:
    name = os.path.basename(f)
    t0 = time.time()
    try:
        p = subprocess.run([PY, f], cwd=APP, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=12)
        dur = time.time() - t0
        out = (p.stdout or "") + "\n" + (p.stderr or "")
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        last_line = lines[-1] if lines else "(empty)"
        has_pass = any("PASS" in l or "通过" in l or "OK" in l or "SUCCESS" in l for l in lines[-5:])
        status = "PASS" if p.returncode == 0 else f"FAIL({p.returncode})"
        print(f"{status:<9} | {name:<40} | {dur:4.1f}s | {last_line[:75]}")
    except subprocess.TimeoutExpired:
        print(f"TIMEOUT   | {name:<40} | >12s")
    except Exception as e:
        print(f"ERROR     | {name:<40} | {e}")
