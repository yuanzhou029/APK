# -*- coding: utf-8 -*-
"""
探测与诊断 tests/ 目录下全部 34 个脚本的运行状态与输出特征
"""
import os, sys, glob, subprocess, time

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")
PY = sys.executable

files = sorted(glob.glob(os.path.join(TESTS, "*.py")))
env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1")

print(f"=== 诊断开始：共 {len(files)} 个测试脚本 ===")

for f in files:
    name = os.path.basename(f)
    t0 = time.time()
    try:
        p = subprocess.run([PY, f], cwd=APP, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        dur = time.time() - t0
        out = (p.stdout or "") + "\n" + (p.stderr or "")
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        last_line = lines[-1] if lines else "(no output)"
        has_pass = any("PASS" in l or "通过" in l or "OK" in l or "SUCCESS" in l for l in lines[-5:])
        print(f"[{p.returncode}] {name:<42} | 耗时:{dur:4.1f}s | 合格标:{has_pass} | 尾行:{last_line[:80]}")
    except subprocess.TimeoutExpired:
        print(f"[TIMEOUT] {name:<42} | 超过 30s")
    except Exception as e:
        print(f"[ERR] {name:<42} | 异常: {e}")
