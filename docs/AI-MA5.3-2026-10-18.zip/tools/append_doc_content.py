# -*- coding: utf-8 -*-
"""
向技术方案追加制造说明书级详尽技术实现与生产级AI插件开发模板
"""

import os
import sys
import shutil
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

DOC_PATH = r"C:\Users\Administrator\Desktop\AI-MA异构协同与自适应灯光控制系统技术方案.docx"
BACKUP_PATH = r"C:\Users\Administrator\Desktop\AI-MA异构协同与自适应灯光控制系统技术方案.docx.bak"

def set_cell_background(cell, fill_hex):
    """设置单元格背景颜色"""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    """设置单元格内边距"""
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_p(doc, text="", bold=False, color_rgb=(51, 65, 85), font_size=10.5, space_after=6, space_before=0, line_spacing=1.25):
    """添加标准正文段落"""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line_spacing
    if text:
        run = p.add_run(text)
        run.bold = bold
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(font_size)
        run.font.color.rgb = RGBColor(*color_rgb)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h1(doc, title):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(10)
    run = p.runs[0] if p.runs else p.add_run(title)
    if not p.runs:
        run.text = title
    else:
        run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(18)
    run.bold = True
    run.font.color.rgb = RGBColor(15, 23, 42)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h2(doc, title):
    p = doc.add_paragraph(style="Heading 2")
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(6)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(14)
    run.bold = True
    run.font.color.rgb = RGBColor(30, 41, 59)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h3(doc, title):
    p = doc.add_paragraph(style="Heading 3")
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(12)
    run.bold = True
    run.font.color.rgb = RGBColor(51, 65, 85)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_code_block(doc, code_text):
    """添加工业级代码容器"""
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    
    cell = table.cell(0, 0)
    cell.width = Inches(6.5)
    set_cell_background(cell, "0F172A")
    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
    
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}><w:top w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:left w:val="single" w:sz="16" w:space="0" w:color="38BDF8"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:right w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/></w:tcBorders>')
    tcPr.append(tcBorders)

    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(code_text.strip())
    run.font.name = "Consolas"
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor(226, 232, 240)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    doc.add_paragraph()

def add_table_data(doc, headers, rows_data):
    """添加规整的系统技术对比/参数表格"""
    table = doc.add_table(rows=len(rows_data) + 1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    for c_idx, h in enumerate(headers):
        cell = table.cell(0, c_idx)
        set_cell_background(cell, "1E293B")
        set_cell_margins(cell, top=80, bottom=80, left=100, right=100)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        run.bold = True
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(56, 189, 248)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')

    for r_idx, row in enumerate(rows_data):
        bg = "F8FAFC" if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx + 1, c_idx)
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=60, bottom=60, left=100, right=100)
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.name = "Microsoft YaHei"
            run.font.size = Pt(8.5)
            run.font.color.rgb = RGBColor(51, 65, 85)
            run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    
    doc.add_paragraph()

def build_full_documentation():
    if not os.path.exists(DOC_PATH):
        raise FileNotFoundError(f"找不到文档: {DOC_PATH}")
    
    # 备份一份原始文档
    if not os.path.exists(BACKUP_PATH):
        shutil.copy2(DOC_PATH, BACKUP_PATH)
        print("已创建原始文档备份:", BACKUP_PATH)

    doc = Document(DOC_PATH)
    print("读取原文档成功，段落数:", len(doc.paragraphs))

    # =========================================================================
    # 第十二章：系统全量工程落地制造说明（底层核心机制全景解析）
    # =========================================================================
    add_h1(doc, "第十二章：系统全量工程落地制造说明（底层核心机制全景解析）")
    add_p(doc, "本章作为《极光灵动 · AI-MA 异构协同与自适应灯光操作系统》的工业落地与制造实现总章，详细阐述系统从物理 DMX/Art-Net 信号仲裁、毫秒级淡变插值器、RAG 演艺知识库驱动、企业级安全鉴权，到全系统容灾备份与现场硬件看门狗的工程级实现方案。所有模块均经过实机 30Hz 连续满负载运行验证。")

    add_h2(doc, "12.1 DMX/Art-Net 四级优先级动态仲裁与硬件物理安全掩码（DmxMerger）")
    add_p(doc, "在现代专业演艺与文旅灯光控制现场，信号源可能同时来自 AI 大模型、灯光师物理控制台、动态走马灯宏插件以及一键黑场急停按键。为保证演出的绝对安全，系统研发了纯原子级多通道信号仲裁引擎（DmxMerger）。")
    add_p(doc, "仲裁引擎设计了四个不可逆的优先级梯度，任何高优先级信号源一旦触发，立即在 0 毫秒内硬性压制低优先级信号：")

    headers_12_1 = ["优先级层级", "优先级常量", "数值定义", "业务信号源场景", "仲裁与抢占规则"]
    rows_12_1 = [
        ["紧急熔断", "PriorityLevel.PANIC", "100", "现场黑场急停 (Blackout) / 物理断险", "绝对最高优先级，无条件全通道归零或强制限位，压制一切信号"],
        ["实体控台", "PriorityLevel.MA_TAKEOVER", "75", "grandMA3 / 外部实体控制台 Art-Net 接入", "外部物理推杆接管，灯光师手动介入，压制所有内部 AI 与预设"],
        ["AI 动态宏", "PriorityLevel.AI_MACRO", "50", "走马灯插件、呼吸灯特效、音频节拍驱动", "处于中间层级，覆盖预设与静态场景，但低于灯光师实体控台"],
        ["预设与底态", "PriorityLevel.AI_CUE", "25", "静态预设 (Presets)、快捷场景 (Quick Scenes)", "基础场景呈现层级，供底层渲染与 Crossfade 毫秒淡变平滑过渡"]
    ]
    add_table_data(doc, headers_12_1, rows_12_1)

    add_p(doc, "硬件物理安全通道掩码（Channel Safety Mask）：", bold=True)
    add_p(doc, "高压气体放电灯、电脑摇头灯具有特定的物理危险通道（如灯泡触发高压电离点火通道、硬件重置通道 Reset、频闪持续高压放电）。AI 大模型在通过自然语言编译时可能因上下文理解偏差向此类通道输出错误数值，导致昂贵灯具物理烧毁。DmxMerger 引入了通道级原子锁定机制：")
    add_code_block(doc, """# DmxMerger 物理安全通道原子锁定算法 (核心源码实现片段)
def lock_channel(self, universe: int, channel: int, safe_value: int = 0):
    \"\"\"锁定危险通道：一旦锁定，任何低于 PANIC 的信号源均无法修改此通道\"\"\"
    with self._lock:
        key = (universe, channel)
        self.locked_channels[key] = max(0, min(255, safe_value))

def get_final_frame(self, universe: int) -> bytearray:
    \"\"\"逐通道优先级仲裁与物理安全通道强制限位\"\"\"
    final_frame = bytearray(512)
    with self._lock:
        # 1. 按照优先级由高到低仲裁 (PANIC -> MA_TAKEOVER -> AI_MACRO -> AI_CUE)
        for ch in range(512):
            for priority, source_name, frame in self._sorted_sources(universe):
                final_frame[ch] = frame[ch]
                break
        # 2. 硬件安全通道物理掩码强制覆盖 (绝对防烧灯物理硬约束)
        for (u, ch), safe_val in self.locked_channels.items():
            if u == universe and 0 <= ch < 512:
                final_frame[ch] = safe_val
    return final_frame""")

    add_h2(doc, "12.2 30Hz 恒定时基物理发送主循环与毫秒级 Crossfade 线性插值器")
    add_p(doc, "剧场人眼对频闪与色彩突变的敏感阈值为 25-30ms。为杜绝舞台灯光画面跳变（Snap），系统底层设计了纳秒级高精度物理发送时基循环与多 Universe 并行 Crossfade 淡变线性插值引擎。")
    add_p(doc, "1. 恒定 33.3ms 时基防抖动算法：采用 time.perf_counter() 高精度单调时钟计算每帧演算开销，并动态计算差值补偿自适应休眠（Adaptive Sleep），彻底消除了 Python 在 Windows/Linux 系统下的时间片调度抖动。")
    add_p(doc, "2. 并发 Crossfade 插值算法：支持每个 Universe 独立的毫秒级平滑淡变。插值公式为：V(t) = V_start + (V_target - V_start) * min((now - t_start) / duration, 1.0)。若同一 Universe 接收到新的淡变指令，插值器自动以当前瞬时输出帧作为新淡变的起点帧，确保光影过渡丝滑连贯无断层。")

    add_h2(doc, "12.3 三层 RAG 演艺知识库物模型驱动与端侧大模型编译上下文流水线")
    add_p(doc, "传统大模型无法直接用于舞台控制，原因在于通用大语言模型不了解当前舞台安装了什么灯具、挂在哪个 Universe、占用哪些 DMX 通道。AI-MA 独创了“三层 RAG 物模型”架构：")
    add_p(doc, "• 第一层（物理灯库层 Profiles）：解析灯具厂商物理属性（通道功能映射、Fine 微调通道、摇摆角度极值、频闪安全区间）。")
    add_p(doc, "• 第二层（场地与节点拓扑层 Venues）：定义舞台三维空间区域（面光区、侧光区、逆光区、地排区）、目标解码器 IP 地址、起始 Universe 与物理排布。")
    add_p(doc, "• 第三层（美学预设与意图映射层 Presets）：收录上百种国际标准灯光美学模式（如落日暖金、赛博朋克深蓝、抒情慢歌呼吸）。")
    add_p(doc, "RAG 上下文拼装流水线：当操作员在交互界面输入自然语言提示词（如“全场变暗，追光灯打向舞台中央主唱，营造神秘氛围”）时，系统动态检索当前场地激活的灯具列表及通道映射，将其压缩组装至 System Prompt 中，约束端侧本地大模型（Qwen 2.5-7B 或 DeepSeek）仅输出符合严格 JSON 规范的执行指令，实现零外网依赖的本地化实时编译。")

    add_h2(doc, "12.4 四级 RBAC 企业权限与会话安全管理（含 root 底层动态准入）")
    add_p(doc, "系统构建了金融级的角色访问控制模型（Role-Based Access Control），彻底隔离日常操作员与高级管理者的管理边界：")

    headers_12_4 = ["角色标识", "角色名称", "业务权限集", "用户账号修改权限", "生命周期与删除约束"]
    rows_12_4 = [
        ["admin", "系统主管理员", "全系统业务配置、用户账号管理、插件管理、容灾备份与回滚、灯光调控", "可自主修改账号名（Rename）与安全密码", "系统基石账号，底层强绑定 is_primary_admin 标识，系统中绝对禁止删除"],
        ["engineer", "主控灯光师", "调光控制、场景录制与编排、工作区面板自定义、快照备份", "由管理员分配，可修改自身密码", "支持按需增删，删除时物理安全销毁专属工作区配置"],
        ["viewer", "现场观察员", "纯只读监视、DMX 实时通道查看、中文运行日志与告警审查", "由管理员分配，可修改自身密码", "只读权限，不可执行任何调光或写操作"],
        ["root", "底层架构维护者", "系统无条件全局最高穿透权限（绕过一切权限闸门），底层架构维护", "系统核心底层维护，外部不可改写", "完全隐形！用户列表不显示，普通登录不开放，仅凭动态 Key 准入，绝对不可删除"]
    ]
    add_table_data(doc, headers_12_4, rows_12_4)

    add_p(doc, "系统底层维护者 (root) 动态 32 位 Hex Key 应急准入机制：", bold=True)
    add_p(doc, "为保证系统在极端情况下（如主管理员忘记密码、权限配置发生死锁）仍能进行底层救砖，系统设计了基于固定密钥种子与系统日期的动态 Hash 应急准入通道：")
    add_p(doc, "• 固定密钥种子（SECRET_SEED）：AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026")
    add_p(doc, "• 动态生成算法：MD5(SECRET_SEED + \":\" + 当前日期 YYYY-MM-DD)，输出严格的 32 位 Hex 字符串。")
    add_p(doc, "• 浏览器直通体验：维护者在浏览器地址栏输入形如 http://127.0.0.1:9000/?key=32位Hex 即可在 0.5 秒内自动通过底层验签，换取最高权限 Session 并直通控制台。")
    add_p(doc, "• Debian Linux 原生一行命令生成：")
    add_code_block(doc, "echo -n \"AURA-MA-ENTERPRISE-DEBIAN-ROOT-KEY-2026:$(date +%F)\" | md5sum | cut -d' ' -f1")

    add_h2(doc, "12.5 全系统级多版本容灾备份与跨用户交互机制")
    add_p(doc, "针对工业演艺现场严苛的连续运行要求，系统实现了零丢失的原子级全系统容灾备份架构：")
    add_p(doc, "1. SHA-256 全文件指纹防篡改：快照生成时对知识库、拓扑图、场景配置的所有文件计算 SHA-256 哈希值并记录至 snapshot_meta.json。回滚前执行全量哈希自检，若有任意文件损坏或被篡改，系统自动拒绝回滚，避免半损坏状态进入生产。")
    add_p(doc, "2. 双模式分类与 5 份 FIFO 循环覆盖：自动备份（Auto）与手动备份（Manual）独立归类存储。每类严格执行最多 5 份上限，超出时自动淘汰最旧快照，避免磁盘爆满。")
    add_p(doc, "3. 用户数据隔离与安全合并导出：操作员可导出专属工作区配置包（AI_MA_USER_DATA_PACKAGE，文件名脱敏隐藏 .json 后缀）。支持跨用户导入，并提供“合并补充”与“完全覆写”两种模式。回滚快照时，系统自动对当前活跃管理员凭据库执行保护性合并，确保管理员登录不中断。")

    add_h2(doc, "12.6 现场 Art-Net 节点发现、动态心跳探针与掉线看门狗")
    add_p(doc, "系统内置工业级 Art-Net 协议栈解码器探针网络：")
    add_p(doc, "• 主动探针（ArtPollProber）：定期广播标准 ArtPoll 数据包，捕获现场解码器回复的 ArtPollReply，自动解析固件版本、端口数及 Universe 绑定。")
    add_p(doc, "• 掉线看门狗（OfflineWatchdog）：对现场所有注册节点维护最后通信时标。若节点超过 5.0 秒未应答即标记为可疑，超过 18.4 秒未收到心跳则触发 critical 级别告警。")
    add_p(doc, "• 告警三态生命周期：告警中心支持未处理（Open）、已确认（Acked）、已恢复（Recovered）完整生命周期闭环，所有状态变更毫秒级同步至 Web 前端。")

    # =========================================================================
    # 第十三章：开放式插件生态系统与生产级 AI 插件开发模板
    # =========================================================================
    add_h1(doc, "第十三章：开放式插件生态系统与生产级 AI 插件开发模板")
    add_p(doc, "本章是系统的核心制造级开发规范与 AI 生成说明书。AI-MA 拥有高内聚、低耦合的企业级插件微内核架构。任何开发者或 AI 助手只需严格遵循本章提供的模板，即可在数分钟内开发出 100% 稳定运行、支持 UI 动态表单渲染、具备热重载能力的全新插件！")

    add_h2(doc, "13.1 插件微内核架构与生命周期状态机（PluginHost）")
    add_p(doc, "PluginHost 负责插件全生命周期的加载、启停、配置持久化与故障隔离：")
    add_p(doc, "1. 扫描与动态导入：扫描 plugins/ 目录下的所有 Python 脚本，采用 importlib.import_module 动态加载，并通过 inspect.isclass 自动定位继承自 BasePlugin 的类实体。")
    add_p(doc, "2. 热重载机制（Hot Reload）：支持不重启控制台主服务直接热加载插件源码（importlib.reload），现场调试零停机。")
    add_p(doc, "3. 参数持久化：插件配置独立保存在 config/plugins_config.json 中，与插件源码彻底解耦。启动时自动回填已配置参数。")
    add_p(doc, "4. 异常熔断隔离沙箱：在 30Hz 发送循环中，任何插件执行异常（如语法错误、除零错误）均被内核沙箱捕获，触发自动保护性熔断并输出中文错误代码，主控台物理时钟永不崩溃。")

    add_h2(doc, "13.2 插件 SDK 标准规范与 UI 参数动态渲染 Schema 体系")
    add_p(doc, "所有插件必须继承自 plugin_sdk.py 中定义的特定基类。通过重写 get_config_schema() 方法，Web 控制台能够自动解析该字典并动态生成前端参数配置界面，开发者无需编写任何前端 HTML/JS 代码！")

    headers_13_2 = ["字段属性", "支持类型", "作用说明", "UI 渲染表现形式"]
    rows_13_2 = [
        ["type", "string / integer / float / boolean / select", "参数的数据类型", "自动映射为文本框、数字框、滑块、开关或下拉选择框"],
        ["label", "string (中文)", "参数在界面的展示标签", "字段标题文本"],
        ["default", "对应类型值", "出厂默认值", "初始化及重置时的默认填充值"],
        ["description", "string (中文)", "详细参数说明与业务含义", "输入框下方的灰色辅助提示文字"],
        ["options", "list of dict", "下拉选择项 (仅 select 类型有效)", "提供 [{value, label}] 选项列表"]
    ]
    add_table_data(doc, headers_13_2, rows_13_2)

    add_h2(doc, "13.3 插件合规验证器（PluginValidator 八大审查准则）")
    add_p(doc, "为确保进入市场的插件绝对安全稳定，系统在加载前执行八项严苛的自动化合规审查：")
    add_p(doc, "1. 基类继承合法性：必须且仅能继承自 BaseProtocolPlugin / BaseMacroPlugin / BasePerceptionPlugin / BaseLLMPlugin 之一。")
    add_p(doc, "2. 元信息完整性：get_info() 必须包含 id, name, version, author, type, description 字段。")
    add_p(doc, "3. ID 格式规范：必须采用纯小写字母、数字与下划线命名（^[a-z0-9_]{3,32}$）。")
    add_p(doc, "4. 语义化版本号：version 必须遵循 SemVer 规范（如 1.0.0）。")
    add_p(doc, "5. Schema 规范性：get_config_schema() 返回的每个字段必须声明 type, label, default。")
    add_p(doc, "6. 生命周期方法实现：必须完整实现 on_init(context), on_enable(), on_disable(), on_destroy()。")
    add_p(doc, "7. 类型专属契约：协议插件必须实现 send_universe()；宏插件必须实现 render()；感知插件必须实现 start_listening()。")
    add_p(doc, "8. 资源释放契约：on_disable() 与 on_destroy() 必须关闭所有打开的 Socket 套接字、停止后台线程并清理内存。")

    add_h2(doc, "13.4 【AI 生产模板 1】输出协议驱动插件模板（以 sACN / E1.31 协议为例）")
    add_p(doc, "【核心模板】：当需要开发新的输出网络协议（如 sACN, OSC, Modbus 等）时，直接将本模板提供给 AI，替换具体的网络封包逻辑即可直接生成。")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级输出协议插件模板：sACN (ANSI E1.31) 工业网络协议驱动
\"\"\"
import socket
import logging
from typing import Dict, Any
from plugin_sdk import BaseProtocolPlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.sACN")

class SacnProtocolPlugin(BaseProtocolPlugin):
    def __init__(self):
        super().__init__()
        self.context: CoreContext = None
        self.sock: socket.socket = None
        self.target_ip: str = "239.255.0.1" # 组播地址
        self.port: int = 5568
        self.priority: int = 100
        self.cid = b'\\x01\\x02\\x03\\x04\\x05\\x06\\x07\\x08\\x09\\x0a\\x0b\\x0c\\x0d\\x0e\\x0f\\x10'

    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "protocol_sacn_e131",
            "name": "sACN (ANSI E1.31) 工业协议驱动",
            "version": "1.0.0",
            "author": "AI-MA Architecture Team",
            "type": PluginType.PROTOCOL,
            "description": "提供标准 sACN E1.31 工业灯光网络流发送能力，支持多 Universe 组播与单播。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "target_ip": {
                "type": "string",
                "label": "目标发送 IP 地址",
                "default": "239.255.0.1",
                "description": "sACN 组播地址 (如 239.255.0.X) 或解码器目标单播地址"
            },
            "port": {
                "type": "integer",
                "label": "UDP 端口",
                "default": 5568,
                "description": "标准 sACN 默认端口为 5568"
            },
            "priority": {
                "type": "integer",
                "label": "sACN 协议优先级 (0-200)",
                "default": 100,
                "description": "E1.31 数据包优先级，控台切换标准"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        cfg = self.get_config()
        self.target_ip = cfg.get("target_ip", "239.255.0.1")
        self.port = int(cfg.get("port", 5568))
        self.priority = int(cfg.get("priority", 100))
        return True

    def on_enable(self) -> bool:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            logger.info(f"sACN 驱动已成功开启输出链路: {self.target_ip}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"启动 sACN 套接字失败: {e}")
            return False

    def on_disable(self) -> bool:
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        logger.info("sACN 驱动已安全断开输出链路。")
        return True

    def on_destroy(self):
        self.on_disable()

    def update_config(self, new_config: Dict[str, Any]) -> bool:
        super().update_config(new_config)
        self.target_ip = new_config.get("target_ip", self.target_ip)
        self.port = int(new_config.get("port", self.port))
        self.priority = int(new_config.get("priority", self.priority))
        return True

    def send_universe(self, universe: int, dmx_data: bytearray) -> bool:
        \"\"\"30Hz 物理输出回调：将 512 字节 DMX 数据打包为 sACN 数据包并发送\"\"\"
        if not self.is_enabled or not self.sock:
            return False
        try:
            # 组装 sACN Root Layer + Framing Layer + DMP Layer 核心数据包
            payload = bytearray()
            # Preamble Size (0x0010) & Post-amble Size (0x0000)
            payload.extend(b'\\x00\\x10\\x00\\x00')
            # ACN Packet Identifier
            payload.extend(b'ASC-E1.17\\x00\\x00\\x00')
            # Root Flags and Length
            payload.extend(b'\\x72\\x6e')
            # Vector Root: E131_DATA_PACKET (0x00000004)
            payload.extend(b'\\x00\\x00\\x00\\x04')
            payload.extend(self.cid)
            # Framing Layer: Flags & Length (0x7258)
            payload.extend(b'\\x72\\x58')
            payload.extend(b'\\x00\\x00\\x00\\x02') # Vector Framing
            payload.extend(b'AI-MA sACN Node'.ljust(64, b'\\x00')) # Source Name
            payload.append(self.priority) # Priority
            payload.extend(b'\\x00\\x00') # Synchronization Universe
            payload.append(0) # Sequence Number
            payload.append(0) # Options
            payload.extend((universe + 1).to_bytes(2, byteorder='big')) # Universe
            # DMP Layer: Flags & Length (0x720b)
            payload.extend(b'\\x72\\x0b')
            payload.append(2) # Vector DMP
            payload.append(0xa1) # Address Type & Data Type
            payload.extend(b'\\x00\\x00\\x00\\x01') # First Property Address & Increment
            payload.extend((len(dmx_data) + 1).to_bytes(2, byteorder='big'))
            payload.append(0) # DMX Start Code (0x00)
            payload.extend(dmx_data[:512]) # DMX 通道数据
            
            # 发送至目标 IP (组播或单播)
            self.sock.sendto(payload, (self.target_ip, self.port))
            return True
        except Exception as e:
            logger.error(f"sACN 发送帧异常 (Universe {universe}): {e}")
            return False""")

    add_h2(doc, "13.5 【AI 生产模板 2】动态灯光特效宏插件模板（以矩阵彩虹呼吸波为例）")
    add_p(doc, "【核心模板】：当需要开发新的舞台特效算法（如水波纹、火焰跳动、矩阵彩虹跑马灯）时，直接提供本模板给 AI，重点重写 render() 算法即可。")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级动态灯光特效宏插件模板：多灯具矩阵彩虹呼吸波特效
\"\"\"
import math
import logging
from typing import Dict, Any, List
from plugin_sdk import BaseMacroPlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.MatrixRainbow")

class MatrixRainbowMacroPlugin(BaseMacroPlugin):
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "macro_matrix_rainbow",
            "name": "矩阵全彩流动彩虹宏",
            "version": "1.0.0",
            "author": "AI-MA Core Team",
            "type": PluginType.MACRO,
            "description": "基于空间位置拓扑计算连续相位正弦差，在多台染色灯之间生成高平滑度的彩虹流动波。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "speed": {
                "type": "float",
                "label": "波动速度 (Hz)",
                "default": 1.0,
                "description": "彩虹波纹流动的周期频率"
            },
            "wave_spread": {
                "type": "float",
                "label": "空间相位差系数",
                "default": 0.35,
                "description": "相邻两台灯具之间的颜色相位偏移量"
            },
            "brightness": {
                "type": "integer",
                "label": "主调光亮度 (0-255)",
                "default": 255,
                "description": "输出整体亮度基准"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        return True

    def on_enable(self) -> bool:
        logger.info("矩阵流动彩虹宏插件已就绪。")
        return True

    def on_disable(self) -> bool:
        return True

    def on_destroy(self):
        pass

    def render(self, elapsed_ms: float, params: Dict[str, Any], base_frame: bytearray) -> bytearray:
        \"\"\"
        30Hz 物理渲染回调：基于毫秒时钟为指定灯具组演算全新的 DMX 帧数据
        \"\"\"
        cfg = self.get_config()
        speed = float(cfg.get("speed", 1.0))
        spread = float(cfg.get("wave_spread", 0.35))
        dimmer = int(cfg.get("brightness", 255))
        fixtures = params.get("fixtures", [])
        
        t = (elapsed_ms / 1000.0) * speed * 2.0 * math.pi
        out_frame = bytearray(base_frame)

        for idx, fix in enumerate(fixtures):
            start_ch = fix.get("start_channel", 1) - 1
            channels_map = fix.get("channels_map", {})
            r_idx = channels_map.get("red", 0)
            g_idx = channels_map.get("green", 1)
            b_idx = channels_map.get("blue", 2)
            dim_idx = channels_map.get("dimmer", -1)

            # 空间正弦相位演算 (红绿蓝三相各相差 120 度)
            phase = t + idx * spread
            r = int((math.sin(phase) + 1.0) * 0.5 * 255)
            g = int((math.sin(phase + 2.094) + 1.0) * 0.5 * 255)
            b = int((math.sin(phase + 4.188) + 1.0) * 0.5 * 255)

            if 0 <= start_ch + r_idx < 512: out_frame[start_ch + r_idx] = r
            if 0 <= start_ch + g_idx < 512: out_frame[start_ch + g_idx] = g
            if 0 <= start_ch + b_idx < 512: out_frame[start_ch + b_idx] = b
            if dim_idx >= 0 and 0 <= start_ch + dim_idx < 512:
                out_frame[start_ch + dim_idx] = dimmer

        return out_frame""")

    add_h2(doc, "13.6 【AI 生产模板 3】外部物理感知插件模板（以音频 FFT 节拍与 BPM 提取器为例）")
    add_p(doc, "【核心模板】：用于接入麦克风音频流、摄像头人脸追踪、MIDI 控制台输入或红外雷达感应。")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级外部感知插件模板：舞台音频流 FFT 频谱分析与 BPM 节拍提取器
\"\"\"
import time
import threading
import logging
from typing import Dict, Any
from plugin_sdk import BasePerceptionPlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.AudioBpm")

class AudioBpmPerceptionPlugin(BasePerceptionPlugin):
    def __init__(self):
        super().__init__()
        self.context: CoreContext = None
        self._thread: threading.Thread = None
        self._running: bool = False
        self.bpm: float = 128.0

    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "perception_audio_bpm",
            "name": "舞台音频实时节拍与 BPM 感知器",
            "version": "1.0.0",
            "author": "AI-MA Core Team",
            "type": PluginType.PERCEPTION,
            "description": "采集声卡低频能量并计算现场 BPM 节拍脉冲，向系统事件总线广播 BEAT 触发事件。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "sensitivity": {
                "type": "float",
                "label": "重低音捕获灵敏度 (0.1 - 2.0)",
                "default": 1.0,
                "description": "调节底鼓与贝斯能量的触发阈值"
            },
            "default_bpm": {
                "type": "float",
                "label": "预设基准 BPM",
                "default": 128.0,
                "description": "静音状态下的默认节拍频率"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        return True

    def on_enable(self) -> bool:
        self._running = True
        self._thread = threading.Thread(target=self._listen_loop, name="AudioBpmThread", daemon=True)
        self._thread.start()
        logger.info("音频节拍感知器后台监听线程已启动。")
        return True

    def on_disable(self) -> bool:
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None
        logger.info("音频节拍感知器后台监听已停止。")
        return True

    def on_destroy(self):
        self.on_disable()

    def start_listening(self) -> bool:
        return self.on_enable()

    def stop_listening(self) -> bool:
        return self.on_disable()

    def _listen_loop(self):
        \"\"\"感知计算主线程 (每 100ms 模拟/计算一次低频特征)\"\"\"
        while self._running:
            time.sleep(0.1)
            # 在实际工程中调用 pyaudio / sounddevice 执行 FFT，此处进行事件发布示例
            # 当检测到底鼓重音脉冲时，通过 event_bus 发布全局事件
            if self.context and hasattr(self.context, "event_bus"):
                self.context.event_bus.publish("PERCEPTION_AUDIO_BEAT", {
                    "bpm": self.bpm,
                    "energy": 0.85,
                    "timestamp": time.time()
                })""")

    add_h2(doc, "13.7 【AI 生产模板 4】端侧大语言模型适配插件模板（以适配本地 Ollama/Qwen 为例）")
    add_p(doc, "【核心模板】：用于快速接入任何第三方或私有部署的本地大语言模型服务（如 Ollama, vLLM, DeepSeek-V3, LocalAI 等）。")
    add_code_block(doc, """# -*- coding: utf-8 -*-
\"\"\"
AI-MA 生产级大模型适配插件模板：本地 Ollama / Qwen 2.5-7B 端侧模型适配器
\"\"\"
import json
import urllib.request
import logging
from typing import Dict, Any
from plugin_sdk import BaseLLMPlugin, PluginType, CoreContext

logger = logging.getLogger("Plugin.OllamaQwen")

class OllamaQwenLLMPlugin(BaseLLMPlugin):
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "llm_ollama_qwen",
            "name": "Ollama 本地大模型驱动 (Qwen/DeepSeek)",
            "version": "1.0.0",
            "author": "AI-MA Core Team",
            "type": PluginType.LLM,
            "description": "适配局域网或本机部署的 Ollama API，提供零延迟离线智能编译与 JSON 提取。"
        }

    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "api_url": {
                "type": "string",
                "label": "Ollama API 端点",
                "default": "http://127.0.0.1:11434/api/generate",
                "description": "本地部署模型的 RESTful 生成接口地址"
            },
            "model_name": {
                "type": "string",
                "label": "加载模型名称",
                "default": "qwen2.5:7b",
                "description": "部署在 Ollama 中的模型标签 (如 qwen2.5:7b / deepseek-r1:8b)"
            },
            "temperature": {
                "type": "float",
                "label": "推理随机度 (Temperature)",
                "default": 0.2,
                "description": "灯光控制推荐保持低随机度 (0.1 - 0.3) 以保证 JSON 输出确定性"
            }
        }

    def on_init(self, context: CoreContext) -> bool:
        return True
    def on_enable(self) -> bool:
        return True
    def on_disable(self) -> bool:
        return True
    def on_destroy(self):
        pass

    def generate(self, prompt: str, system_prompt: str = "") -> str:
        \"\"\"向本地模型接口发送推理请求并返回结果\"\"\"
        cfg = self.get_config()
        url = cfg.get("api_url", "http://127.0.0.1:11434/api/generate")
        model = cfg.get("model_name", "qwen2.5:7b")
        temp = float(cfg.get("temperature", 0.2))

        payload = {
            "model": model,
            "prompt": prompt,
            "system": system_prompt,
            "stream": False,
            "options": {"temperature": temp}
        }
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                res_data = json.loads(resp.read().decode("utf-8"))
                return res_data.get("response", "")
        except Exception as e:
            logger.error(f"调用 Ollama 本地模型失败: {e}")
            raise RuntimeError(f"大模型通信故障: {e}")""")

    add_h2(doc, "13.8 直接丢给 AI 的插件生成指令提示词（Meta Prompt Template）")
    add_p(doc, "【核心实操秘籍】：未来在任何时候需要让 AI 为系统编写插件，直接复制并填写以下提示词模板，AI 即可 100% 按照系统标准生成可以直接运行的源码文件！")
    add_code_block(doc, """你现在是《极光灵动 · AI-MA 异构协同与自适应灯光操作系统》的专属首席插件架构师。
请严格遵循系统【Plugin SDK v3.0】规范为我编写一个全新的插件：

【插件开发需求】
- 插件类型：[填入类型：protocol / macro / perception / llm]
- 插件名称：[填入你的插件名称，例如：LaserStrobeEffect]
- 核心功能：[详细描述插件的具体行为，例如：在5台激光灯上生成高频交错爆闪特效]
- 可调节参数：[列出需要在 Web 界面配置的参数，例如：频闪频率, 颜色通道, 持续时间]

【代码生成约束】
1. 必须从 plugin_sdk 导入 BasePlugin (或 BaseProtocolPlugin, BaseMacroPlugin, BasePerceptionPlugin, BaseLLMPlugin) 及 PluginType, CoreContext。
2. 必须实现 get_info() 并包含完整合规的 id (纯小写字母及下划线), name, version, author, type, description。
3. 必须实现 get_config_schema() 声明各参数的 type, label, default, description，以支持 Web 控制台自动渲染表单。
4. 必须完整实现 on_init(context), on_enable(), on_disable(), on_destroy() 生命周期。
5. 必须具备异常沙箱处理，严禁在执行中抛出导致 30Hz 物理输出主线程崩溃的未捕获异常。
6. 直接输出纯 Python 源码文件，无任何外部私有库依赖。""")

    # =========================================================================
    # 第十四章：系统环境要求与 Debian Linux 工业部署排障指南
    # =========================================================================
    add_h1(doc, "第十四章：系统环境要求与 Debian Linux 工业部署排障指南")
    add_p(doc, "本章面向工程交付人员与现场运维工程师，提供系统在主流工业服务器与演艺车载工控机（重点支持 Debian 11/12 Linux 发行版）上的标准化落地指南。")

    add_h2(doc, "14.1 硬件与系统环境标准")
    headers_14_1 = ["硬件/环境组件", "最低工业标准", "推荐演艺剧场配置", "备注说明"]
    rows_14_1 = [
        ["主控处理器", "Intel Core i5 8代 / AMD Ryzen 5 (4核)", "Intel Core i7 12代及以上 / Xeon (8核16线程)", "保障 30Hz 物理循环纳秒级时基与本地 7B 大模型顺畅运行"],
        ["运行内存", "8 GB DDR4", "16 GB - 32 GB DDR4/DDR5", "三层知识库向量索引与系统快照缓存驻留内存"],
        ["存储硬盘", "64 GB SSD", "256 GB NVMe 高速固态硬盘", "满足多版本全系统容灾备份与快速毫秒级回滚"],
        ["网络接口", "100M/1000M 物理以太网网口 (RJ45)", "双独立千兆千兆以太网口 (Intel I210/I225)", "网口A绑定 192.168.x.x 专供 Art-Net 工业总线，网口B供 Web 远程运维"],
        ["操作系统", "Debian 11 / 12 Linux (64-bit) / Win10/11", "Debian 12 Bookworm (Minimal Server)", "系统针对 Linux epoll 与 POSIX 定时器进行了深度原生优化"]
    ]
    add_table_data(doc, headers_14_1, rows_14_1)

    add_h2(doc, "14.2 Debian Linux systemd 服务化注册与守护进程配置")
    add_p(doc, "在 Debian 终端中将 AI-MA 注册为系统级后台守护服务，实现开机自启、崩溃自动重启与日志持久化：")
    add_code_block(doc, """# 1. 创建 systemd 服务描述文件: /etc/systemd/system/ai-ma.service
[Unit]
Description=AI-MA Adaptive Lighting Operating System v5.0
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ai_lighting_system
ExecStart=/usr/bin/python3 /opt/ai_lighting_system/control_station.py
Restart=always
RestartSec=3s
LimitNOFILE=65535
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target

# 2. 启用并启动服务命令
sudo systemctl daemon-reload
sudo systemctl enable ai-ma.service
sudo systemctl start ai-ma.service
sudo systemctl status ai-ma.service""")

    add_h2(doc, "14.3 中文故障诊断代码对照与自愈排障手册")
    add_p(doc, "系统所有诊断日志均写入 logs/ 目录，统一采用中文语义化故障码格式：")

    headers_14_3 = ["中文故障代码", "故障名称", "触发机理与现场根因", "系统自愈机制与排障推荐"]
    rows_14_3 = [
        ["ERR-AUTH-DENIED", "未授权访问拦截", "非法 Token、会话过期、或试图伪造超级管理员身份访问受限接口", "系统自动阻断并记录审计日志。排障：重新登录或检查 Token 有效期"],
        ["ERR-NODE-OFFLINE", "解码器设备掉线", "现场 Art-Net 解码器网线松动、供电中断、或超过 18.4s 未回复心跳", "系统自动触发黄/红报警并弹窗提示。排障：检查网线连接、交换机指示灯及供电"],
        ["ERR-MASK-TRIP", "物理安全掩码熔断", "外部指令或 AI 生成指令试图修改受锁定的高压触发/复位危险通道", "DmxMerger 瞬间物理强制归零或锁定为安全值，杜绝烧灯。无需人工干预，系统已自动保护"],
        ["ERR-HASH-MISMATCH", "快照校验失败", "待恢复的系统快照中有文件被外部程序篡改或硬盘产生坏道", "系统拒绝执行破坏性回滚，保护生产环境不受污染。排障：选择其他完整历史快照恢复"],
        ["ERR-QUOTA-FULL", "备份槽位已满", "单个用户在主机的备份文件数达到 5 份上限", "系统触发安全确认机制。用户可选择下载至本地或确认后自动循环覆盖最旧备份"]
    ]
    add_table_data(doc, headers_14_3, rows_14_3)

    # 保存文档
    doc.save(DOC_PATH)
    print("全量制造说明书技术方案已成功写入目标 DOCX 文档！")
    print(f"最终文档路径: {DOC_PATH}")
    print("总段落数:", len(doc.paragraphs))
    print("总表格数:", len(doc.tables))

if __name__ == "__main__":
    build_full_documentation()
