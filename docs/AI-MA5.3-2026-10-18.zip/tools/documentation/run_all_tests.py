# -*- coding: utf-8 -*-
"""
准出测试真实运行器

用途：拿到每个测试套件**自报的权威断言数**，而不是靠静态正则数 check() 调用点。
静态计数会漏掉：裸 assert 型套件、循环内的 check() 调用。

前置：检测是否已有 AI-MA 实例在运行。若有则整体跳过并退出码 2，
绝不杀死用户正在使用的进程（这是本项目的历史事故教训）。
"""

import os
import re
import subprocess
import sys
import socket
import time

sys.stdout.reconfigure(encoding="utf-8")

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")
PY = sys.executable

SUITES = [
    "test_aima53_standalone_system.py",
    "test_plugin_observability.py",
    "test_auth_noise_suppression.py",
    "test_aima53_boot_e2e.py",
    "test_kernel_watchdog.py",
    "test_release_package_integrity.py",
]


def port_busy(port=9000):
    with socket.socket() as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def daemon_running():
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq aima-rt-daemon.exe"],
                             capture_output=True, text=True, timeout=15).stdout
        return "aima-rt-daemon" in out
    except Exception:
        return False


def main():
    print("=" * 78)
    print("  准出测试真实运行（获取权威断言数）")
    print("=" * 78)

    if port_busy(9000) or daemon_running():
        print("\n[SKIP] 检测到已有 AI-MA 实例在运行（端口 9000 被占用或存在 aima-rt-daemon）。")
        print("       为避免干扰用户正在使用的系统，本次运行整体跳过。")
        print("       请先停止现有实例后重跑。退出码 2。")
        return 2

    env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1")
    results = []
    t0 = time.time()
    for fn in SUITES:
        path = os.path.join(TESTS, fn)
        print(f"\n{'-' * 78}\n[RUN] {fn}\n{'-' * 78}")
        start = time.time()
        try:
            p = subprocess.run([PY, path], cwd=APP, env=env, capture_output=True,
                               text=True, encoding="utf-8", errors="replace", timeout=900)
            out = (p.stdout or "") + "\n" + (p.stderr or "")
            rc = p.returncode
        except subprocess.TimeoutExpired:
            out, rc = "[TIMEOUT] 超过 900 秒", -1
        dur = time.time() - start

        m = re.search(r"(\d+)\s*/\s*(\d+)\s*全部通过", out)
        self_report = f"{m.group(1)}/{m.group(2)}" if m else None
        n_assert = len(re.findall(r"^\s*assert\s", open(path, encoding="utf-8").read(), re.M))
        passed = "ALL PASSED" in out or "100% 通过" in out
        results.append((fn, rc, self_report, n_assert, passed, dur))

        tail = [l for l in out.splitlines() if l.strip()][-4:]
        for l in tail:
            print("    " + l.strip()[:110])
        print(f"    -> 退出码 {rc} | 自报 {self_report or '(无)'} | 裸assert {n_assert} "
              f"| 耗时 {dur:.1f}s")

    print("\n" + "=" * 78)
    print("  汇总")
    print("=" * 78)
    print(f"  {'套件':<44} {'退出':>4} {'自报':>9} {'裸assert':>9}")
    total_self = 0
    all_ok = True
    for fn, rc, sr, na, passed, dur in results:
        n = int(sr.split("/")[1]) if sr else na
        total_self += n
        if rc != 0 or not passed:
            all_ok = False
        print(f"  {fn:<44} {rc:>4} {sr or '-':>9} {na:>9}")
    print(f"\n  权威断言总数（各套件自报之和）= {total_self}")
    print(f"  全部通过 = {all_ok}")
    print(f"  总耗时 {time.time() - t0:.0f} 秒")
    print("=" * 78)

    # 落盘权威结果，供 verify_docs_against_code.py 校验文档数字
    import json
    artifact = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "_test_results.json")
    data = {
        "total": total_self,
        "all_passed": all_ok,
        "suites": {fn: {"exit": rc, "self_report": sr, "bare_asserts": na,
                        "passed": passed, "seconds": round(dur, 1)}
                   for fn, rc, sr, na, passed, dur in results},
    }
    with open(artifact, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  权威结果已写入: {artifact}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
