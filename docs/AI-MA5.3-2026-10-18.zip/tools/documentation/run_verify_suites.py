# -*- coding: utf-8 -*-
"""
tests/verify_*.py 历史回归套件运行器

背景：这 17 套是 v4.2–v4.3 时期编写的回归套件，其中 12 套会读写真实
knowledge_base/、config/ 或执行删除操作。运行前必须先备份这三个目录。

本运行器做四件事：
  1. 前置独占性检查（端口 9000 / aima-rt-daemon 进程）
  2. 运行前对三个敏感目录做哈希快照
  3. 逐套运行，采集退出码与自报断言数
  4. 运行后再做一次哈希快照，报告哪些文件被改动/删除/新增
     —— 这样"测试是否污染了真实数据"是被测量出来的，不是靠猜

用法: python run_verify_suites.py [--only a,b,c] [--timeout 300]
"""

import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")
SENSITIVE = ["knowledge_base", "config", "backups"]


def snapshot(dirs):
    """返回 {相对路径: md5}"""
    snap = {}
    for d in dirs:
        root = os.path.join(APP, d)
        if not os.path.isdir(root):
            continue
        for dirpath, _, files in os.walk(root):
            for f in files:
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, APP)
                try:
                    with open(full, "rb") as fh:
                        snap[rel] = hashlib.md5(fh.read()).hexdigest()
                except OSError:
                    snap[rel] = "<unreadable>"
    return snap


def diff_snapshots(before, after):
    added = sorted(set(after) - set(before))
    removed = sorted(set(before) - set(after))
    changed = sorted(k for k in set(before) & set(after) if before[k] != after[k])
    return added, removed, changed


def port_busy(port=9000):
    with socket.socket() as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def parse_result(out, rc):
    """
    从套件输出中提取权威的通过/失败计数。

    这些 v4.x 套件的输出格式并不统一，实测存在三种：
      A) "结果: 15 项通过 / 0 项失败"          -> 以「项失败」为准
      B) "[ALL PASSED] ... 54/54 全部通过！"   -> 以 N==M 为准
      C) "[SUCCESS] ... 100% 通过！"           -> 无计数，以退出码为准

    早期版本用裸正则 (\d+)/(\d+) 抓，会抓到进度条的 "2/3"，
    把明明 15 项全过的套件误判为失败。
    """
    # 格式 A：最可靠，「项失败」为 0 即通过
    m = re.search(r"(\d+)\s*项通过\s*/\s*(\d+)\s*项失败", out)
    if m:
        n_pass, n_fail = int(m.group(1)), int(m.group(2))
        return f"{n_pass}/{n_pass + n_fail}", n_fail == 0

    # 格式 B
    m = re.search(r"(\d+)\s*/\s*(\d+)\s*全部通过", out)
    if m:
        n_pass, total = int(m.group(1)), int(m.group(2))
        return f"{n_pass}/{total}", n_pass == total

    # 显式失败标记 —— 必须早于成功标记检查。
    # 有些套件会先打印一个阶段性的 [SUCCESS]/100% 标记，再在后续阶段断言失败；
    # 若先查成功标记，就会把「退出码 1 + AssertionError」误判为通过。
    # verify_architecture.py 踩过这个坑。
    if re.search(r"\[FAILED\]|\[FAIL\]|AssertionError|Traceback|ModuleNotFoundError", out):
        return None, False

    # 格式 C：无计数，只有显式成功标记
    if re.search(r"\[ALL PASSED\]|\[SUCCESS\]|100% 通过|全部测试通过", out):
        return None, True

    # 兜底：以退出码为准
    return None, rc == 0


def main():
    only = None
    timeout = 300
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--only" and i + 1 < len(args):
            only = set(args[i + 1].split(","))
        if a == "--timeout" and i + 1 < len(args):
            timeout = int(args[i + 1])

    print("=" * 80)
    print("  tests/verify_*.py 历史回归套件运行")
    print("=" * 80)

    if port_busy(9000):
        print("\n[SKIP] 端口 9000 被占用，已有实例在运行。为避免干扰，整体跳过。退出码 2。")
        return 2

    suites = sorted(f for f in os.listdir(TESTS)
                    if f.startswith("verify_") and f.endswith(".py"))
    if only:
        suites = [s for s in suites if s.replace(".py", "") in only or s in only]
    print(f"\n  待运行 {len(suites)} 套")

    before = snapshot(SENSITIVE)
    print(f"  运行前快照: {len(before)} 个受监控文件\n")

    env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1")
    results = []
    t0 = time.time()

    for fn in suites:
        print(f"{'-' * 80}\n[RUN] {fn}\n{'-' * 80}")
        start = time.time()
        try:
            p = subprocess.run([sys.executable, os.path.join(TESTS, fn)],
                               cwd=APP, env=env, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=timeout)
            out = (p.stdout or "") + "\n" + (p.stderr or "")
            rc = p.returncode
        except subprocess.TimeoutExpired as e:
            out = (e.stdout or "") if isinstance(e.stdout, str) else ""
            out += "\n[TIMEOUT]"
            rc = -9
        dur = time.time() - start

        self_report, passed = parse_result(out, rc)
        # 提取失败原因（首个异常行或 FAIL 行）
        reason = ""
        for line in out.splitlines():
            s = line.strip()
            if s.startswith("[FAIL]") or "AssertionError" in s:
                reason = s[:110]
                break
        if not reason and rc != 0:
            for line in reversed(out.splitlines()):
                s = line.strip()
                if s and not s.startswith(("File ", "^", "~")):
                    reason = s[:110]
                    break

        results.append({"suite": fn, "exit": rc, "self_report": self_report,
                        "passed": passed, "seconds": round(dur, 1),
                        "reason": reason, "tail": "\n".join(
                            [l for l in out.splitlines() if l.strip()][-12:])})

        tail = [l for l in out.splitlines() if l.strip()][-4:]
        for l in tail:
            print("    " + l.strip()[:110])
        print(f"    -> 退出码 {rc} | 计数 {self_report or '(无)'} | "
              f"{'通过' if passed else '未通过'} | {dur:.1f}s")

    after = snapshot(SENSITIVE)
    added, removed, changed = diff_snapshots(before, after)

    print(f"\n{'=' * 80}\n  汇总\n{'=' * 80}")
    print(f"  {'套件':<48}{'退出':>5}{'计数':>10}{'判定':>7}")
    ok_n = 0
    for r in results:
        verdict = "通过" if r["passed"] else "未通过"
        if r["passed"]:
            ok_n += 1
        print(f"  {r['suite']:<48}{r['exit']:>5}{r['self_report'] or '-':>10}{verdict:>7}")
    print(f"\n  通过 {ok_n} / {len(results)} 套")

    failed = [r for r in results if not r["passed"]]
    if failed:
        print(f"\n  未通过明细（{len(failed)} 套）:")
        for r in failed:
            print(f"\n    ● {r['suite']}  (退出码 {r['exit']})")
            if r["reason"]:
                print(f"      原因: {r['reason']}")
            for l in (r["tail"] or "").splitlines()[-4:]:
                print(f"      | {l.strip()[:100]}")

    print(f"\n  总耗时 {time.time() - t0:.0f} 秒")

    print(f"\n{'=' * 80}\n  数据完整性复核（受监控目录）\n{'=' * 80}")
    if not (added or removed or changed):
        print("  [OK] 三个受监控目录未被任何修改")
    else:
        print(f"  新增 {len(added)} 个，删除 {len(removed)} 个，修改 {len(changed)} 个")
        for k in changed:
            print(f"    ~ {k}")
        if added:
            roots = sorted({k.split(os.sep)[1] if os.sep in k else k for k in added})
            print(f"    新增集中在: {', '.join(roots[:6])}"
                  + (f" 等 {len(added)} 项" if len(added) > 6 else ""))
        if removed:
            print(f"    删除共 {len(removed)} 项（多为备份快照自动轮转）")

    artifact = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "_verify_results.json")
    with open(artifact, "w", encoding="utf-8") as f:
        json.dump({"results": results, "passed": ok_n, "total": len(results),
                   "data_changes": {"added": added, "removed": removed,
                                    "changed": changed}}, f, ensure_ascii=False, indent=2)
    print(f"\n  结果已写入: {artifact}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
