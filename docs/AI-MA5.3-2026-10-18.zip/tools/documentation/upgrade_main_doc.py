# -*- coding: utf-8 -*-
"""
主文档升级：v5.0 单体口径 -> v5.3 混合硬实时微内核实装口径

输入: AI-MA异构协同与自适应灯光控制系统技术方案.docx          (v5.0 原件, 只读不动)
输出: AI-MA异构协同与自适应灯光控制系统技术方案_v5.3实装版.docx

升级策略（不重建文档，全部为原地外科手术，保留既有排版与既有表格）：
  1. 结构修复：把错序到第十四章之后的 13.9/13.10/13.11 移回第十三章
  2. 全局口径替换：30Hz->44Hz、33.3ms->22.7ms、artnet_controller->artnet_sender、
     /opt/ai_lighting_system->/opt/ai-ma、v5.0->v5.3 等
  3. 定点重写：12.2 引擎、13.3 验证器契约、13.8 提示词、14.2 systemd、14.3 故障码
  4. 插入：2.4 v5.3 软件架构（置于「三、核心技术模块详解」之前）
  5. 追加：第十六~十八章（微内核实装 / 三层插件与可观测性 / 发布流水线）

注意：python-docx 的 doc.add_* 一律追加到文末，无法插入中间位置。
因此凡需插入中间的内容，先在临时 Document 中构造，再把 XML 元素搬到目标位置。
"""

import os
import sys
import shutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.oxml.ns import qn
from docx_style import (add_p, add_h1, add_h2, add_h3, add_code_block,
                        add_table_data, add_callout)

# 故障码对照表与代码知识库同源的依据
APP_ROOT = r"D:\python项目文件\AI-MA5.3"
sys.path.insert(0, os.path.join(APP_ROOT, "core"))
from diagnostics_logger import ERROR_DIAGNOSTICS_DB   # noqa: E402

DOC_ROOT = os.path.join(APP_ROOT, "docs")
SRC = os.path.join(DOC_ROOT, "AI-MA异构协同与自适应灯光控制系统技术方案.docx")
DST = os.path.join(DOC_ROOT, "AI-MA异构协同与自适应灯光控制系统技术方案_v5.3实装版.docx")


# ===========================================================================
# 通用工具
# ===========================================================================

def iter_all_paragraphs(doc):
    """遍历正文段落 + 所有表格（含嵌套）内的段落"""
    for p in doc.paragraphs:
        yield p
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p
                for nt in cell.tables:
                    for nrow in nt.rows:
                        for ncell in nrow.cells:
                            for p in ncell.paragraphs:
                                yield p


def replace_text(doc, old, new, counter=None):
    """段落级替换；优先逐 run 替换以完整保留格式，跨 run 时退化为整段重写"""
    if counter is None:
        counter = {}
    n = 0
    for p in iter_all_paragraphs(doc):
        full = "".join(r.text for r in p.runs)
        if old not in full:
            continue
        hit = False
        for r in p.runs:
            if old in r.text:
                r.text = r.text.replace(old, new)
                hit = True
        if not hit:
            if p.runs:
                p.runs[0].text = full.replace(old, new)
                for r in p.runs[1:]:
                    r.text = ""
            else:
                p.text = full.replace(old, new)
        n += 1
    if n:
        counter[old] = counter.get(old, 0) + n
    return n


def body_children(el):
    return [c for c in el.iterchildren() if c.tag in (qn("w:p"), qn("w:tbl"))]


def element_text(el):
    return "".join(t.text or "" for t in el.iter(qn("w:t"))).strip()


def find_paragraph(doc, predicate):
    """按谓词找首个匹配的段落元素，返回 (索引, 元素, 文本)"""
    for i, el in enumerate(body_children(doc.element.body)):
        if el.tag == qn("w:p"):
            t = element_text(el)
            if predicate(t):
                return i, el, t
    return None, None, None


def splice_before(doc, anchor_text, frag):
    """把 frag 文档的全部内容插入到 anchor_text 段落之前"""
    _, anchor, txt = find_paragraph(doc, lambda t: t.strip() == anchor_text.strip())
    if anchor is None:
        return False, f"未找到锚点: {anchor_text}"
    n = 0
    for el in body_children(frag.element.body):
        anchor.addprevious(el)
        n += 1
    return True, f"已插入 {n} 个元素"


def append_frag(doc, frag):
    """把 frag 文档的全部内容追加到文末"""
    body = doc.element.body
    n = 0
    for el in body_children(frag.element.body):
        body.append(el)
        n += 1
    return n


def remap_heading_styles(doc):
    """
    修复标题样式 ID 不匹配。

    本主文档由第三方工具生成，标题样式用的是「数字 ID」（Heading 2 的 styleId 是 "2"），
    而 python-docx 默认模板用的是 "Heading1"/"Heading2"/"Heading3"。
    从临时文档搬运过来的新章节因此无法解析样式，全部退化为 Normal。
    这里先把本文档原生的标题样式 ID 探测出来，再把新段落上的默认 ID 重映射过去。
    """
    # 1. 从既有段落中探测本文档原生标题样式 ID
    native = {}
    for p in doc.paragraphs:
        try:
            name = p.style.name
        except Exception:
            continue
        if name in ("Heading 1", "Heading 2", "Heading 3", "Heading 4", "Title"):
            pPr = p._p.find(qn("w:pPr"))
            if pPr is None:
                continue
            st = pPr.find(qn("w:pStyle"))
            if st is not None:
                native.setdefault(name, st.get(qn("w:val")))
    default_map = {"Heading1": "Heading 1", "Heading2": "Heading 2",
                   "Heading3": "Heading 3", "Heading4": "Heading 4",
                   "Title": "Title"}
    remap = {}
    for default_id, name in default_map.items():
        if name in native and native[name] != default_id:
            remap[default_id] = native[name]

    if not remap:
        return 0, "无需重映射", native

    # 2. 全文档重映射
    n = 0
    for p in doc.paragraphs:
        pPr = p._p.find(qn("w:pPr"))
        if pPr is None:
            continue
        st = pPr.find(qn("w:pStyle"))
        if st is None:
            continue
        val = st.get(qn("w:val"))
        if val in remap:
            st.set(qn("w:val"), remap[val])
            n += 1
    return n, f"重映射 {remap}", native


# ---------------------------------------------------------------------------
# 表格直接改写（python-docx 的段落级替换无法命中表格单元格）
# ---------------------------------------------------------------------------

def find_table_after(doc, heading_prefix, stop_prefix="第十五章"):
    """定位某个标题之后的第一个表格元素"""
    body = doc.element.body
    kids = [c for c in body.iterchildren() if c.tag in (qn("w:p"), qn("w:tbl"))]
    idx = None
    for i, el in enumerate(kids):
        if el.tag == qn("w:p") and element_text(el).startswith(heading_prefix):
            idx = i
            break
    if idx is None:
        return None
    for el in kids[idx + 1:]:
        if el.tag == qn("w:tbl"):
            return el
        if el.tag == qn("w:p") and element_text(el).startswith(stop_prefix):
            break
    return None


def set_cell_text(cell, text):
    """写入单元格文本，保留首个 run 的字体格式，清掉多余段落"""
    ps = cell.paragraphs
    if not ps:
        cell.text = text
        return
    p = ps[0]
    if p.runs:
        p.runs[0].text = text
        for r in p.runs[1:]:
            r.text = ""
    else:
        p.add_run(text)
    for extra in ps[1:]:
        extra._p.getparent().remove(extra._p)


def rebuild_fault_code_table(doc):
    """
    用 core/diagnostics_logger.py 的 ERROR_DIAGNOSTICS_DB 重建 14.3 故障码对照表。

    这样做的意义：文档里的故障码表与代码知识库**同源**，再也不会出现
    「代码登记了 14 个码、文档只写 5 个」的脱节。
    克隆首个数据行作为模板，可完整保留原有边框与底纹。
    """
    import copy
    from docx.table import Table

    tbl = find_table_after(doc, "14.3")
    if tbl is None:
        return False, "未找到 14.3 之后的表格"
    table = Table(tbl, doc)
    if len(table.rows) < 2:
        return False, f"表格行数异常: {len(table.rows)}"

    template = copy.deepcopy(table.rows[1]._tr)   # 模板行，保留格式
    for r in list(table.rows)[1:]:
        r._tr.getparent().remove(r._tr)

    for code, info in ERROR_DIAGNOSTICS_DB.items():
        new_tr = copy.deepcopy(template)
        tbl.append(new_tr)
        row = table.rows[-1]
        vals = [code, info.get("title", ""), info.get("cause", ""),
                info.get("solution", "")]
        for i, cell in enumerate(row.cells):
            if i < len(vals):
                set_cell_text(cell, vals[i])

    total = len(table.rows) - 1
    return True, f"已从知识库生成 {total} 行故障码（与代码同源）"


# ===========================================================================
# 内容构造
# ===========================================================================

def frag_architecture():
    """2.4 v5.3 软件架构总览（插入到「三、核心技术模块详解」之前）"""
    d = Document()
    add_h2(d, "2.4 v5.3 软件架构总览：双进程混合硬实时微内核")
    add_callout(d,
        "【视角说明】2.1 节描述的是「感知层 / 决策层 / 执行层」的系统拓扑视角，"
        "回答信号从哪来、到哪去。本节补充的是 v5.3 新增的「软件运行架构视角」，"
        "回答实时性由谁保证、进程边界在哪、内存如何共享。两套视角并存，不可互相替代。",
        fill="EFF6FF", border="1D4ED8", color=(29, 78, 216))
    add_p(d, "v5.3 把实时性责任从 Python 层彻底剥离，交给一个独立的 Rust 硬实时微内核进程，"
             "形成「业务非实时 + 控制硬实时」的双进程混合架构。两个进程之间不通过 Socket、"
             "HTTP 或消息队列通信，而是通过 Linux /dev/shm 零拷贝共享内存直连，"
             "单次业务帧写入耗时约 0.57 微秒。")
    add_table_data(d,
        ["进程", "实现语言", "职责边界", "实时性要求", "崩溃影响"],
        [
            ["aima-rt-daemon（硬实时微内核）", "Rust 2021",
             "44Hz 精准调度、四级仲裁、O(1) 安全钳位、sendmmsg 批量推流、SPSC 遥测写入",
             "硬实时：SCHED_FIFO 优先级 98、绑定 CPU Core 3、mlockall 内存锁定、抖动小于 100 微秒",
             "致命：物理输出中断。由 systemd 与 Python 看门狗双重守护自动拉起"],
            ["control_station.py（业务与意图层）", "Python 3.12",
             "Web 控制台、大模型意图解析、RAG 知识库、场景编排、插件宿主、鉴权、容灾备份",
             "非实时：允许百毫秒级波动，尽力而为",
             "可容忍：微内核继续以最后已知状态推流，演出不黑场"],
        ])

    add_h3(d, "2.4.1 零拷贝共享内存槽位划分与仲裁顺序")
    add_p(d, "共享内存按职责拆分为 5 个物理独立的文件，实现权限与故障的物理隔离。"
             "任意一个槽位损坏或被异常写入，都不会污染其它层级。")
    add_table_data(d,
        ["共享内存文件", "用途", "写入方", "读取方", "故障隔离意义"],
        [
            ["/dev/shm/aima_slot_l1", "安全层：急停、黑场、物理熔断", "Python 业务层", "实时微内核",
             "最高优先级；即使其它层全部异常，L1 仍可强制归零"],
            ["/dev/shm/aima_slot_l2", "设备基础层：静态预设、灯库底态", "Python 业务层", "实时微内核",
             "基础呈现层，被上层覆盖但不影响上层"],
            ["/dev/shm/aima_slot_l3", "创意层：宏插件、特效、音频节拍", "插件宿主", "实时微内核",
             "3 类插件只被授予 L3 写权限，物理上无法越界篡改 L1"],
            ["/dev/shm/aima_slot_l4", "台面层：控台接管、Crossfade 淡变", "Python 业务层", "实时微内核",
             "灯光师实体操作通道，独立于 AI 生成内容"],
            ["/dev/shm/aima_core_state", "微内核全局只读状态：合成帧 + 8MB 安全查找表",
             "实时微内核（独占）", "Python 业务层（只读）",
             "单向只读，业务层无法反向污染内核状态"],
        ])
    add_p(d, "四级仲裁在微内核内部以固定顺序执行，不可逆、不可配置："
             "L1（安全）大于 L4（台面）大于 L3（创意）大于 L2（设备基础）。"
             "高优先级层一旦在某通道置位，立即在本帧内硬性压制低优先级层，无需等待下一帧。")

    add_h3(d, "2.4.2 为什么必须拆成两个进程")
    add_table_data(d,
        ["单进程 Python 方案（v5.0）的固有问题", "v5.3 双进程方案的解决方式"],
        [
            ["Python GIL 与垃圾回收引入不可预测停顿，抖动可达数十毫秒",
             "实时循环运行在无 GC 的 Rust 进程中，抖动压缩到 100 微秒以内"],
            ["Web 请求、大模型推理、文件 IO 与灯光推流共享同一进程，互相抢占",
             "物理隔离：Web 与大模型的任何卡顿都无法影响 44Hz 推流"],
            ["插件异常可直接击穿主循环，导致全场黑场",
             "插件运行在业务进程中，微内核持续以最后有效帧推流，故障不传导"],
            ["30Hz 时基受操作系统时间片调度影响，无法保证恒定时基",
             "PREEMPT_RT + isolcpus + nohz_full + SCHED_FIFO，时基由内核调度器保证"],
        ])
    return d


def frag_ch16():
    """第十六章：硬实时微内核实装与跨语言 ABI 契约"""
    d = Document()
    add_h1(d, "第十六章：v5.3 硬实时微内核实装与跨语言 ABI 契约")
    add_p(d, "本章描述 v5.3 已实装的硬实时微内核的工程真相。所有结构体定义以 "
             "include/aima_shm.h 为准，任何实现不得偏离。早期规划文档中的定义已过时，"
             "差异之处本章均已标注。")

    add_h2(d, "16.1 微内核进程与实时调度实装")
    add_table_data(d,
        ["实装项", "具体参数", "源代码位置"],
        [
            ["主循环频率", "44Hz（周期 22.7ms），nano-sleep 补齐 + 自适应补偿", "aima-rt-daemon/src/main.rs"],
            ["时钟源", "CLOCK_MONOTONIC 纳秒时钟，绝对时间点调度避免累积漂移", "aima-rt-daemon/src/main.rs"],
            ["CPU 绑定", "CPUAffinity=3（需配合 GRUB isolcpus/nohz_full 才能真正独占）", "aima-rt.service"],
            ["实时调度", "SCHED_FIFO 优先级 98，Nice=-20，IOSchedulingClass=realtime", "aima-rt.service"],
            ["内存锁定", "mlockall(MCL_CURRENT | MCL_FUTURE)，LimitMEMLOCK=infinity", "aima-rt-daemon/src/main.rs"],
            ["四级仲裁", "L1 安全 > L4 台面 > L3 创意 > L2 设备基础，帧内即时压制", "aima-rt-daemon/src/arbitrator.rs"],
            ["安全钳位", "safety_lut[64][512][256] 预展开查找表，O(1) 零分支，约 8MB", "aima-rt-daemon/src/arbitrator.rs"],
            ["批量推流", "sendmmsg() 一次系统调用提交多个 mmsghdr，含微突发流量整形", "aima-rt-daemon/src/batch_network.rs"],
            ["遥测写入", "SPSC 无锁环，仅微内核实时主线程独占写入", "aima-rt-daemon/src/main.rs"],
        ])

    add_h2(d, "16.2 共享内存 ABI 契约（以 include/aima_shm.h 为准）")
    add_callout(d,
        "【ABI 兼容性警告】早期 v5.3 规划文档中的 aima_channel_safety_rule_t 只有单个 "
        "danger_min/danger_max 区间，且完全未定义遥测事件结构体。实装版本已演进为 "
        "「最多 4 组不连续危险区间」+「128 字节对齐的四维遥测事件」+「缓存行对齐原子包装器」。"
        "照旧文档编写代码将与已实装内核 ABI 不兼容，务必以下方实装定义为准。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))
    add_code_block(d, """
#pragma once
#include <stdint.h>
#include <stdalign.h>
#include <stdbool.h>

#define AIMA_MAX_UNIVERSES       64
#define AIMA_DMX_CHANNELS        512
#define AIMA_TELEMETRY_CAPACITY  4096

/* 64 字节缓存行对齐原子包装器（消除多核伪共享 False Sharing） */
typedef struct { alignas(64) volatile uint32_t val; } aima_cache_aligned_u32_t;
typedef struct { alignas(64) volatile uint8_t  val; } aima_cache_aligned_u8_t;

/* 1. 物理安全规则：单通道最多 4 组不连续危险区间（如灭泡 20~29、复位 80~99） */
typedef struct { uint8_t min_val; uint8_t max_val; } aima_danger_range_t;

typedef struct {
    uint8_t enabled;            /* 0=普通直通, 1=启用危险区间硬件防护 */
    uint8_t safe_fallback_val;  /* 命中危险区间时的安全替代值（默认 0） */
    uint8_t range_count;        /* 当前生效区间数 (0~4) */
    uint8_t reserved;           /* 4 字节对齐填充 */
    aima_danger_range_t danger_ranges[4];
} aima_channel_safety_rule_t;

/* 2. 按层级物理独立的共享内存槽位 (/dev/shm/aima_slot_l1 ~ l4) */
typedef struct {
    aima_cache_aligned_u32_t write_seq;            /* 顺序锁：偶数稳定可读，奇数写入中 */
    aima_cache_aligned_u8_t  active_buf_idx;       /* 当前可读双缓冲索引 (0 或 1) */
    volatile uint64_t        frame_index;          /* 绝对递增帧序号 */
    volatile uint64_t        update_timestamp_ns;  /* 纳秒时间戳 (CLOCK_MONOTONIC) */
    uint8_t dmx_buffers[2][AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];   /* 双缓冲 DMX 阵列 */
    uint8_t active_mask[2][AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];   /* 通道覆盖激活掩码 */
} aima_layer_shm_slot_t;

/* 3. 微内核全局只读状态 + O(1) 无分支安全钳位查找表 (/dev/shm/aima_core_state) */
typedef struct {
    aima_cache_aligned_u32_t state_seq;
    volatile uint64_t        rt_frame_index;
    volatile uint64_t        rt_timestamp_ns;
    volatile uint32_t        last_jitter_ns;         /* 上一帧实测抖动纳秒数 */
    volatile uint32_t        active_universe_count;
    uint8_t final_merged[AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];     /* 最终合成输出帧 */
    uint8_t safety_lut[AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS][256];  /* O(1) 安全钳位查表 */
} aima_core_state_shm_t;

/* 4. 四维遥测事件结构体（定长，128 字节对齐） */
typedef struct alignas(128) {
    uint64_t timestamp_ns;
    uint8_t  tier;        /* 0=Kernel, 1=System, 2=Adapter, 3=Community */
    uint8_t  level;       /* 1=INFO, 2=WARN, 3=ERROR, 4=FATAL */
    uint16_t category;
    uint32_t source_id;
    uint32_t latency_ns;
    uint8_t  message[108];
} aima_telemetry_entry_t;

/* 5. 实时微内核独占 SPSC 遥测无锁环形队列 (/dev/shm/aima_telemetry_rt) */
typedef struct alignas(128) {
    aima_cache_aligned_u32_t head;   /* 实时微内核独占写入 (SPSC) */
    aima_cache_aligned_u32_t tail;   /* 遥测守护线程独占读取 */
    uint32_t                 capacity;
    alignas(128) aima_telemetry_entry_t entries[AIMA_TELEMETRY_CAPACITY];
} aima_telemetry_ring_t;
""", size=7.5)

    add_h2(d, "16.3 顺序锁（Seqlock）读写协议")
    add_p(d, "所有槽位读写必须严格遵守顺序锁协议，否则会出现撕裂读——读到写者改到一半的半个帧，"
             "在舞台上表现为灯光随机闪烁。这是本系统最容易被误实现的一处，"
             "请勿自行简化。")
    add_code_block(d, """
// 写入方（Python 业务层）：写前自增为奇数，写后自增为偶数
write_seq += 1;                       // 变为奇数：标记「写入中」
atomic_thread_fence(RELEASE);
memcpy(slot->dmx_buffers[buf], frame, sizeof(frame));
atomic_thread_fence(RELEASE);
write_seq += 1;                       // 变为偶数：标记「稳定可读」

// 读取方（Rust 微内核）：序列号稳定且前后一致才采用
uint32_t s1, s2;
do {
    s1 = read_seq;
    if (s1 & 1u) continue;            // 奇数：正在写入，立即重试
    atomic_thread_fence(ACQUIRE);
    memcpy(frame, slot->dmx_buffers[buf], sizeof(frame));
    atomic_thread_fence(ACQUIRE);
    s2 = read_seq;
} while (s1 != s2);                   // 序列号变化：读取期间被改写，重试
""", size=7.5)

    add_h2(d, "16.4 PyO3 零拷贝 Python SDK（aima_shm_sdk）")
    add_table_data(d,
        ["实装项", "具体内容"],
        [
            ["crate 名称", "crates/aima-shm-sdk，包版本 5.3.0，crate-type = [cdylib]"],
            ["PyO3 配置", "pyo3 0.23.5，features = [extension-module, abi3-py310]"],
            ["ABI 策略", "启用 abi3-py310 稳定 ABI：单个 .so/.pyd 可被 Python 3.10 及以上所有版本加载，"
                        "无需为每个 Python 小版本重新编译"],
            ["Windows 产物", "aima_shm_sdk.dll 改名为 aima_shm_sdk.pyd，同时放置于发布包根目录与 core/"],
            ["Linux 产物", "libaima_shm_sdk.so，放置规则同上"],
            ["Python 侧封装", "core/kernel_bridge.py 中的 AimaKernelBridge 类"
                            "（强依赖 numpy，numpy 缺失时控制台无法启动）"],
            ["对外关键方法", "get_rt_metrics() 返回 (frame_index, timestamp_ns, jitter_ns)；"
                          "以及各层零拷贝读写接口"],
        ])

    add_h2(d, "16.5 运行期内核看门狗（Python 侧守护）")
    add_p(d, "v5.0 只在启动时做一次健康检查，微内核中途死亡时控制台毫无察觉——"
             "这是真实发生过的演出事故。v5.3 增加了常驻看门狗线程，覆盖三种状态：")
    add_table_data(d,
        ["场景", "判定条件", "系统动作", "故障码"],
        [
            ["A. 内核死亡", "探测不到微内核进程", "记录故障并按预算尝试重启", "ERR-KERNEL-DAEMON"],
            ["B. 内核停摆", "进程存活但帧计数连续 N 次不推进", "杀掉僵死进程并按预算重启", "ERR-KERNEL-STALL"],
            ["C. 恢复正常", "帧计数重新推进", "重置重启预算，回到监控态", "无告警，仅 INFO 记录"],
        ])
    add_p(d, "看门狗参数全部支持环境变量覆盖，便于现场调优与自动化测试：")
    add_table_data(d,
        ["环境变量", "默认值", "含义"],
        [
            ["AIMA_WATCHDOG_INTERVAL_SEC", "5.0", "探测间隔（秒）"],
            ["AIMA_WATCHDOG_MAX_RESTART", "5", "最大自动重启次数，超出后停止重启并持续告警"],
            ["AIMA_WATCHDOG_STALL_LIMIT", "3", "连续多少次探测帧计数不推进即判定停摆"],
            ["AIMA_RT_EXTERNAL", "未设置", "设为 1 表示微内核由 systemd 托管，"
                                          "Python 层既不主动拉起也不重启"],
        ])
    return d


def frag_ch17():
    """第十七章：三层插件物理隔离体系与全链路可观测性"""
    d = Document()
    add_h1(d, "第十七章：三层插件物理隔离体系与全链路可观测性")
    add_p(d, "v5.3 的插件体系不再是平铺的一堆插件，而是按「谁能看见、谁能卸载、"
             "出错后果多严重」划分为三个物理隔离的层级。本章同时说明一个容易被忽略的设计原则："
             "用户界面隐匿不等于运维不可见。")

    add_h2(d, "17.1 三层插件物理隔离矩阵")
    add_table_data(d,
        ["层级", "基类", "源码目录", "装载时机", "用户可见", "可否卸载", "失效后果"],
        [
            ["1 类·系统级", "BaseProtocolPlugin / BaseLLMPlugin", "plugins/system/", "随内核启动，全静默",
             "否，界面与已装载接口均隐匿", "禁止", "致命：1 类协议缺失则无任何物理输出"],
            ["2 类·适配级", "BaseAdapterPlugin", "plugins/adapters/", "随系统启动",
             "否", "禁止", "严重：无法导入外部控台灯库资产"],
            ["3 类·表现创意", "BaseMacroPlugin / BasePerceptionPlugin", "plugins/community/", "按需加载",
             "是，插件市场唯一展示分类", "支持热卸载", "轻微：仅该插件特效失效"],
        ])
    add_callout(d,
        "【设计红线】只有 3 类插件允许出现在用户界面与 /api/plugins/installed 接口中。"
        "1/2 类是系统底座，普通用户误卸载会导致系统丧失核心能力，因此必须在接口层完成过滤，"
        "而不能只靠前端隐藏——前端隐藏随时可能被绕过，接口过滤才是物理边界。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))

    add_h3(d, "17.1.1 实装插件全量清单（以代码为准，共 9 个）")
    add_p(d, "下表是 v5.3 实装并随内核启动的插件全量清单。记载的是插件在 get_info() 中声明的 "
             "id 与源码文件名——两者并不相同，排查问题时务必用 id 检索日志，"
             "用文件名定位源码。")
    add_table_data(d,
        ["层级", "插件 id（用于日志检索）", "源码文件", "职责"],
        [
            ["1 类", "protocol_artnet_standard", "plugins/system/artnet_plugin.py",
             "Art-Net 3/4 工业标准协议驱动，系统默认物理输出通道"],
            ["1 类", "protocol_sacn_standard", "plugins/system/sacn_plugin.py",
             "sACN E1.31 协议驱动"],
            ["1 类", "llm_local_qwen_7b", "plugins/system/qwen_plugin.py",
             "Local Qwen 2.5-7B 端侧模型适配器"],
            ["1 类", "system_log_ai_repair", "plugins/system/system_log_ai_repair_plugin.py",
             "系统日志 AI 自愈（对应 13.9 模板 5）"],
            ["2 类", "adapter_ma_fixture", "plugins/adapters/ma_fixture_adapter.py",
             "GrandMA2 XML / MA3 GDTF 灯库资产适配器"],
            ["3 类", "macro_breathing", "plugins/community/breathing_plugin.py",
             "呼吸律动特效（用户可见）"],
            ["3 类", "macro_marquee", "plugins/community/marquee_plugin.py",
             "矩阵走马灯特效（用户可见）"],
            ["3 类", "perception_audio_beat_sim", "plugins/community/perception_audio_beat_sim.py",
             "音频节拍与 BPM 提取（用户可见）"],
            ["3 类", "show_evolution_learning", "plugins/community/show_evolution_learning_plugin.py",
             "演后复盘与自适应演进学习（用户可见，对应 13.10 模板 6）"],
        ])
    add_callout(d,
        "【排查提示】启动日志的「插件生态装载总览」按层级分组打印，"
        "每行格式为「插件 id  中文名称  [启停状态]」。"
        "若某个 id 没出现在总览里，说明它在模块导入、类发现或合规校验阶段就被拒收了，"
        "请在总览末尾的失败明细中按 id 查找具体原因，或调用 "
        "GET /api/plugins/diagnostics 获取结构化失败记录。",
        fill="EFF6FF", border="1D4ED8", color=(29, 78, 216))

    add_h2(d, "17.2 抽象方法契约（开发者必须逐条核对）")
    add_p(d, "下面这张表是插件开发的硬性契约。遗漏任何一个抽象方法，Python 会在加载时把该类"
             "判定为抽象类，插件将在「类发现」阶段被拒收。v5.3 已把这条路径改为显式登记"
             "（见 17.3），但仍应尽量避免。特别注意：早期文档中的 on_destroy()、"
             "start_listening() 并非实际抽象方法，实际契约如下表。")
    add_table_data(d,
        ["基类", "适用层级", "必须实现的抽象方法"],
        [
            ["BasePlugin", "所有插件的根", "get_info() · on_init(context) · on_enable() · on_disable()"],
            ["BaseProtocolPlugin", "1 类", "BasePlugin 四项 + send_universe(universe, dmx_data_512)"],
            ["BaseLLMPlugin", "1 类", "BasePlugin 四项 + chat_completion(...)"],
            ["BaseAdapterPlugin", "2 类", "BasePlugin 四项 + supported_extensions() · convert_to_profile(...)"],
            ["BaseMacroPlugin", "3 类", "BasePlugin 四项 + render(...)"],
            ["BasePerceptionPlugin", "3 类", "BasePlugin 四项 + get_status()"],
        ])
    add_p(d, "另需通过 PluginValidator 校验：get_info() 必须含 id、name、version、author、type、"
             "description 六个字段；id 必须匹配 ^[a-z0-9_]{3,40}$（注意长度上限是 40 而非早期文档"
             "所写的 32）；get_config_schema() 的每个字段必须含 type 与 label。")

    add_h2(d, "17.3 插件装载可观测性（1/2 类必须在日志中可见）")
    add_p(d, "界面隐匿之后曾出现一个严重问题：1/2 类插件究竟加载成功还是失败，日志里无从判断——"
             "因为原实现对所有插件输出完全相同的日志行，不含任何层级标识。更严重的是，"
             "「源文件中没有可实例化插件类」这条路径是完全静默的，插件会被彻底漏掉且查无实据。"
             "对系统底座而言这是致命的，v5.3 已修复。")
    add_p(d, "现在的启动日志会输出分层装载总览：")
    add_code_block(d, """
======================= 插件生态装载总览 =======================
 【1类·系统级】 已装载 4/4  [OK]
      - protocol_artnet_standard    Art-Net 3/4 工业标准协议驱动     [已启用]
      - protocol_sacn_standard      sACN E1.31 协议驱动              [已启用]
      - llm_local_qwen_7b           Local Qwen 2.5-7B 端侧模型适配器 [已启用]
      - system_log_ai_repair        系统日志 AI 自愈                 [已启用]
 【2类·适配级】 已装载 1/1  [OK]
      - adapter_ma_fixture          GrandMA2/MA3 灯库资产适配器      [已启用]
 【3类·表现创意】 已装载 4/4  [OK]
      - ...
----------------------------------------------------------------
 合计: 扫描 9 个源文件 | 装载成功 9 个 | 失败 0 个
==============================================================
""")
    add_table_data(d,
        ["失败阶段", "触发条件", "告警级别"],
        [
            ["模块导入", "语法错误、缺依赖、导入期抛异常",
             "1/2 类走 ERR-PLUGIN-FOUNDATION（ERROR 并触发 CRITICAL 总告警），3 类为普通错误"],
            ["类发现", "文件中没有可实例化的插件类（原静默盲区，已修补）", "同上"],
            ["合规校验", "ID 格式、get_info 字段或 schema 不合规", "同上"],
            ["on_init()", "插件自身初始化返回 False", "同上"],
        ])
    add_p(d, "运维查证通道（需 admin / superadmin 角色）：GET /api/plugins/diagnostics 返回三层"
             "全量结构化状态，含每层的 ID、名称、启停、是否受保护，以及 foundation_healthy 标志"
             "与结构化失败明细（插件 ID、文件、失败阶段、原因）。用户界面保持干净，运维掌握全部三层。")

    add_h2(d, "17.4 鉴权噪音抑制（记录失败与升级为告警必须分开）")
    add_p(d, "曾出现一次正常注销产生数十条 ERROR 级告警的情况：前端有 5 个轮询定时器，注销后"
             "在途请求陆续收到 401，而每个 401 都被记为 ERR-AUTH-DENIED 故障告警。后果不是噪音，"
             "而是安全性下降——真正的令牌爆破与一次日常注销在告警面板上完全无法区分。"
             "v5.3 改为分级判定：")
    add_table_data(d,
        ["情形", "日志级别", "是否告警"],
        [
            ["未携带会话令牌（未登录或刚注销的页面轮询）", "DEBUG",
             "否（DEBUG 低于持久化级别 INFO，不落盘）"],
            ["携带但已失效的令牌（会话过期、注销竞态）", "INFO", "否"],
            ["10 秒内超过 20 次未授权访问", "ERROR",
             "是，ERR-AUTH-BRUTEFORCE（带 30 秒冷却防止告警自身刷屏）"],
            ["令牌有效但权限不足", "ERROR", "是，ERR-AUTH-DENIED（真实授权事件）"],
        ])
    add_p(d, "配套的前端修复：forceLogout() 增加幂等闩锁，并发 401 不再重复触发注销；"
             "5 个轮询定时器统一经 poll() 登记，注销瞬间由 stopAllPolling() 一次性清除。")

    add_h2(d, "17.5 插件开发红线")
    for i, t in enumerate([
        "禁止在插件内直接写共享内存。插件只能通过宿主提供的接口操作 L3 槽位，任何试图直接 "
        "mmap /dev/shm/aima_slot_l1 的行为都会因文件权限被内核拒绝。",
        "禁止在 render() 或 send_universe() 中做阻塞 IO（网络请求、文件读写、大模型调用）。"
        "这些回调运行在调度路径上，阻塞会直接拖慢整帧。",
        "禁止在插件中抛出让宿主无法捕获的异常。虽然宿主有熔断隔离，"
        "但异常会在插件生态总览中登记为失败项，影响交付验收。",
        "禁止绕过 PluginValidator：id 必须小写、get_info() 六字段必须齐全、"
        "get_config_schema() 每项必须有 type 与 label。",
        "禁止大模型插件自主循环触发。所有大模型插件必须经阈值门禁或人工点击触发，"
        "且输出必须以「待审草稿」形式呈现，由人工二次确认后落地。",
    ], 1):
        add_p(d, f"{i}. {t}")
    return d


def frag_ch18():
    """第十八章：发布流水线与交付 SOP"""
    d = Document()
    add_h1(d, "第十八章：v5.3 发布流水线与交付 SOP")
    add_p(d, "本章描述从源码到可交付生产包的完整流水线，以及实装状态的真实边界。")

    add_h2(d, "18.1 构建流水线总览")
    add_table_data(d,
        ["阶段", "执行位置", "动作", "产物"],
        [
            ["1. 基线校验", "开发机", "validate_build_baseline() 检查核心模块、SDK、内核二进制是否齐备，"
                                  "缺失即 FATAL 退出", "快速失败，不产出残缺包"],
            ["2. 前端构建", "开发机", "web/assets 全量 AST 混淆 + 字符串池加密 + 压缩", "混淆后的 web/ 产物"],
            ["3. 后端组装", "开发机", "复制 core/ 业务模块与主入口", "dist 骨架"],
            ["4. 内核构件", "开发机", "复制 bin/ 微内核二进制与 aima_shm_sdk 扩展"
                                  "（根目录与 core/ 各一份），chmod 0755", "bin/aima-rt-daemon 与 SDK"],
            ["5. 部署脚本", "开发机", "生成 build_debian.sh、aima-rt.service、ai-ma.service", "部署工件"],
            ["6. 完整性校验", "开发机", "verify_release_package() 执行完整性强校验，任一失败即终止",
             "可交付生产包"],
            ["7. Cython 编译", "Debian 服务器", "bash build_debian.sh 第一阶段：核心模块编译为 .so",
             "机器码 .so"],
            ["8. Rust 编译", "Debian 服务器", "bash build_debian.sh 第二阶段：cargo build --release "
                                          "-p aima-rt-daemon -p aima-shm-sdk", "原生 ELF 微内核与 SDK"],
            ["9. 源码抹除", "Debian 服务器", "物理删除已编译成功的 .py 源码，并执行最终完整性门禁",
             "黑盒化生产环境"],
        ])

    add_h2(d, "18.2 发布包目录结构")
    add_code_block(d, """
dist/ai-ma-v5-release/
├── control_station.py          # 业务主入口
├── VERSION                     # 5.3.0 / v5.3 Enterprise LTS (Hybrid Microkernel)
├── RELEASE_MANIFEST.json       # 构件清单与校验摘要
├── aima-rt.service             # 硬实时微内核 systemd 单元
├── ai-ma.service               # 业务控制台 systemd 单元（BindsTo 微内核）
├── build_debian.sh             # Debian 两阶段编译加固脚本（Cython + cargo）
├── bin/
│   └── aima-rt-daemon[.exe]    # 微内核二进制
├── aima_shm_sdk.pyd / .so      # PyO3 abi3 扩展（根目录与 core/ 各一份）
├── core/                       # 业务核心模块（Debian 上编译为 .so 并抹除源码）
├── web/                        # 混淆后的前端资产
├── plugins/                    # 三层插件目录（明文开放）
├── config/                     # 现场配置（明文开放）
└── deploy/                     # 部署工件副本（含两个 .service 与安装脚本）
""", size=7.5)

    add_h2(d, "18.3 核心模块编译清单（以实装为准）")
    add_p(d, "早期文档中的模块清单存在两处错误：artnet_controller.py 实际并不存在"
             "（正确文件名为 artnet_sender.py），且漏列了 kernel_bridge.py。"
             "v5.3 的编译清单已与代码逐一对齐：")
    add_table_data(d,
        ["序号", "模块", "保护目标"],
        [
            ["1", "dmx_merger.py", "四级仲裁状态机与物理安全掩码"],
            ["2", "engine.py", "主循环引擎与 Crossfade 插值器"],
            ["3", "kernel_bridge.py", "微内核零拷贝桥接（实装新增，必须纳入编译）"],
            ["4", "auth_manager.py", "RBAC 鉴权与 root 动态 Key 计算"],
            ["5", "artnet_sender.py", "Art-Net 发送器（原文档误写为 artnet_controller.py）"],
            ["6", "node_discovery.py", "节点发现与掉线看门狗"],
            ["7", "backup_manager.py", "容灾备份与 SHA-256 快照校验"],
            ["8", "marketplace_service.py", "插件市场服务（实装新增，必须纳入编译）"],
        ])

    add_h2(d, "18.4 实装状态对照表（开发分工前必读）")
    add_callout(d,
        "【分工前必须澄清的事实】早期 v5.3 规划文档描述的架构比实装代码更激进。"
        "下表逐项区分「已实装并通过测试」与「规划中、尚未编写」的能力。"
        "请勿把规划项当作既有能力分配开发任务，除非明确将其列为新建任务。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))
    add_table_data(d,
        ["能力项", "实装状态", "证据或说明"],
        [
            ["Rust 44Hz 硬实时微内核", "已实装并运行", "aima-rt-daemon，抖动实测 100 微秒内"],
            ["PyO3 零拷贝共享内存 SDK", "已实装", "aima_shm_sdk，abi3-py310 稳定 ABI"],
            ["四级仲裁 + O(1) 安全钳位", "已实装", "safety_lut[64][512][256]，约 8MB"],
            ["SPSC 遥测无锁环（缓存行隔离）", "已实装", "alignas(64) 独立缓存行，杜绝伪共享"],
            ["sendmmsg() 批量推流 + 微突发整形", "已实装", "batch_network.rs"],
            ["三层插件物理隔离", "已实装", "PluginTier 1/2/3，接口层过滤"],
            ["运行期内核看门狗", "已实装", "三场景判定 + 重启预算"],
            ["双 systemd 单元绑定", "已实装", "aima-rt.service + ai-ma.service（BindsTo）"],
            ["发布包完整性校验", "已实装", "verify_release_package()"],
            ["Debian Cython + cargo 两阶段编译", "脚本已实装", "build_debian.sh 已含 cargo 构建段"],
            ["进程级插件沙箱", "已实装（Rust 进程沙箱）", "aima-worker-sandbox crate"],
            ["SquashFS + dm-verity 只读密封", "未实装", "规划阶段 3"],
            ["A/B 双槽位原子 OTA 与 30 秒回退", "未实装", "规划阶段 3"],
            ["Wasmtime 3.00ms 指令级硬熔断", "未实装", "现为进程级沙箱，非 Wasm 指令级"],
            ["llama.cpp 独立推理服务", "未实装", "现为 Ollama/Qwen 插件适配器形态"],
            ["FastAPI + uvloop 控制台", "未实装", "现为 Python 标准库 http.server"],
            ["Maturin 与 .pyi 类型存根", "未实装", "现为 cargo 直接构建，无 .pyi 存根"],
        ])
    return d


def frag_13_12():
    """13.12 六个插件模板的实装修正清单（插入到第十四章之前）"""
    d = Document()
    add_h2(d, "13.12 六个插件模板的实装修正清单（照抄前必读）")
    add_callout(d,
        "【重要】本章 13.4 至 13.10 的六个模板是 v5.0 时期编写的示范代码，"
        "用于说明「插件长什么样」。它们与 v5.3 实装的抽象方法契约和协议规范存在偏差，"
        "直接照抄会无法装载或产生运行时缺陷。以本节清单为准进行修正。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))

    add_h3(d, "13.12.1 契约类偏差（会导致插件被拒收）")
    add_table_data(d,
        ["模板中的写法", "实装契约要求", "修正方式"],
        [
            ["定义了 on_destroy(self)", "on_destroy() 不是抽象方法",
             "可保留（多余方法不影响装载），但不要以为它是必需的"],
            ["感知模板实现 start_listening()", "BasePerceptionPlugin 要求 get_status()",
             "必须补上 get_status()；start_listening 可作为内部方法保留"],
            ["生命周期只写了 on_init/on_enable", "必须同时实现 on_disable()",
             "补齐 on_disable()，并在其中释放 Socket、停止后台线程"],
            ["LLM 模板实现 generate()", "BaseLLMPlugin 要求 chat_completion(...)",
             "必须补上 chat_completion()（generate 可作为内部方法）"],
            ["id 中含大写或超过 40 字符", "必须匹配 ^[a-z0-9_]{3,40}$",
             "统一改为纯小写字母、数字、下划线，长度 3 至 40"],
        ])

    add_h3(d, "13.12.2 协议类缺陷（会导致现场丢包或解码器异常）")
    add_p(d, "13.4 的 sACN / E1.31 模板存在三处协议实现缺陷，"
             "实装时必须修正，否则与标准解码器互通时会出现随机闪灯：")
    add_table_data(d,
        ["缺陷", "模板中的错误写法", "正确做法"],
        [
            ["序列号恒定", "Sequence 字段恒为 0",
             "必须逐帧递增，使解码器能识别重复包与乱序包"],
            ["属性计数越界", "DMP property count 用 len(dmx_data)+1，却只发送 dmx_data[:512]",
             "property count 必须固定为 512，与实际发送字节数一致"],
            ["优先级未限幅", "priority 直接取配置值",
             "必须 clamp 到 0 至 200 的合法区间，越界值会被解码器拒绝"],
        ])

    add_h3(d, "13.12.3 线程与资源缺陷")
    add_table_data(d,
        ["问题", "风险", "修正方式"],
        [
            ["后台线程未设为 daemon 或未在 on_disable 中 join",
             "插件热卸载后线程仍存活，反复装卸会累积线程并最终耗尽资源",
             "线程设为 daemon=True，并在 on_disable() 中 join(timeout=1.0)"],
            ["Socket 在 on_enable() 中创建但未在 on_disable() 中关闭",
             "端口占用导致插件无法重新启用", "在 on_disable() 中 close() 并置为 None"],
            ["模板中直接使用 self.context.backup_mgr",
             "CoreContext 实际只提供 event_bus / dmx_merger / kb / config，该属性不存在",
             "改为通过 context 提供的服务字典获取，或在插件内自行实例化 BackupManager"],
        ])

    add_h3(d, "13.12.4 新增插件时的自检清单")
    for i, t in enumerate([
        "所选基类的全部抽象方法是否都已实现（对照 13.3 节第 7 条）？",
        "get_info() 的六个字段是否齐全，id 是否为纯小写且长度合规？",
        "get_config_schema() 的每一项是否都有 type 与 label？",
        "on_disable() 是否释放了全部 Socket、线程与内存？",
        "插件所属层级是否正确（1 类 system / 2 类 adapters / 3 类 community）？"
        "层级放错会导致插件出现在用户界面或无法被市场安装。",
        "装载后是否在日志的插件生态总览中看到「[层级标签] 插件 [名称] 装载成功」？"
        "没看到就说明被拒收了，请查看总览中的失败明细。",
    ], 1):
        add_p(d, f"{i}. {t}")
    return d


# ===========================================================================
# 主流程
# ===========================================================================
def fix_chapter_order(doc):
    """把错序到第十四章之后的 13.9 / 13.10 / 13.11 移回第十四章之前"""
    body = doc.element.body
    children = list(body)
    i_139 = i_14 = i_15 = None
    for i, el in enumerate(children):
        if el.tag != qn("w:p"):
            continue
        t = element_text(el)
        if i_139 is None and t.startswith("13.9 【AI 生产模板 5】"):
            i_139 = i
        if i_14 is None and t.startswith("第十四章"):
            i_14 = i
        if i_15 is None and t.startswith("第十五章"):
            i_15 = i
    if None in (i_139, i_14, i_15):
        return False, f"定位失败 13.9={i_139} 14章={i_14} 15章={i_15}"
    if i_139 < i_14:
        return False, "13.9 已在第十四章之前，无需移动"
    block = children[i_139:i_15]
    ref = children[i_14]
    for el in block:
        body.remove(el)
    # 逐个插入到 ref 之前；由于每次都插在 ref 前，顺序自然保持
    for el in block:
        ref.addprevious(el)
    return True, f"已移动 {len(block)} 个元素到第十四章之前"


def main():
    if not os.path.exists(SRC):
        raise SystemExit(f"[FATAL] 找不到主文档: {SRC}")
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copy2(SRC, DST)
    print(f"[1] 复制 -> {os.path.basename(DST)}")

    doc = Document(DST)
    print(f"    原件: 段落 {len(doc.paragraphs)} | 表格 {len(doc.tables)}")

    ok, msg = fix_chapter_order(doc)
    print(f"[2] 章节错序修复: {'成功，' + msg if ok else '跳过，' + msg}")

    # ---------------- 全局口径替换 ----------------
    counter = {}
    for old, new in [
        ("30Hz 恒定时基", "44Hz 硬实时微内核时基"),
        ("30Hz 物理循环", "44Hz 微内核物理循环"),
        ("30Hz 物理输出主线程", "44Hz 微内核实时主线程"),
        ("30Hz 发送循环", "44Hz 微内核发送循环"),
        ("30Hz 高精度定时器", "44Hz 硬实时微内核定时器"),
        ("30Hz 连续满负载运行", "44Hz 连续满负载运行"),
        ("30Hz 物理渲染回调", "44Hz 微内核渲染回调"),
        ("30Hz", "44Hz"),
        ("33.3ms", "22.7ms"),
        ("artnet_controller.py", "artnet_sender.py"),
        ("artnet_controller", "artnet_sender"),
        ("/opt/ai_lighting_system", "/opt/ai-ma"),
        ("AI-MA OS v5.0", "AI-MA OS v5.3"),
        ("AI-MA Adaptive Lighting Operating System v5.0",
         "AI-MA Adaptive Lighting Operating System v5.3"),
    ]:
        replace_text(doc, old, new, counter)
    print("[3] 全局口径替换:")
    for k, v in sorted(counter.items(), key=lambda x: -x[1]):
        print(f"      {v:>3} 处  {k}")

    # ---------------- 定点重写 ----------------
    REWRITES = [
        ("12.2 30Hz 恒定时基物理发送主循环与毫秒级 Crossfade 线性插值器",
         "12.2 44Hz 硬实时微内核时基物理发送主循环与毫秒级 Crossfade 线性插值器"),
        ("剧场人眼对频闪与色彩突变的敏感阈值为 25-30ms。为杜绝舞台灯光画面跳变（Snap），"
         "系统底层设计了纳秒级高精度物理发送时基循环与多 Universe 并行 Crossfade 淡变线性插值引擎。",
         "剧场人眼对频闪与色彩突变的敏感阈值为 25-30ms。为杜绝舞台灯光画面跳变（Snap），"
         "v5.3 把物理发送时基下沉到 Rust 硬实时微内核，由内核调度器提供恒定 22.7ms（44Hz）时基；"
         "Crossfade 淡变插值仍在 Python 业务层演算后写入 L4 槽位，两层职责彻底分离。"),
        ("1. 恒定 22.7ms 时基防抖动算法：采用 time.perf_counter() 高精度单调时钟计算每帧演算开销，"
         "并动态计算差值补偿自适应休眠（Adaptive Sleep），彻底消除了 Python 在 Windows/Linux "
         "系统下的时间片调度抖动。",
         "1. 恒定 22.7ms 时基保障：微内核使用 CLOCK_MONOTONIC 纳秒时钟驱动 44Hz 主循环，"
         "配合 SCHED_FIFO 优先级 98、CPU Core 3 物理隔离与 mlockall() 内存锁定，"
         "实测抖动稳定在 100 微秒以内。Python 层不再参与任何时基计算，"
         "业务侧任何卡顿都不会改变推流节奏。"),
        ("2. 并发 Crossfade 插值算法：支持每个 Universe 独立的毫秒级平滑淡变。",
         "2. 并发 Crossfade 插值算法（Python 业务层）：支持每个 Universe 独立的毫秒级平滑淡变。"),
        ("13.3 插件合规验证器（PluginValidator 八大审查准则）",
         "13.3 插件合规验证器（PluginValidator 审查准则 · 已与实装代码逐条核对）"),
        ("为确保进入市场的插件绝对安全稳定，系统在加载前执行八项严苛的自动化合规审查：",
         "为确保进入市场的插件绝对安全稳定，系统在加载前执行以下自动化合规审查。"
         "本节内容已与 core/plugin_sdk.py 与 core/plugin_host.py 的实装代码逐条核对一致，"
         "开发者可将其作为唯一权威依据。"),
        ("1. 基类继承合法性：必须且仅能继承自 BaseProtocolPlugin / BaseMacroPlugin / "
         "BasePerceptionPlugin / BaseLLMPlugin 之一。",
         "1. 基类继承合法性：必须继承自 BaseProtocolPlugin / BaseMacroPlugin / BasePerceptionPlugin / "
         "BaseLLMPlugin / BaseAdapterPlugin（2 类适配器专用基类）之一。"
         "注意：直接继承 BasePlugin 而不补齐其抽象方法会被拒绝——"
         "含未实现抽象方法的类会被判定为抽象类，在类发现阶段拒收。"),
        ("3. ID 格式规范：必须采用纯小写字母、数字与下划线命名（^[a-z0-9_]{3,32}$）。",
         "3. ID 格式规范：必须采用纯小写字母、数字与下划线命名，长度 3 至 40 个字符"
         "（正则 ^[a-z0-9_]{3,40}$）。含大写字母会被直接拒绝。"),
        ("5. Schema 规范性：get_config_schema() 返回的每个字段必须声明 type, label, default。",
         "5. Schema 规范性：get_config_schema() 返回的每个字段必须声明 type 与 label"
         "（default 与 description 为强烈建议项，缺失不影响装载，但会降低界面可用性）。"),
        ("6. 生命周期方法实现：必须完整实现 on_init(context), on_enable(), on_disable(), on_destroy()。",
         "6. 生命周期方法实现：必须完整实现 on_init(context)、on_enable()、on_disable() 三个抽象方法。"
         "on_destroy() 并非抽象方法，无需实现（如需释放资源可在 on_disable() 中处理）。"
         "实现不完整会导致类保持抽象状态，在类发现阶段被拒收。"),
        ("7. 类型专属契约：协议插件必须实现 send_universe()；宏插件必须实现 render()；"
         "感知插件必须实现 start_listening()。",
         "7. 类型专属抽象方法契约（遗漏任意一个都会被拒收）："
         "BaseProtocolPlugin（1 类协议）需实现 send_universe(universe, dmx_data_512)；"
         "BaseLLMPlugin（1 类模型）需实现 chat_completion(...)；"
         "BaseAdapterPlugin（2 类适配）需实现 supported_extensions() 与 convert_to_profile(...)；"
         "BaseMacroPlugin（3 类宏）需实现 render(...)；"
         "BasePerceptionPlugin（3 类感知）需实现 get_status()。"),
        ("8. 资源释放契约：on_disable() 与 on_destroy() 必须关闭所有打开的 Socket 套接字、"
         "停止后台线程并清理内存。",
         "8. 资源释放契约：on_disable() 必须关闭所有打开的 Socket 套接字、停止后台线程并清理内存。"
         "插件被热卸载或宿主退出前系统会调用 on_disable()，此处未释放的资源将成为泄露源。"),
        ("请严格遵循系统【Plugin SDK v3.0】规范为我编写一个全新的插件：",
         "请严格遵循系统【Plugin SDK v5.3】规范为我编写一个全新的插件："),
        ("4. 必须完整实现 on_init(context), on_enable(), on_disable(), on_destroy() 生命周期。",
         "4. 必须完整实现 on_init(context), on_enable(), on_disable() 生命周期，"
         "并按所选基类补齐其专属抽象方法。"),
        ("5. 必须具备异常沙箱处理，严禁在执行中抛出导致 44Hz 微内核实时主线程崩溃的未捕获异常。",
         "5. 必须具备异常沙箱处理，严禁在执行中抛出未捕获异常"
         "（插件异常会被宿主熔断隔离，但会在插件生态总览中登记为失败项）。"),
        ("14.2 Debian Linux systemd 服务化注册与守护进程配置",
         "14.2 Debian Linux systemd 双单元服务化注册与实时进程调度配置"),
        ("在 Debian 终端中将 AI-MA 注册为系统级后台守护服务，实现开机自启、崩溃自动重启与日志持久化：",
         "v5.3 起系统由实时微内核与业务控制台两个独立 systemd 单元组成，两者之间存在强绑定关系："
         "业务单元 BindsTo 微内核单元，微内核停止则业务单元随之停止；"
         "微内核单元配置 WatchdogSec=1s，实现秒级心跳守护。"
         "两个单元由 tools/build_release.py 统一生成，同时输出到发布包根目录与 deploy/ 子目录，"
         "杜绝手工编写产生的不一致。"),
        ("系统所有诊断日志均写入 logs/ 目录，统一采用中文语义化故障码格式：",
         "系统所有诊断日志均写入 logs/ 目录，统一采用中文语义化故障码格式，"
         "并在 core/diagnostics_logger.py 的 ERROR_DIAGNOSTICS_DB 知识库中登记成因与处置建议。"
         "下表为 v5.3 实装并已登记知识库的故障码。未登记知识库的故障码会在日志中显示为"
         "「未知系统异常」，因此新增故障码时必须同步登记知识库。"),
    ]
    for old, new in REWRITES:
        n = replace_text(doc, old, new, {})
        if n == 0:
            print(f"      [警告] 未命中: {old[:48]}...")
    print("[4] 定点重写完成（12.2 / 13.3 / 13.8 / 14.2 / 14.3）")

    # 14.2 systemd 单元内容：直接从 build_release.py 的模板生成，保证与代码同源
    #
    # 此处原先手抄单元内容，结果出了两处错：把 Type=simple 写成了 Type=notify，
    # 且漏掉了 NoNewPrivileges / ProtectHome / ProtectSystem 等加固项。
    # 现改为读取生成器的模板常量，让文档与 tools/build_release.py 永远一致。
    sys.path.insert(0, os.path.join(APP_ROOT, "tools"))
    import build_release as _br

    _rt = _br.AIMA_RT_SERVICE.replace("@@VERSION@@", _br.VERSION).rstrip()
    _app = _br.AI_MA_SERVICE.replace("@@VERSION@@", _br.VERSION).rstrip()
    _deploy = (
        "部署命令（必须按顺序，微内核先行）：\n"
        "sudo cp aima-rt.service ai-ma.service /etc/systemd/system/\n"
        "sudo systemctl daemon-reload\n"
        "sudo systemctl enable --now aima-rt.service\n"
        "sudo systemctl enable --now ai-ma.service\n"
        "sudo systemctl status aima-rt.service ai-ma.service\n\n"
        "关键说明：AIMA_RT_EXTERNAL=1 告知 Python 层「微内核已由 systemd 托管」，"
        "控制台启动时不会重复拉起第二个微内核进程（两个微内核争抢同一组 /dev/shm 槽位"
        "会造成灾难性数据错乱）。控制台另内置运行期看门狗线程，"
        "即使微内核被异常杀死也会在数秒内发现并尝试恢复。"
    )
    _sysd_text = (
        "单元 1：/etc/systemd/system/aima-rt.service（硬实时微内核，必须最先启动）\n"
        + _rt + "\n\n"
        "单元 2：/etc/systemd/system/ai-ma.service（Python 业务控制台）\n"
        + _app + "\n\n" + _deploy
    )

    # 关键：原文档把 systemd 内容放在一个**单格表格**里，段落级 replace_text 匹配不到
    # ——单元格内的文本自带换行，用 Markdown 导出的扁平字符串当锚点必然失配，
    # 而且是静默失配（不报错、不生效）。这个坑与 14.3 故障码表同源。
    # 必须直接改写单元格。
    from docx.table import Table as _Table
    _tbl = find_table_after(doc, "14.2", stop_prefix="14.3")
    if _tbl is None:
        print("[5] 14.2 systemd 单元格: 失败，未找到 14.2 之后的表格")
    else:
        _cell = _Table(_tbl, doc).rows[0].cells[0]
        set_cell_text(_cell, _sysd_text)
        print(f"[5] 14.2 systemd 单元格: 成功写入 {len(_sysd_text)} 字符"
              f"（含双单元 + 加固项，与 build_release.py 同源）")

    # 14.3 故障码对照表：直接从知识库代码重建，保证文档与代码同源
    #
    # 注意：这里不能用 replace_text。python-docx 的段落级替换无法命中表格——
    # 表格里每个单元格是独立段落，用 Markdown 导出的 "| a | b |" 整行字符串做锚点
    # 永远匹配不上（这个 bug 曾导致故障码表静默保持原样，只扩充了标题段落）。
    ok, msg = rebuild_fault_code_table(doc)
    print(f"[5] 14.3 故障码表: {'成功，' + msg if ok else '失败，' + msg}")
    print("    14.2 systemd 双单元已替换")

    # ---------------- 插入 2.4 与 13.12 ----------------
    ok, msg = splice_before(doc, "三、核心技术模块详解", frag_architecture())
    print(f"[6] 插入 2.4 软件架构: {'成功，' + msg if ok else '失败，' + msg}")

    ok, msg = splice_before(doc, "第十四章：系统环境要求与 Debian Linux 工业部署排障指南",
                            frag_13_12())
    print(f"[6b] 插入 13.12 模板修正清单: {'成功，' + msg if ok else '失败，' + msg}")

    # ---------------- 追加新章节 ----------------
    n = append_frag(doc, frag_ch16()) + append_frag(doc, frag_ch17()) + append_frag(doc, frag_ch18())
    print(f"[7] 追加第十六~十八章: {n} 个元素")

    # ---------------- 标题样式重映射 ----------------
    n, msg, native = remap_heading_styles(doc)
    print(f"[7b] 标题样式重映射: {msg}")
    print(f"     本文档原生标题样式: {native}")
    print(f"     已修复段落数: {n}")

    doc.save(DST)
    d2 = Document(DST)
    print(f"[8] 已保存: {DST}")
    print(f"    成品: 段落 {len(d2.paragraphs)} | 表格 {len(d2.tables)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
