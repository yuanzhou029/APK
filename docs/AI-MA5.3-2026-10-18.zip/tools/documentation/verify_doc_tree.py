# -*- coding: utf-8 -*-
"""
Markdown 文档「目录树」与真实文件系统的一致性校验

背景：docs/01_system_architecture.md 里用 ```text 代码块画了一棵目录树，
把插件目录画成 plugins/{protocols,perception,macros,llm}，
而实际是 plugins/{system,adapters,community}。这类失实靠人眼发现代价很高，
本脚本把它变成机器可查的断言。

做法：
  1. 从 md 文件中提取所有 ```text 代码块
  2. 识别其中「像目录树」的块（含 ├── / └── / │ 等制表符）
  3. 解析出树形结构，还原成相对路径集合
  4. 与真实文件系统逐条比对，报告：
       - 文档声称存在、实际不存在  → 失实（ERROR）
       - 文档声称是目录、实际是文件（或反之） → 类型错误（ERROR）
       - 实际存在、文档未提及       → 缺漏（WARN，可配置是否算失败）

用法:
  python verify_doc_tree.py <项目根目录> <md文件> [<md文件> ...]
  python verify_doc_tree.py D:\\python项目文件\\AI-MA5.3 D:\\python项目文件\\AI-MA5.3\\docs\\01_system_architecture.md
"""

import os
import re
import sys

# 目录树里的连接符
TREE_CHARS = re.compile(r"[├└│─┌┐┘┴┬┤]")

# 连接符必须**后跟空白**才算目录树节点。
# 这条限制很关键：ASCII 流程图里的 `└────────────────┬──────┘` 开头也是 `└──`，
# `+--------------------+` 开头也是 `+--`，不要求空白就会把它们误当成目录树
# （04 文档的链路图与 ARCHITECTURE_UPGRADE_GUIDE 的框线图都踩过）。
CONNECTOR = re.compile(r"(?:├──|└──|\+--|`--)\s+")

# 文件名里不可能出现的字符——出现即判定为画图，不是路径
NOT_A_NAME = re.compile(r"[─│├└┌┐┘┴┬┤+┼━┃]")

# 一个块至少要解析出这么多条路径，才认为它是目录树
MIN_ENTRIES = 2

# 明显不是项目内真实路径的根节点（纯示意）
IGNORE_NAMES = {"...", "…"}


def extract_text_blocks(md_text):
    """
    提取所有 fenced code block。

    只保留 text / 无语言的块。这一步很关键：类继承图、伪代码里也会出现
    ├── 连接符（例如插件 SDK 文档里的 BasePlugin 继承树），
    但它们不是目录树，一并解析会报出大量假失实。
    """
    blocks = []
    for m in re.finditer(r"```(\w*)\n(.*?)```", md_text, re.S):
        lang = (m.group(1) or "").lower()
        if lang in ("", "text", "txt", "plaintext"):
            blocks.append((lang, m.group(2)))
    return blocks


def looks_like_tree(body):
    """判断一个代码块是否像目录树（至少 2 个真正的树节点）"""
    hits = 0
    for raw in body.splitlines():
        m = CONNECTOR.search(raw)
        if m:
            nm = raw[m.end():].strip().split()
            if nm and not NOT_A_NAME.search(nm[0]):
                hits += 1
    return hits >= MIN_ENTRIES


def parse_tree(body, root_name):
    """
    解析目录树，返回 {相对路径: 'dir'|'file'}。

    采用缩进层级法：每个 ├──/└── 行贡献一个节点，
    其父节点是「上一个层级更浅的节点」。
    """
    entries = {}
    # 记录每层的路径前缀：level -> 当前目录路径
    stack = {}
    lines = body.splitlines()

    for raw in lines:
        if not raw.strip():
            continue
        # 连接符必须后跟空白，且名字里不能含画图字符
        m = CONNECTOR.search(raw)
        if not m:
            continue
        stripped = raw.rstrip()
        prefix = stripped[:m.start()]
        # 计算层级：每个 "│   " 或 "    " 算一层
        level = len(prefix) // 4 + 1

        name_token = stripped[m.end():].split()
        if not name_token:
            continue
        # 名字要在 # 处截断。有些文档写 "file.md# 说明"（# 前无空格），
        # 只按空白分词会把 "#" 粘进文件名，产生假失实（旧 v4.3 文档踩过）。
        name = name_token[0].split("#")[0].rstrip("/")
        if not name or NOT_A_NAME.search(name) or name in IGNORE_NAMES:
            continue

        # 目录判定：名字以 / 结尾即为目录；否则看后面有无子节点（由回填阶段修正）
        is_dir_mark = name_token[0].split("#")[0].endswith("/")

        parent = stack.get(level - 1, root_name)
        rel = f"{parent}/{name}" if parent else name
        stack[level] = rel
        # 清理更深层的残留
        for k in [k for k in stack if k > level]:
            del stack[k]

        entries.setdefault(rel, {"dir_mark": is_dir_mark, "line": stripped.strip()})

    # 回填：有子节点的必为目录
    for rel, info in list(entries.items()):
        has_child = any(o != rel and o.startswith(rel + "/") for o in entries)
        info["kind"] = "dir" if (has_child or info["dir_mark"]) else "file"
    return entries


def verify(project_root, md_path, verbose=True):
    name = os.path.basename(md_path)
    with open(md_path, encoding="utf-8") as f:
        text = f.read()
    blocks = [b for b in extract_text_blocks(text) if looks_like_tree(b[1])]

    print(f"\n{'=' * 74}")
    print(f"  {name}  —— 发现 {len(blocks)} 棵目录树")
    print("=" * 74)

    problems = []      # (类型, 描述)
    checked = 0

    for style, body in blocks:
        # 找根节点名：树主体之前若有一行 "xxx/" 则作为根
        root = None
        for line in body.splitlines():
            s = line.strip()
            if not s or TREE_CHARS.search(s):
                continue
            cand = s.rstrip("/").split()[0].rstrip("/")
            if cand and not cand.startswith("#"):
                root = cand
                break
        if root is None:
            continue
        entries = parse_tree(body, root)
        # 根目录本身不计（它是项目根别名，可能叫 ai_lighting_system 而实际叫 AI-MA5.3）
        entries.pop(root, None)
        if not entries:
            continue

        # 根节点有两种语义，必须区分：
        #   (a) 项目根别名 —— 文档里写 "ai_lighting_system/" 或 "AI-MA5.3/"，
        #       子路径需剥掉根节点再拼到项目根上；
        #   (b) 真实子目录 —— 文档里写 "plugins/"，它本身就是项目下的一个目录，
        #       子路径已是相对项目根的完整路径，不能剥。
        # 早期版本一律按 (a) 处理，导致 02 文档的 plugins 树被误报 12 项失实。
        root_is_real_dir = os.path.isdir(os.path.join(project_root, root))
        kind_desc = "真实子目录" if root_is_real_dir else "项目根别名"
        print(f"\n  [树] 根节点 {root!r}（{kind_desc}），解析出 {len(entries)} 个路径")

        for rel, info in sorted(entries.items()):
            if root_is_real_dir:
                sub = rel
            else:
                sub = rel.split("/", 1)[1] if "/" in rel else rel
            real = os.path.join(project_root, sub)
            checked += 1
            if not os.path.exists(real):
                problems.append(("ERROR", f"[不存在] {rel}   （文档行: {info['line']}）"))
                continue
            real_is_dir = os.path.isdir(real)
            if info["kind"] == "dir" and not real_is_dir:
                problems.append(("ERROR", f"[应为目录实为文件] {rel}"))
            elif info["kind"] == "file" and real_is_dir:
                problems.append(("ERROR", f"[应为文件实为目录] {rel}"))

    errs = [p for p in problems if p[0] == "ERROR"]
    if errs:
        print(f"\n  失实清单（{len(errs)} 项）:")
        for _, d in errs:
            print(f"    - {d}")
    else:
        print(f"\n  [OK] 共校验 {checked} 条路径，未发现失实")
    return len(errs)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    root = sys.argv[1]
    total = 0
    for md in sys.argv[2:]:
        if not os.path.exists(md):
            print(f"[SKIP] 文件不存在: {md}")
            continue
        total += verify(root, md)
    print(f"\n{'=' * 74}")
    print(f"  合计失实 {total} 项")
    print("=" * 74)
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
