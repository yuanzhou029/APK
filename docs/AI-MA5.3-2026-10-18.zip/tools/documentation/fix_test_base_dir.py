# -*- coding: utf-8 -*-
"""
修复 tests/ 下回归套件的 BASE_DIR 语义

背景：套件原本位于项目根目录，BASE_DIR 的语义是"项目根"，
所有用法（core 导入、knowledge_base、config、plugins、control_station.py、
VERSION、web/）都相对于它。搬迁到 tests/ 后只改了一部分套件，
17 套 verify_*.py + udp_receiver_test.py 仍用单层 dirname，
导致 BASE_DIR 指向 tests/，一运行就 ImportError。

修法：单层 dirname → 双层 dirname，恢复"项目根"语义。
只改这一行定义，所有下游用法自动修好。
"""

import os
import re
import shutil
import sys

sys.stdout.reconfigure(encoding="utf-8")
T = r"D:\python项目文件\AI-MA5.3\tests"
BAK = r"D:\python项目文件\AI-MA5.3\tools\documentation\_pathfix_backup"

SINGLE = re.compile(
    r'^(?P<var>BASE_DIR|BASE)(?P<sp>\s*=\s*)'
    r'os\.path\.dirname\(os\.path\.abspath\(__file__\)\)(?P<tail>\s*)$'
)
DOUBLE_TPL = ('{var}{sp}os.path.dirname(os.path.dirname(os.path.abspath(__file__)))'
              '{tail}  # 项目根（本套件位于 tests/ 下）')

os.makedirs(BAK, exist_ok=True)
changed, skipped = [], []

for fn in sorted(os.listdir(T)):
    if not fn.endswith(".py"):
        continue
    path = os.path.join(T, fn)
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()

    hit = None
    for i, ln in enumerate(lines):
        m = SINGLE.match(ln.rstrip("\r\n"))
        if m:
            hit = (i, m)
            break

    if not hit:
        if fn.startswith(("verify_", "udp_receiver_test")):
            skipped.append(fn)
        continue

    i, m = hit
    shutil.copy2(path, os.path.join(BAK, fn))
    lines[i] = DOUBLE_TPL.format(var=m.group("var"), sp=m.group("sp"),
                                 tail=m.group("tail")) + "\n"
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.writelines(lines)
    changed.append((fn, m.group("var")))

print(f"已修复 {len(changed)} 个文件:\n")
for fn, var in changed:
    print(f"  {fn:<48} ({var})")
if skipped:
    print(f"\n未匹配到单层 dirname 定义的套件（{len(skipped)} 个）:")
    for fn in skipped:
        print(f"  {fn}")
print(f"\n原文件备份于: {BAK}")
