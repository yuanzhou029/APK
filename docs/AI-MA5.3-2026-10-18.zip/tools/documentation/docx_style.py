# -*- coding: utf-8 -*-
"""
AI-MA 技术文档统一排版样式库

从既有生成脚本 tools/append_doc_content.py 中提取，保证新增章节与既有文档
在字体、配色、代码块容器、表格斑马纹上完全一致（中文统一 Microsoft YaHei，
代码统一 Consolas，深色工业代码容器 #0F172A + 天蓝左边框 #38BDF8）。
"""

from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls, qn

CN_FONT = "Microsoft YaHei"
CODE_FONT = "Consolas"

C_TITLE = (15, 23, 42)
C_H2 = (30, 41, 59)
C_H3 = (51, 65, 85)
C_BODY = (51, 65, 85)
C_TBL_HEAD = (56, 189, 248)
C_CODE = (226, 232, 240)
C_ACCENT = (2, 132, 199)
C_WARN = (185, 28, 28)


def _cn(run, font_name=CN_FONT):
    """中文必须显式设置 w:eastAsia，否则字体设置对中文字形不生效"""
    run._r.get_or_add_rPr().set(qn("w:eastAsia"), font_name)
    return run


def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    tcPr.append(parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>'))


def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcPr.append(parse_xml(
        f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/>'
        f'<w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/>'
        f'<w:right w:w="{right}" w:type="dxa"/></w:tcMar>'))


def add_p(doc, text="", bold=False, color_rgb=C_BODY, font_size=10.5,
          space_after=6, space_before=0, line_spacing=1.25):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line_spacing
    if text:
        run = p.add_run(text)
        run.bold = bold
        run.font.name = CN_FONT
        run.font.size = Pt(font_size)
        run.font.color.rgb = RGBColor(*color_rgb)
        _cn(run)
    return p


def add_h1(doc, title, size=18, color=C_TITLE):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(10)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = CN_FONT
    run.font.size = Pt(size)
    run.bold = True
    run.font.color.rgb = RGBColor(*color)
    _cn(run)
    return p


def add_h2(doc, title):
    p = doc.add_paragraph(style="Heading 2")
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(6)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = CN_FONT
    run.font.size = Pt(14)
    run.bold = True
    run.font.color.rgb = RGBColor(*C_H2)
    _cn(run)
    return p


def add_h3(doc, title):
    p = doc.add_paragraph(style="Heading 3")
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = CN_FONT
    run.font.size = Pt(12)
    run.bold = True
    run.font.color.rgb = RGBColor(*C_H3)
    _cn(run)
    return p


def add_code_block(doc, code_text, size=8.5):
    """深色工业代码容器（单格表格），与既有文档一致"""
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    cell.width = Inches(6.5)
    set_cell_background(cell, "0F172A")
    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
    tcPr = cell._tc.get_or_add_tcPr()
    tcPr.append(parse_xml(
        f'<w:tcBorders {nsdecls("w")}>'
        f'<w:top w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/>'
        f'<w:left w:val="single" w:sz="16" w:space="0" w:color="38BDF8"/>'
        f'<w:bottom w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/>'
        f'<w:right w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/>'
        f'</w:tcBorders>'))
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(code_text.strip())
    run.font.name = CODE_FONT
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor(*C_CODE)
    _cn(run)
    doc.add_paragraph()
    return table


def add_table_data(doc, headers, rows_data, head_bg="1E293B",
                   font_size=8.5, head_size=9):
    table = doc.add_table(rows=len(rows_data) + 1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for c_idx, h in enumerate(headers):
        cell = table.cell(0, c_idx)
        set_cell_background(cell, head_bg)
        set_cell_margins(cell, top=80, bottom=80, left=100, right=100)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        run.bold = True
        run.font.name = CN_FONT
        run.font.size = Pt(head_size)
        run.font.color.rgb = RGBColor(*C_TBL_HEAD)
        _cn(run)
    for r_idx, row in enumerate(rows_data):
        bg = "F8FAFC" if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx + 1, c_idx)
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=60, bottom=60, left=100, right=100)
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.name = CN_FONT
            run.font.size = Pt(font_size)
            run.font.color.rgb = RGBColor(*C_BODY)
            _cn(run)
    doc.add_paragraph()
    return table


def add_callout(doc, text, fill="FEF2F2", border="B91C1C", color=C_WARN, size=10):
    """警示/结论强调框（单格表格，浅底+左边框）"""
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_background(cell, fill)
    set_cell_margins(cell, top=120, bottom=120, left=180, right=180)
    tcPr = cell._tc.get_or_add_tcPr()
    tcPr.append(parse_xml(
        f'<w:tcBorders {nsdecls("w")}>'
        f'<w:left w:val="single" w:sz="24" w:space="0" w:color="{border}"/>'
        f'<w:top w:val="single" w:sz="2" w:space="0" w:color="{border}"/>'
        f'<w:bottom w:val="single" w:sz="2" w:space="0" w:color="{border}"/>'
        f'<w:right w:val="single" w:sz="2" w:space="0" w:color="{border}"/>'
        f'</w:tcBorders>'))
    p = cell.paragraphs[0]
    p.paragraph_format.line_spacing = 1.25
    run = p.add_run(text)
    run.font.name = CN_FONT
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor(*color)
    _cn(run)
    doc.add_paragraph()
    return table
