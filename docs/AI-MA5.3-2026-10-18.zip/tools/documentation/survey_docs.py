# -*- coding: utf-8 -*-
"""
AI-MA 技术文档体系勘察工具
输出每份 docx 的：标题、段落/表格/内嵌图数量、标题大纲（1-2 级）、版本口径关键词命中情况。
用于判断哪些文档是"现行基线"、哪些已被后续版本取代、以及口径是否落后于实装代码。
"""
import os
import sys
import glob
import json
from docx import Document

ROOT = r"D:\python项目文件"
DESKTOP = os.path.join(os.environ["USERPROFILE"], "Desktop")

# 口径关键词：命中情况用于判断文档描述的是哪个版本
PROBES = {
    "v5.0口径": ["v5.0", "5.0.0", "Enterprise LTS"],
    "v5.2口径": ["v5.2"],
    "v5.3口径": ["v5.3", "5.3.0"],
    "微内核": ["微内核", "aima-rt-daemon"],
    "共享内存": ["共享内存", "/dev/shm", "seqlock"],
    "44Hz": ["44Hz", "44 Hz"],
    "30Hz(旧)": ["30Hz", "30 Hz"],
    "abi3扩展": ["aima_shm_sdk", "abi3"],
    "三层插件": ["1 类", "2 类", "3 类", "PluginTier"],
    "systemd双单元": ["aima-rt.service", "BindsTo"],
    "看门狗": ["看门狗", "watchdog"],
    "发布流水线": ["build_release", "一键生成发布包"],
}


def scan(path):
    d = Document(path)
    paras = d.paragraphs
    text_all = "\n".join(p.text for p in paras)
    tbl_text = "\n".join(
        c.text for t in d.tables for r in t.rows for c in r.cells
    )
    full = text_all + "\n" + tbl_text

    headings = []
    for p in paras:
        st = (p.style.name or "")
        if st.startswith("Heading") or st.startswith("标题"):
            lvl = "".join(ch for ch in st if ch.isdigit()) or "?"
            if lvl in ("1", "2") and p.text.strip():
                headings.append((lvl, p.text.strip()))

    probe_hits = {k: sum(1 for kw in kws if kw in full) for k, kws in PROBES.items()}

    # 内嵌图片数
    img_count = sum(1 for r in d.part.rels.values() if "image" in r.reltype)

    title = next((p.text.strip() for p in paras if p.text.strip()), "(无标题)")
    return {
        "path": path,
        "title": title,
        "paragraphs": len(paras),
        "tables": len(d.tables),
        "images": img_count,
        "headings": headings,
        "probes": probe_hits,
    }


def main():
    files = sorted(set(glob.glob(os.path.join(ROOT, "*.docx")) +
                       glob.glob(os.path.join(DESKTOP, "*.docx"))))
    out = []
    for f in files:
        try:
            out.append(scan(f))
        except Exception as e:
            out.append({"path": f, "error": f"{type(e).__name__}: {e}"})

    for r in out:
        print("=" * 96)
        if "error" in r:
            print(f"[读取失败] {r['path']}\n   {r['error']}")
            continue
        loc = "桌面" if DESKTOP in r["path"] else "根目录"
        print(f"[{loc}] {os.path.basename(r['path'])}")
        print(f"  标题: {r['title']}")
        print(f"  段落 {r['paragraphs']} | 表格 {r['tables']} | 内嵌图 {r['images']} | 一二级标题 {len(r['headings'])}")
        hits = [k for k, v in r["probes"].items() if v > 0]
        miss = [k for k, v in r["probes"].items() if v == 0]
        print(f"  命中口径: {', '.join(hits) if hits else '(无)'}")
        print(f"  未命中  : {', '.join(miss) if miss else '(无)'}")
        if r["headings"]:
            print("  大纲:")
            for lvl, t in r["headings"][:40]:
                print(f"    {'  ' * (int(lvl) - 1)}{lvl}. {t}")
            if len(r["headings"]) > 40:
                print(f"    ... 另有 {len(r['headings']) - 40} 条")

    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_survey.json"),
              "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print("\n[已写出勘察结果 _survey.json]")


if __name__ == "__main__":
    main()
