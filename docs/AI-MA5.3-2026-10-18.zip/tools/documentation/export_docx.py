# -*- coding: utf-8 -*-
"""
AI-MA 技术文档正文导出工具
把 docx 导出为可读 Markdown（标题按样式层级、表格转 Markdown、保留段落顺序），
便于对文档内容做审阅、比对与改写。
用法: python export_docx.py <input.docx> <output.md>
"""
import os
import sys
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph


def iter_block_items(parent):
    """按文档真实顺序交替产出段落与表格"""
    from docx.oxml.ns import qn
    body = parent.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)


def heading_level(style_name: str) -> int:
    if not style_name:
        return 0
    s = style_name.strip()
    if s.startswith("Heading"):
        tail = s.replace("Heading", "").strip()
        return int(tail) if tail.isdigit() else 0
    if s.startswith("标题"):
        tail = s.replace("标题", "").strip()
        return int(tail) if tail.isdigit() else 0
    if s in ("Title", "标题"):
        return 0
    return 0


def dump(src: str, dst: str):
    doc = Document(src)
    lines = [f"<!-- 源文件: {src} -->", ""]
    for item in iter_block_items(doc):
        if isinstance(item, Paragraph):
            txt = item.text.strip()
            if not txt:
                continue
            lvl = heading_level(item.style.name if item.style else "")
            if lvl == 0 and (item.style and item.style.name in ("Title",)):
                lines.append(f"# {txt}")
            elif lvl > 0:
                lines.append(f"{'#' * min(lvl + 1, 6)} {txt}")
            else:
                lines.append(txt)
            lines.append("")
        else:
            lines.append("| " + " | ".join(
                (c.text or "").replace("\n", " ").replace("|", "\\|").strip()
                for c in item.rows[0].cells) + " |")
            lines.append("|" + "---|" * len(item.rows[0].cells))
            for row in item.rows[1:]:
                lines.append("| " + " | ".join(
                    (c.text or "").replace("\n", " ").replace("|", "\\|").strip()
                    for c in row.cells) + " |")
            lines.append("")

    with open(dst, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"[OK] {os.path.basename(src)} -> {os.path.basename(dst)}  "
          f"({len(lines)} 行, {os.path.getsize(dst):,} 字节)")


if __name__ == "__main__":
    dump(sys.argv[1], sys.argv[2])
