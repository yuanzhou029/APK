# -*- coding: utf-8 -*-
"""
统一总控台 · 四层 RAG 知识库完整能力回归验证 (v4.3)

覆盖范围：
  第一层 物理灯库   : 新增/删除、危险通道锁定、range/slots 取值范围、profile_attributes 属性全集
  第二层 场地拓扑   : 四层节点树保存、扁平 fixtures 派生兼容、端口自定义序号、共址降级、冲突检测
  第三层 美学预设   : 强制分类、单条 CRUD、channel_values 属性驱动、向后兼容派生字段
  注册表            : 自定义分类 CRUD + 删除保护、属性分组注册表
  RAG / 兼容        : 语义检索、字段向后兼容、kb_manager 热重载
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from kb_service import KnowledgeBaseService

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"[FAIL] {name} {extra}")


def main():
    print("=" * 74)
    print(" 统一总控台 · 四层 RAG 知识库能力回归验证 v4.3")
    print("=" * 74)

    kb_root = os.path.join(BASE_DIR, "knowledge_base")
    kb = KnowledgeBaseManager(kb_root)
    svc = KnowledgeBaseService(kb_root, kb_manager=kb)

    # 快照，供最后还原
    presets_before = svc.get_presets()
    cats_before = svc.get_categories()["categories"]
    ags_before = svc.get_attribute_groups()["groups"]

    # =============================================================== 第一层
    s = svc.get_summary()
    check("1. 资产总览统计", s["profiles_count"] >= 2 and s["venues_count"] >= 1,
          f"-> 灯库{s['profiles_count']} / 场地{s['venues_count']} / 预设{s['presets_count']} "
          f"/ 分类{s['categories_count']} / 当前场地={s['active_venue_name']}")

    profiles = svc.list_profiles()
    check("2. 灯库列表字段完整",
          all(k in profiles[0] for k in ("filename", "safe_channel_count", "locked_channel_count",
                                         "ranged_channel_count", "channels")),
          f"-> {[p['profile_id'] for p in profiles]}")

    # 出厂灯库已具备 range / slots
    beam = [p for p in profiles if p["profile_id"] == "beam_230w_16ch"][0]
    gobo = [c for c in beam["channels"] if c["type"] == "gobo"][0]
    check("3. 灯库通道 range / slots 已就绪",
          gobo.get("range") == [0, 255] and len(gobo.get("slots", [])) >= 4,
          f"-> gobo 档位 {[x['label'] for x in gobo.get('slots', [])][:4]}")

    test_pid = "test_tmp_fixture_4ch"
    svc.save_profile({
        "profile_id": test_pid,
        "manufacturer": "测试厂商",
        "model": "回归验证灯",
        "channels": [
            {"ch": 1, "type": "dimmer", "name": "调光", "default": 0, "is_safe": True,
             "range": [10, 240]},
            {"ch": 2, "type": "gobo", "name": "图案盘", "default": 0, "is_safe": True,
             "slots": [{"v": 0, "label": "无"}, {"v": 64, "label": "星芒"}, {"v": 128, "label": "水纹"}]},
            {"ch": 3, "type": "macro", "name": "内置宏演示", "default": 0, "is_safe": False},
            {"ch": 4, "type": "reset", "name": "复位", "default": 0, "is_safe": False},
        ],
    })
    check("4. 灯库新建并热重载", test_pid in kb.profiles,
          "-> 已进入运行中知识库，危险通道已锁定")

    allowed = kb.profiles[test_pid]["allowed_channels"]
    check("5. 危险通道安全锁定生效",
          "macro" not in allowed and "reset" not in allowed and "dimmer" in allowed,
          f"-> 允许通道={sorted(allowed.keys())}")

    # 取值范围归一化：颠倒的 range 应被纠正
    svc.save_profile({
        "profile_id": "test_tmp_range_flip",
        "manufacturer": "T", "model": "R",
        "channels": [{"ch": 1, "type": "dimmer", "name": "d", "range": [240, 10]}],
    })
    flipped = svc.get_profile("test_tmp_range_flip")["channels"][0]
    check("6. range 颠倒自动归一化", flipped["range"] == [10, 240],
          f"-> 输入 [240,10] 归一为 {flipped['range']}")
    svc.delete_profile("test_tmp_range_flip")

    pa = svc.profile_attributes(test_pid)
    locked = set(pa["locked_channels"])
    check("7. 属性全集排除危险通道且带取值元数据",
          {a["attr"] for a in pa["attributes"]} == {"dimmer", "gobo"}
          and "macro" in locked and "reset" in locked
          and [a for a in pa["attributes"] if a["attr"] == "dimmer"][0]["range"] == [10, 240]
          and len([a for a in pa["attributes"] if a["attr"] == "gobo"][0]["slots"]) == 3,
          f"-> {len(pa['attributes'])} 个可调属性 / 锁定 {sorted(locked)}")

    # =============================================================== 注册表
    svc.save_category({"id": "cat_test_warm", "name": "测试暖色", "color": "#f43f5e",
                       "icon": {"mode": "builtin", "builtin": "fa-solid fa-fire"}})
    cats = svc.get_categories()["categories"]
    c = [x for x in cats if x["id"] == "cat_test_warm"]
    check("8. 自定义分类新增（含内置图标）",
          len(c) == 1 and c[0]["name"] == "测试暖色" and c[0]["icon"]["mode"] == "builtin",
          f"-> {len(cats)} 个分类")

    # 图标模式非法值必须被纠正为 none
    svc.save_category({"id": "cat_test_bad", "name": "坏图标", "icon": {"mode": "hack"}})
    bad = [x for x in svc.get_categories()["categories"] if x["id"] == "cat_test_bad"][0]
    check("9. 非法图标模式被纠正", bad["icon"]["mode"] == "none", f"-> mode={bad['icon']['mode']}")

    svc.save_attribute_groups({"groups": [
        {"id": "ag_i", "name": "亮度", "color": "#38bdf8", "attrs": ["dimmer", "dimmer", "strobe"]},
        {"id": "ag_c", "name": "颜色", "color": "#f43f5e", "attrs": ["red", "green"]},
    ]})
    ags = svc.get_attribute_groups()["groups"]
    check("10. 属性分组注册表去重保存",
          len(ags) == 2 and ags[0]["attrs"] == ["dimmer", "strobe"],
          f"-> {[(g['name'], len(g['attrs'])) for g in ags]}")

    # =============================================================== 第三层
    svc.save_preset("preset_verify_a", {
        "name": "验证暖阳", "category_id": "cat_test_warm", "profile_ref": test_pid,
        "channel_values": {"dimmer": 200, "gobo": 64},
        "transition_ms": 900, "summary": "回归验证用", "tags": ["验证", "暖阳"],
    })
    saved = svc.get_presets()["preset_verify_a"]
    check("11. 单条预设保存（属性驱动）",
          saved["channel_values"] == {"dimmer": 200, "gobo": 64} and saved["category_id"] == "cat_test_warm",
          f"-> {saved['name']} / {len(saved['channel_values'])} 个属性")

    check("12. 预设向后兼容派生字段",
          saved["desc"] == "验证、暖阳" and saved["recommended_transition_ms"] == 900
          and saved["suggested_channels"]["red"] == 0,
          f"-> desc={saved['desc']} / 派生 RGBW={saved['suggested_channels']}")

    # 强制分类：缺分类必须拒绝
    missing_cat = False
    try:
        svc.save_preset("preset_no_cat", {"name": "无分类", "profile_ref": test_pid,
                                          "channel_values": {"dimmer": 1}})
    except ValueError:
        missing_cat = True
    check("13. 强制分类：缺失分类被拒绝", missing_cat and "preset_no_cat" not in svc.get_presets(),
          "-> 已拦截未指定分类的预设")

    # 引用不存在的分类必须拒绝
    fake_cat = False
    try:
        svc.save_preset("preset_fake_cat", {"name": "假分类", "category_id": "cat_not_exist",
                                            "profile_ref": test_pid, "channel_values": {"dimmer": 1}})
    except ValueError:
        fake_cat = True
    check("14. 强制分类：引用不存在分类被拒绝", fake_cat, "-> 已拦截")

    # 分类删除保护
    blocked_del = False
    try:
        svc.delete_category("cat_test_warm")
    except ValueError:
        blocked_del = True
    check("15. 分类删除保护（下有预设）", blocked_del,
          "-> 分类下尚有预设时正确拒绝删除")

    svc.delete_preset("preset_verify_a")
    check("16. 单条预设删除", "preset_verify_a" not in svc.get_presets(), "-> 已移除")

    svc.delete_category("cat_test_warm")
    svc.delete_category("cat_test_bad")
    remaining = {x["id"] for x in svc.get_categories()["categories"]}
    check("17. 分类删除（清空后）",
          "cat_test_warm" not in remaining and "cat_test_bad" not in remaining,
          f"-> 剩余 {sorted(remaining)}")

    # =============================================================== 第二层
    venue = svc.get_venue("venue_livehouse_hall_a")
    check("18. 场地已迁移为四层节点树",
          len(venue["nodes"]) >= 1 and len(venue["nodes"][0]["ports"]) >= 1
          and venue["nodes"][0]["ports"][0]["label"] in ("A", "B"),
          f"-> {len(venue['nodes'])} 解码器 / "
          f"{sum(len(n['ports']) for n in venue['nodes'])} 接口 / {len(venue['fixtures'])} 灯具")

    check("19. 扁平 fixtures 派生兼容引擎",
          all("universe" in f and "address" in f for f in venue["fixtures"])
          and len(venue["fixtures"]) == len(kb.current_venue.get("fixtures", [])),
          f"-> 派生 {len(venue['fixtures'])} 条，引擎侧 kb_manager 已同步")

    # 端口自定义序号：字母 / 数字 / 自定义
    test_vid = "venue_test_tmp"
    svc.save_venue({
        "venue_id": test_vid, "venue_name": "回归验证场地", "default_target_ip": "10.0.0.9",
        "nodes": [{
            "node_id": "nd_a", "name": "左侧解码器", "ip": "10.0.0.9", "source": "manual",
            "offline_policy": {"mode": "threshold", "threshold_sec": 8, "liveness_source": "artpoll",
                               "actions": ["log", "banner"]},
            "ports": [
                {"port_id": "p1", "label": "A", "label_style": "alpha", "universe": 0,
                 "fixtures": [{"id": "t1", "name": "测试灯一", "profile_id": test_pid, "address": 1}]},
                {"port_id": "p2", "label": "2", "label_style": "numeric", "universe": 1,
                 "fixtures": [{"id": "t2", "name": "测试灯二", "profile_id": test_pid, "address": 1,
                               "allow_shared_address": True}]},
            ],
        }],
    })
    tv = svc.get_venue(test_vid)
    check("20. 场地四层节点树保存 + 端口自定义序号",
          tv["nodes"][0]["ports"][0]["label"] == "A"
          and tv["nodes"][0]["ports"][1]["label"] == "2"
          and tv["nodes"][0]["ports"][1]["label_style"] == "numeric"
          and len(tv["fixtures"]) == 2,
          f"-> 接口序号 = {[p['label'] for p in tv['nodes'][0]['ports']]}")

    check("21. 节点掉线策略持久化",
          tv["nodes"][0]["offline_policy"]["threshold_sec"] == 8
          and tv["nodes"][0]["offline_policy"]["liveness_source"] == "artpoll"
          and tv["nodes"][0]["offline_policy"]["actions"] == ["log", "banner"],
          f"-> 策略={tv['nodes'][0]['offline_policy']['mode']} / "
          f"{tv['nodes'][0]['offline_policy']['threshold_sec']}s")

    # 冲突检测：越界 + 重叠（无共址 → danger）
    conflict = svc.detect_conflicts({
        "venue_id": "tmp", "venue_name": "冲突测试",
        "fixtures": [
            {"id": "f1", "name": "灯A", "universe": 0, "address": 1, "profile_id": test_pid},
            {"id": "f2", "name": "灯B", "universe": 0, "address": 3, "profile_id": test_pid},
            {"id": "f3", "name": "灯C", "universe": 0, "address": 511, "profile_id": test_pid},
        ],
    })
    types = {c["type"] for c in conflict["conflicts"]}
    check("22. 通道冲突检测（重叠 + 越界均为危险级）",
          conflict["has_conflict"] and "overlap" in types and "overflow" in types
          and conflict["notice_count"] == 0,
          f"-> {len(conflict['conflicts'])} 处冲突 / 类型={sorted(types)}")

    # 共址豁免：任一方勾选「允许共址」→ 降级为提示
    conflict2 = svc.detect_conflicts({
        "venue_id": "tmp2", "venue_name": "共址测试",
        "fixtures": [
            {"id": "g1", "name": "共址灯A", "universe": 0, "address": 1, "profile_id": test_pid,
             "allow_shared_address": True},
            {"id": "g2", "name": "共址灯B", "universe": 0, "address": 1, "profile_id": test_pid,
             "allow_shared_address": True},
        ],
    })
    check("23. 允许共址降级为提示而非冲突",
          not conflict2["has_conflict"] and conflict2["notice_count"] >= 1
          and any(c["type"] == "shared_address" for c in conflict2["conflicts"]),
          f"-> 危险 {conflict2['danger_count']} / 提示 {conflict2['notice_count']}")

    # 跨 Universe 同地址是正常情况，不应报冲突
    conflict3 = svc.detect_conflicts({
        "venue_id": "tmp3", "venue_name": "跨域测试",
        "fixtures": [
            {"id": "h1", "name": "跨域灯A", "universe": 0, "address": 1, "profile_id": test_pid},
            {"id": "h2", "name": "跨域灯B", "universe": 1, "address": 1, "profile_id": test_pid},
        ],
    })
    check("24. 跨 Universe 同地址不误报", not conflict3["has_any_issue"],
          f"-> 覆盖 {conflict3['universe_count']} 条 Universe / 0 冲突")

    # 灯具 ID 重复拦截
    dup_blocked = False
    try:
        svc.save_venue({
            "venue_id": "venue_test_dup", "venue_name": "重复ID",
            "nodes": [{"node_id": "n", "name": "N", "ip": "1.1.1.1",
                       "ports": [{"port_id": "p1", "label": "A", "universe": 0, "fixtures": [
                           {"id": "same", "name": "一", "profile_id": test_pid, "address": 1},
                           {"id": "same", "name": "二", "profile_id": test_pid, "address": 5},
                       ]}]}],
        })
    except ValueError:
        dup_blocked = True
    check("25. 同接口内灯具 ID 重复被拦截", dup_blocked, "-> 已拒绝")

    sw = svc.switch_active_venue("venue_livehouse_hall_a")
    check("26. 工作场地热切换", sw["status"] == "ok" and sw["node_count"] >= 1,
          f"-> {sw['venue_name']} ({sw['node_count']} 解码器 / {sw['fixture_count']} 灯具)")

    svc.delete_venue(test_vid)
    check("27. 临时场地删除", not os.path.exists(
        os.path.join(kb_root, "venues", f"{test_vid}.json")), "-> 已清理")

    # =============================================================== RAG
    rag = svc.rag_test("把左前一号面光调成暖阳金，3秒慢推")
    check("28. RAG 语义检索命中灯具与预设",
          rag["matched_count"] >= 1 and "preset_hint" in rag,
          f"-> 命中 {rag['matched_count']} 台灯具 / "
          f"预设={rag['preset_hint']['preset_name'] if rag.get('preset_hint') else '无'}")

    hint = rag.get("preset_hint") or {}
    check("29. RAG 预设建议携带分类与属性字典",
          "category_id" in hint and "channel_values" in hint,
          f"-> 分类={hint.get('category_id')} / 属性数={len(hint.get('channel_values') or {})}")

    # =============================================================== 安全拦截
    ref_pid = kb.current_venue["fixtures"][0]["profile_id"]
    blocked = False
    try:
        svc.delete_profile(ref_pid)
    except ValueError:
        blocked = True
    check("30. 被引用灯库删除安全拦截", blocked, f"-> 正确拒绝删除 [{ref_pid}]")

    # =============================================================== 清理
    svc.delete_profile(test_pid)
    svc.save_presets(presets_before)
    svc.save_categories({"categories": cats_before})
    svc.save_attribute_groups({"groups": ags_before})
    ok_clean = (test_pid not in {p["profile_id"] for p in svc.list_profiles()}
                and set(svc.get_presets().keys()) == set(presets_before.keys())
                and {c["id"] for c in svc.get_categories()["categories"]} == {c["id"] for c in cats_before})
    check("31. 测试数据完全清理", ok_clean, "-> 灯库 / 预设 / 分类注册表均已还原")

    print("=" * 74)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败")
    print("=" * 74)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
