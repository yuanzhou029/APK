# -*- coding: utf-8 -*-
"""
四合一集成总控台全量接口自动化验证脚本
"""

import os
import sys
import json
import time
import urllib.request
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "core"))

def test_unified_suite():
    print("=" * 65)
    print(" 开始对四合一统一总控台 (Control Station v3.0) 执行集成验证")
    print("=" * 65)

    from control_station import auth, monitor, engine, kb

    # 1. 验证 RBAC 鉴权
    admin_sess = auth.authenticate("admin", "admin123")
    assert admin_sess is not None, "管理员认证失败"
    token = admin_sess["token"]
    print("[PASS] 模块1: RBAC 鉴权核心有效，获得管理员令牌")

    # 2. 验证内置 UDP 接收监视器
    stats = monitor.get_stats()
    print(f"[PASS] 模块2: UDP 6454 接收监视器运行中 (端口: {stats['port']}, 累计帧数: {stats['total_frames']})")

    # 3. 验证本地大模型端点配置插件
    llm = engine.plugin_host.get_llm()
    assert llm is not None, "大模型插件未加载"
    print(f"[PASS] 模块3: 本地大模型插件已装载 (端点: {llm.api_url}, 模型: {llm.model_name})")

    # 4. 验证 RAG 知识库检索与冲突检测
    f_ctx, p_hint = kb.retrieve_context("把舞台左前一号面光调成暖阳金，3秒慢推")
    assert len(f_ctx) > 0, "RAG 拓扑匹配灯具为空"
    print(f"[PASS] 模块4: RAG 知识库检索命中灯具: {[f['name'] for f in f_ctx]}")

    # 5. 验证控制台单场景下发到 DMX 仲裁器
    target_fix = f_ctx[0]
    u = target_fix["universe"]
    addr = target_fix["address"]
    frame = bytearray(512)
    frame[addr + 1] = 255 # Dimmer
    engine.trigger_crossfade(u, frame, duration_ms=500)
    time.sleep(0.6)
    cur_frame = engine.dmx_merger.get_final_frame(u)
    assert cur_frame[addr + 1] == 255, f"DMX 仲裁输出不符合预期: {cur_frame[addr + 1]}"
    print("[PASS] 模块5: 智能调光指令经 Crossfade 平滑下发并驱动仲裁帧 100% 成功")

    print("\n" + "=" * 65)
    print(" 四合一集成总控台全部后端接口与底层联动验证全部 PASS！")
    print("=" * 65)

if __name__ == "__main__":
    test_unified_suite()
