# -*- coding: utf-8 -*-
"""
企业级安全性、RBAC 鉴权与故障诊断综合自动化验证
测试项：
1. PBKDF2-HMAC-SHA256 鉴权与 Session Token 签发有效性
2. 权限分级拦截校验 (Admin 拥有所有权限，Guest 拦截控光/Panic)
3. 结构化中文日志捕获与 ERR-NET-6454 / ERR-MASK-TRIP 故障诊断匹配
4. 代码加固流水线字节码编译与防篡改指纹生成
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "core"))

from auth_manager import AuthManager, Role
from diagnostics_logger import setup_chinese_logger, GLOBAL_LOG_BUFFER, log_diagnostic_error, ERROR_DIAGNOSTICS_DB
from build_hardener import CodeHardener

def run_security_test():
    print("=" * 65)
    print(" 开始执行企业级安全性、RBAC 权限分级与中文故障诊断测试")
    print("=" * 65)

    # 1. 验证 RBAC 鉴权与哈希防破解
    auth = AuthManager(user_db_path=os.path.join(BASE_DIR, "config", "test_users.json"))
    
    # 错误密码应拒绝
    fail_sess = auth.authenticate("admin", "wrong_password")
    assert fail_sess is None, "密码校验失败用例未通过"
    
    # 正确管理员密码
    admin_sess = auth.authenticate("admin", "admin123")
    assert admin_sess is not None, "管理员登录失败"
    assert admin_sess["role"] == Role.ADMIN, "管理员角色分配错误"
    admin_token = admin_sess["token"]
    
    # 观察员登录
    guest_sess = auth.authenticate("guest", "guest")
    assert guest_sess is not None, "观察员登录失败"
    guest_token = guest_sess["token"]

    print("[PASS] PBKDF2-HMAC-SHA256 加盐防碰撞密码校验与 Token 签发通过")

    # 2. 验证权限拦截机制
    # 观察员尝试执行控光或熔断应返回 False
    assert not auth.check_permission(guest_token, "operate_lights"), "安全漏洞：观察员未被拦截控光权限！"
    assert not auth.check_permission(guest_token, "panic_control"), "安全漏洞：观察员未被拦截 Panic 权限！"
    
    # 管理员执行控光或熔断应返回 True
    assert auth.check_permission(admin_token, "operate_lights"), "管理员控光权限缺失"
    assert auth.check_permission(admin_token, "panic_control"), "管理员 Panic 权限缺失"

    print("[PASS] 严格 RBAC 角色权限分级拦截隔离校验 100% 通过")

    # 3. 验证中文日志与故障诊断秒级定位
    logger = setup_chinese_logger(log_dir=os.path.join(BASE_DIR, "logs"), app_name="SecurityTest")
    log_diagnostic_error(logger, "ERR-NET-6454", "端口 6454 冲突模拟")
    
    recent_logs = GLOBAL_LOG_BUFFER.get_logs(limit=10)
    assert len(recent_logs) > 0, "内存环形日志缓冲区捕获失败"
    
    last_log = recent_logs[-1]
    assert last_log["diag_code"] == "ERR-NET-6454", "故障诊断错误代码未正确定位"
    assert "diagnostics" in last_log, "未附带故障诊断知识库建议"
    print(f"[PASS] 中文结构化故障诊断引擎校验通过:")
    print(f"       -> 诊断代码: {last_log['diag_code']}")
    print(f"       -> 故障标题: {last_log['diagnostics']['title']}")
    print(f"       -> 排查建议: {last_log['diagnostics']['solution']}")

    # 4. 验证代码混淆与防篡改加固流水线
    hardener = CodeHardener(target_dir=os.path.join(BASE_DIR, "core"), output_dist_dir=os.path.join(BASE_DIR, "dist_core_test"))
    dist_dir = hardener.obfuscate_and_compile()
    assert os.path.exists(os.path.join(dist_dir, "integrity.manifest")), "未生成防篡改清单"
    print("[PASS] 代码加固编译与防篡改清单 (SHA-256 Manifest) 流水线校验通过")

    # 5. 清理测试产物：验证套件不得在交付目录里留下任何痕迹，
    #    否则客户拿到的包里会多出 test_users.json 和 dist_core_test/ 这类测试垃圾。
    import shutil

    cleaned = []
    test_users = os.path.join(BASE_DIR, "config", "test_users.json")
    if os.path.exists(test_users):
        os.remove(test_users)
        cleaned.append("config/test_users.json")
    dist_test = os.path.join(BASE_DIR, "dist_core_test")
    if os.path.isdir(dist_test):
        shutil.rmtree(dist_test, ignore_errors=True)
        cleaned.append("dist_core_test/")
    print(f"[PASS] 测试产物清理完毕: {cleaned if cleaned else '无残留'}")

    assert not os.path.exists(test_users), "测试用户库未被清理"
    assert not os.path.isdir(dist_test), "加固测试输出目录未被清理"

    print("\n" + "=" * 65)
    print(" 所有企业级安全加固、鉴权隔离、中文诊断与构建测试全部 PASS！")
    print("=" * 65)

if __name__ == "__main__":
    run_security_test()
