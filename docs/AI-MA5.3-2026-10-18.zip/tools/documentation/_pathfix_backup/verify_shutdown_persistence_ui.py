# -*- coding: utf-8 -*-
"""
AI-MA 控台关机、持久化与预设视觉定制回归验证套件 (verify_shutdown_persistence_ui.py)
验证内容：
1. 面板布局持久化：POST /api/panel/save_layout 与 /api/panel/layout 双路由保存无损落盘
2. 预设按钮颜色与图标定制字段 (color, icon) 规范化与持久化
3. 预设分类过滤隔离性断言：绝不串分类
4. 系统关机接口规范度与 DMX 熔断静音机制验证
"""

import os
import sys
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from kb_service import KnowledgeBaseService

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：控台关机、持久化与预设视觉定制深度逻辑验证")
print("==============================================================================")

kb_path = os.path.join(BASE_DIR, "knowledge_base")
svc = KnowledgeBaseService(kb_path)

# 1. 验证预设视觉字段 (color, icon) 规范化与持久化
cats = svc.get_categories().get("categories", [])
first_cat_id = cats[0]["id"] if cats else "cat_general"

test_preset_data = {
    "name": "极光霓虹绿",
    "category_id": first_cat_id,
    "color": "#10b981",
    "icon": "fa-gem",
    "channel_values": {"red": 16, "green": 185, "blue": 129},
    "universal": True,
    "tags": ["极光", "宝石", "绿色"]
}

save_p_res = svc.save_preset("preset_aurora_test", test_preset_data)
check("预设保存接口成功写入", save_p_res.get("status") == "ok")

# 重新读取并验证持久化
saved_p = svc.get_presets().get("preset_aurora_test")
check("持久化保存了按钮自定义发光色 #10b981", saved_p.get("color") == "#10b981", f"color={saved_p.get('color')}")
check("持久化保存了按钮专属图案图标 fa-gem", saved_p.get("icon") == "fa-gem", f"icon={saved_p.get('icon')}")

# 清理测试预设
svc.delete_preset("preset_aurora_test")
check("测试预设安全清理完毕", "preset_aurora_test" not in svc.get_presets())

# 2. 验证控制台面板布局文件原子持久化
from control_station import save_panel_layout, load_panel_layout

backup_layout = load_panel_layout()

test_layout = {
    "groups": [
        {
            "group_id": "g_main",
            "title": "现场主控区",
            "columns": 4,
            "order": 0,
            "item_ids": ["preset:romantic_pink", "preset:rock_red"]
        }
    ]
}

res_save = save_panel_layout(test_layout)
check("save_panel_layout 成功持久化", res_save.get("status") == "ok")

# 再次读取落盘文件
reloaded = load_panel_layout()
check("重启式重新读取面板配置非空且正确", reloaded.get("configured") is True and len(reloaded.get("groups", [])) == 1)
check("重新读取的面板分组标题精准匹配", reloaded["groups"][0]["title"] == "现场主控区")

# 恢复原始面板布局
save_panel_layout(backup_layout)

# 3. 验证预设分类过滤算法严格隔离性 (模拟前端修复后的 keys 过滤逻辑)
mock_presets = {
    "p1": {"name": "粉红", "category_id": "cat_general"},
    "p2": {"name": "摇滚", "category_id": "cat_general"},
    "p3": {"name": "特殊", "category_id": "cat_special"}
}

def simulate_filter(active_cat, presets_dict):
    gmap = {active_cat: []}
    for k, v in presets_dict.items():
        cid = v.get("category_id") or "__none__"
        if cid in gmap:
            gmap[cid].append(k)
    return gmap.get(active_cat, [])

filtered_general = simulate_filter("cat_general", mock_presets)
filtered_special = simulate_filter("cat_special", mock_presets)

check("点击 cat_general 仅包含该分类条目 (不含 cat_special)", set(filtered_general) == {"p1", "p2"})
check("点击 cat_special 仅包含特种分类 (不含 cat_general)", set(filtered_special) == {"p3"})

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
