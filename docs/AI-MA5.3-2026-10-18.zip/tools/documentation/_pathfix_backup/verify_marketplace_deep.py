# -*- coding: utf-8 -*-
"""
AI-MA 插件市场与生命周期管理深度验证套件 (verify_marketplace_deep.py)
验证内容：
1. 已装载插件信息规范度 (name, version, type, author, id 完整性)
2. 插件市场扩展包字段规范度与 is_installed 精准标记
3. 插件参数详情 (schema/properties) 可用性
4. 插件安装、配置热更新、启用停用、卸载生命周期闭环
"""

import os
import sys
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from engine import CoreEngine
from marketplace_service import PluginMarketplace

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：插件市场与已装载生态深度逻辑验证")
print("==============================================================================")

kb = KnowledgeBaseManager(os.path.join(BASE_DIR, "knowledge_base"))
engine = CoreEngine(kb_manager=kb, config={"plugins_dir": os.path.join(BASE_DIR, "plugins")})
market = PluginMarketplace(catalog_path=os.path.join(BASE_DIR, "marketplace", "plugin_catalog.json"),
                           plugins_dir=os.path.join(BASE_DIR, "plugins"))

# 1. 验证已装载插件生态元数据完整性
installed = engine.plugin_host.list_all_plugins_summary()
check("已装载插件列表非空", len(installed) >= 4, f"count={len(installed)}")

for p in installed:
    pid = p.get("id")
    info = p.get("info", {})
    name = info.get("name")
    ver = info.get("version")
    ptype = info.get("type")
    author = info.get("author")
    check(f"插件 [{pid}] 元数据结构完整",
          bool(name and ver and ptype and author),
          f"name={name}, ver={ver}, type={ptype}, author={author}")

# 2. 验证插件市场扩展包列表及 is_installed 标记精准性
installed_ids = list(engine.plugin_host._plugins.keys())
pkgs = market.get_market_packages(installed_ids=installed_ids)
check("市场精选扩展库非空", len(pkgs) >= 3, f"count={len(pkgs)}")

for pkg in pkgs:
    pkg_id = pkg.get("id")
    is_inst = pkg.get("is_installed")
    expected_inst = (pkg_id in installed_ids)
    check(f"市场包 [{pkg_id}] is_installed 状态精准匹配 ({is_inst})",
          is_inst == expected_inst,
          f"actual={is_inst}, expected={expected_inst}")

# 3. 验证插件参数配置 Schema 规范度
macro_p = engine.plugin_host._plugins.get("macro_breathing")
check("动态宏插件 macro_breathing 已成功挂载", macro_p is not None)
if macro_p:
    schema = macro_p.get_config_schema()
    check("插件配置 Schema 包含有效配置项", len(schema) >= 1, f"keys={list(schema.keys())}")
    for k, s in schema.items():
        check(f"配置项 [{k}] 声明了 type 和 label",
              "type" in s and ("label" in s or "title" in s),
              f"item={s}")

# 4. 验证参数热更新生效
if macro_p:
    engine.plugin_host.configure_plugin("macro_breathing", {"default_cycle_ms": 3500})
    cur_cfg = macro_p.get_config()
    check("插件参数热更新生效", cur_cfg.get("default_cycle_ms") == 3500, f"actual={cur_cfg}")
    # 恢复出厂值
    engine.plugin_host.configure_plugin("macro_breathing", {"default_cycle_ms": 2000})

# 5. 验证安装不存在包时异常拦截规范度
bad_install_res = None
try:
    market.install_package("non_existent_pkg_123", engine.plugin_host)
except KeyError as ke:
    bad_install_res = "key_error"

check("尝试安装不存在的包时抛出明确 KeyError 异常", bad_install_res == "key_error")

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
