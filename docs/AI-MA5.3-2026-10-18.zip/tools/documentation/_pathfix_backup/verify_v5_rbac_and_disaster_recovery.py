# -*- coding: utf-8 -*-
"""
AI-MA v5.0 Enterprise LTS 工业级权限隔离、容灾备份与跨用户交互验证套件
(verify_v5_rbac_and_disaster_recovery.py)
"""

import os
import sys
import json
import time
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from auth_manager import AuthManager, Role
from backup_manager import BackupManager

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：v5.0 RBAC权限隔离、系统级容灾备份与跨用户交互专项审计")
print("==============================================================================")

# 1. 验证 VERSION 规范与系统版本号
v_file = os.path.join(BASE_DIR, "VERSION")
check("VERSION 版本元数据文件存在", os.path.exists(v_file))
with open(v_file, "r", encoding="utf-8") as vf:
    v_data = json.load(vf)
check("系统旗舰版本号精准为 5.0.0 (v5.0 Enterprise LTS)", v_data.get("version") == "5.0.0")
check("系统正式旗舰名称确立", "极光灵动" in v_data.get("system_name", ""))

# 2. 验证登录页移除快捷身份
login_html_path = os.path.join(BASE_DIR, "web", "login.html")
with open(login_html_path, "r", encoding="utf-8") as f:
    login_html = f.read()
check("登录页已彻底移除快捷身份填入区域 (.quick-roles)", ".quick-roles" not in login_html)
check("登录页已具备圆心核心居中结构 (.gate-center)", "gate-center" in login_html)

# 3. 验证 RBAC 权限隔离与超级管理员管理能力
users_path = os.path.join(BASE_DIR, "config", "users.json")
auth = AuthManager(user_db_path=users_path)

check("超级管理员 root 账号存在且角色为 superadmin", "root" in auth.users and auth.users["root"]["role"] == Role.SUPERADMIN)

# 测试超级管理员添加各角色（管理员、灯光师、观察员）
res_add_eng = auth.add_or_update_user("test_eng", Role.ENGINEER, password="password123", display_name="测试灯光师")
check("超级管理员成功添加主控灯光师账户", res_add_eng.get("status") == "ok")

res_add_admin = auth.add_or_update_user("test_admin", Role.ADMIN, password="password123", display_name="测试业务管理员")
check("超级管理员成功添加业务管理员账户", res_add_admin.get("status") == "ok")

res_add_viewer = auth.add_or_update_user("test_view", Role.VIEWER, password="password123", display_name="测试现场观察员")
check("超级管理员成功添加现场观察员账户", res_add_viewer.get("status") == "ok")

# 验证新建用户的初始工作区为空白隔离状态
check("新建用户初始拥有独立空白工作区槽位", auth.get_user_profile("test_eng") == {})

# 验证鉴权凭证签发与角色权限隔离
sess_root = auth.authenticate("root", "root123")
sess_eng = auth.authenticate("test_eng", "password123")
sess_view = auth.authenticate("test_view", "password123")

check("root 登录鉴权通过并签发 Token", sess_root is not None and sess_root.get("role") == Role.SUPERADMIN)
check("test_eng 登录鉴权通过且角色为 engineer", sess_eng is not None and sess_eng.get("role") == Role.ENGINEER)
check("test_view 登录鉴权通过且角色为 viewer", sess_view is not None and sess_view.get("role") == Role.VIEWER)

# 验证权限检查：超级管理员拥有全权，而灯光师/观察员无权管理用户
check("超级管理员拥有 manage_users 穿透权限", auth.check_permission(sess_root["token"], "manage_users"))
check("灯光师不具备 manage_users 权限", not auth.check_permission(sess_eng["token"], "manage_users"))
check("观察员不具备 operate_lights 调光权限", not auth.check_permission(sess_view["token"], "operate_lights"))
check("灯光师具备 operate_lights 调光权限", auth.check_permission(sess_eng["token"], "operate_lights"))

# 清理测试用户
auth.delete_user("test_eng")
auth.delete_user("test_admin")
auth.delete_user("test_view")
check("测试用户已干净清理", "test_eng" not in auth.users)

# 4. 验证系统级容灾备份 BackupManager 与 SHA-256 完整性
backup_mgr = BackupManager(BASE_DIR)
snap_res = backup_mgr.create_system_snapshot(tag="manual", description="单元测试全系统容灾基准快照")
check("全系统容灾快照创建成功", snap_res.get("status") == "ok")
snap_id = snap_res.get("snapshot_id")

snapshots = backup_mgr.list_snapshots()
check("快照列表能检索到新建的快照", any(s.get("snapshot_id") == snap_id for s in snapshots))

target_snap = next(s for s in snapshots if s.get("snapshot_id") == snap_id)
check("快照元数据包含文件级 SHA-256 哈希列表", len(target_snap.get("files", {})) > 0)

# 测试一键安全灾备回滚
restore_res = backup_mgr.restore_system_snapshot(snap_id)
check("系统成功从容灾快照中安全回滚恢复", restore_res.get("status") == "ok")

# 5. 验证防篡改校验 (故意篡改快照文件时应拒绝回滚)
manual_dir = os.path.join(backup_mgr.manual_backup_dir, snap_id)
test_file_to_corrupt = None
for root, _, files in os.walk(manual_dir):
    for f in files:
        if f.endswith(".json") and f != "snapshot_meta.json":
            test_file_to_corrupt = os.path.join(root, f)
            break
    if test_file_to_corrupt:
        break

if test_file_to_corrupt:
    with open(test_file_to_corrupt, "a", encoding="utf-8") as f:
        f.write(" ") # 篡改内容破坏 SHA-256
    try:
        backup_mgr.restore_system_snapshot(snap_id)
        check("篡改文件应被 SHA-256 校验拦截", False, "未拦截篡改文件")
    except ValueError as val_err:
        check("SHA-256 防损坏校验成功拦截篡改文件并拒绝回滚", "SHA-256" in str(val_err) or "损坏" in str(val_err))

# 清理测试快照目录
shutil.rmtree(manual_dir, ignore_errors=True)

# 6. 验证跨用户配置包导出与交互导入 (用户间数据分享)
user_pkg_res = backup_mgr.export_user_package(
    username="engineer_alpha",
    user_profile={"fav_faders": [1, 2, 3], "theme": "neon_dark"},
    include_kb_presets=True
)
check("用户专属配置包成功导出", user_pkg_res.get("status") == "ok")
pkg_data = user_pkg_res.get("package")
check("导出的配置包标明标准格式 AI_MA_USER_DATA_PACKAGE", pkg_data.get("format") == "AI_MA_USER_DATA_PACKAGE")

# 导入给另一个用户
import_res = backup_mgr.import_user_package(pkg_data, target_username="engineer_beta", merge_mode="merge")
check("用户配置包成功跨用户导入交互 (增量合并模式)", import_res.get("status") == "ok")

# 清理导出的测试包文件
pkg_file = os.path.join(backup_mgr.user_exports_dir, user_pkg_res.get("filename"))
if os.path.exists(pkg_file):
    os.remove(pkg_file)

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
