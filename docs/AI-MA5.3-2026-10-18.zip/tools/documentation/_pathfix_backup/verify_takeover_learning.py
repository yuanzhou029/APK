# -*- coding: utf-8 -*-
"""
AI-MA 异构协同主备接管 (Takeover) 与现场画面捕获学习模式验证套件
覆盖技术方案《AI-MA异构协同与自适应灯光控制系统技术方案.docx》核心思想：
1. 外部 MA 控台优先级抢占接管 (MANUAL_DESK 80 > AI_CUE 50)
2. 控台超时平滑释放回 AI 控制
3. PANIC 紧急熔断与新场景下发自动解除锁定闭环
4. 学习模式：现场当前物理通道真实电平捕获反解
"""

import os
import sys
import time
import json
import socket
import threading
import urllib.request
import urllib.error

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from dmx_merger import DmxMerger, PriorityLevel
from quick_cue_manager import QuickCueManager

passed = 0
failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} -> {detail}")

print("==============================================================================")
print(" 正在运行：AI-MA 异构协同与自适应灯光控制系统核心逻辑专项验证")
print("==============================================================================")

# 1. 异构协同优先级仲裁机制验证 (DmxMerger 级)
merger = DmxMerger(universe_count=2)

# 配置灯具 CH1=dimmer(HTP), CH2=red(LTP), CH3=control(危险通道, is_safe=False)
merger.configure_fixture_channels(0, 1, [
    {"ch": 1, "type": "dimmer", "is_safe": True},
    {"ch": 2, "type": "red", "is_safe": True},
    {"ch": 3, "type": "control", "is_safe": False}
])

# AI 下发场景 (Priority 50)
ai_frame = bytearray(512)
ai_frame[0] = 120   # dimmer=120
ai_frame[1] = 200   # red=200
ai_frame[2] = 255   # 试图写危险通道
merger.submit_frame("ai_cue", 0, ai_frame, priority=PriorityLevel.AI_CUE)

frame_ai = merger.get_final_frame(0)
check("AI 场景下发：调光通道正确生效", frame_ai[0] == 120, f"actual={frame_ai[0]}")
check("AI 场景下发：颜色通道正确生效", frame_ai[1] == 200, f"actual={frame_ai[1]}")
check("核心安全机制：危险通道被强制归零屏蔽", frame_ai[2] == 0, f"actual={frame_ai[2]}")

# MA 实体控台推流接管 (Priority 80)
ma_frame = bytearray(512)
ma_frame[0] = 255   # dimmer 推满
ma_frame[1] = 50    # 覆盖颜色为暗红
merger.submit_frame("manual_desk", 0, ma_frame, priority=PriorityLevel.MANUAL_DESK)

frame_ma = merger.get_final_frame(0)
check("异构协同接管：MA 实体控台高优先级抢占调光通道", frame_ma[0] == 255, f"actual={frame_ma[0]}")
check("异构协同接管：MA 实体控台高优先级抢占颜色通道", frame_ma[1] == 50, f"actual={frame_ma[1]}")
check("异构协同安全：MA 控台依然受硬件级安全掩码约束", frame_ma[2] == 0, f"actual={frame_ma[2]}")

# MA 控台超时离开 -> 清除 manual_desk 信号源
merger.clear_source("manual_desk", 0)
frame_back = merger.get_final_frame(0)
check("平滑回退：MA 控台离开后控制权无缝交还 AI 场景", frame_back[0] == 120 and frame_back[1] == 200,
      f"dimmer={frame_back[0]}, red={frame_back[1]}")

# 2. PANIC 熔断与自动解锁闭环测试
panic_frame = bytearray(512)
merger.submit_frame("panic", 0, panic_frame, priority=PriorityLevel.PANIC)
frame_panic = merger.get_final_frame(0)
check("PANIC 紧急熔断：全场通道强制黑场归零", frame_panic[0] == 0 and frame_panic[1] == 0,
      f"dimmer={frame_panic[0]}")

# 新场景下发自动清除 PANIC
merger.clear_source("panic", 0)
frame_restored = merger.get_final_frame(0)
check("自动解锁闭环：下发新场景后 PANIC 解除，AI 灯光恢复输出", frame_restored[0] == 120,
      f"actual={frame_restored[0]}")

# 3. 学习模式：反解现场通道数据测试
kb = KnowledgeBaseManager(os.path.join(BASE_DIR, "knowledge_base"))
fixtures = kb.current_venue.get("fixtures", [])
check("当前场地灯具库完整加载", len(fixtures) > 0, f"count={len(fixtures)}")

fix1 = fixtures[0]
u = fix1.get("universe", 0)
addr = fix1.get("address", 1)
pid = fix1.get("profile_id", "")
prof = kb.profiles.get(pid, {})
allowed = prof.get("allowed_channels", {})

# 模拟现场实际输出一帧
test_out_frame = bytearray(512)
if "dimmer" in allowed:
    test_out_frame[addr + allowed["dimmer"] - 2] = 220
if "red" in allowed:
    test_out_frame[addr + allowed["red"] - 2] = 180

# 模拟从输出帧反解捕获灯具电平
captured_chans = {}
for ch_k, offset_1b in allowed.items():
    ch_idx = addr + offset_1b - 2
    if 0 <= ch_idx < 512 and test_out_frame[ch_idx] > 0:
        captured_chans[ch_k] = int(test_out_frame[ch_idx])

check("学习模式捕获：正确反向提取灯具物理通道电平", len(captured_chans) > 0, f"chans={captured_chans}")
if "dimmer" in captured_chans:
    check("学习模式捕获：调光电平解析精确一致", captured_chans["dimmer"] == 220, f"actual={captured_chans.get('dimmer')}")

print("==============================================================================")
print(f" 结果: {passed} 项通过 / {failed} 项失败")
print("==============================================================================")
sys.exit(0 if failed == 0 else 1)
