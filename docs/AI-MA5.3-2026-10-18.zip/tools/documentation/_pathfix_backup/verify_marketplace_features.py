# -*- coding: utf-8 -*-
"""
验证插件市场全生命周期与快捷场景AI联动自动化测试
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "core"))

from control_station import marketplace, engine, quick_cue_mgr

def run_tests():
    print("=" * 65)
    print(" 开始验证插件市场 (Marketplace) 与自定义快捷场景管理")
    print("=" * 65)

    # 1. 验证插件市场读取与合规性静态审查
    pkgs = marketplace.get_market_packages()
    assert len(pkgs) > 0, "插件市场无包可用"
    print(f"[PASS] 1. 插件市场成功挂载，发现精选插件包: {[p['name'] for p in pkgs]}")

    sample_code = pkgs[0]["code"]
    val_res = marketplace.verify_plugin_code(sample_code)
    assert val_res["valid"], f"合规性审查未通过: {val_res['errors']}"
    print(f"[PASS] 2. 插件市场沙箱审查器 (PluginValidator) 验证有效: 接口与Schema规范 100% 合规")

    # 2. 验证一键安装与热加载
    pkg_id = pkgs[0]["id"]
    inst_res = marketplace.install_package(pkg_id, engine.plugin_host)
    assert inst_res["status"] == "ok", f"安装失败: {inst_res}"
    assert pkg_id in engine.plugin_host._plugins, "安装后未在运行表中发现"
    print(f"[PASS] 3. 插件 [{pkg_id}] 一键安装、动态热加载与使能激活成功")

    # 3. 验证参数热更新与启停
    engine.plugin_host.configure_plugin(pkg_id, {"flash_freq_hz": 10})
    p_inst = engine.plugin_host._plugins[pkg_id]
    assert p_inst.get_config().get("flash_freq_hz") == 10, "参数热更新失败"
    print(f"[PASS] 4. 插件运行时参数 Schema 热修改与持久化存储成功")

    engine.plugin_host.set_plugin_enabled(pkg_id, False)
    assert not p_inst.is_enabled, "停用失败"
    engine.plugin_host.set_plugin_enabled(pkg_id, True)
    assert p_inst.is_enabled, "启用失败"
    print(f"[PASS] 5. 插件热启停状态切换测试通过")

    # 4. 验证自定义快捷场景
    new_scene = {
        "id": "scene_test_ambient",
        "name": "极光幽蓝",
        "command": "全场灯具调整为极光幽蓝，缓推5秒",
        "color": "#0ea5e9",
        "icon": "fa-snowflake",
        "desc": "极地氛围"
    }
    quick_cue_mgr.save_scene(new_scene)
    all_scenes = quick_cue_mgr.get_all_scenes()
    assert any(s["id"] == "scene_test_ambient" for s in all_scenes), "自定义快捷场景未能保存"
    print(f"[PASS] 6. 自定义快捷场景新增与持久化成功，当前总场景数: {len(all_scenes)}")

    # 5. 卸载清理测试
    engine.plugin_host.uninstall_plugin(pkg_id)
    assert pkg_id not in engine.plugin_host._plugins, "卸载后残留"
    quick_cue_mgr.delete_scene("scene_test_ambient")
    print(f"[PASS] 7. 插件彻底卸载与场景清理测试通过")

    print("\n" + "=" * 65)
    print(" 插件市场、沙箱验证、参数表单与自定义快捷场景测试全部 PASS！")
    print("=" * 65)

if __name__ == "__main__":
    run_tests()
