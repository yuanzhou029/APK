# -*- coding: utf-8 -*-
"""
微内核与插件化架构综合自动化验证套件
验证微内核加载、插件生命周期、DMX 仲裁合并、Crossfade 平滑过渡以及 Art-Net UDP 报文发送。
"""

import os
import sys
import time
import socket
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(BASE_DIR, "core"))

from kb_manager import KnowledgeBaseManager
from engine import CoreEngine
from dmx_merger import PriorityLevel

def run_test():
    print("=" * 60)
    print(" 开始执行 AI-MA 微内核与插件体系架构全面自动化测试")
    print("=" * 60)

    # 1. 启动本地 UDP 监视接收线程 (验证 ArtNet 驱动插件输出)
    received_packets = []
    receiver_stop = False

    def udp_listener():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 6454))
        sock.settimeout(0.5)
        while not receiver_stop:
            try:
                data, addr = sock.recvfrom(1024)
                if data.startswith(b"Art-Net\x00"):
                    received_packets.append(data)
            except socket.timeout:
                continue
            except Exception:
                break
        sock.close()

    t = threading.Thread(target=udp_listener, daemon=True)
    t.start()

    # 2. 实例化并启动微内核
    kb = KnowledgeBaseManager(os.path.join(BASE_DIR, "knowledge_base"))
    config = {
        "fps": 30,
        "plugins_dir": os.path.join(BASE_DIR, "plugins"),
        "artnet": {"target_ip": "127.0.0.1", "port": 6454},
        "llm": {"api_url": "http://127.0.0.1:8085/v1/chat/completions", "model_name": "qwen2.5-7b-4q"}
    }
    engine = CoreEngine(kb_manager=kb, config=config)
    engine.start()

    print("[PASS] 微内核初始化与 30Hz 心跳线程启动成功")

    # 3. 校验插件加载状态
    plugins = engine.plugin_host._plugins
    print(f"已加载插件列表 ({len(plugins)} 个):")
    for pid, p in plugins.items():
        info = p.get_info()
        print(f"  - [{info['type']}] {info['name']} (ID: {pid}, v{info['version']})")

    assert "protocol_artnet_standard" in plugins, "Art-Net 协议插件未加载"
    assert "llm_local_qwen_7b" in plugins, "Qwen 模型插件未加载"
    assert "macro_marquee" in plugins, "走马灯宏插件未加载"
    assert "macro_breathing" in plugins, "呼吸宏插件未加载"
    print("[PASS] 插件系统发现与反射注册校验 100% 通过")

    # 4. 验证 DMX 仲裁合并 (HTP / LTP / 安全掩码)
    merger = engine.dmx_merger
    test_u = 0

    # 模拟 AI 动态宏低优先级写入 (Priority 30)
    macro_frame = bytearray(512)
    macro_frame[31] = 100 # CH32
    merger.submit_frame("test_macro", test_u, macro_frame, priority=PriorityLevel.AI_MACRO)

    # 模拟人工控台推杆高优先级接入 (Priority 80)
    desk_frame = bytearray(512)
    desk_frame[31] = 200 # CH32
    merger.submit_frame("test_desk", test_u, desk_frame, priority=PriorityLevel.MANUAL_DESK)

    final_frame = merger.get_final_frame(test_u)
    assert final_frame[31] == 200, f"优先级仲裁失败，期望 200，实际 {final_frame[31]}"
    print("[PASS] DMX 多源优先级仲裁 (Priority Overrides) 校验通过")

    # 5. 验证危险通道安全熔断
    # CH43 (Martin MAC Aura 14CH 的第13通道: 31 + 13 - 1 = 43) 是设备复位/危险通道
    risky_frame = bytearray(512)
    risky_frame[42] = 255 # 尝试复位
    merger.submit_frame("test_risky", test_u, risky_frame, priority=PriorityLevel.AI_CUE)
    final_frame_after_risk = merger.get_final_frame(test_u)
    assert final_frame_after_risk[42] == 0, "安全熔断失效！危险通道未被拦截！"
    print("[PASS] 物理安全掩码拦截 (Safety Mask Shield) 校验通过（危险复位通道已被强制归零）")

    # 6. 等待并检查 UDP 报文接收
    time.sleep(1.0) # 运行 1 秒，理论应接收约 30*4=120 个包
    print(f"1 秒内本地监视器捕获到的 Art-Net 报文总数: {len(received_packets)} 帧")
    assert len(received_packets) >= 20, "未捕获到足够的 Art-Net 报文流"
    print("[PASS] 工业级 30Hz 恒定网络广播输出实测通过")

    # 7. 安全停机
    engine.stop()
    receiver_stop = True
    print("[PASS] 内核与插件生命周期停机释放校验通过")

    print("\n" + "=" * 60)
    print(" 所有架构核心机制、插件生态与通信测试全部 PASS (100% 成功)！")
    print("=" * 60)

if __name__ == "__main__":
    run_test()
