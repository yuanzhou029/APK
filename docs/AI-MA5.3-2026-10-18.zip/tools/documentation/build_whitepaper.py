# -*- coding: utf-8 -*-
"""
生成《AI-MA 操作系统 v5.3 硬实时微内核架构实装白皮书》

合并来源（两份 v5.3 规划文档）：
  - AI-MA操作系统v5.3微内核工业化重构与不可篡改架构技术白皮书(终极技术栈定稿版).docx
  - AI-MA操作系统v5.3微内核工业化重构与不可篡改架构技术白皮书(终极准出实装版).docx

升级目标：从「架构已冻结、待实装」口径升级为「已实装、已测试」口径，
并明确标注规划中尚未落地项，避免开发分工时把规划当既有能力。

输出: D:\\python项目文件\\AI-MA操作系统v5.3硬实时微内核架构实装白皮书.docx
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx_style import (add_p, add_h1, add_h2, add_h3, add_code_block,
                        add_table_data, add_callout, CN_FONT)

OUT = r"D:\python项目文件\AI-MA操作系统v5.3硬实时微内核架构实装白皮书.docx"
APP_ROOT = r"D:\python项目文件\AI-MA5.3"


def _load_build_release():
    """
    加载 tools/build_release.py，取它的 systemd 单元模板常量。

    这样做的意义：文档里的单元内容与交付包中的实际工件**同源**。
    先前手抄导致过两处错误——把 Type=simple 写成 Type=notify，
    并漏掉 NoNewPrivileges / ProtectHome / ProtectSystem 等加固项。
    """
    sys.path.insert(0, os.path.join(APP_ROOT, "tools"))
    import build_release
    return build_release


def cover(d):
    p = d.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(90)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run("AI-MA 操作系统 v5.3")
    r.bold = True
    r.font.size = Pt(26)
    r.font.name = CN_FONT
    r.font.color.rgb = RGBColor(15, 23, 42)
    r._r.get_or_add_rPr().set(
        "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", CN_FONT)

    p = d.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(20)
    r = p.add_run("硬实时微内核架构实装白皮书")
    r.bold = True
    r.font.size = Pt(20)
    r.font.name = CN_FONT
    r.font.color.rgb = RGBColor(30, 41, 59)
    r._r.get_or_add_rPr().set(
        "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", CN_FONT)

    for line, size, color in [
        ("As-Built 实装版 · 架构冻结 · 源码级工程真相", 12, (2, 132, 199)),
        ("对标体系：GrandMA3 / Linux PREEMPT_RT & systemd / ROS2 / AUTOSAR A+B OTA", 10, (71, 85, 105)),
        ("版本 5.3.0 | 发布标签 v5.3 Enterprise LTS (Hybrid Microkernel)", 10, (71, 85, 105)),
        ("文档状态：现行权威基线（取代全部 v5.1 / v5.2 / v5.3 规划期文档）", 10, (185, 28, 28)),
    ]:
        p = d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(line)
        r.font.size = Pt(size)
        r.font.name = CN_FONT
        r.font.color.rgb = RGBColor(*color)
        r._r.get_or_add_rPr().set(
            "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia", CN_FONT)

    d.add_page_break()

    add_callout(d,
        "【本版与历史版本的定位差异】历史上的 v5.1、v5.2、v5.3 系列白皮书与评审建议书，"
        "均为「架构设计期」产物，其结论是「架构已冻结，准予进入阶段 1 源码实装」。"
        "本版是「实装完成后」的 As-Built 基线：所有描述均已与运行中的代码逐条核对，"
        "并明确区分「已实装并通过测试」与「规划中尚未编写」。"
        "开发分工必须以本版为唯一依据。",
        fill="EFF6FF", border="1D4ED8", color=(29, 78, 216))


def main():
    d = Document()
    cover(d)

    # ================= 第 1 章 =================
    add_h1(d, "第 1 章 架构准出结论与实装状态总览")

    add_h2(d, "1.1 准出结论")
    add_p(d, "AI-MA v5.3 的「Rust 硬实时微内核（aima-rt-daemon）+ PyO3 零拷贝共享内存 SDK + "
             "Python 业务控制台 + 三层插件物理隔离」混合架构已完成源码级实装，"
             "并通过 148 项自动化断言验证，覆盖真实进程启动、真实 HTTP 接口、"
             "真实内核看门狗触发与真实发布包构建启动。架构正式冻结，可用于生产交付与并行开发。")

    add_h2(d, "1.2 实装状态对照表（开发分工前必读）")
    add_callout(d,
        "【最重要的前置事实】早期 v5.3 规划文档所描述的架构比实装代码更激进："
        "SquashFS/dm-verity 密封、A/B 双槽位 OTA、Wasmtime 指令级熔断、llama.cpp 独立推理服务、"
        "FastAPI 控制台这五项在规划文档中作为「已定稿技术栈」出现，但**当前一行代码都没有**。"
        "请勿把它们当作既有能力分配开发任务，除非明确列为新建任务包。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))
    add_table_data(d,
        ["能力项", "实装状态", "证据或说明", "对应章节"],
        [
            ["Rust 44Hz 硬实时微内核", "已实装并运行", "aima-rt-daemon，抖动实测 100 微秒以内", "第 4 章"],
            ["四级仲裁与 O(1) 安全钳位", "已实装", "safety_lut[64][512][256]，约 8MB，零分支", "第 4 章"],
            ["共享内存 seqlock 双缓冲", "已实装", "5 个物理独立槽位 + 顺序锁协议", "第 3 章"],
            ["SPSC 无锁遥测环", "已实装", "alignas(64) 缓存行隔离，杜绝伪共享", "第 6 章"],
            ["sendmmsg() 批量推流与微突发整形", "已实装", "batch_network.rs", "第 4 章"],
            ["PyO3 零拷贝 Python SDK", "已实装", "aima_shm_sdk，abi3-py310 稳定 ABI", "第 5 章"],
            ["三层插件物理隔离", "已实装", "PluginTier 1/2/3，接口层过滤", "第 8 章"],
            ["运行期内核看门狗", "已实装", "三场景判定 + 重启预算 + 故障码", "第 4 章"],
            ["双 systemd 单元绑定", "已实装", "aima-rt.service + ai-ma.service（BindsTo）", "第 9 章"],
            ["发布包完整性校验", "已实装", "verify_release_package() 强校验后放行", "第 9 章"],
            ["Debian 两阶段编译脚本", "脚本已实装", "Cython 段 + cargo 构建段", "第 9 章"],
            ["进程级插件沙箱", "已实装", "aima-worker-sandbox crate（Rust 进程沙箱）", "第 8 章"],
            ["SquashFS + dm-verity 只读密封", "未实装", "规划阶段 3，当前 bin/ 为普通文件", "第 10 章"],
            ["A/B 双槽位原子 OTA", "未实装", "规划阶段 3", "第 10 章"],
            ["Wasmtime 3.00ms 指令级硬熔断", "未实装", "现为进程级沙箱，非 Wasm 指令级", "第 10 章"],
            ["llama.cpp 独立推理服务", "未实装", "现为 Ollama/Qwen 插件适配器形态", "第 10 章"],
            ["FastAPI + uvloop 控制台", "未实装", "现为 Python 标准库 http.server", "第 10 章"],
            ["Maturin 与 .pyi 类型存根", "未实装", "现为 cargo 直接构建，无 .pyi", "第 10 章"],
        ])

    # ================= 第 2 章 =================
    add_h1(d, "第 2 章 混合双进程架构总览")
    add_p(d, "v5.3 把实时性责任从 Python 层彻底剥离，交给独立的 Rust 硬实时微内核进程，"
             "形成「业务非实时 + 控制硬实时」的双进程混合架构。进程之间不通过 Socket、HTTP 或"
             "消息队列通信，而是通过 Linux /dev/shm 零拷贝共享内存直连，"
             "单次业务帧写入耗时约 0.57 微秒。")

    add_h2(d, "2.1 进程职责边界")
    add_table_data(d,
        ["进程", "语言", "职责", "实时性要求", "崩溃影响"],
        [
            ["aima-rt-daemon", "Rust 2021",
             "44Hz 调度、四级仲裁、O(1) 安全钳位、sendmmsg 批量推流、SPSC 遥测写入",
             "硬实时：SCHED_FIFO 98、Core 3 独占、mlockall、抖动小于 100 微秒",
             "致命：物理输出中断，由 systemd 与 Python 看门狗双重守护拉起"],
            ["control_station.py", "Python 3.12",
             "Web 控制台、大模型意图解析、RAG 知识库、场景编排、插件宿主、鉴权、容灾备份",
             "非实时：允许百毫秒级波动", "可容忍：微内核以最后有效帧继续推流，演出不黑场"],
        ])

    add_h2(d, "2.2 共享内存槽位划分")
    add_table_data(d,
        ["共享内存文件", "用途", "写入方", "读取方"],
        [
            ["/dev/shm/aima_slot_l1", "安全层：急停、黑场、物理熔断", "Python 业务层", "实时微内核"],
            ["/dev/shm/aima_slot_l2", "设备基础层：静态预设、灯库底态", "Python 业务层", "实时微内核"],
            ["/dev/shm/aima_slot_l3", "创意层：宏插件、特效、音频节拍", "插件宿主", "实时微内核"],
            ["/dev/shm/aima_slot_l4", "台面层：控台接管、Crossfade 淡变", "Python 业务层", "实时微内核"],
            ["/dev/shm/aima_core_state", "全局只读状态：合成帧 + 8MB 安全查找表",
             "实时微内核（独占）", "Python 业务层（只读）"],
        ])
    add_p(d, "按层级拆分物理文件的根本目的是权限隔离：3 类插件只被授予 L3 文件的写权限，"
             "即使插件被恶意构造，也无法越界篡改 L1 安全层——这是靠操作系统文件权限实现的物理边界，"
             "而非应用层约定。")

    # ================= 第 3 章 =================
    add_h1(d, "第 3 章 共享内存 ABI 契约（实装定稿）")
    add_callout(d,
        "【ABI 兼容性警告】历史文档中 aima_channel_safety_rule_t 只有单组 danger_min/danger_max，"
        "且未定义遥测事件结构体。实装版本已演进为「最多 4 组不连续危险区间」+"
        "「128 字节对齐四维遥测事件」+「缓存行对齐原子包装器」。"
        "任何实现必须以下方定义为准，否则与运行中的内核 ABI 不兼容。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))
    add_code_block(d, """
#pragma once
#include <stdint.h>
#include <stdalign.h>
#include <stdbool.h>

#define AIMA_MAX_UNIVERSES       64
#define AIMA_DMX_CHANNELS        512
#define AIMA_TELEMETRY_CAPACITY  4096

/* 64 字节缓存行对齐原子包装器（消除多核伪共享 False Sharing） */
typedef struct { alignas(64) volatile uint32_t val; } aima_cache_aligned_u32_t;
typedef struct { alignas(64) volatile uint8_t  val; } aima_cache_aligned_u8_t;

/* 1. 物理安全规则：单通道最多 4 组不连续危险区间 */
typedef struct { uint8_t min_val; uint8_t max_val; } aima_danger_range_t;

typedef struct {
    uint8_t enabled;            /* 0=普通直通, 1=启用危险区间硬件防护 */
    uint8_t safe_fallback_val;  /* 命中危险区间时的安全替代值（默认 0） */
    uint8_t range_count;        /* 当前生效区间数 (0~4) */
    uint8_t reserved;           /* 4 字节对齐填充 */
    aima_danger_range_t danger_ranges[4];
} aima_channel_safety_rule_t;

/* 2. 按层级物理独立的共享内存槽位 (/dev/shm/aima_slot_l1 ~ l4) */
typedef struct {
    aima_cache_aligned_u32_t write_seq;            /* 顺序锁：偶数稳定可读，奇数写入中 */
    aima_cache_aligned_u8_t  active_buf_idx;       /* 当前可读双缓冲索引 (0 或 1) */
    volatile uint64_t        frame_index;
    volatile uint64_t        update_timestamp_ns;
    uint8_t dmx_buffers[2][AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];
    uint8_t active_mask[2][AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];
} aima_layer_shm_slot_t;

/* 3. 微内核全局只读状态 + O(1) 无分支安全钳位查找表 */
typedef struct {
    aima_cache_aligned_u32_t state_seq;
    volatile uint64_t        rt_frame_index;
    volatile uint64_t        rt_timestamp_ns;
    volatile uint32_t        last_jitter_ns;
    volatile uint32_t        active_universe_count;
    uint8_t final_merged[AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS];
    uint8_t safety_lut[AIMA_MAX_UNIVERSES][AIMA_DMX_CHANNELS][256];
} aima_core_state_shm_t;

/* 4. 四维遥测事件结构体（定长，128 字节对齐） */
typedef struct alignas(128) {
    uint64_t timestamp_ns;
    uint8_t  tier;        /* 0=Kernel, 1=System, 2=Adapter, 3=Community */
    uint8_t  level;       /* 1=INFO, 2=WARN, 3=ERROR, 4=FATAL */
    uint16_t category;
    uint32_t source_id;
    uint32_t latency_ns;
    uint8_t  message[108];
} aima_telemetry_entry_t;

/* 5. 实时微内核独占 SPSC 遥测无锁环形队列 */
typedef struct alignas(128) {
    aima_cache_aligned_u32_t head;
    aima_cache_aligned_u32_t tail;
    uint32_t                 capacity;
    alignas(128) aima_telemetry_entry_t entries[AIMA_TELEMETRY_CAPACITY];
} aima_telemetry_ring_t;
""", size=7.5)

    add_h2(d, "3.1 顺序锁读写协议（必须严格遵守）")
    add_p(d, "所有槽位读写必须遵守顺序锁协议，否则会出现撕裂读——读到写者改到一半的半个帧，"
             "表现为舞台灯光随机闪烁。这是最容易被误实现的一处。")
    add_code_block(d, """
/* 写入方：写前自增为奇数，写后自增为偶数 */
write_seq += 1;                       /* 奇数：写入中 */
atomic_thread_fence(RELEASE);
memcpy(slot->dmx_buffers[buf], frame, sizeof(frame));
atomic_thread_fence(RELEASE);
write_seq += 1;                       /* 偶数：稳定可读 */

/* 读取方：序列号稳定且前后一致才采用 */
uint32_t s1, s2;
do {
    s1 = read_seq;
    if (s1 & 1u) continue;            /* 奇数：正在写入，立即重试 */
    atomic_thread_fence(ACQUIRE);
    memcpy(frame, slot->dmx_buffers[buf], sizeof(frame));
    atomic_thread_fence(ACQUIRE);
    s2 = read_seq;
} while (s1 != s2);
""", size=7.5)

    # ================= 第 4 章 =================
    add_h1(d, "第 4 章 微内核调度、四级仲裁与推流实现")
    add_h2(d, "4.1 实时调度参数")
    add_table_data(d,
        ["项目", "实装参数", "源码位置"],
        [
            ["主循环频率", "44Hz（22.7ms），nano-sleep 补齐 + 自适应补偿", "aima-rt-daemon/src/main.rs"],
            ["时钟源", "CLOCK_MONOTONIC，绝对时间点调度避免累积漂移", "aima-rt-daemon/src/main.rs"],
            ["CPU 绑定", "CPUAffinity=3", "aima-rt.service"],
            ["实时调度", "SCHED_FIFO 优先级 98，Nice=-20，IOSchedulingClass=realtime", "aima-rt.service"],
            ["内存锁定", "mlockall(MCL_CURRENT | MCL_FUTURE)", "aima-rt-daemon/src/main.rs"],
            ["心跳看门狗", "WatchdogSec=1s", "aima-rt.service"],
        ])

    add_h2(d, "4.2 四级仲裁与 O(1) 安全钳位")
    add_table_data(d,
        ["优先级", "层级", "业务信号源", "仲裁规则"],
        [
            ["最高", "L1 安全层", "急停、黑场、物理熔断", "无条件压制一切，强制归零或安全值"],
            ["高", "L4 台面层", "grandMA3 / 外部实体控台接管", "压制 L3 与 L2，灯光师手动优先"],
            ["中", "L3 创意层", "宏插件、呼吸特效、音频节拍", "压制 L2，被 L1/L4 覆盖"],
            ["基础", "L2 设备基底层", "静态预设、快捷场景", "仅提供底态，被所有上层覆盖"],
        ])
    add_p(d, "安全钳位不使用分支判断，而是把「危险区间规则」在共享内存中预展开为 "
             "safety_lut[64][512][256] 查找表（约 8MB）。运行时只需一次数组索引即可得到安全输出值，"
             "实现 O(1) 零分支耗时钳位——这在 44Hz 硬实时路径上是必要的，"
             "分支预测失败带来的抖动不可接受。")

    add_h2(d, "4.3 sendmmsg 批量推流与微突发整形")
    add_p(d, "64 个 Universe 若逐个 sendto() 需要 64 次系统调用与上下文切换。"
             "实装改用 sendmmsg()，一次系统调用提交包含多个 mmsghdr 的数组。"
             "同时引入微突发流量整形与 DSCP EF 高优先级标记，避免 40 微秒内倾泻 64 个 UDP 包"
             "撑爆末端廉价 Art-Net 解码盒的接收缓冲区。")

    add_h2(d, "4.4 运行期内核看门狗")
    add_p(d, "v5.0 只在启动时做一次健康检查，微内核中途死亡时控制台毫无察觉——"
             "这是真实发生过的演出事故。v5.3 增加常驻看门狗线程：")
    add_table_data(d,
        ["场景", "判定条件", "系统动作", "故障码"],
        [
            ["A 内核死亡", "探测不到微内核进程", "记录故障并按预算重启", "ERR-KERNEL-DAEMON"],
            ["B 内核停摆", "进程存活但帧计数连续 N 次不推进", "杀掉僵死进程并按预算重启", "ERR-KERNEL-STALL"],
            ["C 恢复正常", "帧计数重新推进", "重置重启预算，回到监控态", "无告警，仅 INFO"],
        ])
    add_table_data(d,
        ["环境变量", "默认值", "含义"],
        [
            ["AIMA_WATCHDOG_INTERVAL_SEC", "5.0", "探测间隔（秒）"],
            ["AIMA_WATCHDOG_MAX_RESTART", "5", "最大自动重启次数，超出后停止重启并持续告警"],
            ["AIMA_WATCHDOG_STALL_LIMIT", "3", "连续多少次探测帧计数不推进即判定停摆"],
            ["AIMA_RT_EXTERNAL", "未设置", "设为 1 表示微内核由 systemd 托管，Python 层不拉起也不重启"],
        ])

    # ================= 第 5 章 =================
    add_h1(d, "第 5 章 PyO3 零拷贝 Python SDK")
    add_table_data(d,
        ["项目", "实装内容"],
        [
            ["crate", "crates/aima-shm-sdk，版本 5.3.0，crate-type = [cdylib]"],
            ["PyO3", "0.23.5，features = [extension-module, abi3-py310]"],
            ["ABI 策略", "abi3-py310 稳定 ABI：单个扩展文件可被 Python 3.10 及以上所有版本加载，"
                        "无需为每个小版本重编译"],
            ["产物命名", "Windows 为 aima_shm_sdk.pyd（由 .dll 改名）；Linux 为 libaima_shm_sdk.so"],
            ["部署位置", "发布包根目录与 core/ 各一份"],
            ["Python 封装", "core/kernel_bridge.py 的 AimaKernelBridge 类"],
            ["硬依赖", "numpy（缺失时控制台无法启动，构建脚本会预先探测解释器是否具备 numpy）"],
        ])

    # ================= 第 6 章 =================
    add_h1(d, "第 6 章 遥测与全链路可观测性")
    add_h2(d, "6.1 SPSC 无锁遥测环")
    add_p(d, "遥测使用单生产者单消费者无锁环形队列，head 与 tail 各自独占一条 64 字节缓存行。"
             "若二者位于同一缓存行，写入 head 会导致读取方的缓存行失效，"
             "引发伪共享性能崩塌。写入权限严格限定给微内核实时主线程独占。")

    add_h2(d, "6.2 插件装载可观测性")
    add_p(d, "用户界面隐匿 1/2 类插件之后，一度出现「底座插件到底加载成功没有」无从判断的问题，"
             "且「源文件中没有可实例化插件类」这条路径完全静默。v5.3 已修复："
             "启动日志输出分层装载总览，四条失败路径全部显式登记，"
             "并提供 GET /api/plugins/diagnostics 结构化诊断接口（需 admin 角色）。")

    add_h2(d, "6.3 鉴权噪音抑制")
    add_p(d, "把每一次 401 都记为 ERROR 级故障告警，会让真正的令牌爆破淹没在日常注销噪音中，"
             "导致安全性下降。v5.3 改为分级判定：")
    add_table_data(d,
        ["情形", "级别", "告警"],
        [
            ["未携带令牌", "DEBUG", "否（低于持久化级别 INFO，不落盘）"],
            ["令牌已失效", "INFO", "否"],
            ["10 秒内超过 20 次未授权", "ERROR", "是，ERR-AUTH-BRUTEFORCE（30 秒冷却）"],
            ["令牌有效但权限不足", "ERROR", "是，ERR-AUTH-DENIED"],
        ])

    # ================= 第 7 章 =================
    add_h1(d, "第 7 章 Debian PREEMPT_RT 加固与抗抖动基准")
    add_p(d, "微内核的实时性依赖内核层面配合，仅靠应用层 SCHED_FIFO 无法真正独占 CPU。"
             "以下为 Debian 12/13 的完整启动参数：")
    add_code_block(d,
        "GRUB_CMDLINE_LINUX_DEFAULT=\"isolcpus=domain,managed_irq,3 "
        "nohz_full=3 rcu_nocbs=3 irqaffinity=0-2 max_cstate=0\"", size=9)
    add_table_data(d,
        ["参数", "作用"],
        [
            ["isolcpus=domain,managed_irq,3", "隔离 Core 3，并强制把内核硬件中断（IRQ）移离该核"],
            ["nohz_full=3", "关闭 Core 3 上的时钟滴答中断，消除操作系统自身抖动"],
            ["rcu_nocbs=3", "把 RCU 软中断回调移出 Core 3"],
            ["irqaffinity=0-2", "把所有硬件中断绑定到 Core 0 至 2"],
            ["max_cstate=0", "禁用 CPU 节能降频，保持 Core 3 持续运行于最高标称频率"],
        ])
    add_callout(d,
        "【部署提示】未配置上述内核参数时，微内核仍可运行，但抖动无法保证在 100 微秒以内，"
        "演出高负载场景下可能出现可见闪烁。请在交付前确认目标机器的 GRUB 配置已生效"
        "（可通过 cat /proc/cmdline 核验）。",
        fill="FFFBEB", border="D97706", color=(180, 83, 9))

    # ================= 第 8 章 =================
    add_h1(d, "第 8 章 三层插件物理隔离体系")
    add_table_data(d,
        ["层级", "基类", "目录", "用户可见", "可否卸载", "失效后果"],
        [
            ["1 类·系统级", "BaseProtocolPlugin / BaseLLMPlugin", "plugins/system/", "否", "禁止",
             "致命：无任何物理输出"],
            ["2 类·适配级", "BaseAdapterPlugin", "plugins/adapters/", "否", "禁止",
             "严重：无法导入控台灯库资产"],
            ["3 类·表现创意", "BaseMacroPlugin / BasePerceptionPlugin", "plugins/community/", "是",
             "支持热卸载", "轻微：仅该插件特效失效"],
        ])
    add_callout(d,
        "【设计红线】只有 3 类插件允许出现在用户界面与 /api/plugins/installed 接口中。"
        "过滤必须做在接口层——前端隐藏随时可能被绕过，接口过滤才是物理边界。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))
    add_p(d, "插件还运行在独立的进程级沙箱中（aima-worker-sandbox crate），"
             "沙箱异常不会击穿主循环。注意：这是进程级沙箱，不是规划文档中所述的 "
             "Wasmtime 指令级熔断——两者隔离强度有本质差异，不可混为一谈。")

    add_h2(d, "8.1 实装插件全量清单（共 9 个，以代码为准）")
    add_table_data(d,
        ["层级", "插件 id（日志检索用）", "源码文件"],
        [
            ["1 类", "protocol_artnet_standard", "plugins/system/artnet_plugin.py"],
            ["1 类", "protocol_sacn_standard", "plugins/system/sacn_plugin.py"],
            ["1 类", "llm_local_qwen_7b", "plugins/system/qwen_plugin.py"],
            ["1 类", "system_log_ai_repair", "plugins/system/system_log_ai_repair_plugin.py"],
            ["2 类", "adapter_ma_fixture", "plugins/adapters/ma_fixture_adapter.py"],
            ["3 类", "macro_breathing", "plugins/community/breathing_plugin.py"],
            ["3 类", "macro_marquee", "plugins/community/marquee_plugin.py"],
            ["3 类", "perception_audio_beat_sim", "plugins/community/perception_audio_beat_sim.py"],
            ["3 类", "show_evolution_learning", "plugins/community/show_evolution_learning_plugin.py"],
        ])
    add_p(d, "注意插件 id 与源码文件名**并不相同**（例如 id 为 macro_breathing，"
             "文件名为 breathing_plugin.py）。排查问题用 id 检索日志，用文件名定位源码。")

    # ================= 第 9 章 =================
    add_h1(d, "第 9 章 发布流水线与交付 SOP")
    add_h2(d, "9.1 流水线阶段")
    add_table_data(d,
        ["阶段", "位置", "动作"],
        [
            ["1 基线校验", "开发机", "检查核心模块、SDK、内核二进制齐备，缺失即 FATAL 退出"],
            ["2 前端构建", "开发机", "AST 混淆 + 字符串池加密 + 压缩"],
            ["3 后端组装", "开发机", "复制 core/ 与主入口"],
            ["4 内核构件", "开发机", "复制 bin/ 与 aima_shm_sdk 到根目录与 core/，chmod 0755"],
            ["5 部署脚本", "开发机", "生成 build_debian.sh、aima-rt.service、ai-ma.service"],
            ["6 完整性校验", "开发机", "verify_release_package() 强校验，任一失败即终止"],
            ["7 Cython 编译", "Debian", "编译核心模块为 .so"],
            ["8 Rust 编译", "Debian", "cargo build --release -p aima-rt-daemon -p aima-shm-sdk"],
            ["9 源码抹除", "Debian", "物理删除已编译成功的 .py，执行最终完整性门禁"],
        ])

    add_h2(d, "9.2 双 systemd 单元")
    add_p(d, "以下单元内容由 tools/build_release.py 的模板常量直接生成，"
             "与交付包中的实际工件逐字一致（文档不再手抄，避免与代码脱节）。")
    _br = _load_build_release()
    _rt = _br.AIMA_RT_SERVICE.replace("@@VERSION@@", _br.VERSION).rstrip()
    _app = _br.AI_MA_SERVICE.replace("@@VERSION@@", _br.VERSION).rstrip()
    add_code_block(d, "# 单元 1：/etc/systemd/system/aima-rt.service（硬实时微内核，最先启动）\n"
                      + _rt + "\n\n"
                      "# 单元 2：/etc/systemd/system/ai-ma.service（Python 业务控制台）\n"
                      + _app, size=7.5)
    add_p(d, "部署必须按顺序，微内核先行：")
    add_code_block(d,
        "sudo cp aima-rt.service ai-ma.service /etc/systemd/system/\n"
        "sudo systemctl daemon-reload\n"
        "sudo systemctl enable --now aima-rt.service\n"
        "sudo systemctl enable --now ai-ma.service", size=9)
    add_callout(d,
        "【致命陷阱】AIMA_RT_EXTERNAL=1 必须设置。若 Python 层不知道微内核已由 systemd 托管，"
        "它会自行再拉起一个微内核进程，两个内核争抢同一组 /dev/shm 槽位，"
        "将造成灾难性的数据错乱与随机闪灯。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))

    # ================= 第 10 章 =================
    add_h1(d, "第 10 章 实施路线图与未启动事项")
    add_h2(d, "10.1 阶段完成情况")
    add_table_data(d,
        ["阶段", "原规划内容", "实际状态"],
        [
            ["阶段 1", "aima_shm 共享内存协议、aima-rt-daemon 调度骨架、POSIX RT 时钟、"
                     "与 Python 跨进程解耦", "已完成并超出范围：四级仲裁、安全钳位、"
                     "批量推流、遥测环均已实装"],
            ["阶段 2", "PyO3 构建 aima-shm-sdk、Python 无缝对接、1/2/3 类插件总线与沙箱",
             "SDK 与三层插件已完成；沙箱为进程级（非 Wasm 指令级）；"
             "llama.cpp 独立服务与 FastAPI 控制台未启动"],
            ["阶段 3", "build_kernel.py 流水线、core.squashfs 密封、dm-verity、"
                     "A/B 槽位与 30 秒看门狗回退", "未启动。当前发布包为普通目录结构，"
                     "bin/ 未密封，无 A/B 槽位"],
            ["阶段 4", "Debian 物理机集成压测：64 Universe 满载、抖动小于 100 微秒、"
                     "断电恢复验证", "部分完成。抖动与推流已有本机验证；"
                     "Debian 物理机满载压测与断电恢复尚未执行"],
        ])

    add_h2(d, "10.2 未启动事项清单（可作为新建任务包）")
    add_table_data(d,
        ["编号", "事项", "技术要点", "前置依赖"],
        [
            ["P3-1", "SquashFS 只读镜像密封", "core.squashfs + dm-verity 校验后挂载，"
                                            "bin/ 封装进镜像内部", "需要 Debian 构建环境"],
            ["P3-2", "A/B 双槽位原子 OTA", "slot_a/slot_b 自闭环 + Ed25519 验签 + "
                                        "renameat2(RENAME_EXCHANGE) 原子切换", "P3-1"],
            ["P3-3", "30 秒回退看门狗", "systemd fallback 服务在自检超时后切回原槽位", "P3-2"],
            ["P2-1", "Wasmtime 指令级沙箱", "Fuel 步数配额 + Epoch 3ms 中断熔断，"
                                          "替换现有进程级沙箱", "需评估对插件生态的兼容影响"],
            ["P2-2", "llama.cpp 独立推理服务", "原生编译 + Unix Domain Socket 异步交互，"
                                             "替换 Ollama HTTP 适配", "需确定目标模型与量化格式"],
            ["P2-3", "FastAPI + uvloop 控制台", "替换标准库 http.server，"
                                              "提升并发与流式遥测能力", "需完整回归现有接口契约"],
            ["P4-1", "Debian 物理机满载压测", "64 Universe 满载、抖动统计、"
                                            "死循环注入旁路熔断、断电恢复", "需要目标硬件"],
        ])
    add_p(d, "建议的分工顺序：P3-1 至 P3-3 是一条完整链路，必须由同一人负责；"
             "P2-1 与 P2-3 相互独立可并行；P4-1 需要硬件到位后才能启动。"
             "详见配套文档《AI-MA v5.3 开发分工与任务分解书》。")

    # ================= 附录 =================
    add_h1(d, "附录 A 测试准出矩阵")
    add_p(d, "下表的断言数取自各测试套件**自报的实际执行总数**"
             "（运行输出的「N/N 全部通过」），而不是静态代码统计——"
             "静态统计会漏掉循环内的断言，也会把裸 assert 型套件算成 0。")
    add_table_data(d,
        ["测试脚本", "断言数", "覆盖内容", "需独占端口"],
        [
            ["tests/test_aima53_standalone_system.py", "5",
             "桥接可用性、内核模式锁定、三层隔离、L4 写入（裸 assert 型，无自报汇总）", "否"],
            ["tests/test_plugin_observability.py", "31", "分层日志、四类失败路径登记、故障码、诊断报告", "否"],
            ["tests/test_auth_noise_suppression.py", "28", "注销零噪音、突发仍告警、登录失败告警、前端闩锁", "是"],
            ["tests/test_aima53_boot_e2e.py", "32", "双进程启动、日志基线、鉴权、插件零泄漏、遥测、孤儿回收", "是"],
            ["tests/test_kernel_watchdog.py", "17", "真杀内核后看门狗自动拉起与静态接线核验", "是"],
            ["tests/test_release_package_integrity.py", "35", "真实构建、产物强校验、真实启动发布包", "是"],
            ["合计", "148", "全部通过（实测耗时约 33 秒）", ""],
        ])
    add_callout(d,
        "【测试纪律】所有需要独占端口的测试均带独占性前置检查：检测到已有实例在运行时"
        "以退出码 2 礼貌跳过，绝不为了自身方便而杀死用户正在使用的进程。"
        "该纪律源于一次真实事故——早期测试曾 taskkill 掉用户正在运行的微内核。",
        fill="FFFBEB", border="D97706", color=(180, 83, 9))

    d.save(OUT)
    print(f"[OK] 已生成: {OUT}")
    v = Document(OUT)
    print(f"     段落 {len(v.paragraphs)} | 表格 {len(v.tables)}")


if __name__ == "__main__":
    main()
