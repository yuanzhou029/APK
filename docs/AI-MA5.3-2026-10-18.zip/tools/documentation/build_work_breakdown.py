# -*- coding: utf-8 -*-
"""
生成《AI-MA v5.3 开发分工与任务分解书》

面向并行开发的派工依据，包含：
  - 工作包分解（WBS）与编号、负责人角色、工作量粗估、依赖关系、可并行分组
  - 既有模块的交接包（范围 / 接口契约 / 不得修改的边界）
  - 新建任务包（未实装事项，可直接作为新建任务）
  - 跨模块接口契约汇总（ABI / Python API / 插件 SDK / HTTP API / systemd）
  - 每个工作包的可执行验收标准（绑定到具体测试脚本与断言）

输出: D:\\python项目文件\\AI-MA_v5.3开发分工与任务分解书.docx
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx_style import (add_p, add_h1, add_h2, add_h3, add_code_block,
                        add_table_data, add_callout, CN_FONT)

OUT = r"D:\python项目文件\AI-MA_v5.3开发分工与任务分解书.docx"
NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia"


def center_run(d, text, size, bold=False, color=(15, 23, 42), after=6, before=0):
    p = d.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(before)
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    r.font.name = CN_FONT
    r.font.color.rgb = RGBColor(*color)
    r._r.get_or_add_rPr().set(NS, CN_FONT)
    return p


def cover(d):
    center_run(d, "AI-MA 异构协同与自适应灯光操作系统", 20, True, (15, 23, 42), 4, 100)
    center_run(d, "v5.3 开发分工与任务分解书", 24, True, (2, 132, 199), 20)
    for line, size, color in [
        ("Work Breakdown Structure & Interface Contracts", 12, (71, 85, 105)),
        ("依据基线：《AI-MA 操作系统 v5.3 硬实时微内核架构实装白皮书》", 10, (71, 85, 105)),
        ("版本 5.3.0 | 文档状态：派工执行依据", 10, (71, 85, 105)),
        ("本文件用于并行开发派工，任何任务分配不得与本文件的接口契约冲突", 10, (185, 28, 28)),
    ]:
        center_run(d, line, size, False, color)
    d.add_page_break()

    add_callout(d,
        "【使用说明】本文件把 v5.3 的剩余工作拆成可独立派发的工作包。"
        "每个工作包都给出了负责人角色、依赖关系、可并行分组，以及绑定到具体测试脚本的验收标准。"
        "派工时请连同《v5.3 硬实时微内核架构实装白皮书》一并交付——"
        "白皮书定义「系统是什么样」，本文件定义「谁在什么时候做什么、做完怎么算通过」。",
        fill="EFF6FF", border="1D4ED8", color=(29, 78, 216))


def main():
    d = Document()
    cover(d)

    # ==================== 第 1 章 ====================
    add_h1(d, "第 1 章 分工总则")

    add_h2(d, "1.1 四条不可动摇的分工原则")
    for i, t in enumerate([
        "接口先行，实现其次。每个工作包开工前必须先把跨模块接口（共享内存 ABI、Python 调用签名、"
        "HTTP 路径与响应结构、插件抽象方法）写进本文件的第 5 章并冻结；接口冻结后任何变更需走变更记录。",
        "一个模块只有一个负责人。同一文件不允许两人同时改动。"
        "跨模块需求通过接口调用完成，不允许直接改别人的内部实现。",
        "测试即验收。每个工作包的完成标准是「指定测试脚本全部通过」，"
        "而不是「代码写完了」。新增能力必须同时新增断言。",
        "不得把规划当既有。白皮书第 10 章列出的未实装事项，"
        "在对应工作包完成前不得在文档或代码中被描述为已具备能力。",
    ], 1):
        add_p(d, f"{i}. {t}")

    add_h2(d, "1.2 角色定义")
    add_table_data(d,
        ["角色代号", "职责范围", "能力要求", "对应工作包"],
        [
            ["RUST", "硬实时微内核与共享内存协议", "Rust 2021、无锁并发、Linux 实时调度、内存屏障",
             "WP-A、P2-1"],
            ["BRIDGE", "PyO3 扩展与 Python 侧桥接", "PyO3、abi3 稳定 ABI、Python C 扩展构建、numpy",
             "WP-B"],
            ["PYCORE", "Python 业务控制台与引擎", "Python 3.12、http.server、多线程、numpy",
             "WP-C、P2-3"],
            ["PLUGIN", "插件宿主、三层生态与插件开发", "Python 插件架构、反射、抽象基类契约",
             "WP-D、P4-2"],
            ["FRONT", "Web 前端与交互", "原生 JS、DOM、轮询与幂等控制、构建混淆",
             "WP-E"],
            ["BUILD", "发布流水线、Debian 编译与部署", "Cython、cargo 交叉构建、systemd、Shell",
             "WP-F、P3-1、P3-2、P3-3"],
            ["QA", "准出测试与现场压测", "自动化测试、实时性能测量、故障注入",
             "WP-G、P4-1"],
        ])
    add_p(d, "注：小团队可由一人兼任多个角色，但 WP-A（Rust 微内核）与 WP-C（Python 核心）"
             "必须由不同的人负责——这两个模块的接口正是整个架构的分界线，"
             "由同一人负责会失去接口约束的意义。")

    add_h2(d, "1.3 关键路径与并行分组")
    add_p(d, "依赖关系决定了并行上限。当前存在两条互不干扰的主线，可立即并行开工：")
    add_table_data(d,
        ["并行组", "工作包", "说明"],
        [
            ["组 1（加固线）", "P3-1 → P3-2 → P3-3", "不可拆分，同一条链路必须同一负责人，"
                                                    "中途换人风险极高"],
            ["组 2（服务线）", "P2-2 与 P2-3", "相互独立，可两人并行"],
            ["组 3（沙箱线）", "P2-1", "独立，但需评估对现有插件生态的兼容影响"],
            ["组 4（硬件线）", "P4-1", "需目标硬件到位后才能启动"],
            ["组 5（维护线）", "WP-A 至 WP-G", "既有模块的交接与维护，可随时并行"],
        ])
    add_callout(d,
        "【并行纪律】WP-A（Rust 微内核）与 WP-B（Python 桥接）共享 aima_shm.h 契约。"
        "任何一方修改结构体定义，必须同步另一方并重跑 WP-G 的全量回归，"
        "否则会出现内存布局错位——这类缺陷表现为随机闪灯，极难现场定位。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))

    # ==================== 第 2 章 ====================
    add_h1(d, "第 2 章 工作包总览")
    add_p(d, "工作包分两类：WP 开头为既有实装模块的交接包（维护与演进），"
             "P 开头为新建任务包（尚未实装）。工作量为粗估人日，仅供排期参考，"
             "实际以负责人评估为准。")
    add_table_data(d,
        ["编号", "名称", "角色", "工作量粗估", "依赖", "并行组"],
        [
            ["WP-A", "硬实时微内核维护与演进", "RUST", "持续", "无", "5"],
            ["WP-B", "PyO3 桥接与 SDK 维护", "BRIDGE", "持续", "WP-A 契约", "5"],
            ["WP-C", "Python 业务控制台维护", "PYCORE", "持续", "WP-B 接口", "5"],
            ["WP-D", "插件宿主与三层生态", "PLUGIN", "持续", "WP-C", "5"],
            ["WP-E", "Web 前端维护", "FRONT", "持续", "WP-C 接口", "5"],
            ["WP-F", "发布流水线与部署", "BUILD", "持续", "全部模块", "5"],
            ["WP-G", "准出测试体系维护", "QA", "持续", "全部模块", "5"],
            ["P2-1", "Wasmtime 指令级沙箱替换", "RUST", "15 至 25", "WP-D 评估", "3"],
            ["P2-2", "llama.cpp 独立推理服务", "PYCORE", "10 至 15", "无", "2"],
            ["P2-3", "FastAPI 控制台迁移", "PYCORE", "15 至 20", "接口冻结", "2"],
            ["P3-1", "SquashFS 只读镜像密封", "BUILD", "8 至 12", "Debian 环境", "1"],
            ["P3-2", "A/B 双槽位原子 OTA", "BUILD", "10 至 15", "P3-1", "1"],
            ["P3-3", "30 秒回退看门狗", "BUILD", "5 至 8", "P3-2", "1"],
            ["P4-1", "Debian 物理机满载压测", "QA", "8 至 12", "目标硬件", "4"],
            ["P4-2", "插件生态扩充", "PLUGIN", "按需", "WP-D", "5"],
        ])

    # ==================== 第 3 章 ====================
    add_h1(d, "第 3 章 既有模块交接包")

    add_h2(d, "3.1 WP-A 硬实时微内核（RUST）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "crates/aima-rt-daemon（main.rs / arbitrator.rs / batch_network.rs）、"
                        "crates/aima-shm（lib.rs）、include/aima_shm.h"],
            ["核心职责", "44Hz 主循环、四级仲裁、O(1) 安全钳位、sendmmsg 批量推流、"
                        "SPSC 遥测写入、顺序锁读写"],
            ["对外契约", "仅通过 /dev/shm 共享内存与 include/aima_shm.h 结构体定义对外交互。"
                        "不得引入任何网络接口或文件协议作为对 Python 的通信方式。"],
            ["不得修改", "aima_shm.h 中的结构体字段顺序与对齐（alignas 值）。"
                        "改动会破坏与已编译 Python 扩展的二进制兼容。"],
            ["验收标准", "tests/test_aima53_standalone_system.py 全部通过；"
                        "tests/test_aima53_boot_e2e.py 中遥测帧计数与抖动断言通过；"
                        "cargo build --release 无警告升级为错误"],
        ])

    add_h2(d, "3.2 WP-B PyO3 桥接与 SDK（BRIDGE）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "crates/aima-shm-sdk/src/lib.rs、pyproject.toml、以及发布包中的 "
                        "aima_shm_sdk.pyd / libaima_shm_sdk.so"],
            ["核心职责", "把共享内存槽位与核心状态暴露为 Python 可调用接口，保持零拷贝语义"],
            ["对外契约", "core/kernel_bridge.py 的 AimaKernelBridge 类。"
                        "get_rt_metrics() 必须返回 (frame_index:int, timestamp_ns:int, jitter_ns:int) "
                        "三个 Python 原生整数——不得返回 numpy 标量，否则 JSON 序列化会失败。"],
            ["不得修改", "abi3-py310 特性。移除会导致扩展无法跨 Python 小版本加载。"],
            ["验收标准", "tests/test_aima53_standalone_system.py 桥接断言通过；"
                        "tests/test_aima53_boot_e2e.py 的遥测接口断言通过"
                        "（含「仲裁后通道采样为纯 Python 整型列表」断言）"],
        ])
    add_callout(d,
        "【历史缺陷记录】遥测接口曾因返回 numpy.uint8 标量导致 json.dumps 抛异常，"
        "表现为控制台 RemoteDisconnected。修复方式是在桥接层做强转 int()。"
        "改动此处时必须保留 tests 中的整型列表断言。",
        fill="FFFBEB", border="D97706", color=(180, 83, 9))

    add_h2(d, "3.3 WP-C Python 业务控制台（PYCORE）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "control_station.py、core/ 下除 plugin_host.py 与 plugin_sdk.py 外的全部模块"],
            ["核心职责", "HTTP 控制台、鉴权、场景编排、RAG 知识库、容灾备份、微内核看门狗、"
                        "遥测读取与转发"],
            ["对外契约", "HTTP 接口（见第 5.4 节）。所有 /api/* 读写接口必须经统一鉴权闸门，"
                        "未授权一律 401 并走分级日志。"],
            ["不得修改", "运行期内核看门狗的判定逻辑与 AIMA_RT_EXTERNAL 短路语义。"
                        "这两处是防止双内核与内核失联事故的防线。"],
            ["验收标准", "tests/test_aima53_boot_e2e.py 32 项全部通过；"
                        "tests/test_kernel_watchdog.py 17 项全部通过；"
                        "tests/test_auth_noise_suppression.py 28 项全部通过"],
        ])

    add_h2(d, "3.4 WP-D 插件宿主与三层生态（PLUGIN）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "core/plugin_host.py、core/plugin_sdk.py、plugins/ 三个子目录、"
                        "marketplace/plugin_catalog.json"],
            ["核心职责", "插件装载与生命周期、三层物理隔离过滤、抽象契约校验、"
                        "分层装载日志、失败登记、诊断报告接口"],
            ["对外契约", "插件抽象方法契约（见第 5.3 节）。"
                        "/api/plugins/installed 只返回 3 类；"
                        "/api/plugins/diagnostics 返回全部三层（需 admin）。"],
            ["不得修改", "plugin_host 中四类失败路径的日志记录。"
                        "删除任一条会重新引入静默盲区——底座插件失效将查无实据。"],
            ["验收标准", "tests/test_plugin_observability.py 31 项全部通过"],
        ])

    add_h2(d, "3.5 WP-E Web 前端（FRONT）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "web/assets/app.js、web/assets/theme.css、web/login.html、web/index.html"],
            ["核心职责", "控制台界面、参数动态渲染、轮询与状态同步"],
            ["对外契约", "仅通过 HTTP 接口与后端交互，不得在前端做业务校验之外的权限判断"],
            ["不得修改", "forceLogout() 的幂等闩锁与 poll() 定时器登记机制。"
                        "移除会重新引入注销自我请求风暴（一次注销产生数十条虚假告警）。"],
            ["验收标准", "tests/test_auth_noise_suppression.py 的前端静态核验 5 项通过；"
                        "构建产物混淆成功"],
        ])

    add_h2(d, "3.6 WP-F 发布流水线与部署（BUILD）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "tools/build_release.py、一键生成发布包.bat、deploy/ 下全部工件"],
            ["核心职责", "基线校验、前端混淆、内核构件复制、部署脚本生成、完整性门禁"],
            ["对外契约", "生成两个 systemd 单元（见第 5.5 节）。"
                        "两个单元模板必须以 build_release.py 为唯一真源，"
                        "不得手工维护 deploy/ 下的副本。"],
            ["不得修改", "validate_build_baseline() 的快速失败语义与 "
                        "verify_release_package() 的门禁清单。放宽门禁会产出残缺发布包。"],
            ["验收标准", "tests/test_release_package_integrity.py 35 项全部通过"
                        "（含真实构建与真实启动发布包）"],
        ])

    add_h2(d, "3.7 WP-G 准出测试体系（QA）")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["交付范围", "tests/ 目录下全部测试脚本"],
            ["核心职责", "维护 148 项断言的准出矩阵；新增能力时同步新增断言"],
            ["纪律要求", "所有需要独占端口的测试必须带独占性前置检查，"
                        "检测到已有实例时以退出码 2 跳过，绝不 taskkill 他人进程。"
                        "曾因违反此纪律杀死过用户正在运行的微内核。"],
            ["日志读取纪律", "增量读取日志必须用字节偏移（open(..., 'rb') + seek），"
                          "不能用 os.path.getsize 配合字符切片——中文日志每字 3 字节，"
                          "按字符切会跳过大段内容并导致误判。"],
            ["验收标准", "6 套测试全部通过，合计 148 项断言；"
                        "运行结束后零残留微内核进程、端口 9000 已释放"],
        ])

    # ==================== 第 4 章 ====================
    add_h1(d, "第 4 章 新建任务包（尚未实装）")

    add_h2(d, "4.1 P3-1 SquashFS 只读镜像密封")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "把微内核二进制的启动路径纳入不可篡改边界：bin/ 封装进只读镜像内部，"
                    "经 dm-verity 校验后挂载执行，杜绝外部磁盘替换"],
            ["关键点", "core.squashfs 构建；veritysetup 生成根哈希；"
                      "挂载点 /run/ai-ma/slot_a_mnt/；systemd 单元改为先挂载后执行；"
                      "预读校验，运行期遇坏块只告警降级、绝不中断推流"],
            ["风险", "镜像构建需要 Debian 环境；挂载失败会导致微内核无法启动，"
                    "必须设计降级路径（回退到未密封镜像并告警，而不是直接黑场）"],
            ["前置依赖", "可用的 Debian 构建环境"],
            ["验收标准", "篡改镜像任一字节后系统拒绝启动并给出明确故障码；"
                        "正常路径下微内核启动时间增量小于 500ms"],
        ])

    add_h2(d, "4.2 P3-2 A/B 双槽位原子 OTA")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "支持在线升级与原子回滚，升级失败不影响当前运行版本"],
            ["关键点", "slots/slot_a 与 slots/slot_b 各自自闭环（含 core.squashfs、"
                      "manifest.json.sig、bin/）；Ed25519 验签；"
                      "renameat2(..., RENAME_EXCHANGE) 原子对调 current 与 standby"],
            ["风险", "早期设计曾把 bin/ 与 squashfs 放在槽位之外，导致回滚不完整。"
                    "必须确保槽位自闭环。"],
            ["前置依赖", "P3-1"],
            ["验收标准", "升级过程中断电，重启后系统仍能启动到某一个完整版本；"
                        "验签失败时拒绝升级并保持当前版本不变"],
        ])

    add_h2(d, "4.3 P3-3 30 秒回退看门狗")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "新版本启动后 30 秒内未完成自检并喂狗，自动切回原槽位"],
            ["关键点", "systemd fallback 服务；自检项包括微内核存活、共享内存挂载、"
                      "帧计数推进、插件 1/2 类底座健康"],
            ["前置依赖", "P3-2"],
            ["验收标准", "注入启动失败（如故意损坏新槽位配置），系统在 30 秒内自动回到原版本并告警"],
        ])

    add_h2(d, "4.4 P2-1 Wasmtime 指令级沙箱")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "把 3 类插件的隔离从进程级提升到 Wasm 指令级，"
                    "以 Fuel 步数配额与 Epoch 实现 3 毫秒硬熔断"],
            ["现状", "当前为 aima-worker-sandbox（Rust 进程级沙箱）"],
            ["风险", "插件生态现有的 3 类插件均为 Python 源码，"
                    "Wasm 化需要重写或引入 Python-to-Wasm 编译路径，"
                    "对生态开放性的影响必须先评估"],
            ["前置依赖", "需先完成生态兼容性评估并给出迁移方案"],
            ["验收标准", "死循环插件在 3 毫秒内被熔断且主循环无抖动；"
                        "现有 3 类插件功能不缺失"],
        ])

    add_h2(d, "4.5 P2-2 llama.cpp 独立推理服务")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "把端侧大模型从 HTTP 适配插件形态改为独立推理服务进程，"
                    "绑定非实时 CPU 核心，通过 Unix Domain Socket 异步交互"],
            ["现状", "现为 llm_local_qwen_7b 等插件通过 Ollama HTTP 接口调用"],
            ["关键点", "llama.cpp 原生编译；Qwen 2.5-7B GGUF Q4_K_M 量化；"
                      "服务崩溃不得影响控制台与微内核"],
            ["验收标准", "单次推理首字延迟低于现有 HTTP 方案；"
                        "服务被杀死后控制台给出明确告警且灯光推流不受影响"],
        ])

    add_h2(d, "4.6 P2-3 FastAPI 控制台迁移")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "把控制台从 Python 标准库 http.server 迁移到 FastAPI + uvloop，"
                    "提升并发能力与流式遥测体验"],
            ["现状", "control_station.py 使用 http.server + ThreadingHTTPServer"],
            ["风险", "接口数量多且契约已被测试锁定。迁移必须保持全部 HTTP 路径、"
                    "请求体与响应结构不变，否则前端与测试同时失效"],
            ["前置依赖", "先冻结全部接口契约（第 5.4 节）"],
            ["验收标准", "迁移后 148 项断言全部通过，且不修改任何测试脚本的断言内容"],
        ])

    add_h2(d, "4.7 P4-1 Debian 物理机满载压测")
    add_table_data(d,
        ["项目", "内容"],
        [
            ["目标", "在目标硬件上验证生产级稳定性"],
            ["压测项", "64 Universe 满载推流；时钟抖动统计（目标小于 100 微秒）；"
                      "死循环注入旁路熔断；断电恢复；连续 24 小时运行无内存增长"],
            ["前置依赖", "目标硬件与 Debian + PREEMPT_RT 内核就位"],
            ["验收标准", "24 小时连续运行抖动 P99 小于 100 微秒；零黑场；"
                        "内存占用无增长趋势"],
        ])

    add_h2(d, "4.8 P4-2 插件生态扩充")
    add_p(d, "按业务需要新增插件。开发时必须遵守第 5.3 节的抽象方法契约，"
             "并注意主文档第 13.12 节列出的六个模板修正清单——"
             "模板中的 sACN 协议实现存在三处缺陷（序列号恒为 0、属性计数越界、优先级未限幅），"
             "照抄会与标准解码器互通时随机闪灯。")

    # ==================== 第 5 章 ====================
    add_h1(d, "第 5 章 跨模块接口契约（冻结基线）")
    add_callout(d,
        "本章是分工的约束条件。任何工作包需要变更以下契约时，"
        "必须先提交变更说明，评估对其他工作包的影响，并同步更新对应测试断言。",
        fill="FEF2F2", border="B91C1C", color=(185, 28, 28))

    add_h2(d, "5.1 共享内存 ABI 契约（WP-A 与 WP-B 共享）")
    add_table_data(d,
        ["结构体", "关键字段", "约束"],
        [
            ["aima_layer_shm_slot_t", "write_seq / active_buf_idx / frame_index / "
                                     "dmx_buffers[2][64][512] / active_mask[2][64][512]",
             "write_seq 与 active_buf_idx 必须 64 字节对齐；"
             "读写必须遵守顺序锁协议"],
            ["aima_core_state_shm_t", "state_seq / rt_frame_index / last_jitter_ns / "
                                     "final_merged[64][512] / safety_lut[64][512][256]",
             "仅微内核写入，Python 只读；safety_lut 约 8MB，不得按需分配"],
            ["aima_channel_safety_rule_t", "enabled / safe_fallback_val / range_count / "
                                          "danger_ranges[4]",
             "最多 4 组不连续区间；range_count 必须在 0 至 4 之间"],
            ["aima_telemetry_ring_t", "head / tail / capacity / entries[4096]",
             "head 与 tail 必须各自独占缓存行；容量必须为 2 的幂"],
            ["aima_telemetry_entry_t", "timestamp_ns / tier / level / category / source_id / "
                                      "latency_ns / message[108]",
             "alignas(128)；tier 取值 0 至 3 对应内核/系统/适配/创意"],
        ])

    add_h2(d, "5.2 Python 侧桥接接口（WP-B 与 WP-C 共享）")
    add_code_block(d, """
from kernel_bridge import AimaKernelBridge

bridge = AimaKernelBridge()
ok, msg = bridge.mount()                 # 挂载共享内存，返回 (bool, 描述)
frame_index, ts_ns, jitter_ns = bridge.get_rt_metrics()
                                         # 三个返回值必须是 Python 原生 int，
                                         # 不得是 numpy 标量（否则 JSON 序列化失败）
bridge.write_layer("l4", universe, dmx_512_bytes, active_mask)
bridge.read_core_state()                 # 读取最终合成帧与内核状态
""", size=8.5)

    add_h2(d, "5.3 插件抽象方法契约（WP-D 与所有插件作者共享）")
    add_table_data(d,
        ["基类", "层级", "必须实现的抽象方法"],
        [
            ["BasePlugin", "根", "get_info() · on_init(context) · on_enable() · on_disable()"],
            ["BaseProtocolPlugin", "1 类", "上述四项 + send_universe(universe, dmx_data_512)"],
            ["BaseLLMPlugin", "1 类", "上述四项 + chat_completion(...)"],
            ["BaseAdapterPlugin", "2 类", "上述四项 + supported_extensions() · convert_to_profile(...)"],
            ["BaseMacroPlugin", "3 类", "上述四项 + render(...)"],
            ["BasePerceptionPlugin", "3 类", "上述四项 + get_status()"],
        ])
    add_p(d, "另需满足：get_info() 六字段齐全（id、name、version、author、type、description）；"
             "id 匹配 ^[a-z0-9_]{3,40}$；get_config_schema() 每项含 type 与 label。"
             "注意 on_destroy() 与 start_listening() 并非抽象方法，早期文档有误。")

    add_h2(d, "5.4 HTTP 接口契约（WP-C 与 WP-E 共享）")
    add_table_data(d,
        ["路径", "方法", "鉴权", "说明"],
        [
            ["/api/auth/login", "POST", "否", "登录，返回 session.token 与 role"],
            ["/api/auth/logout", "POST", "令牌", "注销，清除会话并下发失效 Cookie"],
            ["/api/auth/verify", "GET", "令牌", "会话校验"],
            ["/api/plugins/installed", "GET", "令牌", "仅返回 3 类创意插件（1/2 类必须零泄漏）"],
            ["/api/plugins/diagnostics", "GET", "admin", "返回全部三层插件状态与失败明细"],
            ["/api/kernel/telemetry", "GET", "令牌",
             "返回 enabled / frame_index / timestamp_ns / jitter_ns / 仲裁后通道采样"],
            ["/api/system/status", "GET", "令牌", "系统状态"],
            ["/api/alarms", "GET", "令牌", "告警列表"],
            ["/api/dmx/universe/<n>", "GET", "令牌", "指定 Universe 通道值"],
            ["/api/logs/stream", "GET", "令牌", "日志流"],
        ])
    add_callout(d,
        "【契约要点】任何 /api/* 只读接口在未授权时必须返回 401，"
        "且必须走分级日志（未携带令牌 DEBUG、令牌失效 INFO、突发超阈值才 ERROR）。"
        "禁止把每一次 401 都记为 ERR-AUTH-DENIED 故障告警。",
        fill="FFFBEB", border="D97706", color=(180, 83, 9))

    add_h2(d, "5.5 systemd 与进程环境契约（WP-F 与全部模块共享）")
    add_table_data(d,
        ["契约项", "内容"],
        [
            ["单元绑定", "ai-ma.service 的 BindsTo=aima-rt.service 与 PartOf 不得移除"],
            ["双内核防护", "ai-ma.service 必须设置 Environment=\"AIMA_RT_EXTERNAL=1\"，"
                          "否则 Python 层会重复拉起微内核并争抢共享内存"],
            ["实时参数", "aima-rt.service 的 CPUAffinity=3、CPUSchedulingPolicy=fifo、"
                        "CPUSchedulingPriority=98、LimitMEMLOCK=infinity 不得放宽"],
            ["共享内存权限", "aima-rt.service 需 ReadWritePaths=/dev/shm"],
            ["启动顺序", "Before=ai-ma.service；部署时必须先 enable --now aima-rt.service"],
        ])

    # ==================== 第 6 章 ====================
    add_h1(d, "第 6 章 验收标准与测试纪律")

    add_h2(d, "6.1 准出测试矩阵（148 项断言）")
    add_p(d, "断言数取自各套件自报的实际执行总数，已实测验证。"
             "test_aima53_standalone_system.py 为裸 assert 型脚本，无自报汇总，"
             "其 5 项由静态计数确认。")
    add_table_data(d,
        ["测试脚本", "断言", "运行前提", "覆盖范围"],
        [
            ["tests/test_aima53_standalone_system.py", "5", "无需独占",
             "桥接可用、内核模式锁定、三层隔离、L4 写入"],
            ["tests/test_plugin_observability.py", "31", "进程内自包含",
             "分层日志、四类失败登记、故障码、诊断报告结构"],
            ["tests/test_auth_noise_suppression.py", "28", "需独占端口",
             "注销零噪音、突发仍告警、登录失败仍告警、前端闩锁"],
            ["tests/test_aima53_boot_e2e.py", "32", "需独占端口",
             "双进程启动、日志基线、鉴权、插件零泄漏、诊断接口、遥测、孤儿回收"],
            ["tests/test_kernel_watchdog.py", "17", "需独占端口",
             "真杀内核后看门狗自动拉起与静态接线核验"],
            ["tests/test_release_package_integrity.py", "35", "需独占端口",
             "真实构建、产物强校验、真实启动发布包"],
        ])

    add_h2(d, "6.2 三条测试铁律")
    for i, t in enumerate([
        "绝不杀死用户进程。需要独占资源的测试必须先检测（端口占用或存在 aima-rt-daemon 进程），"
        "发现已占用时以退出码 2 礼貌跳过并打印指引，不得 taskkill。",
        "日志增量读取必须用字节偏移。os.path.getsize 返回字节数，而文件按字符读取返回 str；"
        "中文日志每汉字 3 字节，按字符切片会跳过大段内容导致误判。"
        "正确做法是 open(path, 'rb') + seek(byte_offset) + decode。",
        "测完必须收尾。运行结束后确认零残留 aima-rt-daemon 进程且端口 9000 已释放，"
        "否则会影响下一位开发者的测试。",
    ], 1):
        add_p(d, f"{i}. {t}")

    add_h2(d, "6.3 新增能力的验收要求")
    add_table_data(d,
        ["新增内容", "必须同步交付的验收断言"],
        [
            ["新增插件", "该插件的分层装载日志断言 + 抽象契约合规断言"],
            ["新增 HTTP 接口", "鉴权边界断言（未登录 401）+ 响应结构断言"],
            ["修改共享内存结构体", "双向 ABI 断言（Rust 侧写入、Python 侧读取一致性）+ 全量回归"],
            ["新增诊断故障码", "知识库收录断言（否则日志显示为「未知系统异常」）"],
            ["修改前端轮询", "定时器登记与注销清理断言"],
            ["修改构建设计", "发布包完整性断言（缺失关键构件的负向测试）"],
        ])

    # ==================== 第 7 章 ====================
    add_h1(d, "第 7 章 里程碑与交付节奏")
    add_table_data(d,
        ["里程碑", "判定条件", "包含工作包"],
        [
            ["M1 交接完成", "各角色完成既有模块的代码走查，能独立定位本模块故障",
             "WP-A 至 WP-G"],
            ["M2 服务线就绪", "推理服务与 FastAPI 控制台迁移完成，148 项断言全通过",
             "P2-2、P2-3"],
            ["M3 不可篡改交付链", "镜像密封、A/B OTA、回退看门狗三者联调通过",
             "P3-1、P3-2、P3-3"],
            ["M4 沙箱升级", "Wasmtime 指令级熔断生效且现有插件功能不缺失", "P2-1"],
            ["M5 生产准出", "Debian 物理机 24 小时满载压测通过", "P4-1"],
        ])
    add_callout(d,
        "【交付纪律】每个里程碑完成时，负责人需同时更新两份文档："
        "《v5.3 硬实时微内核架构实装白皮书》中对应的实装状态，"
        "以及本文件中的工作包状态。文档与代码不同步是本项目历史上最大的返工来源——"
        "曾出现过规划文档描述的五项能力实际一行代码都没有的情况。",
        fill="FFFBEB", border="D97706", color=(180, 83, 9))

    d.save(OUT)
    print(f"[OK] 已生成: {OUT}")
    v = Document(OUT)
    print(f"     段落 {len(v.paragraphs)} | 表格 {len(v.tables)}")


if __name__ == "__main__":
    main()
