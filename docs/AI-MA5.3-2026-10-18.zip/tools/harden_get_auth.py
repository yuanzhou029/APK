# -*- coding: utf-8 -*-
"""
安全加固手术：为 control_station.py 的 do_GET 增加统一鉴权闸门。

原实现中仅 do_POST 校验会话令牌，do_GET 下的全部只读接口
(/api/kb/*、/api/scenes/list、/api/dmx/universe/0、/api/logs/stream 等)
对未登录访问者完全开放，存在越权信息泄露风险。

本脚本将原有的 GET 接口分发链整体抽取为 _dispatch_api_get()，
并在其入口前插入强制会话校验，未持有效令牌一律 401。
"""

import io
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TARGET = os.path.join(BASE_DIR, "control_station.py")

CHAIN_START = '        elif path == "/api/system/status":'
CHAIN_END_ANCHOR = '            self._send_json({"api_url": api_url, "model_name": model_name})\n'

GATE = '''        elif path.startswith("/api/"):
            # ==================== 统一鉴权闸门 ====================
            # 除上方 /api/auth/verify 外的全部只读接口，必须携带有效会话令牌，
            # 否则一律以 401 拒绝，杜绝未登录状态下的知识库与运行数据越权读取。
            gate_token = self._get_token()
            if not auth.verify_token(gate_token):
                log_diagnostic_error(logger, "ERR-AUTH-DENIED", f"未授权只读接口访问被拒绝: {path}")
                self._send_json({"status": "error", "message": "未授权：请先登录后再访问"}, 401)
                return
            self._dispatch_api_get(path, url)
'''


def main():
    with io.open(TARGET, "r", encoding="utf-8") as f:
        src = f.read()

    if "_dispatch_api_get" in src:
        raise SystemExit("[ABORT] 已存在 _dispatch_api_get，疑似重复执行，已中止。")

    start = src.find(CHAIN_START)
    if start == -1:
        raise SystemExit("[ABORT] 未找到 GET 分发链起始锚点。")
    end = src.find(CHAIN_END_ANCHOR, start)
    if end == -1:
        raise SystemExit("[ABORT] 未找到 GET 分发链结束锚点。")
    end += len(CHAIN_END_ANCHOR)

    chain = src[start:end]
    n_routes = chain.count('        elif path ==')
    if n_routes < 10:
        raise SystemExit(f"[ABORT] 分发链仅识别到 {n_routes} 条路由，疑似锚点错误。")
    print(f"[OK] 定位到 GET 分发链：{n_routes + 1} 条只读接口路由，{len(chain)} 字符。")

    # 1) 用鉴权闸门替换原分发链
    src = src[:start] + GATE + src[end:]

    # 2) 将原分发链改造为独立方法（首分支 elif -> if，补充兜底 404）
    method_body = chain.replace(CHAIN_START, '        if path == "/api/system/status":', 1)
    method_body += '        else:\n            self._send_json({"error": "Not Found"}, 404)\n'
    method = (
        '    def _dispatch_api_get(self, path, url):\n'
        '        """已通过会话鉴权的只读接口分发（调用前必须已完成令牌校验）"""\n'
        + method_body + '\n'
    )

    # 3) 插入到 do_GET 之前
    anchor = '    def do_GET(self):'
    idx = src.find(anchor)
    if idx == -1:
        raise SystemExit("[ABORT] 未找到 do_GET 锚点。")
    src = src[:idx] + method + src[idx:]

    with io.open(TARGET, "w", encoding="utf-8") as f:
        f.write(src)

    print("[OK] 已插入统一鉴权闸门并抽取 _dispatch_api_get()。")
    print("=" * 68)
    print("[DONE] do_GET 只读接口安全加固完成。")
    print("=" * 68)
    return 0


if __name__ == "__main__":
    sys.exit(main())
