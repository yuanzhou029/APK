import os, re, glob, json

test_files = sorted(glob.glob('tests/*.py'))

results = []

for f in test_files:
    fname = os.path.basename(f)
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        content = fp.read()
    
    # 查找是否有 check / assert / unittest / TestCase
    has_unittest = 'unittest.TestCase' in content or 'import unittest' in content
    assert_count = len(re.findall(r'\bassert\b', content))
    check_count = len(re.findall(r'\bcheck\(', content))
    
    # 查找独占性检查或端口使用
    has_9000 = '9000' in content
    has_exclusive = 'exit(2)' in content or 'is_port_in_use' in content or 'ALREADY_RUNNING' in content or '独占' in content
    
    # 提取首段注释/文档
    title = ""
    lines = content.splitlines()
    for l in lines[:15]:
        s = l.strip('# \t\r\n')
        if 'coding:' in s: continue
        if s.startswith('AI-MA') or '验证' in s or '测试' in s or '套件' in s:
            title = s
            break
    if not title and len(lines) > 2:
        title = lines[1].strip('# \t\r\n')
        
    results.append({
        'file': fname,
        'title': title,
        'lines': len(lines),
        'has_unittest': has_unittest,
        'assert_count': assert_count,
        'check_count': check_count,
        'has_9000': has_9000,
        'has_exclusive': has_exclusive
    })

print(json.dumps(results, ensure_ascii=False, indent=2))
