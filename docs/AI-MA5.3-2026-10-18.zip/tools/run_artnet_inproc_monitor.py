# -*- coding: utf-8 -*-
"""
AI-MA 进程内直驱 Art-Net 全协议动作监视套件
直接在同进程内驱动控制台的 CoreEngine、ArtNetPacketMonitor 与伴生微内核，
不经过外部 HTTP 网络端口探测，规避容器环境内外部端口限制，精准捕获全量 Art-Net 发包与收包动作。
"""
import sys
import os
import time
import socket
import threading

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

core_dir = os.path.join(BASE_DIR, "core")
if core_dir not in sys.path:
    sys.path.insert(0, core_dir)

# 确保无浏览器自动弹出
os.environ["AIMA_NO_BROWSER"] = "1"

import control_station
from core.dmx_merger import PriorityLevel

def run_artnet_deep_monitor():
    print("=" * 80)
    print("      AI-MA v5.3 工业级控制系统 · Art-Net 协议全景动作监测矩阵")
    print("=" * 80)
    
    print("\n[系统启动] 正在唤醒系统业务引擎、伴生微内核与 UDP 6454 接收监视器...")
    engine = control_station.engine
    monitor = control_station.monitor
    monitor.start()
    
    print("[微内核状态] 伴生 Rust 44Hz 硬实时微内核状态:")
    bridge = engine.kernel_bridge
    print(f"  -> 微内核共享内存就绪: {bridge.is_available}")
    rt_metrics = bridge.get_rt_metrics()
    print(f"  -> 实时帧序: {rt_metrics[0]} | 抖动控制: {rt_metrics[2]}ns")

    print("\n" + "-" * 80)
    print(" 阶段一: 监测微内核与系统默认推流 (发包监测 · 持续 3 秒)")
    print("-" * 80)
    time.sleep(3.0)
    with monitor.lock:
        init_pkts = list(monitor.packet_history)
    print(f"[*] 监视器累计抓获 UDP 6454 数据帧: {len(init_pkts)} 帧，当前实时刷新率: {monitor.current_fps} FPS")
    if init_pkts:
        last = init_pkts[-1]
        print(f"    最新广播包: 时间={last['time']} 来源={last['from_ip']} 宇宙=U{last['universe']} 序列号=#{last['seq']} 活跃通道数={last['active_count']}")

    print("\n" + "-" * 80)
    print(" 阶段二: 业务调光指令注入与仲裁下发 (发包动作监测)")
    print("-" * 80)
    print("[动作指令] 触发快捷场景 [scene_bright] (全场高亮照明)...")
    target_scene = next((s for s in control_station.quick_cue_mgr.get_all_scenes() if s["id"] == "scene_bright"), None)
    if target_scene:
        control_station.execute_payload_directly(target_scene.get("payload", {}))
        print("  -> 指令已执行并注入 L4 槽位，微内核正在进行 O(1) 硬件钳位与推流合成...")
    
    time.sleep(2.0)
    with monitor.lock:
        scene_pkts = list(monitor.packet_history[-10:])
    print(f"[*] 场景下发后协议捕获 (最新 5 帧):")
    for p in scene_pkts[-5:]:
        ch_desc = ",".join(p['active_channels'][:5]) or "(电平=0)"
        print(f"    [{p['time']}] 来源: {p['from_ip']} | 宇宙: U{p['universe']} | 序号: #{p['seq']} | 有效通道数: {p['active_count']} | 通道数据: {ch_desc}")

    print("\n" + "-" * 80)
    print(" 阶段三: 模拟外部 MA 实体控制台注入抢权 (收包与仲裁动作监测)")
    print("-" * 80)
    print("[外部信号] 模拟外部实体灯光控台 (IP: 192.168.1.100) 向系统推送 ArtDmx 帧...")
    # 发送一帧伪造的外部 MA 控制台推流包
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    artnet_header = bytearray(b"Art-Net\x00\x00\x50\x00\x0e\x01\x00\x00\x00\x02\x00")
    # 设置 Universe 0
    artnet_header[14] = 0 # Universe 低字节
    artnet_header[15] = 0 # Universe 高字节
    desk_frame = bytearray(512)
    desk_frame[0] = 255 # Dimmer 100%
    desk_frame[1] = 180 # Red
    desk_frame[2] = 220 # Green
    desk_frame[12] = 255 # 尝试写危险通道(复位)
    
    sock.sendto(artnet_header + desk_frame, ("127.0.0.1", 6454))
    sock.close()
    time.sleep(1.0)

    with monitor.lock:
        desk_pkts = list(monitor.packet_history[-5:])
    print("[*] 系统多源仲裁与安全熔断反馈:")
    for p in desk_pkts:
        print(f"    捕获时间: {p['time']} | 来源: {p['from_ip']} | 宇宙: U{p['universe']} | 帧序号: #{p['seq']} | 活跃通道: {p['active_channels'][:4]}")
    
    # 检查仲裁器状态
    final_f = engine.dmx_merger.get_final_frame(0)
    print(f"  -> 通道1 (亮度) 仲裁结果: {final_f[0]} (期望 255)")
    print(f"  -> 通道13 (危险复位通道) 物理熔断结果: {final_f[12]} (期望 0 强制熔断)")

    print("\n" + "=" * 80)
    print(" 阶段四: 协议动作全景汇总与系统平稳停止")
    print("=" * 80)
    print(f"[+] 监视周期内总处理 Art-Net 帧数: {monitor.total_frames} 帧")
    print(f"[+] 稳态吞吐帧率: {monitor.current_fps} FPS (符合系统 30/44Hz 时基规范)")
    
    # 释放资源
    monitor.stop()
    engine.stop()
    control_station.stop_microkernel()
    print("[+] 监视器套接字、微内核进程与引擎主循环已安全停机！\n")

if __name__ == "__main__":
    run_artnet_deep_monitor()