# -*- coding: utf-8 -*-
"""
前端契约校验（v4.3）
  A. index.html / app.js 中出现的 class 是否都在 theme.css 中定义
     —— 纯 JS 取值钩子（无样式需求）单列，不算失败
  B. app.js 里 $('id') 引用的元素是否都存在于 index.html
  C. index.html 的 id 是否唯一
  D. 模态窗宽度类是否只用 w-sm / w-md / w-lg 三档
"""

import io
import os
import re
import sys
from collections import Counter

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB = os.path.join(BASE, "web")


def read(p):
    with io.open(p, "r", encoding="utf-8") as f:
        return f.read()


html = read(os.path.join(WEB, "index.html"))
js = read(os.path.join(WEB, "assets", "app.js"))
css = read(os.path.join(WEB, "assets", "theme.css"))

# ------------------------------------------------------------------ A. class
# HTML 与 JS 里的 class="..." 一律截断到第一个引号，避免把 JS 拼接片段当成类名
CLS = re.compile(r'class="([^\'"]*)')
used = set()
for src in (html, js):
    for m in CLS.finditer(src):
        for tok in m.group(1).split():
            if tok:
                used.add(tok)
for m in re.finditer(r"classList\.(?:add|remove|toggle|contains)\(\s*'([^']+)'", js):
    for tok in m.group(1).split():
        used.add(tok)

defined = set(re.findall(r'\.([A-Za-z_][A-Za-z0-9_-]*)', css))

FA = re.compile(r'^fa(-|$)')
# 纯 JS 绑定钩子：只用于 querySelector / getAttribute 定位，不承载视觉样式
HOOK = re.compile(
    r'^(ch|ct|ag|ar|sl|vn|nd|fx|pd|pt|sc|pf|bk|gw)-'
    r'|^(ch|ct|ag|ar|sl|vn|nd|fx|pd|pt|sc|pf)-?$'
    r'|^(tgl|drag|caret|sw|nm|t|d|n|v|spacer|has-children|open|active|on|hi|hot|is-empty|disabled)$'
)

missing_all = sorted(c for c in used if c not in defined and not FA.match(c))
missing_style = [c for c in missing_all if not HOOK.match(c)]
missing_hook = [c for c in missing_all if HOOK.match(c)]

# ------------------------------------------------------------------ B/C. id
ids = re.findall(r'\bid="([^"]+)"', html)
dup = sorted(k for k, n in Counter(ids).items() if n > 1)
html_ids = set(ids)
js_ids = set(re.findall(r"\$\('([^']+)'\)", js)) | set(re.findall(r"getElementById\('([^']+)'\)", js))
js_missing = sorted(js_ids - html_ids)

# ------------------------------------------------------------------ D. 模态宽度
MODAL_OK = {'w-sm', 'w-md', 'w-lg', 'modal-card'}
modal_widths = set(re.findall(r'class="modal-card ([^"]*)"', html))
bad_widths = sorted(w for w in modal_widths if w not in MODAL_OK)

# ------------------------------------------------------------------ 输出
print("=" * 74)
print(" 前端契约校验 v4.3")
print("=" * 74)
print(f"  class 使用 {len(used)} / theme.css 定义 {len(defined)}")
print()
if missing_style:
    print(f"[X] 缺失样式定义 ({len(missing_style)} 个) —— 必须补齐：")
    for c in missing_style:
        print("      ." + c)
else:
    print("[OK] A. 所有承载视觉的 class 均已在 theme.css 中定义")
print()
if missing_hook:
    print(f"[i] JS 取值钩子（无需样式，共 {len(missing_hook)} 个）：{', '.join('.' + c for c in missing_hook)}")
    print()
if dup:
    print(f"[X] C. index.html 存在重复 id ({len(dup)} 个)：{', '.join('#' + d for d in dup)}")
else:
    print("[OK] C. index.html 全部 id 唯一")
print()
if js_missing:
    print(f"[X] B. app.js 引用但 HTML 中不存在的 id ({len(js_missing)} 个)：")
    for i in js_missing:
        print("      #" + i)
else:
    print("[OK] B. app.js 引用的全部 id 均存在于 index.html")
print()
if bad_widths:
    print(f"[X] D. 模态窗使用了非标度宽度：{', '.join(bad_widths)}")
else:
    print(f"[OK] D. 模态窗宽度仅使用三档标度：{sorted(modal_widths)}")
print()

fails = len(missing_style) + len(dup) + len(js_missing) + len(bad_widths)
print("=" * 74)
print(f" 结果：{'全部通过' if fails == 0 else str(fails) + ' 项待修复'}")
print("=" * 74)
sys.exit(0 if fails == 0 else 2)
