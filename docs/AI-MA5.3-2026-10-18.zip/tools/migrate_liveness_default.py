# -*- coding: utf-8 -*-
"""
把出厂场地里遗留的 artdmx 存活判据迁移为 artpoll，并补齐新策略字段。

背景：artdmx 判据是"被动观测到该 IP 回传灯光数据"。但调音台在现场只发不收，
解码器不会把 DMX 回传给控制台，所以这个判据对绝大多数设备根本不成立。
本项目已把默认判据改为 artpoll（主动探测应答），默认行为改为"从未收到心跳时报
未监测而不报警"。这里同步把出厂场地文件对齐到新默认值，避免用户第一次启动就看到
一个语义过时的判据。
"""

import io
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VENUES = os.path.join(BASE, "knowledge_base", "venues")

changed_files = []
for name in sorted(os.listdir(VENUES)):
    if not name.endswith(".json"):
        continue
    path = os.path.join(VENUES, name)
    with io.open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    touched = []
    for node in (data.get("nodes") or []):
        pol = node.get("offline_policy")
        if not isinstance(pol, dict):
            continue
        nid = node.get("node_id", "?")
        if pol.get("liveness_source") == "artdmx":
            pol["liveness_source"] = "artpoll"
            touched.append(f"{nid}: artdmx → artpoll")
        if "alarm_when_never_seen" not in pol:
            pol["alarm_when_never_seen"] = False
            touched.append(f"{nid}: 补 alarm_when_never_seen=False")

    if not touched:
        print(f"[跳过] {name}（无需迁移）")
        continue

    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    changed_files.append(name)
    print(f"[OK] {name}")
    for t in touched:
        print(f"       {t}")

print(f"\n共迁移 {len(changed_files)} 个场地文件。")
sys.exit(0)
