# -*- coding: utf-8 -*-
"""
知识库数据迁移脚本 v3.0（一次性）

将既有知识库数据升级到新模型，全程幂等可重复执行：
  1. 灯库 Profiles : 为通道补充 range（连续型取值范围）与 slots（枚举型档位中文名）
  2. 场地 Venues   : 由旧扁平 fixtures[] 自动归拢为 解码器→接口→灯具 三层节点树，
                     同时保留派生的扁平 fixtures[] 以保证引擎侧零改动
  3. 美学预设      : 补充强制分类 category_id、迁移 suggested_channels → channel_values、
                     desc → tags、recommended_transition_ms → transition_ms
"""

import io
import os
import sys
import json

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB = os.path.join(BASE, "knowledge_base")

# ---------------------------------------------------------------------------
# 1. 各通道类型的取值范围与枚举档位
# ---------------------------------------------------------------------------
SLOT_LIBRARY = {
    "color_wheel": [
        {"v": 0, "label": "白光"}, {"v": 8, "label": "红"}, {"v": 20, "label": "绿"},
        {"v": 32, "label": "蓝"}, {"v": 44, "label": "青"}, {"v": 56, "label": "品红"},
        {"v": 68, "label": "黄"}, {"v": 80, "label": "橙"}, {"v": 92, "label": "紫"},
    ],
    "gobo": [
        {"v": 0, "label": "白光（无图案）"}, {"v": 8, "label": "圆点"},
        {"v": 24, "label": "星芒"}, {"v": 40, "label": "雪花"},
        {"v": 56, "label": "同心圆"}, {"v": 72, "label": "条纹"},
        {"v": 88, "label": "火焰"}, {"v": 104, "label": "水纹"},
    ],
    "prism": [
        {"v": 0, "label": "无棱镜"}, {"v": 32, "label": "3 面棱镜"},
        {"v": 96, "label": "8 面棱镜"}, {"v": 160, "label": "16 面棱镜"},
        {"v": 224, "label": "棱镜旋转"},
    ],
    "frost": [
        {"v": 0, "label": "无雾化"}, {"v": 128, "label": "半雾化"}, {"v": 255, "label": "全雾化"},
    ],
    "shutter": [
        {"v": 0, "label": "关闭"}, {"v": 64, "label": "慢速频闪"},
        {"v": 160, "label": "快速频闪"}, {"v": 255, "label": "常开"},
    ],
    "ctc": [
        {"v": 0, "label": "无校正"}, {"v": 64, "label": "暖白 3200K"},
        {"v": 128, "label": "标准 5600K"}, {"v": 200, "label": "冷白 7500K"},
    ],
}

DEFAULT_RANGE = [0, 255]


def migrate_profiles():
    pdir = os.path.join(KB, "profiles")
    total_ch = 0
    for fname in sorted(os.listdir(pdir)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(pdir, fname)
        with io.open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for ch in data.get("channels", []):
            t = ch.get("type", "")
            if "range" not in ch and "slots" not in ch:
                if t in SLOT_LIBRARY:
                    ch["slots"] = SLOT_LIBRARY[t]
                    ch["range"] = [0, 255]
                else:
                    ch["range"] = list(DEFAULT_RANGE)
                total_ch += 1

        with io.open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"  [灯库] {fname} 已补充取值范围")
    print(f"  -> 共处理 {total_ch} 个通道\n")


def alpha_label(idx):
    label = ""
    while True:
        label = chr(ord("A") + idx % 26) + label
        idx = idx // 26 - 1
        if idx < 0:
            return label


DEFAULT_OFFLINE_POLICY = {
    "mode": "threshold", "liveness_source": "artdmx",
    "threshold_sec": 5, "grace_period_sec": 2,
    "severity": "warning", "actions": ["log", "banner", "toast"],
    "auto_recover": True,
}


def migrate_venues():
    vdir = os.path.join(KB, "venues")
    for fname in sorted(os.listdir(vdir)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(vdir, fname)
        with io.open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if data.get("nodes"):
            print(f"  [场地] {fname} 已是节点树结构，跳过")
            continue

        fixtures = data.get("fixtures", [])
        by_universe = {}
        for f in fixtures:
            by_universe.setdefault(int(f.get("universe", 0)), []).append(f)

        ports = []
        for i, u in enumerate(sorted(by_universe.keys())):
            ports.append({
                "port_id": f"p{i + 1}",
                "label": alpha_label(i),
                "label_style": "alpha",
                "universe": u,
                "direction": "out",
                "fixtures": [
                    {
                        "id": fx.get("id"),
                        "name": fx.get("name"),
                        "profile_id": fx.get("profile_id"),
                        "address": fx.get("address", 1),
                        "tags": fx.get("tags", []),
                        "allow_shared_address": False,
                        "position": fx.get("position", {}),
                        "semantic_desc": fx.get("semantic_desc", ""),
                    }
                    for fx in by_universe[u]
                ],
            })
        if not ports:
            ports = [{"port_id": "p1", "label": "A", "label_style": "alpha",
                      "universe": 0, "direction": "out", "fixtures": []}]

        data["nodes"] = [{
            "node_id": "node_1",
            "name": "主解码器",
            "source": "manual",
            "ip": data.get("default_target_ip", "127.0.0.1"),
            "protocol": "artnet",
            "groups": ["舞台"],
            "discovery": {"online": None, "artpoll_reply": None, "rtt_ms": None,
                          "first_seen": None, "last_seen": None},
            "offline_policy": dict(DEFAULT_OFFLINE_POLICY),
            "ports": ports,
        }]

        with io.open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"  [场地] {fname} 已迁移为 {len(data['nodes'])} 解码器 / "
              f"{len(ports)} 接口 / {len(fixtures)} 灯具")
    print()


def migrate_presets():
    ppath = os.path.join(KB, "presets", "aesthetic_presets.json")
    with io.open(ppath, "r", encoding="utf-8") as f:
        presets = json.load(f)

    for pid, p in presets.items():
        # 强制分类
        p.setdefault("category_id", "cat_general")

        # suggested_channels -> channel_values
        if "channel_values" not in p:
            sc = p.get("suggested_channels") or {}
            p["channel_values"] = {k: int(v) for k, v in sc.items()}

        # desc -> tags
        if "tags" not in p:
            p["tags"] = [t.strip() for t in str(p.get("desc", "")).split("、") if t.strip()]

        # 推荐淡变时间
        if "transition_ms" not in p:
            p["transition_ms"] = int(p.get("recommended_transition_ms", 1000))

        # 旧的四个预设均为纯 RGBW 配色，无特定灯型依赖 -> 标记为通用预设
        p.setdefault("profile_ref", None)
        p["universal"] = p.get("profile_ref") is None

        p.setdefault("summary", "")
        # 清理无法被新模型承载的旧字段
        p.pop("desc", None)
        p.pop("suggested_channels", None)
        p.pop("recommended_transition_ms", None)

    with io.open(ppath, "w", encoding="utf-8") as f:
        json.dump(presets, f, ensure_ascii=False, indent=2)
    print(f"  [预设] 已迁移 {len(presets)} 条，全部强制归属分类 cat_general")
    print()


def main():
    print("=" * 70)
    print(" 知识库数据迁移 v3.0")
    print("=" * 70)
    migrate_profiles()
    migrate_venues()
    migrate_presets()
    print("=" * 70)
    print(" 迁移完成。")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
