# -*- coding: utf-8 -*-
"""
生成所有现役 31 个测试脚本的结构化元数据分析，用于起草技术方案与交付报告
"""
import os, glob, re, json

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")

files = sorted(glob.glob(os.path.join(TESTS, "*.py")))

catalog = []

for f in files:
    name = os.path.basename(f)
    with open(f, "r", encoding="utf-8", errors="ignore") as fp:
        lines = fp.readlines()
    content = "".join(lines)
    
    # 分类判定
    cat = "未知"
    if name.startswith("test_aima53") or name in ["test_kernel_watchdog.py", "test_audit_remediation.py", "test_release_package_integrity.py"]:
        cat = "Tier-1: 准出与内核硬实时测试套件"
    elif "plugin" in name:
        cat = "Tier-2: 插件生态与三层阶梯架构测试套件"
    elif "auth" in name or "security" in name or "admin" in name or "rbac" in name:
        cat = "Tier-3: 安全鉴权、RBAC与灾备测试套件"
    elif "kb" in name or "categories" in name or "scenes" in name or "marketplace" in name or "alarm" in name or "discovery" in name or "takeover" in name:
        cat = "Tier-4: 业务功能与RAG知识库验证套件"
    elif "ui" in name or "smoke" in name or "unified" in name:
        cat = "Tier-5: UI与端到端集成冒烟套件"
    elif name in ["test_ai_profile_extract.py"]:
        cat = "Tier-6: 环境自检与辅助工具套件"
    elif name.startswith("verify_"):
        cat = "Tier-4: 业务功能与RAG知识库验证套件"
    else:
        cat = "Tier-1: 准出与内核硬实时测试套件"

    # 提取测试目的与第一段描述
    desc_lines = []
    in_doc = False
    for l in lines[:30]:
        s = l.strip()
        if '"""' in s or "'''" in s:
            if not in_doc:
                in_doc = True
                cleaned = s.replace('"""', '').replace("'''", '').strip()
                if cleaned: desc_lines.append(cleaned)
                continue
            else:
                cleaned = s.replace('"""', '').replace("'''", '').strip()
                if cleaned: desc_lines.append(cleaned)
                break
        if in_doc:
            if s: desc_lines.append(s)
        elif s.startswith("#") and not "coding" in s:
            cleaned = s.lstrip("#").strip()
            if cleaned: desc_lines.append(cleaned)
            
    summary = " ".join(desc_lines[:4])
    
    # 独占性与端口
    exclusive = ("9000" in content and "exit(2)" in content) or "is_port_in_use" in content
    port_9000 = "9000" in content
    
    # 统计断言与测试方法
    test_methods = re.findall(r"def\s+(test_\w+)\s*\(", content)
    check_calls = re.findall(r"\bcheck\(", content)
    assert_calls = re.findall(r"^\s*assert\s+", content, re.M)
    
    catalog.append({
        "name": name,
        "category": cat,
        "lines": len(lines),
        "exclusive": exclusive,
        "port_9000": port_9000,
        "test_methods_count": len(test_methods),
        "test_methods": test_methods[:5],
        "check_count": len(check_calls),
        "assert_count": len(assert_calls),
        "summary": summary[:200]
    })

    print(f"[{cat}] {name}: {summary[:100]} | lines:{len(lines)} | check:{len(check_calls)} | assert:{len(assert_calls)}")

print(f"成功分析 {len(catalog)} 个脚本元数据")
