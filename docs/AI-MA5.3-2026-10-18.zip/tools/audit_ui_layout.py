# -*- coding: utf-8 -*-
"""
界面几何量化审计

既然美感最终要落到"比例是否合理、有没有被裁切、有没有溢出"这些可测量的量上，
就用无头浏览器真实渲染后，把关键控件的盒模型量出来，用规则判定，而不是靠肉眼。

审计项：
  A. 页面横向溢出           —— 出现横向滚动条说明有元素突破了栅格
  B. 按钮最小可点面积       —— 高度 < 24px 或宽度 < 24px 的按钮在触控/精细操作下不可用
  C. 文本裁切               —— overflow 为 hidden 且 scrollWidth 超出 clientWidth
  D. 面板内垂直溢出         —— 面板内容被裁掉
  E. 字号下限               —— 任何可见文本字号 < 11px 视为不可读
  F. 控件高度离散度         —— 同类型按钮高度应落在设计标度（28/32/36/44）上
  G. 标度一致性             —— 半径、内边距是否复用设计变量
  H. 图标字体可用性         —— FontAwesome 是否真正加载（离线内网场景的关键风险）
"""

import io
import json
import os
import re
import shutil
import subprocess
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB = os.path.join(BASE, "web")
PREVIEW = os.path.join(WEB, "_preview.html")
AUDIT_HTML = os.path.join(WEB, "_audit.html")

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

AUDIT_JS = r"""
<script>
window.__AUDIT__ = function () {
  var out = {overflowX: null, buttons: [], clipped: [], panels: [], tiny: [],
             fonts: {}, iconFontOK: null, radii: {}, heights: {}, heightByClass: {}};
  var de = document.documentElement;

  out.overflowX = {scrollW: de.scrollWidth, clientW: de.clientWidth,
                   overflow: de.scrollWidth - de.clientWidth};

  function visible(el) {
    var r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    var s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';
  }

  // ---- 按钮几何 ----
  document.querySelectorAll('.btn, button, .tab, .chip, .seg-item, .nav-item').forEach(function (b) {
    if (!visible(b)) return;
    var r = b.getBoundingClientRect();
    var s = getComputedStyle(b);
    var cls = (b.className || '').toString();
    var key = cls.split(/\s+/).filter(function (x) {
      return x && ['btn','active','disabled','open','sm','primary','ghost'].indexOf(x) < 0;
    })[0] || (b.tagName.toLowerCase());
    out.buttons.push({
      cls: cls.slice(0, 60), key: key,
      txt: (b.textContent || '').trim().slice(0, 18),
      w: Math.round(r.width * 10) / 10,
      h: Math.round(r.height * 10) / 10,
      fs: parseFloat(s.fontSize), pad: s.padding, radius: s.borderRadius
    });
    out.heights[Math.round(r.height)] = (out.heights[Math.round(r.height)] || 0) + 1;
    if (!out.heightByClass[key]) out.heightByClass[key] = {};
    out.heightByClass[key][Math.round(r.height)] = (out.heightByClass[key][Math.round(r.height)] || 0) + 1;
    if (r.height < 24 || r.width < 22) {
      out.tiny.push({txt: (b.textContent || '').trim().slice(0, 18),
                     w: Math.round(r.width), h: Math.round(r.height), cls: cls.slice(0, 50)});
    }
  });

  // ---- 文本裁切（横向 / 纵向）----
  // 只有"既溢出、又没有声明省略号"才算硬裁切；带 ellipsis 的是刻意的优雅截断
  document.querySelectorAll('div,span,p,td,th,h1,h2,h3,h4,label,a,strong,b').forEach(function (el) {
    if (!visible(el)) return;
    var hasText = false;
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3 && el.childNodes[i].textContent.trim()) { hasText = true; break; }
    }
    if (!hasText) return;
    var s = getComputedStyle(el);
    var ellipsis = s.textOverflow === 'ellipsis';
    var hiddenX = s.overflowX === 'hidden' || s.overflow === 'hidden';
    var hiddenY = s.overflowY === 'hidden' || s.overflow === 'hidden';
    var cls = (el.className || '').toString().slice(0, 50);
    if (hiddenX && el.scrollWidth > el.clientWidth + 2) {
      out.clipped.push({t: 'x', ellipsis: ellipsis, txt: (el.textContent || '').trim().slice(0, 26),
        over: el.scrollWidth - el.clientWidth, cls: cls});
    }
    if (hiddenY && el.scrollHeight > el.clientHeight + 2) {
      out.clipped.push({t: 'y', ellipsis: ellipsis, txt: (el.textContent || '').trim().slice(0, 26),
        over: el.scrollHeight - el.clientHeight, cls: cls});
    }
  });

  // ---- 面板 ----
  document.querySelectorAll('.panel, .card, .kpi').forEach(function (p) {
    if (!visible(p)) return;
    var s = getComputedStyle(p);
    var body = p.querySelector('.panel-body');
    var rec = {cls: (p.className || '').toString().slice(0, 40),
      w: Math.round(p.getBoundingClientRect().width),
      h: Math.round(p.getBoundingClientRect().height),
      radius: s.borderRadius};
    if (body) {
      rec.bodyOverflowY = body.scrollHeight - body.clientHeight;
      rec.bodyOverflowX = body.scrollWidth - body.clientWidth;
    }
    out.panels.push(rec);
    out.radii[s.borderRadius] = (out.radii[s.borderRadius] || 0) + 1;
  });

  // ---- 字号下限 ----
  document.querySelectorAll('*').forEach(function (el) {
    if (!visible(el)) return;
    var hasText = false;
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3 && el.childNodes[i].textContent.trim()) { hasText = true; break; }
    }
    if (!hasText) return;
    var fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs < 11) {
      out.tiny.push({kind: 'font', fs: fs, txt: (el.textContent || '').trim().slice(0, 20),
        cls: (el.className || '').toString().slice(0, 40)});
    }
    out.fonts[fs] = (out.fonts[fs] || 0) + 1;
  });

  // ---- FontAwesome 真实可用性 ----
  try {
    var probe = document.createElement('i');
    probe.className = 'fa-solid fa-bolt';
    probe.style.position = 'absolute';
    probe.style.left = '-9999px';
    document.body.appendChild(probe);
    var pf = getComputedStyle(probe, ':before').fontFamily || '';
    out.iconFontOK = /Font\s*Awesome/i.test(pf);
    out.iconFontFamily = pf.slice(0, 60);
    document.body.removeChild(probe);
  } catch (e) { out.iconFontOK = 'error: ' + e.message; }

  out.viewport = {w: window.innerWidth, h: window.innerHeight};
  out.counts = {
    buttons: out.buttons.length, panels: out.panels.length,
    clipped: out.clipped.length, tiny: out.tiny.length
  };
  return out;
};

setTimeout(function () {
  var data = window.__AUDIT__();
  var pre = document.createElement('pre');
  pre.id = '__AUDIT_RESULT__';
  pre.textContent = '@@AUDIT@@' + JSON.stringify(data) + '@@END@@';
  document.body.innerHTML = '';
  document.body.appendChild(pre);
}, 2200);
</script>
"""

# 设计标度（来自 theme.css 的 --ctl-h-* / --r-*）
EXPECTED_HEIGHTS = {28, 32, 36, 44, 52}
EXPECTED_RADII = {"6px", "10px", "14px", "999px", "9999px"}

# 内容卡片不是控件，其高度由内容决定（可换行、可带副标题），不受控件高度标度约束
CARD_LIKE = {"tile", "card", "kpi", "pcard", "plugin", "pkg", "scene-card"}


def find_chrome():
    for c in CHROME_CANDIDATES:
        if os.path.exists(c):
            return c
    return shutil.which("chrome") or shutil.which("chromium")


def build_audit_html():
    with io.open(PREVIEW, "r", encoding="utf-8") as f:
        html = f.read()
    if "</body>" not in html:
        raise SystemExit("[ABORT] 预览页缺少 </body>")
    with io.open(AUDIT_HTML, "w", encoding="utf-8") as f:
        f.write(html.replace("</body>", AUDIT_JS + "\n</body>", 1))
    return AUDIT_HTML


def run(url_query, chrome):
    url = "file:///" + AUDIT_HTML.replace("\\", "/")
    if url_query:
        url += "?" + url_query
    proc = subprocess.run(
        [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
         "--force-device-scale-factor=1", "--window-size=1680,1050",
         "--virtual-time-budget=6000", "--dump-dom", url],
        capture_output=True, timeout=120)
    dom = proc.stdout.decode("utf-8", "replace")
    m = re.search(r"@@AUDIT@@(.*?)@@END@@", dom, re.S)
    if not m:
        return None
    return json.loads(m.group(1))


VIEWS = [
    ("主控台", "v=control"),
    ("快捷场景管理", "v=scenes_studio"),
    ("设备节点与监视", "v=monitor"),
    ("知识库总览", "v=kb&p=overview"),
    ("物理灯库", "v=kb&p=profiles"),
    ("场地与节点拓扑", "v=kb&p=venues"),
    ("美学预设", "v=kb&p=presets"),
    ("AI解析与RAG", "v=kb&p=airag"),
    ("插件市场", "v=marketplace"),
    ("本地大模型", "v=llm_cfg"),
    ("告警中心", "v=diagnostics&d=alarms"),
    ("运行日志诊断", "v=diagnostics&d=logs"),
]

PASS = 0
FAIL = 0
WARN = 0


def ok(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name} {extra}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name} {extra}")


def warn(name, extra=""):
    global WARN
    WARN += 1
    print(f"  [WARN] {name} {extra}")


def main():
    print("=" * 78)
    print(" 界面几何量化审计（无头浏览器实测盒模型）")
    print("=" * 78)

    if not os.path.exists(PREVIEW):
        print("[ABORT] 请先运行 tools/render_ui_preview.py 生成预览页。")
        return 1

    chrome = find_chrome()
    if not chrome:
        print("[ABORT] 未找到 Chrome/Edge。")
        return 1

    build_audit_html()
    print(f"[OK] 审计页: {AUDIT_HTML}\n")

    all_heights = {}
    all_hbc = {}
    all_radii = {}
    all_fonts = {}
    total_tiny = 0
    total_clipped = 0

    for label, q in VIEWS:
        data = run(q, chrome)
        print(f"── {label} " + "─" * (60 - len(label)))
        if data is None:
            FAIL_GLOBAL = True
            ok(f"{label} 渲染", False, "-> 审计脚本未返回结果")
            continue

        ov = data["overflowX"]
        ok(f"{label} · 无横向溢出",
           ov["overflow"] <= 1,
           f"-> scrollW={ov['scrollW']} clientW={ov['clientW']} 溢出={ov['overflow']}px")

        tiny = data.get("tiny", [])
        fonts_tiny = [t for t in tiny if t.get("kind") == "font"]
        box_tiny = [t for t in tiny if t.get("kind") != "font"]
        ok(f"{label} · 无过小控件（<24px）",
           len(box_tiny) == 0,
           f"-> {len(box_tiny)} 个" + (f" 例: {box_tiny[:2]}" if box_tiny else ""))
        ok(f"{label} · 无过小字号（<11px）",
           len(fonts_tiny) == 0,
           f"-> {len(fonts_tiny)} 处" + (f" 例: {fonts_tiny[:2]}" if fonts_tiny else ""))

        clipped = data.get("clipped", [])
        # 带 text-overflow:ellipsis 的是刻意的优雅截断，不算缺陷
        hard = [c for c in clipped if not c.get("ellipsis")]
        soft = [c for c in clipped if c.get("ellipsis")]
        ok(f"{label} · 无文本硬裁切",
           len(hard) == 0,
           f"-> {len(hard)} 处硬裁切" + (f"，另有 {len(soft)} 处省略号截断（正常）" if soft else "")
           + (f" 例: {hard[:2]}" if hard else ""))

        total_tiny += len(box_tiny)
        total_clipped += len(hard)
        for k, v in data.get("heights", {}).items():
            all_heights[k] = all_heights.get(k, 0) + v
        for k, v in data.get("heightByClass", {}).items():
            dst = all_hbc.setdefault(k, {})
            for hh, cc in v.items():
                dst[hh] = dst.get(hh, 0) + cc
        for k, v in data.get("radii", {}).items():
            all_radii[k] = all_radii.get(k, 0) + v
        for k, v in data.get("fonts", {}).items():
            all_fonts[k] = all_fonts.get(k, 0) + v

        if label == "主控台":
            print(f"    图标字体可用: {data.get('iconFontOK')}  ({data.get('iconFontFamily','')})")
        print()

    print("=" * 78)
    print(" 全局标度统计")
    print("=" * 78)
    print(f"  控件高度分布 : {dict(sorted(all_heights.items(), key=lambda x: int(x[0])))}")
    print(f"  圆角使用分布 : {dict(sorted(all_radii.items(), key=lambda x: -x[1]))}")
    print(f"  字号使用分布 : {dict(sorted(all_fonts.items()))}")
    print()
    print("  ── 按类名归因的控件高度 ──")
    for k in sorted(all_hbc, key=lambda x: -sum(all_hbc[x].values())):
        hs = dict(sorted(all_hbc[k].items(), key=lambda x: int(x[0])))
        if k in CARD_LIKE:
            flag = "  （内容卡片，不受控件标度约束）"
        elif any(int(h) not in EXPECTED_HEIGHTS and int(h) > 20 for h in hs):
            flag = "  <== 偏离标度"
        else:
            flag = ""
        print(f"    {k:<22} {hs}{flag}")
    print()

    off_scale = {k: {int(h): c for h, c in v.items()
                     if int(h) not in EXPECTED_HEIGHTS and int(h) > 20}
                 for k, v in all_hbc.items() if k not in CARD_LIKE}
    off_scale = {k: v for k, v in off_scale.items() if v}
    if off_scale:
        warn("部分控件高度不在设计标度内",
             f"-> {off_scale}（控件标度应为 {sorted(EXPECTED_HEIGHTS)}）")
    else:
        print("  [PASS] 所有控件高度均落在设计标度内")

    off_radius = {r: c for r, c in all_radii.items() if r not in EXPECTED_RADII}
    if off_radius:
        warn("部分圆角不在设计标度内", f"-> {off_radius}")
    else:
        print("  [PASS] 所有圆角均复用设计变量")

    # JSON 的键会变成字符串，必须转成数值再比对，否则永远为真
    FONT_SCALE = (11, 12, 13, 14, 16, 20, 26, 34)
    off_font = {f: c for f, c in all_fonts.items() if float(f) not in FONT_SCALE}
    used = sorted({float(f) for f in all_fonts})
    if off_font:
        warn("部分字号不在 8 级标度内", f"-> {off_font}")
    else:
        print(f"  [PASS] 所有字号均落在 8 级标度内（11/12/13/14/16/20/26/34）")
        unused = [s for s in FONT_SCALE if s not in used]
        if unused:
            print(f"         （本页未使用的层级: {unused}，属正常，不代表缺陷）")

    print()
    print("=" * 78)
    print(f" 结果: {PASS} 项通过 / {FAIL} 项失败 / {WARN} 项提示")
    print("=" * 78)
    # _audit.html 只是本次审计的临时产物，_preview.html 保留供人工目视核验
    try:
        os.remove(AUDIT_HTML)
    except OSError:
        pass
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
