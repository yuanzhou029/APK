# -*- coding: utf-8 -*-
"""
Art-Net 协议动作全量监视探针 (实时监控收发与解析)
"""
import sys
import os
import time
import json
import urllib.request
import urllib.error

API_URL = "http://127.0.0.1:9000"

def get_admin_token():
    req = urllib.request.Request(
        f"{API_URL}/api/auth/login",
        data=json.dumps({"username": "admin", "password": "admin123"}).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=3.0) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        return data["session"]["token"]

def monitor_artnet_loop(duration_sec=15):
    print(f"[*] 尝试登录总控台获取会话令牌...")
    try:
        token = get_admin_token()
    except Exception as e:
        print(f"[-] 登录失败，服务可能尚未就绪: {e}")
        return

    print(f"[+] 鉴权成功，开始对 Art-Net UDP 6454 协议动作进行高频采样 (时长: {duration_sec}s)...")
    print("-" * 75)
    print(f"{'时间':<12} | {'来源IP':<15} | {'宇宙':<6} | {'帧序号':<6} | {'活跃通道摘要':<30}")
    print("-" * 75)

    headers = {"Authorization": f"Bearer {token}"}
    seen_times = set()
    start_t = time.time()

    while time.time() - start_t < duration_sec:
        try:
            req = urllib.request.Request(f"{API_URL}/api/monitor/stats", headers=headers)
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                stats = json.loads(resp.read().decode("utf-8"))
                fps = stats.get("current_fps", 0.0)
                total = stats.get("total_frames", 0)
                history = stats.get("packet_history", [])

                for pkt in history[-10:]:
                    pkey = (pkt.get("time"), pkt.get("seq"), pkt.get("universe"))
                    if pkey not in seen_times:
                        seen_times.add(pkey)
                        ch_str = ",".join(pkt.get("active_channels", [])) or "(全0通道)"
                        print(f"{pkt.get('time'):<12} | {pkt.get('from_ip'):<15} | U{pkt.get('universe'):<5} | #{pkt.get('seq'):<5} | {ch_str:<30}")
        except Exception as e:
            print(f"[!] 轮询监视异常: {e}")
        time.sleep(0.5)

    print("-" * 75)
    print(f"[*] 监视周期完成，累计捕捉并解析帧总数: {total} 帧，当前吞吐速率: {fps} FPS")

if __name__ == "__main__":
    monitor_artnet_loop(12)