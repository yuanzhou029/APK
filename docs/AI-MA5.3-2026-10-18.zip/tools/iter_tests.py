# -*- coding: utf-8 -*-
import os, sys, glob, subprocess, time

APP = r"D:\python项目文件\AI-MA5.3"
TESTS = os.path.join(APP, "tests")
PY = sys.executable

files = sorted(glob.glob(os.path.join(TESTS, "*.py")))
env = dict(os.environ, PYTHONIOENCODING="utf-8", AIMA_NO_BROWSER="1", AIMA_LOG_CONSOLE="1")

for f in files:
    name = os.path.basename(f)
    print(f"Testing {name}...", end=" ", flush=True)
    t0 = time.time()
    try:
        p = subprocess.run([PY, f], cwd=APP, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=8)
        dur = time.time() - t0
        print(f"code: {p.returncode} ({dur:.1f}s)")
        if p.returncode != 0:
            out = (p.stdout or "") + "\n" + (p.stderr or "")
            lines = [l.strip() for l in out.splitlines() if l.strip()]
            for l in lines[-3:]:
                print("   ERR:", l[:100])
    except subprocess.TimeoutExpired:
        print("TIMEOUT (>8s)!")
