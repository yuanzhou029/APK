# -*- coding: utf-8 -*-
"""
深入扫描 tests/ 下 34 个测试脚本的目标模块、断言数与特征
"""
import os, glob, re

TESTS_DIR = r"D:\python项目文件\AI-MA5.3\tests"

files = sorted(glob.glob(os.path.join(TESTS_DIR, "*.py")))

print(f"Total test files: {len(files)}")

for f in files:
    name = os.path.basename(f)
    with open(f, "r", encoding="utf-8", errors="replace") as fp:
        content = fp.read()
    
    # 查找主要 import
    imports = re.findall(r'^(?:from|import)\s+([\w\.]+)', content, re.MULTILINE)
    top_imports = list(dict.fromkeys(imports))[:6]
    
    # 统计 assert / check
    assert_count = len(re.findall(r'\bassert\b', content))
    check_count = len(re.findall(r'\bcheck\s*\(', content))
    self_report = len(re.findall(r'全部通过|ALL PASS|项通过', content)) > 0
    lines = len(content.splitlines())
    
    # 是否依赖 9000 端口或真实服务
    needs_9000 = "9000" in content or "urllib" in content or "requests" in content or "httpx" in content
    
    print(f"{name:<42} | 行数:{lines:<4} | assert:{assert_count:<2} | check:{check_count:<2} | 端口/网络:{needs_9000} | 自报:{self_report}")
