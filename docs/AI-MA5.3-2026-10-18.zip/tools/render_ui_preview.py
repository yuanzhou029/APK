# -*- coding: utf-8 -*-
"""
离线 UI 预览渲染器

用途：在没有真实 Art-Net 设备、也不想污染知识库的前提下，把总控台界面用一套
      完整且贴近现场的桩数据渲染出来，供人工核验视觉效果与布局比例。

做法：
  1. 读取 web/index.html
  2. 在 app.js 之前注入一段脚本：伪造 localStorage 会话 + 拦截 fetch 返回桩数据
  3. 把 /assets/ 绝对路径改写为相对路径，使 file:// 直接可开
  4. 输出 web/_preview.html
  5. 可选：调用本机 Chrome 无头模式，对每个视图/子页签截图到 screenshots/

用法：
  python tools/render_ui_preview.py            # 只生成预览页
  python tools/render_ui_preview.py --shot     # 生成预览页并截图
"""

import io
import os
import sys
import json
import glob
import shutil
import subprocess

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB = os.path.join(BASE, "web")
OUT_HTML = os.path.join(WEB, "_preview.html")
SHOT_DIR = os.path.join(BASE, "screenshots")

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
]

# ===========================================================================
# 桩数据：刻意做成"满负载现场"——多解码器、多接口、自定义序号、
# 含待归类预设、含未处理掉线告警、含自定义上传图标分类
# ===========================================================================
STUB = r"""
(function () {
  var CATS = [
    {id:"cat_general", name:"常规", color:"#38bdf8", order:0,
     icon:{mode:"none", builtin:"", upload:"", align:"inline"}},
    {id:"cat_warm", name:"暖场氛围", color:"#f59e0b", order:1,
     icon:{mode:"builtin", builtin:"fa-solid fa-fire", upload:"", align:"inline"}},
    {id:"cat_edm", name:"电音炸场", color:"#a855f7", order:2,
     icon:{mode:"builtin", builtin:"fa-solid fa-bolt", upload:"", align:"inline"}},
    {id:"cat_ballad", name:"抒情慢歌", color:"#22d3ee", order:3,
     icon:{mode:"upload", builtin:"",
           upload:"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M12 2C8 7 5 9 5 14a7 7 0 0 0 14 0c0-5-3-7-7-12z'/></svg>",
           align:"inline"}}
  ];
  var AGS = [
    {id:"ag_intensity", name:"亮度", color:"#38bdf8", attrs:["dimmer","strobe","shutter"]},
    {id:"ag_color", name:"颜色", color:"#f43f5e", attrs:["red","green","blue","white","ctc","color_wheel"]},
    {id:"ag_beam", name:"光束", color:"#f59e0b", attrs:["zoom","focus","frost","prism","prism_rot"]},
    {id:"ag_gobo", name:"图案", color:"#6366f1", attrs:["gobo","pan","tilt","speed"]}
  ];
  var CH = function (ch, type, name, def, safe, range, slots) {
    var o = {ch:ch, type:type, name:name, default:def, is_safe:safe!==false, range:range||[0,255]};
    if (slots) o.slots = slots;
    return o;
  };
  var AURA = {profile_id:"martin_mac_aura_14ch", manufacturer:"Martin", model:"MAC Aura",
    channel_count:14, safe_channel_count:12, locked_channel_count:2, ranged_channel_count:14,
    filename:"martin_mac_aura_14ch.json",
    channels:[
      CH(1,"shutter","频闪/快门",20,true,[0,255],[{v:0,label:"关闭"},{v:64,label:"慢速频闪"},{v:160,label:"快速频闪"},{v:255,label:"常开"}]),
      CH(2,"dimmer","总调光",0),CH(3,"pan","水平旋转",128),CH(4,"pan_fine","水平微调",0),
      CH(5,"tilt","垂直俯仰",128),CH(6,"tilt_fine","垂直微调",0),
      CH(7,"red","红色(R)",0),CH(8,"green","绿色(G)",0),CH(9,"blue","蓝色(B)",0),
      CH(10,"white","白色(W)",0),
      CH(11,"ctc","色温校正",0,true,[0,255],[{v:0,label:"无校正"},{v:64,label:"暖白 3200K"},{v:128,label:"标准 5600K"},{v:200,label:"冷白 7500K"}]),
      CH(12,"macro","内置宏",0,false),CH(13,"control","设备复位/危险通道",0,false),
      CH(14,"speed","运行速度",0)
    ]};
  var BEAM = {profile_id:"beam_230w_16ch", manufacturer:"ClayPaky", model:"Sharpy 230W",
    channel_count:16, safe_channel_count:13, locked_channel_count:3, ranged_channel_count:16,
    filename:"beam_230w_16ch.json",
    channels:[
      CH(1,"color_wheel","色盘",0,true,[0,255],[{v:0,label:"白光"},{v:8,label:"红"},{v:20,label:"绿"},{v:32,label:"蓝"},{v:44,label:"青"},{v:56,label:"品红"},{v:68,label:"黄"}]),
      CH(2,"strobe","频闪",255),CH(3,"dimmer","调光",0),
      CH(4,"gobo","图案盘",0,true,[0,255],[{v:0,label:"白光（无图案）"},{v:8,label:"圆点"},{v:24,label:"星芒"},{v:40,label:"雪花"},{v:56,label:"同心圆"},{v:72,label:"条纹"}]),
      CH(5,"prism","棱镜",0,true,[0,255],[{v:0,label:"无棱镜"},{v:32,label:"3 面棱镜"},{v:96,label:"8 面棱镜"},{v:160,label:"16 面棱镜"}]),
      CH(6,"prism_rot","棱镜旋转",0),CH(7,"frost","雾化",0),CH(8,"focus","调焦",128),
      CH(9,"pan","水平旋转",128),CH(10,"pan_fine","水平微调",0),
      CH(11,"tilt","垂直旋转",128),CH(12,"tilt_fine","垂直微调",0),
      CH(13,"macro","内部宏",0,false),CH(14,"reset","灯具复位",0,false),
      CH(15,"lamp_control","泡控开关",0,false),CH(16,"speed","电机速度",0)
    ]};

  var NODES = [
    {node_id:"node_1", name:"舞台左侧主解码器", source:"discovered", ip:"192.168.3.51",
     protocol:"artnet", groups:["舞台左侧"],
     discovery:{online:true, artpoll_reply:"AI-MA Node 4Port", rtt_ms:0.8, first_seen:"2026-10-13 19:02:11", last_seen:"2026-10-13 21:38:02"},
     offline_policy:{mode:"threshold", liveness_source:"artdmx", threshold_sec:5, grace_period_sec:2, severity:"warning", actions:["log","banner","toast"], auto_recover:true},
     ports:[
       {port_id:"p1", label:"A", label_style:"alpha", universe:0, direction:"out", fixtures:[
         {id:"fix_01", name:"舞台左前一号面光", profile_id:"martin_mac_aura_14ch", address:31, tags:["面光","左前"], semantic_desc:"主唱面部补光", allow_shared_address:false},
         {id:"fix_02", name:"舞台右前二号面光", profile_id:"martin_mac_aura_14ch", address:45, tags:["面光","右前"], semantic_desc:"吉他手补光", allow_shared_address:false}
       ]},
       {port_id:"p2", label:"B", label_style:"alpha", universe:1, direction:"out", fixtures:[
         {id:"fix_03", name:"舞台后方中央光束", profile_id:"beam_230w_16ch", address:1, tags:["逆光","光束"], semantic_desc:"背景光柱造型", allow_shared_address:false}
       ]},
       {port_id:"p3", label:"C", label_style:"alpha", universe:2, direction:"out", fixtures:[]},
       {port_id:"p4", label:"D", label_style:"alpha", universe:3, direction:"out", fixtures:[]}
     ]},
    {node_id:"node_2", name:"舞台右侧辅助解码器", source:"manual", ip:"192.168.3.52",
     protocol:"artnet", groups:["舞台右侧"],
     discovery:{online:false, artpoll_reply:null, rtt_ms:null, first_seen:null, last_seen:"2026-10-13 21:33:40"},
     offline_policy:{mode:"threshold", liveness_source:"artdmx", threshold_sec:5, grace_period_sec:2, severity:"critical", actions:["log","banner","toast"], auto_recover:true},
     ports:[
       {port_id:"p1", label:"A", label_style:"alpha", universe:10, direction:"out", fixtures:[
         {id:"fix_04", name:"侧光染色灯组", profile_id:"martin_mac_aura_14ch", address:1, tags:["侧光"], semantic_desc:"", allow_shared_address:false}
       ]},
       {port_id:"p2", label:"B", label_style:"alpha", universe:11, direction:"out", fixtures:[
         {id:"fix_05", name:"侧光染色灯组备份", profile_id:"martin_mac_aura_14ch", address:1, tags:["侧光","备份"], semantic_desc:"与主灯同址，已标记允许共址", allow_shared_address:true}
       ]}
     ]},
    {node_id:"node_3", name:"观众席矩阵解码器", source:"manual", ip:"192.168.3.60",
     protocol:"artnet", groups:["观众席"],
     discovery:{online:null, artpoll_reply:null, rtt_ms:null, first_seen:null, last_seen:null},
     offline_policy:{mode:"ignore", liveness_source:"artdmx", threshold_sec:30, grace_period_sec:5, severity:"warning", actions:["log"], auto_recover:true},
     ports:[
       {port_id:"p1", label:"1", label_style:"numeric", universe:20, direction:"out", fixtures:[]},
       {port_id:"p2", label:"2", label_style:"numeric", universe:21, direction:"out", fixtures:[]}
     ]}
  ];

  var FLAT = [];
  NODES.forEach(function (n) {
    n.ports.forEach(function (p) {
      p.fixtures.forEach(function (f) {
        var c = Object.assign({}, f);
        c.universe = p.universe; c.node_id = n.node_id; c.node_name = n.name;
        c.port_id = p.port_id; c.port_label = p.label;
        FLAT.push(c);
      });
    });
  });

  var PRESETS = {
    romantic_pink:{name:"浪漫粉", category_id:"cat_ballad", profile_ref:null, universal:true,
      channel_values:{red:255,green:105,blue:180,white:20}, transition_ms:1500,
      summary:"抒情段落的柔和底色", tags:["浪漫","温情","甜美","柔和"]},
    cyberpunk_blue:{name:"赛博朋克蓝", category_id:"cat_edm", profile_ref:"beam_230w_16ch", universal:false,
      channel_values:{dimmer:255,color_wheel:32,prism:96,gobo:24,frost:64,strobe:200,pan:128,tilt:110},
      transition_ms:800, summary:"电子乐段落的冷艳科技质感", tags:["科技","冷艳","电音","未来"]},
    rock_red:{name:"热烈摇滚红", category_id:"cat_edm", profile_ref:null, universal:true,
      channel_values:{red:255,green:0,blue:0,white:0}, transition_ms:500,
      summary:"高强度冲击", tags:["高能","激情","冲击","炸裂"]},
    sunset_gold:{name:"暖阳金", category_id:"cat_warm", profile_ref:"martin_mac_aura_14ch", universal:false,
      channel_values:{dimmer:245,red:255,green:190,blue:80,white:100,ctc:128,speed:40},
      transition_ms:2000, summary:"日落时分的自然温暖", tags:["自然","日落","温馨"]},
    aurora_teal:{name:"极光青", category_id:"cat_ballad", profile_ref:"martin_mac_aura_14ch", universal:false,
      channel_values:{dimmer:180,red:0,green:220,blue:200,white:60,ctc:200}, transition_ms:2600,
      summary:"深蓝到青绿的缓慢呼吸", tags:["极光","呼吸","幽暗"]},
    legacy_unknown:{name:"早期未归类配色", category_id:"", profile_ref:null, universal:true,
      channel_values:{red:180,green:180,blue:60}, transition_ms:1200,
      summary:"尚未指派分类的历史资产", tags:["历史","待整理"]}
  };

  var SCENES = [
    {id:"warm_sunset", name:"暖阳金慢推", color:"#f59e0b", icon:"fa-solid fa-sun",
     desc:"主唱段落 3 秒慢推暖色", payload:{mode:"single", transition_ms:3000, fixtures:[
       {id:"fix_01", channels:{dimmer:255,red:255,green:190,blue:80,white:100}},
       {id:"fix_02", channels:{dimmer:255,red:255,green:190,blue:80,white:100}}]}},
    {id:"edm_burst", name:"电音爆发", color:"#a855f7", icon:"fa-solid fa-bolt",
     desc:"副歌瞬间全功率冷色冲击", payload:{mode:"single", transition_ms:120, fixtures:[
       {id:"fix_03", channels:{dimmer:255,prism:96,gobo:24,strobe:255}}]}},
    {id:"blackout", name:"全黑收场", color:"#475569", icon:"fa-solid fa-moon",
     desc:"谢幕安全归零", payload:{mode:"single", transition_ms:800, fixtures:[
       {id:"fix_01", channels:{dimmer:0}},{id:"fix_02", channels:{dimmer:0}},{id:"fix_03", channels:{dimmer:0}}]}},
    {id:"ballad_breath", name:"抒情呼吸", color:"#22d3ee", icon:"fa-solid fa-wind",
     desc:"三段式缓慢呼吸时序", payload:{mode:"sequence", sequence_name:"抒情呼吸", transition_ms:2200, steps:[]}}
  ];

  var ALARMS = [
    {id:"alm_00007", code:"ERR-NODE-OFFLINE", title:"设备掉线 · 舞台右侧辅助解码器",
     message:"解码器节点 [node_2] 掉线：超过阈值 5.0s 未收到 ARTDMX 心跳（已静默 18.4s）",
     node_id:"node_2", severity:"critical", actions:["log","banner","toast"],
     state:"open", raised_at:"2026-10-13 21:33:58", last_at:"2026-10-13 21:38:12", recovered_at:null, acked_at:null},
    {id:"alm_00006", code:"ERR-NODE-OFFLINE", title:"设备掉线 · 观众席矩阵解码器",
     message:"解码器节点 [node_3] 掉线（已于 21:31:02 恢复，离线 42.6s）",
     node_id:"node_3", severity:"warning", actions:["log"],
     state:"recovered", raised_at:"2026-10-13 21:30:19", last_at:"2026-10-13 21:31:02",
     recovered_at:"2026-10-13 21:31:02", acked_at:null},
    {id:"alm_00005", code:"ERR-MASK-TRIP", title:"物理安全掩码触发硬件熔断拦截",
     message:"大模型指令尝试向锁定通道 [control] 写入非零值，已被强制归零",
     node_id:"", severity:"warning", actions:["log","banner"],
     state:"acked", raised_at:"2026-10-13 20:58:41", last_at:"2026-10-13 20:58:41",
     recovered_at:null, acked_at:"2026-10-13 21:02:10"}
  ];

  var LAYOUT = {version:2, configured:true, groups:[
    {group_id:"g1", title:"常用氛围", columns:3, order:0,
     item_ids:["preset:sunset_gold","preset:romantic_pink","preset:aurora_teal"]},
    {group_id:"g2", title:"炸场与收场", columns:2, order:1,
     item_ids:["preset:cyberpunk_blue","preset:rock_red"]},
    {group_id:"g3", title:"快机器按钮", columns:4, order:2,
     item_ids:["scene:warm_sunset","scene:edm_burst","scene:ballad_breath","scene:blackout"]}
  ]};

  var DMX = new Array(512).fill(0);
  [1,2,3,4,7,8,9,10,11,14,20,21,22,31,32,45,46,60,64,72,80,96,110,128,140,160,180,200,220,240,255]
    .forEach(function (v, i) { DMX[i] = v; });

  var ROUTES = {
    "/api/auth/verify": {status:"ok", session:{username:"admin", display_name:"系统主管理员", role:"admin", permissions:["manage_users","manage_backups","view_dashboard","operate_lights","edit_kb","panic_control","manage_plugins","system_config","view_logs"]}},
    "/api/system/status": {venue_name:"演艺大厅A现场", target_ip:"192.168.3.2:6454", fps:30},
    "/api/kb/summary": {profiles_count:2, venues_count:3, presets_count:Object.keys(PRESETS).length,
      categories_count:CATS.length, kb_path:"D:\\ai_lighting_system\\knowledge_base",
      active_venue_file:"venue_livehouse_hall_a.json", active_venue_name:"演艺大厅A现场",
      active_fixture_count:FLAT.length, active_node_count:NODES.length,
      active_port_count:NODES.reduce(function(a,n){return a+n.ports.length;},0),
      active_universes:[0,1,2,3,10,11,20,21]},
    "/api/kb/profiles": [AURA, BEAM],
    "/api/kb/profile_detail": AURA,
    "/api/kb/venues": [
      {filename:"venue_livehouse_hall_a.json", venue_id:"venue_livehouse_hall_a", venue_name:"演艺大厅A现场",
       default_target_ip:"192.168.3.2", fixture_count:FLAT.length, node_count:NODES.length,
       port_count:NODES.reduce(function(a,n){return a+n.ports.length;},0),
       fixtures:FLAT, nodes:NODES, is_active:true},
      {filename:"venue_theatre_b.json", venue_id:"venue_theatre_b", venue_name:"小剧场B厅",
       default_target_ip:"192.168.4.2", fixture_count:0, node_count:1, port_count:1,
       fixtures:[], nodes:[], is_active:false},
      {filename:"venue_arena_c.json", venue_id:"venue_arena_c", venue_name:"体育中心C馆",
       default_target_ip:"10.20.0.2", fixture_count:24, node_count:6, port_count:12,
       fixtures:[], nodes:[], is_active:false}
    ],
    "/api/kb/venue_detail": {venue_id:"venue_livehouse_hall_a", venue_name:"演艺大厅A现场",
      default_target_ip:"192.168.3.2", nodes:NODES, fixtures:FLAT},
    "/api/kb/presets": PRESETS,
    "/api/kb/categories": {categories:CATS},
    "/api/kb/attribute_groups": {groups:AGS},
    "/api/kb/conflicts": {has_conflict:true, has_any_issue:true, danger_count:2, notice_count:1,
      checked_fixtures:FLAT.length, universe_count:6, conflicts:[
        {type:"overflow", severity:"danger", universe:10,
         desc:"灯具 [侧光染色灯组] 通道区间 CH1~CH14 超过单 Universe 上限 512"},
        {type:"overlap", severity:"danger", universe:0,
         desc:"Universe 0 通道冲突：[舞台左前一号面光 (CH31~CH44)] 与 [舞台右前二号面光 (CH45~CH58)] 重叠！"},
        {type:"shared_address", severity:"warn", universe:11,
         desc:"Universe 11 通道共址：[侧光染色灯组备份] 与 [侧光染色灯组] 地址相同（已标记允许共址，仅作提示）"}
      ]},
    "/api/panel/layout": LAYOUT,
    "/api/alarms": {alarms:ALARMS, open_count:1, acked_count:1, recovered_count:1, total:3},
    "/api/nodes/discovered": {
      discovered:[
        {ip:"192.168.3.51", universes:[0,1,2,3], stale:false, age_sec:0.4, last_seen_ms:1791898261092},
        {ip:"192.168.3.53", universes:[7], stale:false, age_sec:1.2, last_seen_ms:1791898260000},
        {ip:"192.168.3.71", universes:[12,13], stale:true, age_sec:184.6, last_seen_ms:1791897000000}
      ],
      watchdog:{
        node_1:{online:true, mode:"threshold", liveness_source:"artdmx", severity:"warning", last_seen_age_sec:0.4, offline_sec:0},
        node_2:{online:false, mode:"threshold", liveness_source:"artdmx", severity:"critical", last_seen_age_sec:18.4, offline_sec:18.4},
        node_3:{online:true, mode:"ignore", liveness_source:"artdmx", severity:"warning", last_seen_age_sec:42.1, offline_sec:0}
      }},
    "/api/dmx/universe": {universe:0, channels:DMX},
    "/api/monitor/stats": {port:6454, current_fps:29.8, total_frames:184320,
      recent_packets:Array.from({length:14}).map(function(_,i){
        return {time:"21:38:" + String(2+i).padStart(2,"0") + ".4" + i,
          from_ip:i%2?"192.168.3.51":"192.168.3.53", universe:(i%3)*1+0, seq:(200+i)%256,
          active_channels:["CH1:255","CH2:128","CH7:255","CH8:105","CH9:180","CH10:20"],
          active_count:6+i};})},
    "/api/logs/stream": [
      {timestamp:"2026-10-13 21:38:12", level:"ERROR", logger:"root",
       message:"【掉线告警】节点 [node_2] 判定掉线：超过阈值 5.0s 未收到 ARTDMX 心跳（已静默 18.4s）",
       diag_code:"ERR-NODE-OFFLINE",
       diagnostics:{title:"Art-Net 解码器节点掉线",
         cause:"该解码器在设定的阈值时间内未按存活判据上报心跳。常见成因：网线/交换机端口松动、解码器断电重启、IP 被其他设备抢占。",
         solution:"1. 先确认解码器电源与链路指示灯；2. 在「设备节点与监视」中对该 IP 执行「测试连接」查看三态判定；3. 若设备本身正常但长期静默，把该节点的存活判据改为 artpoll 或把模式改为「忽略」。"}},
      {timestamp:"2026-10-13 21:37:40", level:"INFO", logger:"root",
       message:"已切换当前场地为: [演艺大厅A现场] (3 个解码器节点 / 5 台灯具)"},
      {timestamp:"2026-10-13 21:36:02", level:"WARNING", logger:"root",
       message:"安全机制生效: 已封锁灯库 [beam_230w_16ch] 的危险通道 CH14 (灯具复位)"},
      {timestamp:"2026-10-13 21:35:18", level:"INFO", logger:"root",
       message:"【快捷直通执行】单一场景 Cue (淡变: 3000ms) 0毫秒推送底层 DMX"},
      {timestamp:"2026-10-13 21:31:02", level:"INFO", logger:"root",
       message:"解码器节点 [node_3] 已恢复在线（离线 42.6s）"},
      {timestamp:"2026-10-13 21:30:19", level:"ERROR", logger:"root",
       message:"【掉线告警】节点 [node_3] 判定掉线：超过阈值 30.0s 未收到 ARTDMX 心跳",
       diag_code:"ERR-NODE-OFFLINE"},
      {timestamp:"2026-10-13 21:20:44", level:"WARNING", logger:"root",
       message:"【故障告警 - 代码 ERR-MASK-TRIP】: 物理安全掩码触发硬件熔断拦截",
       diag_code:"ERR-MASK-TRIP",
       diagnostics:{title:"物理安全掩码触发硬件熔断拦截",
         cause:"大模型或外部指令尝试向被锁定的危险通道（如系统复位 Reset、危险宏）写入非安全数值。",
         solution:"系统已自动将其强制归零，无需人工干预。如需开放该通道，请在对应灯库 Profile 中将 is_safe 显式配置为 true。"}}
    ],
    "/api/scenes/list": SCENES,
    "/api/plugins/installed": [
      {plugin_id:"artnet_protocol", name:"Art-Net 输出协议", type:"protocol", version:"2.4.1", enabled:true},
      {plugin_id:"qwen_local_llm", name:"本地 Qwen2.5 推理适配器", type:"llm", version:"1.8.0", enabled:true},
      {plugin_id:"beat_perception", name:"音频节拍感知", type:"perception", version:"1.1.3", enabled:false},
      {plugin_id:"chase_macro", name:"追光宏调度器", type:"macro", version:"0.9.7", enabled:true}
    ],
    "/api/plugins/detail": {plugin_id:"qwen_local_llm", name:"本地 Qwen2.5 推理适配器",
      config:{api_url:"http://127.0.0.1:8085/v1/chat/completions", model_name:"qwen2.5-7b-4q", timeout_sec:30, enable_stream:false},
      config_schema:{properties:{
        api_url:{type:"string", title:"推理服务端点", description:"兼容 OpenAI Chat Completions 协议"},
        model_name:{type:"string", title:"模型标识名"},
        timeout_sec:{type:"integer", title:"请求超时（秒）"},
        enable_stream:{type:"boolean", title:"流式返回", default:false}}}},
    "/api/market/packages": [
      {package_id:"dmx_fixture_sim", name:"DMX 灯具仿真器", type:"tool", version:"1.2.0",
       description:"在没有真实灯具的情况下回放 DMX 帧，用于离线排练与培训。", author:"AI-MA Labs"},
      {package_id:"ma2_bridge", name:"grandMA2 桥接", type:"protocol", version:"0.6.4",
       description:"双向同步 grandMA2 的序列与执行器状态。", author:"社区贡献"},
      {package_id:"timecode_sync", name:"时间码同步 (MTC/LTC)", type:"perception", version:"2.0.1",
       description:"按时间码驱动场景切换，适合剧场与晚会。", author:"Stage Systems"}
    ],
    "/api/llm/config": {api_url:"http://127.0.0.1:8085/v1/chat/completions", model_name:"qwen2.5-7b-4q"}
  };

  // ---- 会话伪造 ----
  var SESS = {username:"admin", display_name:"系统管理员", role:"admin",
    permissions:["view_dashboard","operate_lights","edit_kb","panic_control","manage_plugins","system_config","view_logs"]};
  try {
    localStorage.setItem("ai_ma_token", "preview-token");
    localStorage.setItem("ai_ma_session", JSON.stringify(SESS));
  } catch (e) {}

  // ---- 由 URL 查询参数指定要展示的视图 / 子页签 ----
  var Q = new URLSearchParams(location.search);
  var VIEW = Q.get("v") || "control";
  try { localStorage.setItem("ai_ma_view", VIEW); } catch (e) {}

  // ---- fetch 拦截 ----
  var realFetch = window.fetch;
  window.fetch = function (url, opts) {
    var u = String(url);
    var path = u.split("?")[0];
    var body = null;
    if (ROUTES[path] !== undefined) body = ROUTES[path];
    else {
      var keys = Object.keys(ROUTES).sort(function (a, b) { return b.length - a.length; });
      for (var i = 0; i < keys.length; i++) {
        if (path.indexOf(keys[i]) === 0) { body = ROUTES[keys[i]]; break; }
      }
    }
    if (body === null) body = {status: "ok"};
    if (opts && opts.method === "POST") {
      if (path === "/api/nodes/test_connection") {
        body = {ip: "192.168.3.51", reply: true, node_name: "AI-MA Node 4Port",
          short_name: "AI-MA NODE 01", num_ports: 4, port_universes: [0,1,2,3],
          mac: "00:11:22:33:44:55", rtt_ms: 0.82, style: 0, style_name: "Node",
          state: "online", hint: "已收到 ArtPollReply，节点在线", error: null};
      } else { body = {status: "ok", created: true, count: 6}; }
    }
    return Promise.resolve({status: 200, ok: true,
      json: function () { return Promise.resolve(JSON.parse(JSON.stringify(body))); }});
  };

  // ---- boot 完成后切到目标 KB / 诊断子页签 ----
  var PANE = Q.get("p"), DPANE = Q.get("d");
  setTimeout(function () {
    if (PANE) {
      var t = document.querySelector('#kbSubnav .tab[data-pane="' + PANE + '"]');
      if (t) t.click();
    }
    if (DPANE) {
      var d = document.querySelector('#diagSubnav .tab[data-dpane="' + DPANE + '"]');
      if (d) d.click();
    }
    // 打开指定模态窗，便于截图核验
    var MODAL = Q.get("m");
    if (MODAL) {
      if (MODAL === "preset") {
        var card = document.querySelector('#presetGroups .pcard[data-key="cyberpunk_blue"]');
        if (card) card.click();
      } else if (MODAL === "categories") {
        var b = document.getElementById('btnManageCats'); if (b) b.click();
      } else if (MODAL === "panel") {
        var b2 = document.getElementById('btnEditPanel'); if (b2) b2.click();
      } else if (MODAL === "node") {
        var b3 = document.getElementById('btnTestConn');
        var nb = document.querySelector('#nodeTree button[data-manual]');
        if (b3) { document.getElementById('modalNode').classList.add('open');
                  b3.click(); }
      }
    }
    document.documentElement.setAttribute('data-preview-ready', '1');
  }, 900);
})();
"""


def build():
    with io.open(os.path.join(WEB, "index.html"), "r", encoding="utf-8") as f:
        html = f.read()

    # file:// 下 /assets 绝对路径不可用，改写为相对路径
    html = html.replace('href="/assets/', 'href="assets/')
    html = html.replace('src="/assets/', 'src="assets/')

    inject = "<script>\n" + STUB + "\n</script>\n"
    marker = '<script src="assets/app.js"></script>'
    if marker not in html:
        raise SystemExit("[ABORT] 未找到 app.js 引入锚点。")
    html = html.replace(marker, inject + marker, 1)

    banner = ('<div style="position:fixed;right:12px;bottom:12px;z-index:99999;'
              'padding:6px 12px;border-radius:999px;font:600 11px/1.4 system-ui;'
              'background:rgba(245,158,11,.16);border:1px solid rgba(245,158,11,.45);'
              'color:#fcd34d;">离线预览 · 桩数据，非真实设备</div>')

    with io.open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(html.replace("</body>", banner + "\n</body>", 1))
    return OUT_HTML


SHOTS = [
    ("01-登录页",          "login",           None),
    ("02-主控台",          "control",         None),
    ("03-主控台-面板组装",  "control",         "m=panel"),
    ("04-快捷场景管理",     "scenes_studio",   None),
    ("05-设备节点与监视",   "monitor",         None),
    ("06-解码器连接测试",   "monitor",         "m=node"),
    ("07-插件市场",        "marketplace",     None),
    ("08-本地大模型",       "llm_cfg",         None),
    ("09-知识库总览",       "kb",              "p=overview"),
    ("10-物理灯库",         "kb",              "p=profiles"),
    ("11-场地与节点拓扑",   "kb",              "p=venues"),
    ("12-美学预设",         "kb",              "p=presets"),
    ("13-预设详情编辑",     "kb",              "p=presets&m=preset"),
    ("14-分类与属性分组",   "kb",              "p=presets&m=categories"),
    ("15-AI解析与RAG",      "kb",              "p=airag"),
    ("16-告警中心",         "diagnostics",     "d=alarms"),
    ("17-运行日志诊断",     "diagnostics",     "d=logs"),
]


def find_chrome():
    for c in CHROME_CANDIDATES:
        if os.path.exists(c):
            return c
    return shutil.which("chrome") or shutil.which("google-chrome") or shutil.which("chromium")


def shoot():
    chrome = find_chrome()
    if not chrome:
        print("[!] 未找到 Chrome/Edge，跳过截图。")
        return 1
    os.makedirs(SHOT_DIR, exist_ok=True)
    import urllib.parse
    base = "file:///" + OUT_HTML.replace("\\", "/")
    login = "file:///" + os.path.join(WEB, "login.html").replace("\\", "/")

    made = 0
    for name, view, extra in SHOTS:
        url = login if view == "login" else (base + "?v=" + view + ("&" + extra if extra else ""))
        out = os.path.join(SHOT_DIR, name + ".png")
        cmd = [chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
               "--force-device-scale-factor=1", "--window-size=1680,1050",
               "--virtual-time-budget=5000", "--screenshot=" + out, url]
        try:
            subprocess.run(cmd, timeout=90,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print(f"  [X] {name}: {e}")
            continue
        if os.path.exists(out) and os.path.getsize(out) > 2000:
            print(f"  [OK] {name}.png  ({os.path.getsize(out) // 1024} KB)")
            made += 1
        else:
            print(f"  [X] {name} 截图失败")
    print(f"\n共生成 {made} 张截图 -> {SHOT_DIR}")
    return 0 if made else 1


if __name__ == "__main__":
    p = build()
    print(f"[OK] 预览页已生成: {p}")
    if "--shot" in sys.argv:
        print("\n正在用无头浏览器渲染各视图 …")
        sys.exit(shoot())
