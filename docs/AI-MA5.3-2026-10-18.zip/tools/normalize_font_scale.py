# -*- coding: utf-8 -*-
"""
界面标度收敛：把 theme.css 中所有跌破设计标度的字号拉回 8 级标度。

设计标度：11 / 12 / 13 / 14 / 16 / 20 / 26 / 34
问题：存在 9px、10px、22px 等标度外字号，实测共 227 处元素低于 11px 可读下限。
"""

import io
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSS = os.path.join(BASE, "web", "assets", "theme.css")

with io.open(CSS, "r", encoding="utf-8") as f:
    src = f.read()
orig = src

report = []


def sub(pattern, repl, why, expect=None):
    global src
    n = len(re.findall(pattern, src))
    if expect is not None and n != expect:
        raise SystemExit(f"[ABORT] {why}: 期望 {expect} 处，实际 {n} 处")
    src = re.sub(pattern, repl, src)
    if n:
        report.append(f"  {n:>3} 处  {why}")
    return n


# 1) 徽标内的图标跟随文字字号，避免"图标比文字小一号"的廉价感
sub(r"\.badge i \{ font-size: 10px; \}", ".badge i { font-size: 1em; }",
    "徽标图标字号改为 1em（跟随文字）", expect=1)

# 2) 跌破可读下限的微字号统一拉到 11px
sub(r"font-size: 10px", "font-size: var(--fs-11)", "10px → 11px（可读下限）")
sub(r"font-size: 9px", "font-size: var(--fs-11)", "9px  → 11px（可读下限）")

# 3) 标度外的 22px 归入 20px
sub(r"font-size: 22px", "font-size: var(--fs-20)", "22px → 20px（标度外）", expect=1)

# 4) 折叠箭头容器宽度需容纳 11px 字形，否则会被裁切
sub(r"(\.attr-head \.caret \{[^}]*?)width: 10px;", r"\1width: 12px;",
    "属性组折叠箭头容器加宽至 12px", expect=1)

# 5) 行内小徽章高度按 11px 字号重新配平
sub(r"(\.tile-kind \{[^}]*?)height: 18px;", r"\1height: 20px;",
    "卡片类型徽章 18px → 20px（配平 11px 字号）", expect=1)
# 先处理带父选择器的那条，再处理裸选择器，避免二次匹配
sub(r"(\.nav-item \.nav-count \{[^}]*?)height: 18px;", r"\1height: 20px;",
    "侧栏计数徽章 18px → 20px", expect=1)
sub(r"(?m)^\.nav-count \{[^}]*?height: 18px;", lambda m: m.group(0).replace("height: 18px;", "height: 20px;"),
    "通用计数徽章 18px → 20px", expect=1)

# 6) 控件高度落回设计标度（侧栏导航 36px、页签 32px）
sub(r"(\.nav-item \{[^}]*?)height: 38px;", r"\1height: 36px;",
    "侧栏导航项 38px → 36px（对齐控件标度）", expect=1)
sub(r"(\.tab \{[^}]*?)height: 30px;", r"\1height: 32px;",
    "页签 30px → 32px（对齐 btn-sm 标度）", expect=1)

if src == orig:
    print("[!] 没有任何改动，可能已经收敛过。")
    sys.exit(0)

with io.open(CSS + ".tmp", "w", encoding="utf-8", newline="") as f:
    f.write(src)
os.replace(CSS + ".tmp", CSS)

print("[OK] theme.css 标度收敛完成：")
for line in report:
    print(line)

# 复核
with io.open(CSS, "r", encoding="utf-8") as f:
    check = f.read()
left = re.findall(r"font-size:\s*(\d+(?:\.\d+)?)px", check)
bad = sorted({v for v in left if float(v) not in (11, 12, 13, 14, 16, 20, 26, 34)})
print(f"\n  剩余标度外字号: {bad if bad else '无'}")
print(f"  字号声明分布  : {sorted(set(left), key=float)}")
