# -*- coding: utf-8 -*-
"""
向技术方案追加第十五章：系统编译混淆规范与自动化构建 SOP (面向 Debian Linux 生产部署)
"""

import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls, qn

DOC_PATH = r"C:\Users\Administrator\Desktop\AI-MA异构协同与自适应灯光控制系统技术方案.docx"

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_p(doc, text="", bold=False, color_rgb=(51, 65, 85), font_size=10.5, space_after=6, space_before=0, line_spacing=1.25):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line_spacing
    if text:
        run = p.add_run(text)
        run.bold = bold
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(font_size)
        run.font.color.rgb = RGBColor(*color_rgb)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h1(doc, title):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(10)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(18)
    run.bold = True
    run.font.color.rgb = RGBColor(15, 23, 42)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_h2(doc, title):
    p = doc.add_paragraph(style="Heading 2")
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(6)
    run = p.runs[0] if p.runs else p.add_run(title)
    run.text = title
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(14)
    run.bold = True
    run.font.color.rgb = RGBColor(30, 41, 59)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    return p

def add_code_block(doc, code_text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    
    cell = table.cell(0, 0)
    cell.width = Inches(6.5)
    set_cell_background(cell, "0F172A")
    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
    
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}><w:top w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:left w:val="single" w:sz="16" w:space="0" w:color="38BDF8"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/><w:right w:val="single" w:sz="4" w:space="0" w:color="38BDF8"/></w:tcBorders>')
    tcPr.append(tcBorders)

    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(code_text.strip())
    run.font.name = "Consolas"
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor(226, 232, 240)
    run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    doc.add_paragraph()

def add_table_data(doc, headers, rows_data):
    table = doc.add_table(rows=len(rows_data) + 1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    for c_idx, h in enumerate(headers):
        cell = table.cell(0, c_idx)
        set_cell_background(cell, "1E293B")
        set_cell_margins(cell, top=80, bottom=80, left=100, right=100)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(h)
        run.bold = True
        run.font.name = "Microsoft YaHei"
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(56, 189, 248)
        run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')

    for r_idx, row in enumerate(rows_data):
        bg = "F8FAFC" if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx + 1, c_idx)
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=60, bottom=60, left=100, right=100)
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.name = "Microsoft YaHei"
            run.font.size = Pt(8.5)
            run.font.color.rgb = RGBColor(51, 65, 85)
            run._r.get_or_add_rPr().set(qn('w:eastAsia'), 'Microsoft YaHei')
    
    doc.add_paragraph()

def append_obfuscation_chapter():
    doc = Document(DOC_PATH)
    print("开始向技术方案追加第十五章：系统编译混淆规范与自动化构建SOP...")

    add_h1(doc, "第十五章：系统核心编译混淆规范与自动化构建 SOP（面向 Debian Linux 生产部署）")
    add_p(doc, "在工业级交付与商业落地过程中，软件资产的知识产权保护、核心算法黑盒化以及防逆向工程至关重要。本章制定了《极光灵动 · AI-MA OS v5.0》严格的编译混淆范围红线，详细阐述前端全量 AST 深度混淆与后端核心 Cython 二进制编译的实施细则，并提供一键式开箱即用的自动化构建 SOP。")

    add_h2(doc, "15.1 编译与混淆设计哲学：核心深度黑盒化，开放生态透明化")
    add_p(doc, "如果对系统进行无差别的盲目混淆或全盘加密，会导致演艺现场插件无法开发、大模型 RAG 无法解析灯库 JSON、现场工程师无法修改 IP 端口。因此，系统确立了不可动摇的构建哲学：")
    add_p(doc, "1. 核心深度黑盒化：DMX 仲裁机理、30Hz 高精度定时器、RBAC 密码学鉴权与 32 位 Hex Key 计算逻辑全部编译为 Linux 原生 ELF 二进制共享库（.so），物理剥离敏感 Python 源码。")
    add_p(doc, "2. 前端全量无断点混淆：前端所有 JS、CSS、HTML 进行深度压缩与字符串池动态混淆，杜绝 API 路径外泄；同时根据业务需求明确关闭无限断点死循环（debugProtection: false），保障现场运维审查顺畅。")
    add_p(doc, "3. 开放生态与配置透明：保持 plugin_sdk.py 抽象基类、plugins/ 目录、knowledge_base/ 知识库及 config/ 配置文件的开放可读性，确保第三方与 AI 能随时生成新插件。")

    add_h2(doc, "15.2 系统编译混淆范围红线与资产分类矩阵")
    headers_15_2 = ["系统资产分类", "目标文件 / 目录路径", "处理方式与保护深度", "设计目的与业务合理性"]
    rows_15_2 = [
        ["前端全量资产", "web/assets/app.js\nweb/assets/theme.css\nweb/login.html\nweb/index.html", "全量深度混淆 + 字符串阵列化 + 极致压缩", "防页面结构复刻与 API 泄露，关闭无限断点确保日常运行平稳"],
        ["后端绝对核心", "core/dmx_merger.py\ncore/engine.py\ncore/auth_manager.py\ncore/artnet_controller.py\ncore/node_discovery.py\ncore/backup_manager.py", "Cython 编译为 C 原生机器码共享库 (.so)\n生产包物理彻底删除对应 .py 源码", "保护仲裁状态机、时钟防抖、root 动态 Key 与容灾哈希校验等核心技术秘密，逆向难度等同于 C/C++ 二进制"],
        ["插件开放底座", "core/plugin_sdk.py\ncore/plugin_host.py", "保留 Python 源码格式 (仅剥离开发注释)", "确保生态开放，用户、第三方及 AI 能够清晰导入基类规范开发新插件"],
        ["业务知识库", "knowledge_base/profiles/\nknowledge_base/venues/\nknowledge_base/presets/", "坚决保持标准 JSON 格式 (不混淆)", "保证大模型 RAG 上下文拼装顺畅，支持灯光师自由导入导出场地与美学预设"],
        ["现场配置与运维", "config/*.json\nlogs/*.log\nVERSION", "坚决保持明文 (不混淆)", "允许工程人员在现场修改 IP、端口、查看中文运行诊断日志"]
    ]
    add_table_data(doc, headers_15_2, rows_15_2)

    add_h2(doc, "15.3 前端全量无断点 AST 深度混淆规范")
    add_p(doc, "前端混淆采用纯原生 AST 变量重构与动态字符串池加密流水线：")
    add_p(doc, "• 字符串池动态加密：扫描提取所有 API 路由、关键 DOM 选择器与交互文案，统一打乱并进行 Base64 编码，存储于顶部独立数组池（如 _0x288217）。")
    add_p(doc, "• 动态移位解码：运行时通过轻量解码函数（如 _0xf181(_idx)）在毫秒级内动态解密，任何静态文本扫描工具均无法直接嗅探到系统接口。")
    add_p(doc, "• 关闭无限断点阻滞：根据生产现场需求，严格将 debugProtection 设为 false，开发人员在需要时依然可以打开 Chrome F12 控制台排查网络连通性，而不会导致浏览器主线程陷入卡死死循环。")

    add_h2(doc, "15.4 Debian Linux 原生 Cython 机器码编译与源码物理抹除 SOP")
    add_p(doc, "针对主力目标生产系统 Debian Linux，采用标准 Cython 编译流水线：")
    add_code_block(doc, """# Debian 生产服务器一键编译加固流程 (build_debian.sh 核心逻辑)
# 1. 安装基础 C 编译链与 Cython
sudo apt-get update && sudo apt-get install -y build-essential python3-dev cython3

# 2. 调用 setup_cython.py 将核心模块编译为机器码 .so 共享库
python3 setup_cython.py build_ext --inplace

# 3. 生产包物理删除 Python 源码 (彻底黑盒化)
for mod in dmx_merger engine auth_manager artnet_controller node_discovery backup_manager; do
    if [ -f "${mod}.*.so" ] || [ -f "${mod}.so" ]; then
        rm -f "${mod}.py" "${mod}.c"
        echo "[OK] 源码已物理清除，生效二进制共享库: ${mod}.so"
    fi
done""")

    add_h2(doc, "15.5 一键自动化构建流水线工具使用手册（tools/build_release.py）")
    add_p(doc, "系统在 tools/build_release.py 中内置了开箱即用的自动化发布构建引擎。开发者在开发机上执行该脚本，系统会自动完成前端全量混淆、组装 Debian 编译工程并输出至独立的 dist/ai-ma-v5-release 生产发布目录。")
    add_p(doc, "构建执行命令：")
    add_code_block(doc, "python tools/build_release.py")
    add_p(doc, "发布包部署至 Debian 服务器的操作步骤：")
    add_p(doc, "1. 将生成的 dist/ai-ma-v5-release 目录整体打包拷贝到 Debian 服务器（如 /opt/ai_lighting_system）；")
    add_p(doc, "2. 在服务器上运行单行命令执行核心编译加固：bash build_debian.sh；")
    add_p(doc, "3. 部署 systemd 守护服务：sudo cp ai-ma.service /etc/systemd/system/ && sudo systemctl enable --now ai-ma；")
    add_p(doc, "4. 系统即刻以纯二进制机器码内核与全量混淆前端对外提供服务，资产绝对安全！")

    doc.save(DOC_PATH)
    print("第十五章已成功追加并保存至技术方案文档！")
    print(f"最终文档路径: {DOC_PATH}")
    print("最新段落数:", len(doc.paragraphs))
    print("最新表格数:", len(doc.tables))

if __name__ == "__main__":
    append_obfuscation_chapter()
