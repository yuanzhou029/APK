# -*- coding: utf-8 -*-
"""
AI-MA 操作系统 v5.3 · 生产发布一键混淆与二进制编译构建系统 (Release Build Pipeline)

架构基线：混合硬实时微内核架构
    - 底层：Rust 44Hz 硬实时微内核 (aima-rt-daemon) + 共享内存 ABI 扩展 (aima_shm_sdk)
    - 上层：Python 业务调度与意图理解层 (control_station.py)

支持平台：主推 Debian Linux (x86_64 / aarch64)，兼容 Windows 构建环境

核心构建原则：
1. 前端全量深度混淆 (AST 字符串抽取 + 变量重写 + 极致压缩，关闭无限断点)
2. 后端核心 Cython 编译 (Cython -> GCC -> *.so，物理剥离敏感 .py 源码)
3. **内核构件完整打包** (bin/ 微内核二进制 + abi3 共享内存扩展，缺一不可)
4. **双 systemd 单元** (aima-rt.service 硬实时独占 + ai-ma.service 依赖挂靠)
5. 开放生态透明化 (plugin_sdk.py, plugins/, config/, knowledge_base/ 保持开放可配)
6. 输出至独立发布目录 dist/ai-ma-v5-release，不污染开发源码工作区
7. **产物完整性强校验**：关键内核构件缺失时构建直接失败，绝不静默产出残废包
"""

import os
import sys
import shutil
import re
import base64
import random
import string
import subprocess
import json
import time

# ==============================================================================
# 构建基线常量
# ==============================================================================

VERSION = "5.3.0"
RELEASE_TAG = "v5.3"
SYSTEM_NAME = "极光灵动 · AI-MA 异构协同与自适应灯光操作系统"

# 安装根目录 (Debian 部署路径)
INSTALL_ROOT = "/opt/ai-ma"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST_DIR = os.path.join(BASE_DIR, "dist", "ai-ma-v5-release")

# 需要 Cython 编译为机器码并物理抹除源码的绝对核心模块。
# 注意：kernel_bridge.py 承载微内核共享内存 ABI 契约 (slot 布局 / seqlock 协议)，
#      属于新内核架构最核心的知识产权，必须纳入编译保护。
CORE_MODULES_TO_COMPILE = [
    "dmx_merger.py",
    "engine.py",
    "kernel_bridge.py",      # 微内核共享内存 ABI 契约 (新内核架构成败所系)
    "auth_manager.py",
    "artnet_sender.py",      # 修正：原 artnet_controller.py 已重命名，旧名会被静默跳过
    "node_discovery.py",
    "backup_manager.py",
    "marketplace_service.py",
]

# 新内核架构必需的微内核二进制 (44Hz 硬实时仲裁与批量推流守护进程)
REQUIRED_KERNEL_BINARIES = ["aima-rt-daemon"]
# 运维辅助二进制 (缺失不阻断构建，仅提示)
OPTIONAL_KERNEL_BINARIES = ["aima-telemetry-consumer", "aima-worker-sandbox"]

# 共享内存 ABI 扩展 (PyO3 abi3-py310 稳定 ABI，一个 .so 通吃 Python >= 3.10)
SHM_SDK_BASENAME = "aima_shm_sdk"
SDK_SOURCE_CANDIDATES = {
    "win32": ["aima_shm_sdk.pyd", "aima_shm_sdk.dll"],
    "linux": ["aima_shm_sdk.so", "libaima_shm_sdk.so", f"{SHM_SDK_BASENAME}.abi3.so"],
}

# 保持明文开放、供第三方与 AI 自由开发插件的生态资产
OPEN_ECOSYSTEM_DIRS = ["config", "knowledge_base", "plugins", "marketplace", "deploy", "backups"]


def log_step(title):
    print("\n" + "=" * 70)
    print(f" [*] {title}")
    print("=" * 70)


def die(msg):
    """构建致命错误：立即终止，绝不产出静默残废包"""
    print("\n" + "!" * 70)
    print(f" [FATAL] {msg}")
    print("!" * 70)
    sys.exit(1)


def pick_sdk_target_name() -> str:
    """按当前构建平台决定 ABI 扩展在发布包中的最终文件名"""
    return "aima_shm_sdk.pyd" if sys.platform == "win32" else "aima_shm_sdk.so"


def find_sdk_extension():
    """在工程根与 core/ 中定位 aima_shm_sdk ABI 扩展，返回 (源路径, 目标文件名) 或 None"""
    plat = "win32" if sys.platform == "win32" else "linux"
    candidates = SDK_SOURCE_CANDIDATES[plat]
    for root in (BASE_DIR, os.path.join(BASE_DIR, "core")):
        if not os.path.isdir(root):
            continue
        for name in candidates:
            p = os.path.join(root, name)
            if os.path.isfile(p):
                return p, pick_sdk_target_name()
    return None


# ==============================================================================
# 第零部分：构建前置基线校验 (任何缺项立即失败)
# ==============================================================================

def validate_build_baseline():
    log_step("构建前置基线校验 (核心模块 / ABI 扩展 / 内核二进制)")

    # 1. Cython 编译清单必须全部真实存在，静默跳过是不可接受的
    src_core = os.path.join(BASE_DIR, "core")
    missing = [m for m in CORE_MODULES_TO_COMPILE if not os.path.isfile(os.path.join(src_core, m))]
    if missing:
        die(f"核心编译保护清单中存在 {len(missing)} 个不存在的模块，"
            f"发布包的核心保护将出现缺口：{missing}\n"
            f"       请修正 CORE_MODULES_TO_COMPILE 后重新构建。")
    print(f" [OK] 核心编译保护清单 {len(CORE_MODULES_TO_COMPILE)} 个模块全部就位")
    for m in CORE_MODULES_TO_COMPILE:
        print(f"       - core/{m}")

    # 2. ABI 扩展必须存在，否则发布包会静默退回纯软件模式 (等于没上新内核)
    sdk = find_sdk_extension()
    if not sdk:
        die("未找到 aima_shm_sdk ABI 扩展 (.pyd / .so)！\n"
            "       该扩展是上层 Python 与微内核通信的唯一通道，缺失将导致发布包\n"
            "       静默退回 Python 纯软件模式 (即实际运行旧内核行为)。\n"
            f"       请先在 ai-ma-kernel-v5.3 中构建 aima-shm-sdk 并放置于工程根或 core/ 下。")
    print(f" [OK] 共享内存 ABI 扩展已就位: {os.path.relpath(sdk[0], BASE_DIR)} "
          f"-> {sdk[1]} (abi3 稳定 ABI)")

    # 3. 微内核二进制必须存在
    bin_src = os.path.join(BASE_DIR, "bin")
    if not os.path.isdir(bin_src):
        die("未找到 bin/ 目录！新内核架构要求 bin/aima-rt-daemon 随包发布。")

    ext = ".exe" if sys.platform == "win32" else ""
    found_required = []
    for name in REQUIRED_KERNEL_BINARIES:
        if os.path.isfile(os.path.join(bin_src, f"{name}{ext}")):
            found_required.append(f"{name}{ext}")
    if not found_required:
        die(f"bin/ 中未找到当前平台 ({sys.platform}) 的必需微内核二进制 "
            f"{[n + ext for n in REQUIRED_KERNEL_BINARIES]}！\n"
            f"       若目标为 Debian Linux，请先交叉编译或在构建机上 cargo build --release\n"
            f"       后把 aima-rt-daemon (无扩展名) 放入 bin/。")
    print(f" [OK] 微内核二进制已就位: {found_required}")

    missing_opt = [n for n in OPTIONAL_KERNEL_BINARIES
                   if not os.path.isfile(os.path.join(bin_src, f"{n}{ext}"))]
    if missing_opt:
        print(f" [注意] 可选运维二进制缺失 (不阻断构建): {missing_opt}")


# ==============================================================================
# 第一部分：前端全量代码深度混淆引擎 (AST 字符串抽取 + 变量重写 + 极致压缩)
# ==============================================================================

def obfuscate_js_content(js_code: str) -> str:
    """
    高强度 JavaScript 纯原生混淆器 (不依赖外部 npm 包，零断点阻滞，安全高效)
    1. 剥离全部注释
    2. 提取双引号/单引号中的长文本为 Base64 编码的动态混淆字符串池
    3. 插入轻量混淆解码器与运行时索引替换
    4. 变量名与函数关键字压缩，关闭 debug-protection
    """
    clean_code = re.sub(r'/\*[\s\S]*?\*/', '', js_code)
    lines = []
    for line in clean_code.splitlines():
        stripped = line.strip()
        if stripped.startswith('//'):
            continue
        lines.append(line)
    clean_code = "\n".join(lines)

    str_candidates = re.findall(r'["\']([^"\'\n\r\\]{4,120})["\']', clean_code)
    unique_strs = list(dict.fromkeys(str_candidates))

    random.shuffle(unique_strs)
    pool_data = [base64.b64encode(s.encode('utf-8')).decode('ascii') for s in unique_strs]

    var_pool_name = "_0x" + "".join(random.choices(string.hexdigits.lower()[:16], k=6))
    func_decode_name = "_0x" + "".join(random.choices(string.hexdigits.lower()[:16], k=4))

    decoder_stub = f"""
var {var_pool_name} = {json.dumps(pool_data)};
function {func_decode_name}(_idx) {{
  var _raw = {var_pool_name}[_idx];
  return decodeURIComponent(escape(atob(_raw)));
}}
"""
    for idx, s in enumerate(unique_strs[:120]):
        escaped_s = re.escape(s)
        pattern = r'["\']' + escaped_s + r'["\']'
        if re.search(pattern, clean_code):
            clean_code = re.sub(pattern, f"{func_decode_name}({idx})", clean_code, count=3)

    compressed = re.sub(r'[ \t]+', ' ', clean_code)
    compressed = re.sub(r'\s*([\{\}\(\)\;\:\,\+\-\=\<\>\!])\s*', r'\1', compressed)

    return f"/* AI-MA Enterprise Obfuscated */\n" + decoder_stub.strip() + "\n" + compressed.strip()


def obfuscate_css_content(css_code: str) -> str:
    clean = re.sub(r'/\*[\s\S]*?\*/', '', css_code)
    compressed = re.sub(r'\s+', ' ', clean)
    compressed = re.sub(r'\s*([\{\}\;\:\,])\s*', r'\1', compressed)
    return compressed.strip()


def obfuscate_html_content(html_code: str) -> str:
    clean = re.sub(r'<!--[\s\S]*?-->', '', html_code)
    clean = re.sub(r'\n\s+', '\n', clean)
    return clean.strip()


def build_frontend(target_web_dir: str):
    log_step("执行前端全量深度混淆 (JS 字符串池混淆 + CSS/HTML 极致压缩)")
    os.makedirs(target_web_dir, exist_ok=True)

    for html_file in ["index.html", "login.html"]:
        src_p = os.path.join(BASE_DIR, "web", html_file)
        if os.path.exists(src_p):
            with open(src_p, "r", encoding="utf-8") as f:
                content = f.read()
            obf_content = obfuscate_html_content(content)
            with open(os.path.join(target_web_dir, html_file), "w", encoding="utf-8") as f:
                f.write(obf_content)
            print(f" [OK] HTML 混淆完成: {html_file} ({len(content)} -> {len(obf_content)} 字节)")

    assets_src = os.path.join(BASE_DIR, "web", "assets")
    assets_dst = os.path.join(target_web_dir, "assets")
    os.makedirs(assets_dst, exist_ok=True)

    for item in os.listdir(assets_src):
        src_item = os.path.join(assets_src, item)
        dst_item = os.path.join(assets_dst, item)
        if os.path.isdir(src_item):
            shutil.copytree(src_item, dst_item, dirs_exist_ok=True)
        elif not item.endswith((".js", ".css")):
            shutil.copy2(src_item, dst_item)

    app_js_src = os.path.join(assets_src, "app.js")
    if os.path.exists(app_js_src):
        with open(app_js_src, "r", encoding="utf-8") as f:
            js_text = f.read()
        obf_js = obfuscate_js_content(js_text)
        with open(os.path.join(assets_dst, "app.js"), "w", encoding="utf-8") as f:
            f.write(obf_js)
        print(f" [OK] JavaScript 深度混淆完成: app.js ({len(js_text)} -> {len(obf_js)} 字节，关闭无限断点)")

    theme_css_src = os.path.join(assets_src, "theme.css")
    if os.path.exists(theme_css_src):
        with open(theme_css_src, "r", encoding="utf-8") as f:
            css_text = f.read()
        obf_css = obfuscate_css_content(css_text)
        with open(os.path.join(assets_dst, "theme.css"), "w", encoding="utf-8") as f:
            f.write(obf_css)
        print(f" [OK] CSS 深度混淆完成: theme.css ({len(css_text)} -> {len(obf_css)} 字节)")


# ==============================================================================
# 第二部分：后端核心 Cython 二进制编译与剥离引擎
# ==============================================================================

def generate_cython_setup(target_core_dir: str) -> str:
    setup_content = f"""# -*- coding: utf-8 -*-
from setuptools import setup, Extension
from Cython.Build import cythonize
import os

modules = {json.dumps(CORE_MODULES_TO_COMPILE)}
extensions = [
    Extension(os.path.splitext(m)[0], [m], extra_compile_args=["-O3", "-fPIC"])
    for m in modules if os.path.exists(m)
]

setup(
    name="ai_ma_core_binary",
    ext_modules=cythonize(
        extensions,
        compiler_directives={{'language_level': "3", 'always_allow_keywords': True}},
        quiet=True
    )
)
"""
    setup_path = os.path.join(target_core_dir, "setup_cython.py")
    with open(setup_path, "w", encoding="utf-8") as f:
        f.write(setup_content)
    return setup_path


def build_backend_core(target_core_dir: str):
    log_step("准备核心模块 Cython 二进制保护流水线")
    os.makedirs(target_core_dir, exist_ok=True)
    src_core = os.path.join(BASE_DIR, "core")

    for f in os.listdir(src_core):
        src_f = os.path.join(src_core, f)
        dst_f = os.path.join(target_core_dir, f)
        if os.path.isfile(src_f):
            shutil.copy2(src_f, dst_f)

    setup_file = generate_cython_setup(target_core_dir)
    print(" [OK] 已生成 Cython 模块编译工程文件:", os.path.basename(setup_file))
    print(f" [OK] 核心保护编译清单 ({len(CORE_MODULES_TO_COMPILE)} 个绝对核心模块):")
    for m in CORE_MODULES_TO_COMPILE:
        print(f"       - core/{m} -> 编译为机器码动态库并在生产包中物理抹除源码")
    print(" [OK] 开放生态保障: core/plugin_sdk.py 保持透明开放基类接口，供第三方与 AI 扩展")


# ==============================================================================
# 第三部分：新内核构件打包 (微内核二进制 + 共享内存 ABI 扩展)
# ==============================================================================

def build_kernel_artifacts(dist_root: str):
    """
    打包新内核架构的两大必备构件：
      1. bin/ 微内核二进制 (aima-rt-daemon 等)
      2. aima_shm_sdk ABI 扩展 (工程根与 core/ 双份放置，兼容不同 sys.path 布局)
    这是"发布包到底跑的是新内核还是旧内核"的分水岭。
    """
    log_step(f"打包新内核构件 (微内核二进制 + {RELEASE_TAG} 共享内存 ABI 扩展)")

    # ---- 1. bin/ 微内核二进制 ----
    bin_src = os.path.join(BASE_DIR, "bin")
    bin_dst = os.path.join(dist_root, "bin")
    os.makedirs(bin_dst, exist_ok=True)

    packaged_bins = []
    for item in os.listdir(bin_src):
        src_item = os.path.join(bin_src, item)
        if os.path.isfile(src_item):
            shutil.copy2(src_item, os.path.join(bin_dst, item))
            packaged_bins.append(item)
    for name in packaged_bins:
        # Debian 下需要可执行位 (Windows 上为无害的 no-op 语义)
        target = os.path.join(bin_dst, name)
        try:
            os.chmod(target, 0o755)
        except Exception:
            pass
    print(f" [OK] 微内核二进制目录已同步: bin/ ({len(packaged_bins)} 个文件)")
    for n in sorted(packaged_bins):
        print(f"       - bin/{n}")

    # ---- 2. 共享内存 ABI 扩展 ----
    sdk = find_sdk_extension()
    if not sdk:
        die("打包阶段丢失 aima_shm_sdk ABI 扩展，构建中止。")
    sdk_src, sdk_name = sdk

    placed = []
    for dst_dir in (dist_root, os.path.join(dist_root, "core")):
        os.makedirs(dst_dir, exist_ok=True)
        shutil.copy2(sdk_src, os.path.join(dst_dir, sdk_name))
        placed.append(os.path.relpath(os.path.join(dst_dir, sdk_name), dist_root))
    print(f" [OK] 共享内存 ABI 扩展已打包 (abi3 稳定 ABI，Python >= 3.10 通用):")
    for p in placed:
        print(f"       - {p}")

    return packaged_bins, placed


# ==============================================================================
# 第四部分：生成 Debian Linux 专用编译部署与安全加固脚本
# ==============================================================================

DEBIAN_BUILD_SH = r"""#!/bin/bash
# ==============================================================================
# 《极光灵动 · AI-MA OS @@VERSION@@》Debian Linux 原生二进制编译与安全加固脚本
# 架构基线：混合硬实时微内核 (Rust 44Hz 微内核 + Python 业务调度层)
# ==============================================================================
set -e

PKG_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PKG_ROOT"

echo "=================================================================="
echo " AI-MA OS @@VERSION@@ Debian 编译加固流水线"
echo " 阶段一: 核心 Python 模块 -> Cython 机器码 (.so)"
echo " 阶段二: Rust 硬实时微内核 -> ELF 二进制与共享内存 ABI 扩展"
echo "=================================================================="

# ------------------------------------------------------------------
# 公共依赖检查
# ------------------------------------------------------------------
if ! command -v gcc >/dev/null 2>&1; then
    echo "[!] 未检测到 gcc 编译器，正在通过 apt 自动安装依赖..."
    sudo apt-get update && sudo apt-get install -y build-essential python3-dev python3-pip
fi

python3 -c "import cython" >/dev/null 2>&1 || {
    echo "[*] 正在安装 Cython 编译引擎..."
    pip3 install cython || sudo apt-get install -y cython3
}

# ------------------------------------------------------------------
# 阶段一：核心 Python 模块 Cython 二进制编译
# ------------------------------------------------------------------
echo ""
echo "------------------------------------------------------------------"
echo " [阶段一] 核心 Python 模块 Cython 编译"
echo "------------------------------------------------------------------"
cd "$PKG_ROOT/core"
python3 setup_cython.py build_ext --inplace

MODULES="@@MODULES@@"
for mod in $MODULES; do
    mod="${mod%.py}"
    if ls ${mod}.*.so >/dev/null 2>&1 || [ -f "${mod}.so" ]; then
        rm -f "${mod}.py" "${mod}.c"
        echo " [OK] 源码已销毁，已转换为二进制动态库: ${mod}.so"
    else
        echo " [!] 严重警告: ${mod}.so 编译未完成，为防呆暂保留源码"
    fi
done
rm -rf build setup_cython.py
cd "$PKG_ROOT"

# ------------------------------------------------------------------
# 阶段二：Rust 硬实时微内核构建
# ------------------------------------------------------------------
echo ""
echo "------------------------------------------------------------------"
echo " [阶段二] Rust 硬实时微内核 (aima-rt-daemon) 与 ABI 扩展构建"
echo "------------------------------------------------------------------"

KERNEL_SRC="${AIMA_KERNEL_SRC:-${1:-}}"
if [ -z "$KERNEL_SRC" ]; then
    for cand in \
        "$PKG_ROOT/../ai-ma-kernel-v5.3" \
        "/opt/ai-ma-kernel-src/ai-ma-kernel-v5.3" \
        "/usr/local/src/ai-ma-kernel-v5.3"
    do
        if [ -f "$cand/Cargo.toml" ]; then KERNEL_SRC="$(cd "$cand" && pwd)"; break; fi
    done
fi

if [ -n "$KERNEL_SRC" ] && [ -f "$KERNEL_SRC/Cargo.toml" ]; then
    echo " [*] 内核源码目录: $KERNEL_SRC"

    if ! command -v cargo >/dev/null 2>&1; then
        echo "[!] 未检测到 Rust 工具链 (cargo)。"
        echo "    请先安装: curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
        echo "    安装后执行: source \"\$HOME/.cargo/env\" 并重新运行本脚本。"
        exit 1
    fi

    ( cd "$KERNEL_SRC" && cargo build --release -p aima-rt-daemon -p aima-shm-sdk )

    REL="$KERNEL_SRC/target/release"
    install -m 0755 "$REL/aima-rt-daemon" "$PKG_ROOT/bin/aima-rt-daemon"
    echo " [OK] 微内核二进制已安装: bin/aima-rt-daemon"

    for tool in aima-telemetry-consumer aima-worker-sandbox; do
        if [ -f "$REL/$tool" ]; then
            install -m 0755 "$REL/$tool" "$PKG_ROOT/bin/$tool"
            echo " [OK] 运维二进制已安装: bin/$tool"
        fi
    done

    SDK_SO=""
    for cand in "$REL/libaima_shm_sdk.so" "$REL/aima_shm_sdk.so" "$REL/aima_shm_sdk.abi3.so"; do
        if [ -f "$cand" ]; then SDK_SO="$cand"; break; fi
    done
    if [ -z "$SDK_SO" ]; then
        echo " [!] 致命: 未找到 libaima_shm_sdk.so，ABI 扩展缺失将导致系统退回软件模式！"
        exit 1
    fi
    install -m 0755 "$SDK_SO" "$PKG_ROOT/aima_shm_sdk.so"
    install -m 0755 "$SDK_SO" "$PKG_ROOT/core/aima_shm_sdk.so"
    echo " [OK] 共享内存 ABI 扩展已安装: aima_shm_sdk.so (abi3，Python >= 3.10 通用)"

    # 可选剥离调试符号，减小体积
    if command -v strip >/dev/null 2>&1; then
        strip --strip-unneeded "$PKG_ROOT/bin/aima-rt-daemon" 2>/dev/null || true
        strip --strip-unneeded "$PKG_ROOT/aima_shm_sdk.so" 2>/dev/null || true
        strip --strip-unneeded "$PKG_ROOT/core/aima_shm_sdk.so" 2>/dev/null || true
        echo " [OK] 已剥离调试符号"
    fi
else
    echo " [!] 未定位到 Rust 内核源码 (Cargo.toml)。"
    echo "     将改用 bin/ 中预置的交叉编译产物。请确认其为 Linux ELF:"
    if [ -f "$PKG_ROOT/bin/aima-rt-daemon" ]; then
        file "$PKG_ROOT/bin/aima-rt-daemon" 2>/dev/null || true
        chmod +x "$PKG_ROOT/bin/aima-rt-daemon" 2>/dev/null || true
        echo " [OK] 已使用预置 bin/aima-rt-daemon"
    else
        echo " [!] 致命: 既无内核源码，也无预置 bin/aima-rt-daemon！"
        exit 1
    fi
fi

# ------------------------------------------------------------------
# 内核构件完整性终检 (防止静默产出残废包)
# ------------------------------------------------------------------
echo ""
echo "------------------------------------------------------------------"
echo " [终检] 内核构件完整性"
echo "------------------------------------------------------------------"
FAIL=0
[ -x "$PKG_ROOT/bin/aima-rt-daemon" ] || { echo " [X] 缺失可执行 bin/aima-rt-daemon"; FAIL=1; }
[ -f "$PKG_ROOT/aima_shm_sdk.so" ] || { echo " [X] 缺失 aima_shm_sdk.so"; FAIL=1; }
[ -f "$PKG_ROOT/core/aima_shm_sdk.so" ] || { echo " [X] 缺失 core/aima_shm_sdk.so"; FAIL=1; }
if [ "$FAIL" -ne 0 ]; then
    echo ""
    echo " [FATAL] 内核构件不完整，包不可用于生产！"
    exit 1
fi
echo " [OK] 内核构件完整：微内核二进制 + ABI 扩展 + 核心机器码"

echo ""
echo "=================================================================="
echo " 恭喜！AI-MA OS @@VERSION@@ Debian 二进制加固已完成！"
echo "   - 核心算法已转换为机器码，敏感源码已物理移除"
echo "   - Rust 硬实时微内核与 abi3 ABI 扩展已就位"
echo "=================================================================="
echo " 下一步:"
echo "   sudo cp aima-rt.service ai-ma.service /etc/systemd/system/"
echo "   sudo systemctl daemon-reload"
echo "   sudo systemctl enable --now aima-rt.service"
echo "   sudo systemctl enable --now ai-ma.service"
echo " 访问: http://<主机IP>:9000   (默认账号 admin / admin123)"
echo "=================================================================="
"""


def generate_debian_build_script(dist_root: str):
    """生成 Debian Linux 一键编译加固脚本 (含 Rust 微内核构建段与内核构件终检)"""
    modules = " ".join(CORE_MODULES_TO_COMPILE)
    sh_content = DEBIAN_BUILD_SH.replace("@@VERSION@@", RELEASE_TAG).replace("@@MODULES@@", modules)
    sh_path = os.path.join(dist_root, "build_debian.sh")
    with open(sh_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(sh_content)
    try:
        os.chmod(sh_path, 0o755)
    except Exception:
        pass
    print(" [OK] 已生成 Debian Linux 编译加固脚本: build_debian.sh (含 Rust 微内核构建段)")


# ==============================================================================
# 第五部分：双 systemd 单元生成 (硬实时微内核 + 业务控制台)
# ==============================================================================

AIMA_RT_SERVICE = """[Unit]
Description=AI-MA @@VERSION@@ Hard Real-Time Microkernel (44Hz Arbitration & Batch Output)
Documentation=file:/opt/ai-ma/docs/ARCHITECTURE_UPGRADE_GUIDE.md
After=network.target
Before=ai-ma.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ai-ma
Environment="AIMA_ARTNET_TARGET=127.0.0.1:6454"
ExecStart=/opt/ai-ma/bin/aima-rt-daemon
Restart=always
RestartSec=1s

# ---------------- 硬实时特权与 CPU 亲和性隔离 ----------------
# 将该核绑定的 CPU 核心从通用调度器中隔离 (内核启动参数 isolcpus=3)
CPUAffinity=3
CPUSchedulingPolicy=fifo
CPUSchedulingPriority=98
Nice=-20
IOSchedulingClass=realtime
IOSchedulingPriority=0

# ---------------- 内存与文件描述符 ----------------
# 锁定全部内存页，杜绝换页导致的时钟抖动
LimitMEMLOCK=infinity
LimitNOFILE=65535

# ---------------- 看门狗 ----------------
WatchdogSec=1s

# ---------------- 沙箱加固 ----------------
NoNewPrivileges=true
ProtectHome=true
ProtectKernelTunables=true
PrivateTmp=false

# 共享内存设备必须可见 (微内核与业务层通过 /dev/shm 通信)
ReadWritePaths=/dev/shm

[Install]
WantedBy=multi-user.target
"""

AI_MA_SERVICE = """[Unit]
Description=AI-MA @@VERSION@@ Unified Control Station (Python Business Orchestration Layer)
Documentation=file:/opt/ai-ma/docs/ARCHITECTURE_UPGRADE_GUIDE.md
After=network.target network-online.target aima-rt.service
Wants=network-online.target

# ---------------- 与硬实时微内核的强依赖关系 ----------------
# Requires + BindsTo: 微内核停止或被杀死时，控制台必须同步停止，
#   避免出现"业务层仍在运行但无人推流"的幽灵状态。
# PartOf: 重启/停止 aima-rt.service 时联动本单元。
Requires=aima-rt.service
BindsTo=aima-rt.service
PartOf=aima-rt.service

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=/opt/ai-ma

Environment="PYTHONUNBUFFERED=1"
Environment="PYTHONIOENCODING=utf-8"
Environment="LANG=C.UTF-8"

# 告知控制台：微内核由 systemd 独立托管，禁止重复伴生拉起 (防止双内核争抢同一组共享内存槽位)
Environment="AIMA_RT_EXTERNAL=1"

ExecStart=/usr/bin/python3 /opt/ai-ma/control_station.py
Restart=always
RestartSec=3s
LimitNOFILE=65535
TimeoutStopSec=10s

# ---------------- 沙箱加固 ----------------
ProtectSystem=full
ProtectHome=true
NoNewPrivileges=true

# 共享内存目录必须可读写 (与微内核的零拷贝通道)
ReadWritePaths=/dev/shm

[Install]
WantedBy=multi-user.target
"""


def generate_systemd_units(dist_root: str):
    log_step("生成双 systemd 单元 (硬实时微内核 + 业务控制台强依赖挂靠)")

    def _write(path, content):
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(content.replace("@@VERSION@@", RELEASE_TAG))

    rt_txt = AIMA_RT_SERVICE
    app_txt = AI_MA_SERVICE

    _write(os.path.join(dist_root, "aima-rt.service"), rt_txt)
    print(" [OK] 已生成硬实时微内核服务单元: aima-rt.service")
    print("       CPUAffinity=3 / SCHED_FIFO 98 / LimitMEMLOCK=infinity / WatchdogSec=1s")

    _write(os.path.join(dist_root, "ai-ma.service"), app_txt)
    print(" [OK] 已生成业务控制台服务单元: ai-ma.service")
    print("       Requires + BindsTo + PartOf=aima-rt.service (内核停则控制台停)")
    print("       Environment=AIMA_RT_EXTERNAL=1 (禁止重复伴生拉起微内核)")

    # 同步进 deploy/，使包内不再残留旧内核语义的服务模板 (单一事实来源)
    deploy_dst = os.path.join(dist_root, "deploy")
    if os.path.isdir(deploy_dst):
        _write(os.path.join(deploy_dst, "aima-rt.service"), rt_txt)
        _write(os.path.join(deploy_dst, "ai-ma.service"), app_txt)
        legacy = os.path.join(deploy_dst, "ai-lighting.service")
        if os.path.exists(legacy):
            os.remove(legacy)
            print(" [OK] 已清除包内旧内核语义服务模板: deploy/ai-lighting.service")
        print(" [OK] deploy/ 服务模板已同步为双单元基线")


# ==============================================================================
# 第六部分：组装独立发布包 + 产物完整性强校验
# ==============================================================================

def assemble_release_package():
    log_step(f"组装 {RELEASE_TAG} 完整生产发布包")

    if os.path.exists(DIST_DIR):
        shutil.rmtree(DIST_DIR, ignore_errors=True)
    os.makedirs(DIST_DIR, exist_ok=True)

    # 1. 前端混淆
    build_frontend(os.path.join(DIST_DIR, "web"))

    # 2. 后端核心 Cython 编译工程
    build_backend_core(os.path.join(DIST_DIR, "core"))

    # 3. 新内核构件 (bin/ + ABI 扩展) —— 决定发布包运行的是新内核还是旧内核
    packaged_bins, placed_sdk = build_kernel_artifacts(DIST_DIR)

    # 4. 主调度入口与版本标定
    for main_file in ["control_station.py", "VERSION"]:
        src_f = os.path.join(BASE_DIR, main_file)
        if os.path.exists(src_f):
            shutil.copy2(src_f, os.path.join(DIST_DIR, main_file))
    print(" [OK] 主控调度程序已就绪: control_station.py")

    # 5. 保持开放的生态资产与核心业务库
    for d in OPEN_ECOSYSTEM_DIRS:
        src_d = os.path.join(BASE_DIR, d)
        dst_d = os.path.join(DIST_DIR, d)
        if os.path.exists(src_d):
            shutil.copytree(src_d, dst_d, dirs_exist_ok=True)
            print(f" [OK] 生态与业务目录已安全同步: {d}/")
        else:
            os.makedirs(dst_d, exist_ok=True)

    # 6. 生产运维专用工具
    dist_tools = os.path.join(DIST_DIR, "tools")
    os.makedirs(dist_tools, exist_ok=True)
    for tool_name in ["gen_root_key.py"]:
        src_t = os.path.join(BASE_DIR, "tools", tool_name)
        if os.path.exists(src_t):
            shutil.copy2(src_t, os.path.join(dist_tools, tool_name))
            print(f" [OK] 生产运维工具已同步: tools/{tool_name}")

    # 7. Windows 一键启动引导脚本
    bat_src = os.path.join(BASE_DIR, "启动系统总控台.bat")
    if os.path.exists(bat_src):
        shutil.copy2(bat_src, os.path.join(DIST_DIR, "启动系统总控台.bat"))
        print(" [OK] Windows 一键启动引导脚本已同步: 启动系统总控台.bat")

    # 8. 运行状态空目录
    for empty_d in ["logs", "screenshots"]:
        os.makedirs(os.path.join(DIST_DIR, empty_d), exist_ok=True)

    # 9. Debian 编译加固脚本
    generate_debian_build_script(DIST_DIR)

    # 10. 双 systemd 单元
    generate_systemd_units(DIST_DIR)

    # 11. 生成发布清单
    manifest = {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "release_tag": RELEASE_TAG,
        "architecture": "Hybrid Hard-Real-Time Microkernel (Rust) + Python Orchestration",
        "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "build_host_platform": sys.platform,
        "protected_core_modules": CORE_MODULES_TO_COMPILE,
        "kernel_binaries_in_bin": sorted(packaged_bins),
        "shm_sdk_placements": placed_sdk,
        "systemd_units": ["aima-rt.service", "ai-ma.service"],
        "open_ecosystem_dirs": OPEN_ECOSYSTEM_DIRS,
    }
    with open(os.path.join(DIST_DIR, "RELEASE_MANIFEST.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(" [OK] 发布清单已生成: RELEASE_MANIFEST.json")

    # 12. 产物完整性强校验 —— 缺项即构建失败
    verify_release_package(DIST_DIR)

    log_step(f"{RELEASE_TAG} 构建打包成功完成！")
    print(f"生产发布包输出路径: {DIST_DIR}")
    print("交付包特性：")
    print(" 1. 前端全量代码 (app.js, theme.css, HTML) 已经过不可逆混淆与压缩；")
    print(f" 2. 新内核构件完整：bin/ 微内核二进制 + aima_shm_sdk abi3 ABI 扩展 (双份放置)；")
    print(f" 3. 核心保护：{len(CORE_MODULES_TO_COMPILE)} 个模块编译为机器码并物理抹除源码 (含 kernel_bridge 共享内存 ABI 契约)；")
    print(" 4. 双 systemd 单元：aima-rt.service (硬实时独占) + ai-ma.service (强依赖挂靠)；")
    print(" 5. 开放生态 (plugin_sdk.py, plugins/, config/, knowledge_base/) 保持标准格式，支持 AI 与人工开发插件；")
    print(" 6. Debian 部署：运行 bash build_debian.sh (含 Rust 内核构建段) 后按提示启动 systemd 服务。")


def verify_release_package(dist_root: str):
    """发布包产物完整性强校验：任何关键构件的缺失都必须让构建失败"""
    log_step("产物完整性强校验 (缺失即构建失败)")

    errors = []

    # 1. 微内核二进制
    ext = ".exe" if sys.platform == "win32" else ""
    for name in REQUIRED_KERNEL_BINARIES:
        p = os.path.join(dist_root, "bin", f"{name}{ext}")
        if not os.path.isfile(p):
            errors.append(f"缺少微内核二进制: bin/{name}{ext}")
    if os.path.isfile(os.path.join(dist_root, "bin", f"aima-rt-daemon{ext}")):
        print(f" [OK] bin/aima-rt-daemon{ext}")

    # 2. ABI 扩展 (双份)
    sdk_name = pick_sdk_target_name()
    for rel in (sdk_name, os.path.join("core", sdk_name)):
        p = os.path.join(dist_root, rel)
        if not os.path.isfile(p):
            errors.append(f"缺少共享内存 ABI 扩展: {rel}")
        else:
            print(f" [OK] {rel} ({os.path.getsize(p)} 字节)")

    # 3. 双 systemd 单元
    for unit in ("aima-rt.service", "ai-ma.service"):
        p = os.path.join(dist_root, unit)
        if not os.path.isfile(p):
            errors.append(f"缺少 systemd 单元: {unit}")
        else:
            print(f" [OK] {unit}")

    # 4. Debian 构建脚本必须含 Rust 内核构建段
    sh_p = os.path.join(dist_root, "build_debian.sh")
    if not os.path.isfile(sh_p):
        errors.append("缺少 build_debian.sh")
    else:
        with open(sh_p, "r", encoding="utf-8") as f:
            sh_txt = f.read()
        if "cargo build --release" not in sh_txt:
            errors.append("build_debian.sh 中缺少 Rust 微内核构建段 (cargo build --release)")
        else:
            print(" [OK] build_debian.sh 含 Rust 微内核构建段")

    # 5. 核心模块保护清单一致性 (build_debian.sh 的销毁清单必须覆盖编译清单)
    if os.path.isfile(sh_p):
        missing_in_sh = [m[:-3] for m in CORE_MODULES_TO_COMPILE if m[:-3] not in sh_txt]
        if missing_in_sh:
            errors.append(f"build_debian.sh 源码销毁清单未覆盖: {missing_in_sh}")
        else:
            print(f" [OK] build_debian.sh 源码销毁清单完整覆盖 {len(CORE_MODULES_TO_COMPILE)} 个核心模块")

    # 6. 主入口与前端
    for rel in ("control_station.py", "VERSION", os.path.join("web", "index.html"),
                os.path.join("web", "assets", "app.js")):
        if not os.path.isfile(os.path.join(dist_root, rel)):
            errors.append(f"缺少发布资产: {rel}")
    print(" [OK] 主入口 / VERSION / 前端混淆产物齐备")

    if errors:
        for e in errors:
            print(f"   [X] {e}")
        die(f"发布包产物完整性校验失败，共 {len(errors)} 项缺失，构建已中止。")

    print(" [OK] 全部关键构件校验通过，发布包可用于生产交付")


if __name__ == "__main__":
    print("=" * 70)
    print(f" {SYSTEM_NAME}")
    print(f" {RELEASE_TAG} 生产发布打包流水线 (混合硬实时微内核架构)")
    print("=" * 70)
    validate_build_baseline()
    assemble_release_package()
