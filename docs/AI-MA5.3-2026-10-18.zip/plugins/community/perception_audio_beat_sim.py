# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: perception_audio_beat_sim
插件名称: BPM 音乐律动与音频节拍模拟发生器 (3 类 · 表现与创意插件)
物理位置: plugins/community/perception_audio_beat_sim.py
适用架构: AI-MA v5.3+ (3 类外部感知标准)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BasePerceptionPlugin，属于 PluginTier.CREATIVE (3 类)。
   - 必须实现 get_status() -> Dict[str, Any]，供监控面板实时读取。
2. 核心职责:
   - 负责模拟演艺现场声卡音频信号捕获与瞬态 BPM 提取，向系统总线广播节拍脉冲。
3. 声明式参数:
   - get_config_schema 声明 bpm (音乐节拍速度，默认 128) 与 sensitivity。
==============================================================================
"""

import time
from typing import Dict, Any

try:
    from plugin_sdk import BasePerceptionPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BasePerceptionPlugin, PluginType, CoreContext


class AudioBeatSimPlugin(BasePerceptionPlugin):
    """
    音频律动与实时 BPM 感知模拟插件实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "perception_audio_beat_sim",
            "name": "BPM 音乐律动模拟发生器",
            "version": "1.1.0",
            "author": "SonicLab",
            "type": PluginType.PERCEPTION,
            "description": "模拟演艺现场音频捕获与瞬态 BPM 提取，向灯光系统广播实时节拍 TICK。"
        }

    # --------------------------------------------------------------------------
    # 2. 阶梯式依赖规范
    # --------------------------------------------------------------------------
    def get_required_adapters(self) -> list:
        return ["artnet_monitor"]

    # --------------------------------------------------------------------------
    # 3. 声明式参数规范 (支持在 Web 界面自由调节)
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "bpm": {
                "type": "integer",
                "label": "音乐节拍 (BPM)",
                "default": 128,
                "description": "每分钟节拍数 (常见 EDM 约为 128 BPM，慢歌约 70-90)"
            },
            "sensitivity": {
                "type": "number",
                "label": "瞬态峰值灵敏度 (0.1~1.0)",
                "default": 0.85,
                "description": "检测底鼓/军鼓瞬态跳变阈值灵敏度"
            }
        }

    # --------------------------------------------------------------------------
    # 4. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.start_time = time.time()
        self.beat_count: int = 0
        self.bpm: int = 128
        self.current_energy: float = 0.5
        self._last_beat_time: float = 0.0
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def on_save_state(self) -> Dict[str, Any]:
        """保存 beat_count、bpm、current_energy 等状态"""
        return {
            "beat_count": self.beat_count,
            "bpm": self.bpm,
            "current_energy": self.current_energy
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复 beat_count、bpm、current_energy 等状态"""
        if isinstance(state, dict):
            self.beat_count = int(state.get("beat_count", 0))
            self.bpm = int(state.get("bpm", 128))
            self.current_energy = float(state.get("current_energy", 0.5))

    # --------------------------------------------------------------------------
    # 5. 感知插件核心状态获取抽象方法实现
    # --------------------------------------------------------------------------
    def get_status(self) -> Dict[str, Any]:
        """
        供上层引擎与 Web 前端轮询读取实时感知状态
        """
        cfg = self.get_config()
        bpm = int(cfg.get("bpm", self.bpm))
        self.bpm = bpm
        sensitivity = float(cfg.get("sensitivity", 0.85))

        # 计算当前节拍相位与脉冲
        now = time.time()
        beat_interval = 60.0 / max(1, bpm)
        beat_phase = (now % beat_interval) / beat_interval
        is_on_beat = beat_phase < 0.15

        if is_on_beat and (now - self._last_beat_time > beat_interval * 0.7):
            self._last_beat_time = now
            self.beat_count += 1
            self.current_energy = min(1.0, 0.4 + sensitivity * 0.6)

            # 在生成节拍时可通过 self.get_event_hub().publish("audio.beat", ...) 发布事件
            hub = self.get_event_hub()
            if hub:
                hub.publish(
                    topic="audio.beat",
                    sender_id="perception_audio_beat_sim",
                    data={
                        "beat_count": self.beat_count,
                        "bpm": self.bpm,
                        "energy": self.current_energy,
                        "timestamp": now
                    }
                )
        else:
            self.current_energy = max(0.1, self.current_energy * 0.95)

        return {
            "status": "active" if self.is_enabled else "idle",
            "bpm": bpm,
            "sensitivity": sensitivity,
            "beat_phase": round(beat_phase, 3),
            "is_on_beat": is_on_beat,
            "beat_count": self.beat_count,
            "current_energy": round(self.current_energy, 3),
            "uptime_sec": int(now - self.start_time)
        }
