# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: macro_marquee
插件名称: 多灯走马灯与流水追逐特效宏 (3 类 · 表现与创意插件)
物理位置: plugins/community/marquee_plugin.py
适用架构: AI-MA v5.3+ (3 类表现创意热插拔标准)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseMacroPlugin，属于 PluginTier.CREATIVE (3 类)。
   - 实现 render(elapsed_ms, params, current_frame) -> bytearray。
2. 算法实现:
   - 基于时间流逝与 step_ms 模运算计算当前激活灯位 (current_step_idx)。
   - 支持拖尾余辉指数衰减：val = int(255 * (decay ** distance))，实现平滑流水拖尾。
3. 声明式参数与 AI 意图隔离:
   - get_config_schema 声明 step_ms (流动步进耗时) 与 decay_factor (余辉系数)；
   - get_ai_prompts 注入追逐节奏 AI 调校提示词。
==============================================================================
"""

from typing import Dict, Any

try:
    from plugin_sdk import BaseMacroPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseMacroPlugin, PluginType, CoreContext


class MarqueeMacroPlugin(BaseMacroPlugin):
    """
    空间追逐走马灯与拖尾流水特效宏实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "macro_marquee",
            "name": "多灯走马灯与流水追逐特效宏",
            "version": "2.2.0",
            "author": "AI-MA Creative Community",
            "type": PluginType.MACRO,
            "description": "基于空间拓扑顺序的高精度追逐流动发生器，支持流动速度微调与底色平滑过渡。",
            "homepage": "https://ai-ma.lighting/marketplace/macro_marquee"
        }

    # --------------------------------------------------------------------------
    # 2. 阶梯式依赖规范
    # --------------------------------------------------------------------------
    def get_required_adapters(self) -> list:
        return ["fixture_profile_conversion"]

    # --------------------------------------------------------------------------
    # 3. 专属 AI 角色 System Prompt 隔离定义
    # --------------------------------------------------------------------------
    def get_ai_prompts(self) -> Dict[str, str]:
        return {
            "default_system": (
                "你是一个精通舞台动态跑灯与流水追逐的灯光师助理。根据用户的语言（如'跑快一点、带点余辉拖尾'），"
                "输出 JSON：{\"step_ms\": 整数毫秒(100-3000), \"decay_factor\": 浮点数(0.0-0.9)}，严禁多余废话。"
            )
        }

    # --------------------------------------------------------------------------
    # 3. 声明式参数规范
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "default_speed_ms": {
                "type": "integer",
                "label": "默认流动步进周期 (ms)",
                "default": 400,
                "description": "单盏灯点亮后移交给下一盏灯的毫秒耗时"
            },
            "decay_factor": {
                "type": "number",
                "label": "余辉尾流衰减系数",
                "default": 0.0,
                "description": "0 表示纯单灯走马灯，0.1~0.9 表示带拖尾余辉"
            }
        }

    # --------------------------------------------------------------------------
    # 5. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.step_offset: int = 0
        self.direction: int = 1
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def on_save_state(self) -> Dict[str, Any]:
        """保存 step_offset、direction 等步进状态"""
        return {
            "step_offset": self.step_offset,
            "direction": self.direction
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复 step_offset、direction 等步进状态"""
        if isinstance(state, dict):
            self.step_offset = int(state.get("step_offset", 0))
            self.direction = int(state.get("direction", 1))

    # --------------------------------------------------------------------------
    # 6. 核心渲染方法实现
    # --------------------------------------------------------------------------
    def render(self, elapsed_ms: float, params: Dict[str, Any], current_frame: bytearray) -> bytearray:
        """
        根据耗时毫秒数与灯具分组列表，计算生成新的 DMX 帧
        """
        cfg = self.get_config()
        step_ms = params.get("step_ms", cfg.get("default_speed_ms", 400))
        decay = params.get("decay_factor", cfg.get("decay_factor", 0.0))
        fixture_groups = params.get("fixtures", [])
        direction = params.get("direction", self.direction)
        self.direction = 1 if direction >= 0 else -1

        if not fixture_groups:
            return current_frame

        total_steps = len(fixture_groups)
        base_step = int((elapsed_ms / float(step_ms)))
        if self.direction < 0:
            current_step_idx = (total_steps - 1 - (base_step % total_steps)) % total_steps
        else:
            current_step_idx = base_step % total_steps
        self.step_offset = current_step_idx

        out_frame = bytearray(current_frame)

        for idx, fix in enumerate(fixture_groups):
            dimmer_ch = fix.get("dimmer_ch")
            if not dimmer_ch or not (1 <= dimmer_ch <= 512):
                continue

            if idx == current_step_idx:
                out_frame[dimmer_ch - 1] = 255
            else:
                if decay > 0:
                    distance = (current_step_idx - idx) % total_steps
                    val = int(255 * (decay ** distance))
                    out_frame[dimmer_ch - 1] = max(out_frame[dimmer_ch - 1], val)
                else:
                    out_frame[dimmer_ch - 1] = 0

        return out_frame
