# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: macro_breathing
插件名称: 正弦曲线平滑呼吸律动宏 (3 类 · 表现与创意插件)
物理位置: plugins/community/breathing_plugin.py
适用架构: AI-MA v5.3+ (3 类表现创意热插拔标准)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseMacroPlugin，属于 PluginTier.CREATIVE (3 类)。
   - 必须实现 render(elapsed_ms, params, current_frame) -> bytearray。
   - 天然面向 Web 用户界面与插件市场开放，支持灯光师热启停与热卸载。
2. 算法实现:
   - 基于正弦缓动 (Sine Easing) 曲线：(sin(phase * 2π - π/2) + 1.0) / 2.0，
     消除呼吸两端的突变冲击，呈现平滑自然的明暗过渡。
3. 声明式参数与 AI 意图隔离:
   - get_config_schema 声明默认周期与底噪最低亮度；
   - get_ai_prompts 注入专属氛围调节提示词，支持自然语言解析为毫秒周期与明暗范围。
==============================================================================
"""

import math
from typing import Dict, Any

try:
    from plugin_sdk import BaseMacroPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseMacroPlugin, PluginType, CoreContext


class BreathingMacroPlugin(BaseMacroPlugin):
    """
    正弦曲线平滑呼吸律动动态宏实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "macro_breathing",
            "name": "正弦曲线平滑呼吸律动宏",
            "version": "2.2.0",
            "author": "AI-MA Creative Community",
            "type": PluginType.MACRO,
            "description": "基于高精度正弦缓动算法的平滑呼吸律动发生器，支持周期与明暗范围精细设定。",
            "homepage": "https://ai-ma.lighting/marketplace/macro_breathing"
        }

    # --------------------------------------------------------------------------
    # 2. 阶梯式依赖规范
    # --------------------------------------------------------------------------
    def get_required_adapters(self) -> list:
        return ["fixture_profile_conversion"]

    # --------------------------------------------------------------------------
    # 3. 声明式参数规范
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "default_cycle_ms": {
                "type": "integer",
                "label": "默认呼吸周期 (ms)",
                "default": 2000,
                "description": "完整呼气吸气循环一次的耗时 (毫秒)"
            },
            "default_min_brightness": {
                "type": "integer",
                "label": "底噪最低亮度 (0~255)",
                "default": 10,
                "description": "呼吸最暗处的保持亮度，防止完全黑场熄灭"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 专属 AI 角色 System Prompt 隔离定义
    # --------------------------------------------------------------------------
    def get_ai_prompts(self) -> Dict[str, str]:
        return {
            "default_system": (
                "你是一个精通舞台氛围灯光宏调节的助理。根据用户的自然语言（例如'慢一点、更加柔和'或'心跳急促'），"
                "输出 JSON 参数对象：{\"cycle_ms\": 整数毫秒(500-10000), \"min_val\": 0-255, \"max_val\": 0-255}，绝不输出其他文字。"
            )
        }

    # --------------------------------------------------------------------------
    # 4. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.current_phase: float = 0.0
        self.cycle_time: float = 2000.0
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def on_save_state(self) -> Dict[str, Any]:
        """保存当前 current_phase、cycle_time 等状态"""
        return {
            "current_phase": self.current_phase,
            "cycle_time": self.cycle_time
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复当前 current_phase、cycle_time 等状态"""
        if isinstance(state, dict):
            self.current_phase = float(state.get("current_phase", 0.0))
            self.cycle_time = float(state.get("cycle_time", 2000.0))

    # --------------------------------------------------------------------------
    # 5. 核心渲染方法实现
    # --------------------------------------------------------------------------
    def render(self, elapsed_ms: float, params: Dict[str, Any], current_frame: bytearray) -> bytearray:
        """
        根据时间流逝毫秒与动态参数，计算生成新的 DMX 帧
        注意：必须是非阻塞运算，严禁进行网络或磁盘 IO
        """
        cfg = self.get_config()
        cycle_ms = params.get("cycle_ms", cfg.get("default_cycle_ms", 2000))
        min_val = params.get("min_val", cfg.get("default_min_brightness", 10))
        max_val = params.get("max_val", 255)
        channels = params.get("channels", [])

        # 正弦归一化相位计算 (0.0 ~ 1.0)
        phase = (elapsed_ms % float(cycle_ms)) / float(cycle_ms)
        self.current_phase = phase
        self.cycle_time = float(cycle_ms)
        sin_val = (math.sin(phase * 2 * math.pi - math.pi / 2) + 1.0) / 2.0
        val = int(min_val + sin_val * (max_val - min_val))
        val = max(0, min(255, val))

        # 运行中支持使用 self.get_state_mirror() 读取系统全局电平作为底噪与环境基准进行正向动态混合
        mirror = self.get_state_mirror()
        base_frame = mirror.get_universe_frame(0) if mirror else current_frame

        out_frame = bytearray(current_frame)
        for ch in channels:
            if 1 <= ch <= 512:
                idx = ch - 1
                base_val = base_frame[idx] if idx < len(base_frame) else 0
                # 将底噪电平或者环境基础电平与呼吸强度进行动态正向混合/叠加，确保 mirror 真实参与运算
                mixed = int(base_val + val * (1.0 - base_val / 255.0))
                out_frame[idx] = max(0, min(255, mixed))

        return out_frame
