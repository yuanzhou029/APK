# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: show_evolution_learning
插件名称: 演后审美自主进化学习引擎 (3 类 · 表现与创意进阶插件)
物理位置: plugins/community/show_evolution_learning_plugin.py
适用架构: AI-MA v5.3+ (3 类表现创意进阶范式)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseCreativePlugin (或 BasePlugin 且 tier 默认为 CREATIVE)，属于 3 类。
   - 允许在 Web 前端配置参数、启停与卸载。
2. 核心功能与机制:
   - 无感采样: 在演出期间无感采样记录灯光师手动推杆覆盖差分 (record_manual_intervention)；
   - 演后泛化: 调用大模型中枢将高频推杆差分提炼总结为新的灯光预设 (evolve_show_presets)。
3. 声明式参数与 AI 意图隔离:
   - get_config_schema 声明 record_manual_diff (采样开关) 与 sample_interval_ms (采样间隔)；
   - get_ai_prompts 注入舞美与灯光设计大师角色的专用 System Prompt。
==============================================================================
"""

import time
import json
import logging
from typing import Dict, Any, List

try:
    from plugin_sdk import BaseCreativePlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseCreativePlugin, PluginType, CoreContext

logger = logging.getLogger("ShowEvolutionLearningPlugin")


class ShowEvolutionLearningPlugin(BaseCreativePlugin):
    """
    演后自主进化与审美风格学习插件实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "show_evolution_learning",
            "name": "演后审美自主进化学习引擎",
            "version": "1.1.0",
            "author": "AI-MA Core Team",
            "type": PluginType.LLM,
            "description": "基于演出实况轨迹与灯光师干预差分的自主学习系统，能自动提炼高频调光审美范式并持久化为新预设。"
        }

    # --------------------------------------------------------------------------
    # 2. 阶梯式依赖规范
    # --------------------------------------------------------------------------
    def get_required_adapters(self) -> list:
        return ["fixture_profile_conversion"]

    # --------------------------------------------------------------------------
    # 3. 声明式参数规范
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "record_manual_diff": {
                "type": "boolean",
                "label": "记录人工干预轨迹",
                "default": True,
                "description": "演出期间是否在内存中无感采样记录灯光师手动推杆覆盖差分"
            },
            "sample_interval_ms": {
                "type": "integer",
                "label": "采样间隔 (ms)",
                "default": 1000,
                "description": "手动推杆轨迹抽样间隔 (毫秒)"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 专属 AI 角色 System Prompt 隔离定义
    # --------------------------------------------------------------------------
    def get_ai_prompts(self) -> Dict[str, str]:
        return {
            "default_system": (
                "你是一位国际顶尖的舞美与灯光设计大师。\n"
                "输入的是灯光师在演出过程中的手动干预调整差分（例如在某种曲风下手动拉高蓝色通道或提升频闪）。\n"
                "你必须总结出灯光师的独特审美意图，并以标准 JSON 格式输出可持久化的新灯光预设模板：\n"
                "{\n"
                "  \"style_name\": \"提炼的风格名称\",\n"
                "  \"color_palette\": [\"主色十六进制\", \"辅色十六进制\"],\n"
                "  \"atmosphere\": \"情绪与空间氛围描述\",\n"
                "  \"channel_offsets\": {\"dimmer\": 0.8, \"color_temp\": 5600}\n"
                "}"
            )
        }

    # --------------------------------------------------------------------------
    # 4. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.trajectory_samples: List[Dict[str, Any]] = []
        self.learning_weights: Dict[str, float] = {
            "dimmer": 1.0,
            "color": 0.8,
            "strobe": 0.5,
            "position": 0.7
        }
        self.evolution_rounds: int = 0
        self.learning_rate: float = 0.05
        return True

    def on_enable(self) -> None:
        logger.info("演后自主进化与审美学习插件已启动。")

    def on_disable(self) -> None:
        logger.info("演后自主进化与审美学习插件已安全停止。")

    def on_save_state(self) -> Dict[str, Any]:
        """保存学习权重字典、演化轮次与学习率"""
        return {
            "learning_weights": dict(self.learning_weights),
            "evolution_rounds": self.evolution_rounds,
            "learning_rate": self.learning_rate,
            "trajectory_count": len(self.trajectory_samples)
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复学习权重字典、演化轮次与学习率"""
        if isinstance(state, dict):
            if "learning_weights" in state and isinstance(state["learning_weights"], dict):
                self.learning_weights = dict(state["learning_weights"])
            self.evolution_rounds = int(state.get("evolution_rounds", 0))
            self.learning_rate = float(state.get("learning_rate", 0.05))

    # --------------------------------------------------------------------------
    # 5. 核心业务：人工干预轨迹采集与大模型泛化
    # --------------------------------------------------------------------------
    def record_manual_intervention(self, universe: int, channel: int, old_val: int, new_val: int, scene_tag: str = "live") -> None:
        """无感采样记录一次灯光师推杆调整"""
        cfg = self.get_config()
        if not cfg.get("record_manual_diff", True):
            return

        self.trajectory_samples.append({
            "timestamp": time.time(),
            "universe": universe,
            "channel": channel,
            "diff": new_val - old_val,
            "target_val": new_val,
            "tag": scene_tag
        })
        # 内存环形保持最多 2000 个采样切片
        if len(self.trajectory_samples) > 2000:
            self.trajectory_samples.pop(0)

    def evolve_show_presets(self) -> Dict[str, Any]:
        """演出结束后调用，汇总整场轨迹并生成进化预设"""
        if not self.trajectory_samples:
            return {"status": "no_data", "message": "演出期间未捕获到有效人工推杆调整轨迹"}

        # 汇总高频干预特征
        summary = {
            "total_interventions": len(self.trajectory_samples),
            "affected_universes": list(set(s["universe"] for s in self.trajectory_samples)),
            "sample_head": self.trajectory_samples[:10]
        }

        user_prompt = (
            f"演出已顺利结束，以下为整场演出灯光师的人工干预统计采样:\n"
            f"{json.dumps(summary, ensure_ascii=False, indent=2)}\n"
            f"请提炼灯光师在各环节的审美偏好，生成符合上述 JSON 规范的全新灯光预设。"
        )

        try:
            # 安全调用大模型中枢，自动注入本插件专属 System Prompt
            ai_reply = self.call_ai_service("default_system", user_prompt, temperature=0.3)
            clean_reply = ai_reply.strip()
            if clean_reply.startswith("```json"):
                clean_reply = clean_reply[7:]
            if clean_reply.startswith("```"):
                clean_reply = clean_reply[3:]
            if clean_reply.endswith("```"):
                clean_reply = clean_reply[:-3]

            parsed = json.loads(clean_reply.strip())
            logger.info(f"审美进化预设提炼成功: {parsed.get('style_name')}")
            return {"status": "evolved", "preset": parsed}
        except Exception as e:
            logger.error(f"演后预设提炼异常: {e}")
            return {"status": "error", "message": str(e)}
