# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: adapter_artnet_dashboard
插件名称: Art-Net 实时协议数据流与抓包适配器 (自包含 UI 看板范例)
层级归属: 2 类 · 资产与生态适配级 (PluginTier.ADAPTER = 2)
物理位置: plugins/adapters/artnet_dashboard_adapter.py
适用架构: AI-MA v5.3+ (零侵入动态插槽与通用视窗宿主标准)

【本插件特性与教学范式说明】:
1. 真正自包含 (Self-Contained):
   - 本插件仅这一个 .py 文件即可完整工作！
   - 无需在宿主系统的 index.html 或 app.js 中添加任何代码。
   - 包含 UDP 6454 后台抓包线程、实时统计指标计算，以及自带的 Web 看板 UI 视图与轮询脚本。
2. 安装与卸载纯净:
   - 放置进 plugins/adapters/ 即自动加载并在系统顶栏生成 [Art-Net 看板] 按钮；
   - 移出目录即可完全卸载，宿主界面无任何代码残留。
3. 契约完备:
   - 继承 BaseAdapterPlugin，实现 supported_extensions 与 convert_to_profile。
   - 完美通过 PluginValidator 合规性审查。
==============================================================================
"""

import socket
import struct
import threading
import time
import logging
from typing import Dict, Any, List

try:
    from plugin_sdk import BaseAdapterPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseAdapterPlugin, PluginType, CoreContext

logger = logging.getLogger("ArtNetDashboardAdapter")


class ArtNetDashboardAdapter(BaseAdapterPlugin):
    """
    Art-Net 协议实时数据流与抓包适配器
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据 (PluginValidator 必检项)
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "adapter_artnet_dashboard",
            "name": "Art-Net 实时协议流监控看板",
            "version": "1.1.0",
            "author": "AI-MA Core Engineering",
            "type": PluginType.ADAPTER,
            "description": "自包含独立看板插件范例：实时捕获 UDP 6454 Art-Net 数据帧，在顶栏生成自适应动态监控视窗。"
        }

    def get_provided_capabilities(self) -> List[str]:
        return [
            "artnet_monitor",
            "dmx_telemetry",
            "adapter_artnet_dashboard"
        ]

    # --------------------------------------------------------------------------
    # 2. 2 类适配器专有抽象方法 (资产格式转换)
    # --------------------------------------------------------------------------
    def supported_extensions(self) -> List[str]:
        return [".artnet", ".pcap", ".dmx"]

    def convert_to_profile(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """将外部抓包快照转为系统分析数据"""
        return {
            "source_filename": filename,
            "file_size": len(file_bytes),
            "parsed_type": "artnet_snapshot",
            "timestamp": time.time(),
            "summary": f"已成功解析抓包文件 {filename}，共计 {len(file_bytes)} 字节。"
        }

    # --------------------------------------------------------------------------
    # 3. 核心机制：自包含 UI 插槽与动态视窗定义 (零改动宿主界面)
    # --------------------------------------------------------------------------
    def get_ui_extensions(self) -> List[Dict[str, Any]]:
        """
        向宿主系统声明自包含 UI 扩展:
        - slot: 挂载目标插槽 (如 'topbar_actions' 顶栏操作区)
        - label / icon: 自动生成的按钮样式
        - view_html: 点击按钮后在通用视窗中渲染的专属 HTML/CSS/JS 内容！
        """
        return [
            {
                "slot": "topbar_actions",
                "id": "btnOpenArtNetDashboard",
                "plugin_id": "adapter_artnet_dashboard",
                "label": "Art-Net 看板",
                "icon": "fa-chart-network",
                "btn_class": "btn-brand",
                "modal_title": "Art-Net 协议实时数据流看板",
                "modal_sub": "UDP 6454 物理推流监听 · 实时 PPS 与通道电平矩阵",
                "modal_size": "lg",
                "modal_foot": '监听端口: 6454 · 状态: <span class="badge badge-ok">自包含视窗容器运行中</span>',
                "view_html": self._build_dashboard_html()
            }
        ]

    def _build_dashboard_html(self) -> str:
        """
        构建自包含看板的完整 HTML、CSS 与前端 JavaScript。
        前端宿主 Generic Plugin Host 会自动将这段内容注入通用 Modal 并执行脚本。
        """
        return """
<div style="display:flex;flex-direction:column;gap:14px;">
  <!-- 核心指标卡片 -->
  <div style="display:flex;gap:12px;">
    <div style="flex:1;padding:12px 14px;background:rgba(255,255,255,0.03);border:1px solid var(--line);border-radius:var(--r-md);">
      <div style="color:var(--txt-3);font-size:12px;">实时推流速率 (PPS)</div>
      <div id="artnetPpsVal" style="font-size:24px;font-weight:bold;color:var(--brand);margin-top:4px;">0 pps</div>
    </div>
    <div style="flex:1;padding:12px 14px;background:rgba(255,255,255,0.03);border:1px solid var(--line);border-radius:var(--r-md);">
      <div style="color:var(--txt-3);font-size:12px;">活跃 Universe 数量</div>
      <div id="artnetUniverseCountVal" style="font-size:24px;font-weight:bold;color:var(--success);margin-top:4px;">0</div>
    </div>
    <div style="flex:1;padding:12px 14px;background:rgba(255,255,255,0.03);border:1px solid var(--line);border-radius:var(--r-md);">
      <div style="color:var(--txt-3);font-size:12px;">累计接收总帧数</div>
      <div id="artnetTotalPacketsVal" style="font-size:24px;font-weight:bold;color:var(--txt-1);margin-top:4px;">0</div>
    </div>
  </div>

  <!-- Universe 通道电平矩阵列表 -->
  <div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px;">
    <span style="font-size:13px;font-weight:bold;color:var(--txt-2);">Universe 实时推流矩阵</span>
    <span style="font-size:11px;color:var(--txt-3);">采样前 24 个物理通道电平</span>
  </div>
  <div id="artnetUniverseContainer" style="display:flex;flex-direction:column;gap:10px;max-height:360px;overflow-y:auto;padding-right:4px;">
    <div style="text-align:center;padding:35px 20px;color:var(--txt-3);">
      <i class="fa-solid fa-satellite-dish" style="font-size:22px;margin-bottom:8px;display:block;opacity:0.6;"></i>
      正在捕获 Art-Net 广播/单播数据帧…
    </div>
  </div>
</div>

<script>
// 插件内自包含的运行态脚本，通过 pluginContext 接入宿主容器
var pid = pluginContext.pluginId;
var api = pluginContext.api;
var esc = pluginContext.esc;

async function fetchAndRenderDashboard() {
  try {
    var res = await api('/api/plugins/detail?id=' + encodeURIComponent(pid));
    if (!res || !res.config) return;
    
    // 从插件实时状态中读取遥测
    var pps = res.live_pps || 0;
    var total = res.live_total || 0;
    var unis = res.live_universes || [];

    var ppsEl = document.getElementById('artnetPpsVal');
    var countEl = document.getElementById('artnetUniverseCountVal');
    var totalEl = document.getElementById('artnetTotalPacketsVal');
    var box = document.getElementById('artnetUniverseContainer');

    if (ppsEl) ppsEl.textContent = pps + ' pps';
    if (countEl) countEl.textContent = unis.length;
    if (totalEl) totalEl.textContent = total;

    if (!box) return;
    if (!unis.length) {
      box.innerHTML = '<div style="text-align:center;padding:30px;color:var(--txt-3);">' +
        '<div style="font-size:13px;margin-bottom:4px;">当前网络中未检测到 Art-Net 数据推流</div>' +
        '<div style="font-size:11px;opacity:0.7;">请确认主控引擎是否已启用或输出驱动已连接。</div></div>';
      return;
    }

    var html = '';
    unis.forEach(function (u) {
      var isAct = u.status === 'active';
      html += '<div style="background:rgba(255,255,255,0.02);border:1px solid var(--line);border-radius:6px;padding:10px 12px;">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
          '<div style="display:flex;align-items:center;gap:8px;">' +
            '<span style="font-weight:bold;color:var(--txt-0);font-size:13px;">Universe ' + esc(u.universe) + '</span>' +
            '<span style="font-size:11px;color:var(--txt-3);">帧序号: ' + esc(u.seq) + ' · 帧率: ' + esc(u.fps) + ' fps</span>' +
          '</div>' +
          '<span class="badge ' + (isAct ? 'badge-ok' : 'badge-warn') + '">' + (isAct ? '推流中' : '静止') + '</span>' +
        '</div>' +
        '<div style="display:flex;gap:2px;height:24px;align-items:flex-end;background:rgba(0,0,0,0.35);padding:2px;border-radius:4px;">';

      var chs = u.preview || [];
      chs.forEach(function (val, idx) {
        var pct = Math.round((val / 255) * 100);
        var bg = val > 0 ? 'var(--brand)' : 'rgba(255,255,255,0.08)';
        html += '<div style="flex:1;height:' + Math.max(3, pct) + '%;background:' + bg + ';border-radius:1px;transition:height 0.1s;" title="通道 ' + (idx + 1) + ': ' + val + ' (' + pct + '%)"></div>';
      });

      html += '</div></div>';
    });
    box.innerHTML = html;
  } catch (err) {
    console.warn('看板渲染异常:', err);
  }
}

// 首次拉取并挂载定时轮询 (500ms 刷新)
fetchAndRenderDashboard();
var timer = setInterval(fetchAndRenderDashboard, 500);
pluginContext.setTimer(timer);
</script>
"""

    # --------------------------------------------------------------------------
    # 4. 可配置参数 Schema
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "listen_port": {
                "type": "integer",
                "label": "UDP 监听端口",
                "default": 6454,
                "description": "标准 Art-Net 广播与单播接收端口，默认为 6454"
            },
            "bind_ip": {
                "type": "string",
                "label": "监听绑定 IP",
                "default": "0.0.0.0",
                "description": "绑定 0.0.0.0 监听本机所有网卡数据流"
            }
        }

    # --------------------------------------------------------------------------
    # 5. 生命周期与后台网络接收
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self._sock = None
        self._running = False
        self._thread = None
        self._using_event_hub = False
        self._lock = threading.Lock()

        # 统计指标与滑动窗口
        self._stats = {
            "total_packets": 0,
            "current_pps": 0,
            "universes": {}  # {uid: {"last_seen": t, "packets": n, "seq": s, "preview": [...]}}
        }
        self._recent_packet_times = []
        return True

    def on_save_state(self) -> Dict[str, Any]:
        """保存统计数据（如已接收帧数等）"""
        with self._lock:
            return {
                "total_packets": self._stats.get("total_packets", 0),
                "universes_summary": {
                    uid: {"packets": u.get("packets", 0), "seq": u.get("seq", 0)}
                    for uid, u in self._stats.get("universes", {}).items()
                }
            }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复统计数据（如已接收帧数等）"""
        if isinstance(state, dict):
            with self._lock:
                self._stats["total_packets"] = int(state.get("total_packets", 0))
                uni_summary = state.get("universes_summary", {})
                if isinstance(uni_summary, dict):
                    for uid_str, u_data in uni_summary.items():
                        try:
                            uid = int(uid_str)
                            if uid not in self._stats["universes"]:
                                self._stats["universes"][uid] = {
                                    "universe": uid,
                                    "packets": u_data.get("packets", 0),
                                    "seq": u_data.get("seq", 0),
                                    "recent_times": [],
                                    "last_seen": time.time(),
                                    "preview": []
                                }
                            else:
                                self._stats["universes"][uid]["packets"] = u_data.get("packets", 0)
                                self._stats["universes"][uid]["seq"] = u_data.get("seq", 0)
                        except Exception:
                            pass

    def on_enable(self) -> None:
        cfg = self.get_config()
        self._running = True

        # 优先通过宿主 EventHub 订阅 Art-Net 抓包流（完全规避 Windows UDP 端口冲突与抢占）
        event_hub = None
        is_hosted = False
        if hasattr(self, "context") and self.context:
            event_hub = getattr(self.context, "event_hub", None) or getattr(self.context, "hub", None)
            is_hosted = getattr(self.context, "hosted", False)

        if event_hub and is_hosted:
            try:
                def _on_artnet_packet(topic: str, event_data: Dict[str, Any]):
                    if not self._running:
                        return
                    raw_data = event_data.get("data")
                    if raw_data and isinstance(raw_data, (bytes, bytearray)):
                        self._parse_packet(bytes(raw_data))

                event_hub.subscribe("network.artnet.packet", "adapter_artnet_dashboard", _on_artnet_packet)
                self._using_event_hub = True
                logger.info("Art-Net 看板已接入宿主 EventHub 接收数据流 (免套接字冲突)")
                return
            except Exception as e:
                logger.warning(f"Art-Net 看板订阅 EventHub 异常，降级为独立监听: {e}")

        # 脱机独立模式或无 EventHub 时降级为独立套接字监听
        self._using_event_hub = False
        port = int(cfg.get("listen_port", 6454))
        bind_ip = str(cfg.get("bind_ip", "0.0.0.0"))

        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except Exception:
                    pass

            self._sock.bind((bind_ip, port))
            self._sock.settimeout(0.5)

            self._thread = threading.Thread(
                target=self._capture_worker,
                daemon=True,
                name="ArtNetDashboardCaptureWorker"
            )
            self._thread.start()
            logger.info(f"Art-Net 数据流看板独立监听线程已启动 -> {bind_ip}:{port}")
        except Exception as e:
            logger.warning(f"Art-Net 看板独立套接字绑定失败 (端口已被占用或受限，已优雅降级): {e}")
            if self._sock:
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None

    def on_disable(self) -> None:
        self._running = False
        if getattr(self, "_using_event_hub", False):
            event_hub = None
            if hasattr(self, "context") and self.context:
                event_hub = getattr(self.context, "event_hub", None) or getattr(self.context, "hub", None)
            if event_hub:
                try:
                    event_hub.unsubscribe("network.artnet.packet", "adapter_artnet_dashboard")
                except Exception:
                    pass
            self._using_event_hub = False
            logger.info("Art-Net 看板已注销 EventHub 订阅。")

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.5)
        self._thread = None

        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None
        logger.info("Art-Net 看板网络套接字已安全释放。")

    def _capture_worker(self) -> None:
        """后台持续接收并解析 Art-Net 数据包"""
        while self._running:
            try:
                data, _ = self._sock.recvfrom(2048)
                self._parse_packet(data)
            except socket.timeout:
                continue
            except Exception:
                if not self._running:
                    break

    def _parse_packet(self, data: bytes) -> None:
        now = time.time()
        # 校验头部特征: "Art-Net\x00" 且至少 18 字节
        if len(data) < 18 or data[:8] != b"Art-Net\x00":
            return

        opcode = struct.unpack("<H", data[8:10])[0]
        # 0x5000 = OpOutput / OpDmx
        if opcode != 0x5000:
            return

        seq = data[12]
        universe = struct.unpack("<H", data[14:16])[0]
        dmx_len = struct.unpack(">H", data[16:18])[0]
        channels = list(data[18:18 + min(dmx_len, 512)])

        with self._lock:
            self._stats["total_packets"] += 1
            self._recent_packet_times.append(now)

            # 1 秒滑动窗口计算实时 PPS
            cutoff = now - 1.0
            self._recent_packet_times = [t for t in self._recent_packet_times if t > cutoff]
            self._stats["current_pps"] = len(self._recent_packet_times)

            # 更新该 Universe 状态
            if universe not in self._stats["universes"]:
                self._stats["universes"][universe] = {
                    "universe": universe,
                    "packets": 0,
                    "recent_times": []
                }

            u = self._stats["universes"][universe]
            u["last_seen"] = now
            u["packets"] += 1
            u["seq"] = seq
            u["preview"] = channels[:24]

            # 计算单 Universe 的 fps
            u["recent_times"].append(now)
            u["recent_times"] = [t for t in u["recent_times"] if t > cutoff]
            u["fps"] = len(u["recent_times"])

    def get_config(self) -> Dict[str, Any]:
        """
        扩展返回实时遥测状态供前端 /api/plugins/detail 一键读取
        """
        cfg = super().get_config()
        now = time.time()
        with self._lock:
            u_list = []
            for uid, info in self._stats["universes"].items():
                is_active = (now - info.get("last_seen", 0)) < 2.5
                u_list.append({
                    "universe": uid,
                    "status": "active" if is_active else "idle",
                    "packets": info.get("packets", 0),
                    "seq": info.get("seq", 0),
                    "fps": info.get("fps", 0),
                    "preview": info.get("preview", [])
                })

            cfg["live_pps"] = self._stats["current_pps"]
            cfg["live_total"] = self._stats["total_packets"]
            cfg["live_universes"] = sorted(u_list, key=lambda x: x["universe"])
        return cfg

    def get_stats(self) -> Dict[str, Any]:
        """获取内部统计数据快照（供测试套件与监控总线统一读取）"""
        with self._lock:
            return {
                "total_packets": self._stats.get("total_packets", 0),
                "current_pps": self._stats.get("current_pps", 0),
                "universes": list(self._stats.get("universes", {}).keys()),
                "universes_detail": {
                    uid: {
                        "packets": u.get("packets", 0),
                        "seq": u.get("seq", 0),
                        "fps": u.get("fps", 0),
                        "preview": list(u.get("preview", []))
                    }
                    for uid, u in self._stats.get("universes", {}).items()
                }
            }
