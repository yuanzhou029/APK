# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: adapter_ma_fixture
插件名称: GrandMA2 / GrandMA3 物理灯库资产适配器 (2 类 · 资产与格式适配插件)
物理位置: plugins/adapters/ma_fixture_adapter.py
适用架构: AI-MA v5.3+ (知识库物理灯库 RAG 体系)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseAdapterPlugin，属于 PluginTier.ADAPTER (2 类)。
   - 专职于外部格式无损转换，面向专业灯光控台资产互通。
2. 抽象方法约束:
   - 必须实现 supported_extensions() 声明支持扩展名 [.xml, .gdtf]。
   - 必须实现 convert_to_profile() 完成第三方二进制/文本到系统标准灯库 JSON 的解析。
3. UI 扩展插槽与安全设计:
   - 通过 get_ui_extensions 声明在知识库灯库工具栏 (kb_profiles_toolbar) 注入导入动作。
   - 内置安全通道锁定机制 (auto_lock_dangerous_channels)，在导入时自动锁死复位、灭泡等危险通道。
==============================================================================
"""

import re
import xml.etree.ElementTree as ET
from typing import Dict, Any, List

try:
    from plugin_sdk import BaseAdapterPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseAdapterPlugin, PluginType, CoreContext


class MAFixtureAdapterPlugin(BaseAdapterPlugin):
    """
    GrandMA2 XML 与 GrandMA3 GDTF 灯库格式解析转换适配器
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "adapter_ma_fixture",
            "name": "GrandMA2/3 控台灯库资产适配器",
            "version": "1.0.0",
            "author": "AI-MA Core Engineering",
            "type": PluginType.ADAPTER,
            "description": "提供 GrandMA2 (.xml) 及 GrandMA3 GDTF 格式灯库一键无损转换入库能力。",
            "homepage": "https://ai-ma.lighting/docs/adapters/ma"
        }

    def get_provided_capabilities(self) -> List[str]:
        return [
            "fixture_profile_conversion",
            "grandma_xml_import",
            "adapter_ma_fixture"
        ]

    # --------------------------------------------------------------------------
    # 2. 声明式参数规范 (UI 自动渲染)
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "auto_lock_dangerous_channels": {
                "type": "boolean",
                "label": "自动物理锁定危险通道",
                "default": True,
                "description": "遇到复位、灭泡、内置宏等通道时自动标记 is_safe=false，防止演出时误触发"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 专属 AI 语义修正提示词 (用于未知通道属性智能映射)
    # --------------------------------------------------------------------------
    def get_ai_prompts(self) -> Dict[str, str]:
        return {
            "default_system": (
                "你是一个精通 MA2/MA3 控台语法与现代 DMX 灯库标准的工程师。"
                "你的专职任务是将非标或模糊的 MA 属性名称准确转换为系统标准属性 (pan, tilt, dimmer, strobe, color_wheel, gobo, prism, focus, zoom, effect, speed, control)。"
            ),
            "repair_unknown_channel": (
                "请将以下未知的 MA 控台属性名称修正为标准分类，只输出分类单词："
            )
        }

    # --------------------------------------------------------------------------
    # 4. UI 扩展插槽声明 (挂载至知识库灯库面板工具栏)
    # --------------------------------------------------------------------------
    def get_ui_extensions(self) -> List[Dict[str, Any]]:
        return [
            {
                "slot": "kb_profiles_toolbar",
                "id": "btnImportMa",
                "label": "导入 MA 灯库 (.xml)",
                "icon": "fa-file-arrow-up",
                "file_accept": ".xml,.gdtf",
                "action": "import_ma_xml"
            }
        ]

    # --------------------------------------------------------------------------
    # 5. 2 类抽象方法：格式支持与数据转换
    # --------------------------------------------------------------------------
    def supported_extensions(self) -> List[str]:
        return [".xml", ".gdtf"]

    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self._converted_count: int = 0
        return True

    def on_enable(self) -> None:
        pass

    def on_disable(self) -> None:
        pass

    def on_save_state(self) -> Dict[str, Any]:
        """缓存已转换灯库计数等运行时状态"""
        return {
            "converted_count": self._converted_count
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复已转换灯库计数等运行时状态"""
        if isinstance(state, dict):
            self._converted_count = int(state.get("converted_count", 0))

    def convert_to_profile(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """
        将 GrandMA2 XML 或 GDTF 灯库文件转换为系统标准灯库 JSON 结构
        """
        self._converted_count += 1
        try:
            root = ET.fromstring(file_bytes)
        except Exception as e:
            raise ValueError(f"XML 文件解析失败（格式错误或编码不支持）: {e}")

        # 兼容带命名空间与不带命名空间的 XML 节点查找
        fx = root.find('.//{http://schemas.malighting.de/grandma2/xml/MA}FixtureType')
        if fx is None:
            fx = root.find('.//FixtureType')
        if fx is None:
            fx = root.find('.//GDTF') or root

        model = fx.get('name', 'Unknown_Model')
        mode = fx.get('mode', 'Standard')

        mfr_elem = fx.find('.//{http://schemas.malighting.de/grandma2/xml/MA}manufacturer')
        if mfr_elem is None:
            mfr_elem = fx.find('.//manufacturer')
        mfr = (mfr_elem.text if mfr_elem is not None else 'Generic').strip()

        safe_mfr = re.sub(r'[^a-z0-9_]', '', mfr.lower())
        safe_model = re.sub(r'[^a-z0-9_]', '', model.lower())

        ch_types = fx.findall('.//{http://schemas.malighting.de/grandma2/xml/MA}ChannelType')
        if not ch_types:
            ch_types = fx.findall('.//ChannelType')

        raw_channels = []
        for ct in ch_types:
            coarse = ct.get('coarse')
            attr = (ct.get('attribute') or ct.get('name') or 'UNKNOWN').upper()

            # 解析通道的枚举档位 (ChannelSet)
            slots = []
            cfuncs = ct.findall('{http://schemas.malighting.de/grandma2/xml/MA}ChannelFunction')
            if not cfuncs:
                cfuncs = ct.findall('ChannelFunction')

            for cf in cfuncs:
                csets = cf.findall('{http://schemas.malighting.de/grandma2/xml/MA}ChannelSet')
                if not csets:
                    csets = cf.findall('ChannelSet')
                for cs in csets:
                    try:
                        v_from = int(cs.get('from_dmx', 0))
                        label = cs.get('name', '')
                        if label:
                            slots.append({'v': v_from, 'label': label})
                    except Exception:
                        pass

            if coarse is not None:
                try:
                    ch_num = int(coarse) + 1
                    raw_channels.append({
                        'ch_index': ch_num,
                        'attr': attr,
                        'slots': slots
                    })
                except Exception:
                    pass

        raw_channels.sort(key=lambda x: x['ch_index'])

        auto_lock = bool(self.get_config().get("auto_lock_dangerous_channels", True))
        channels = []
        for idx, rc in enumerate(raw_channels, start=1):
            attr_name = rc['attr']

            # 映射为系统标准属性
            t = "control"
            if "PAN" in attr_name: t = "pan"
            elif "TILT" in attr_name: t = "tilt"
            elif "DIM" in attr_name: t = "dimmer"
            elif "SHUTTER" in attr_name or "STROBE" in attr_name: t = "strobe"
            elif "COLOR" in attr_name: t = "color_wheel"
            elif "GOBO" in attr_name: t = "gobo"
            elif "PRISM" in attr_name: t = "prism"
            elif "FOCUS" in attr_name: t = "focus"
            elif "ZOOM" in attr_name: t = "zoom"
            elif "FROST" in attr_name or "EFFECT" in attr_name: t = "effect"
            elif "SPEED" in attr_name: t = "speed"
            elif any(w in attr_name for w in ['RESET', 'LAMP', 'CONTROL', 'MACRO']): t = "control"

            # 危险通道自动物理上锁标记
            is_safe = True
            if auto_lock and any(w in attr_name for w in ['RESET', 'LAMP', 'CONTROL', 'MACRO', 'OFF']):
                is_safe = False

            channels.append({
                "ch": idx,
                "name": f"CH{idx}_{rc['attr']}",
                "type": t,
                "is_safe": is_safe,
                "range": [0, 255],
                "default": 0,
                "slots": rc['slots']
            })

        profile_id = f"profile_{safe_mfr}_{safe_model}_{mode.lower()}"
        return {
            "profile_id": profile_id,
            "manufacturer": mfr,
            "model": model,
            "mode": mode,
            "channel_count": len(channels),
            "channels": channels
        }
