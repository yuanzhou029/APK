# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: llm_local_qwen_7b
插件名称: Local Qwen 2.5-7B 端侧模型适配驱动 (1 类 · 系统底层核心插件)
物理位置: plugins/system/qwen_plugin.py
适用架构: AI-MA v5.3+ (OpenAI 兼容端点协议)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseLLMPlugin，属于 PluginTier.SYSTEM (1 类)。
   - 随底层静默启动，为全系统插件提供统一的大模型意图理解与认知决策能力。
2. 提示词隔离机制:
   - 支持通过 call_ai_service 接收各插件独立的 System Prompt，互不污染。
3. 参数热更新与容错:
   - 实现了 update_config()，允许在系统运行时动态更改 API 端点与模型名而无需重启。
   - 使用标准库 urllib 进行轻量级 HTTP 请求，严格超时保护，绝不阻塞主循环。
==============================================================================
"""

import json
import time
import urllib.request
import logging
from typing import Dict, Any, List

try:
    from plugin_sdk import BaseLLMPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseLLMPlugin, PluginType, CoreContext

logger = logging.getLogger("LocalQwenPlugin")


class LocalQwenLLMPlugin(BaseLLMPlugin):
    """
    本地 Qwen 端侧模型推理中枢实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "llm_local_qwen_7b",
            "name": "Local Qwen 2.5-7B 端侧模型适配器",
            "version": "2.1.0",
            "author": "AI-MA Core Team",
            "type": PluginType.LLM,
            "description": "基于本地 OpenAI 兼容端点的高性能端侧大模型中枢驱动，负责意图理解、时序解析与各插件专属提示词推理。"
        }

    # --------------------------------------------------------------------------
    # 2. 声明式参数规范 (可在前端与 config/plugins_config.json 热维护)
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "api_url": {
                "type": "string",
                "label": "本地 API 端点",
                "default": "http://127.0.0.1:8085/v1/chat/completions",
                "description": "本地模型 HTTP 端点 URL"
            },
            "model_name": {
                "type": "string",
                "label": "模型标识名",
                "default": "qwen2.5-7b-4q",
                "description": "向本地服务请求时携带的模型名称"
            },
            "timeout_sec": {
                "type": "integer",
                "label": "超时时间 (秒)",
                "default": 30,
                "description": "等待模型生成回复的最长时限"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 插件生命周期与热参数响应
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        cfg = self.get_config()
        self.api_url = str(cfg.get("api_url", "http://127.0.0.1:8085/v1/chat/completions"))
        self.model_name = str(cfg.get("model_name", "qwen2.5-7b-4q"))
        self.timeout_sec = int(cfg.get("timeout_sec", 30))
        self.total_calls: int = 0
        self.last_latency_ms: float = 0.0

        # 注册 RPC 服务供安全大模型对话
        broker = self.get_service_broker()
        if broker:
            try:
                broker.register_service(
                    plugin_id="llm_local_qwen_7b",
                    service_name="llm_chat",
                    handler=self._rpc_chat_completion,
                    spec={"description": "提供安全 RPC 跨插件大模型对话能力"}
                )
            except Exception as e:
                logger.warning(f"注册 llm_chat RPC 服务失败: {e}")
        return True

    def _rpc_chat_completion(self, payload: dict = None) -> dict:
        payload = payload or {}
        messages = payload.get("messages", [])
        temp = float(payload.get("temperature", 0.2))
        res = self.chat_completion(messages, temperature=temp)
        return {"content": res, "model": self.model_name}

    def on_save_state(self) -> Dict[str, Any]:
        """保存调用统计与模型配置状态"""
        return {
            "total_calls": self.total_calls,
            "last_latency_ms": self.last_latency_ms,
            "model_name": self.model_name
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复调用统计与模型配置状态"""
        if isinstance(state, dict):
            self.total_calls = int(state.get("total_calls", 0))
            self.last_latency_ms = float(state.get("last_latency_ms", 0.0))
            if "model_name" in state:
                self.model_name = str(state["model_name"])

    def update_config(self, new_config: Dict[str, Any]) -> bool:
        """用户在前端修改参数后即时热更新生效"""
        super().update_config(new_config)
        cfg = self.get_config()
        self.api_url = str(cfg.get("api_url", "http://127.0.0.1:8085/v1/chat/completions"))
        self.model_name = str(cfg.get("model_name", "qwen2.5-7b-4q"))
        self.timeout_sec = int(cfg.get("timeout_sec", 30))
        logger.info(f"Qwen 模型服务参数已热更新 -> {self.api_url} ({self.model_name})")
        return True

    def on_enable(self) -> None:
        logger.info(f"端侧 Qwen 大模型驱动已就绪 -> {self.api_url}")

    def on_disable(self) -> None:
        logger.info("端侧 Qwen 大模型驱动已停止。")

    # --------------------------------------------------------------------------
    # 4. 大模型对话补全抽象方法实现
    # --------------------------------------------------------------------------
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> str:
        """
        向端侧推理服务发送标准 Chat Completion 请求并返回文本
        """
        payload = {
            "model": self.model_name,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 2048
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.api_url,
            data=data,
            headers={"Content-Type": "application/json"}
        )

        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_sec) as resp:
                if resp.status == 200:
                    result = json.loads(resp.read().decode("utf-8"))
                    choices = result.get("choices", [])
                    if choices and "message" in choices[0]:
                        self.total_calls += 1
                        self.last_latency_ms = (time.time() - t0) * 1000
                        return choices[0]["message"].get("content", "").strip()
                raise RuntimeError(f"HTTP 响应状态非预期: {resp.status}")
        except Exception as e:
            logger.error(f"调用端侧大模型中枢推理失败: {e}")
            raise e
