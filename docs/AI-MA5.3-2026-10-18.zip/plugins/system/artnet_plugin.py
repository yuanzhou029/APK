# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: protocol_artnet_standard
插件名称: Art-Net 3/4 工业标准协议驱动 (1 类 · 系统底层核心插件)
物理位置: plugins/system/artnet_plugin.py
适用架构: AI-MA v5.3+ (混合硬实时微内核架构)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseProtocolPlugin，属于 PluginTier.SYSTEM (1 类)。
   - 随控制台底层伴生启动，保持纯净静默运行，绝不透出到普通用户界面与插件市场。
2. 核心职责:
   - 负责将经过四级仲裁 (Arbitration) 与安全钳位后的 DMX 帧，通过 UDP 6454 发送至目标网络节点。
   - 严格遵循 Art-Net 3/4 官方帧结构规范 (OpDmx / 0x5000)。
3. 生命周期管理:
   - on_init: 仅初始化配置与对象引用，禁止耗时网络 IO。
   - on_enable: 初始化广播 Socket。
   - on_disable: 严格关闭套接字，释放系统资源。
==============================================================================
"""

import socket
import logging
from typing import Dict, Any

try:
    from plugin_sdk import BaseProtocolPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseProtocolPlugin, PluginType, CoreContext

logger = logging.getLogger("ArtNetPlugin")


class ArtNetProtocolPlugin(BaseProtocolPlugin):
    """
    Art-Net 3/4 工业协议驱动实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范 (PluginValidator 必检项)
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "protocol_artnet_standard",
            "name": "Art-Net 3/4 工业标准协议驱动",
            "version": "2.1.0",
            "author": "AI-MA Core Team",
            "type": PluginType.PROTOCOL,
            "description": "基于 UDP 6454 端口的工业级 Art-Net 3/4 通信协议发送驱动，支持网络广播与单播推流。"
        }

    # --------------------------------------------------------------------------
    # 2. 声明式参数规范 (支持在系统配置中统一维护与热读取)
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "target_ip": {
                "type": "string",
                "label": "目标网络 IP",
                "default": "127.0.0.1",
                "description": "Art-Net 广播/单播目标 IP（本地测试通常为 127.0.0.1）"
            },
            "port": {
                "type": "integer",
                "label": "UDP 端口",
                "default": 6454,
                "description": "标准 Art-Net 端口号 6454"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        """注入内核上下文，禁止阻塞"""
        self.context = context
        self.sock = None
        self.packet_count: int = 0
        self.target_ip: str = "127.0.0.1"
        self.port: int = 6454

        # 注册 RPC 服务供状态查询
        broker = self.get_service_broker()
        if broker:
            try:
                broker.register_service(
                    plugin_id="protocol_artnet_standard",
                    service_name="artnet_stats",
                    handler=self._rpc_get_stats,
                    spec={"description": "查询 Art-Net 发送端包计数与目标地址统计"}
                )
            except Exception as e:
                logger.warning(f"注册 artnet_stats RPC 服务失败: {e}")
        return True

    def _rpc_get_stats(self, payload: dict = None) -> dict:
        return {
            "packet_count": self.packet_count,
            "target_ip": self.target_ip,
            "port": self.port,
            "is_enabled": self.is_enabled
        }

    def on_save_state(self) -> Dict[str, Any]:
        """保存包计数与目标地址"""
        return {
            "packet_count": self.packet_count,
            "target_ip": self.target_ip,
            "port": self.port
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复包计数与目标地址"""
        if isinstance(state, dict):
            self.packet_count = int(state.get("packet_count", 0))
            self.target_ip = str(state.get("target_ip", "127.0.0.1"))
            self.port = int(state.get("port", 6454))

    def on_enable(self) -> None:
        """激活协议套接字"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            cfg = self.get_config()
            self.target_ip = str(cfg.get("target_ip", "127.0.0.1"))
            self.port = int(cfg.get("port", 6454))
            logger.info(f"Art-Net 发送驱动已就绪 -> 目标地址: {self.target_ip}:{self.port}")
        except Exception as e:
            logger.error(f"Art-Net Socket 初始化失败: {e}")
            raise e

    def on_disable(self) -> None:
        """安全释放套接字"""
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        logger.info("Art-Net 发送服务已安全停机释放。")

    # --------------------------------------------------------------------------
    # 4. 核心协议推流抽象方法实现
    # --------------------------------------------------------------------------
    def send_universe(self, universe: int, dmx_data_512: bytearray) -> bool:
        """
        发送单个 Universe 的 DMX 帧数据
        报文格式:
          - 0~7 字节: "Art-Net\0"
          - 8~9 字节: OpCode 0x5000 (OpDmx，小端序: 0x00, 0x50)
          - 10~11 字节: ProtVer 14 (大端序: 0x00, 0x0E)
          - 12 字节: Sequence (0 表示禁用协议栈序号检查)
          - 13 字节: Physical (物理端口 0)
          - 14~15 字节: Universe (15-bit，小端序: 低位在前，高位在后)
          - 16~17 字节: Length (大端序: 512 字节)
          - 18~529 字节: DMX 数据 payload
        """
        if not self.is_enabled or not self.sock:
            return False

        cfg = self.get_config()
        target_ip = str(cfg.get("target_ip", "127.0.0.1"))
        port = int(cfg.get("port", 6454))

        packet = bytearray(b"Art-Net\x00")
        packet.extend([0x00, 0x50])          # OpCode 0x5000
        packet.extend([0x00, 14])            # ProtVer 14
        packet.append(0)                     # Sequence
        packet.append(0)                     # Physical
        packet.append(universe & 0xFF)       # SubUni
        packet.append((universe >> 8) & 0xFF)# Net

        length = min(512, len(dmx_data_512))
        packet.append((length >> 8) & 0xFF)  # Length High
        packet.append(length & 0xFF)         # Length Low
        packet.extend(dmx_data_512[:length])

        # 补齐 512 字节
        if length < 512:
            packet.extend(b"\x00" * (512 - length))

        try:
            self.sock.sendto(packet, (target_ip, port))
            self.packet_count += 1
            return True
        except Exception as e:
            logger.debug(f"Art-Net 发送异常: {e}")
            return False
