# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: system_log_ai_repair
插件名称: AI 异常日志自愈与诊断修复中枢 (1 类 · 系统底层核心插件)
物理位置: plugins/system/system_log_ai_repair_plugin.py
适用架构: AI-MA v5.3+ (AI 运维自愈与系统保护中枢)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseSystemPlugin，属于 PluginTier.SYSTEM (1 类)。
   - 属于工业操作系统中的安全监视与日志守护者，静默运行。
2. 提示词隔离范例:
   - 实现 get_ai_prompts() 注入专有的工业诊断 System Prompt，要求输出严格的结构化 JSON。
3. 环形故障缓冲 (Error Ring Buffer):
   - 在内存中保留近 100 条故障遥测记录，当满足频率阈值时调用 AI 中枢进行故障根因推导。
==============================================================================
"""

import time
import json
import logging
from typing import Dict, Any, List, Optional

try:
    from plugin_sdk import BaseSystemPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseSystemPlugin, PluginType, CoreContext

logger = logging.getLogger("SystemLogAIRepairPlugin")


class SystemLogAIRepairPlugin(BaseSystemPlugin):
    """
    AI 驱动的系统异常日志诊断与自愈修复插件
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "system_log_ai_repair",
            "name": "AI 异常日志自愈与诊断修复中枢",
            "version": "1.0.0",
            "author": "AI-MA Core Team",
            "type": PluginType.LLM,
            "description": "基于端侧大模型的系统日志异常模式自动分析器，支持故障根因推导、智能修复策略输出与系统安全回滚。"
        }

    # --------------------------------------------------------------------------
    # 2. 声明式参数规范
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "auto_repair_enabled": {
                "type": "boolean",
                "label": "启用自动自愈修复",
                "default": True,
                "description": "当诊断出明确的高置信度恢复动作时，是否自动执行自愈策略"
            },
            "error_rate_threshold": {
                "type": "integer",
                "label": "报警触发阈值 (条/分钟)",
                "default": 5,
                "description": "一分钟内聚合的异常事件超过该阈值时自动启动大模型诊断"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 专属 AI 角色 System Prompt 隔离定义
    # --------------------------------------------------------------------------
    def get_ai_prompts(self) -> Dict[str, str]:
        return {
            "default_system": (
                "你是一个精通舞台灯光控制系统、PREEMPT_RT 硬实时操作系统以及 DMX512/Art-Net/sACN 协议的工业级自愈诊断专家。\n"
                "当输入系统错误日志和微内核遥测事件时，你必须严格以 JSON 格式输出分析结论：\n"
                "{\n"
                "  \"root_cause\": \"简要故障根因说明\",\n"
                "  \"severity\": \"LOW / MEDIUM / HIGH / CRITICAL\",\n"
                "  \"suggested_actions\": [\"建议自愈动作1\", \"建议自愈动作2\"],\n"
                "  \"auto_heal_code\": \"RESTORE_SAFE_CUE / RESTART_PLUGIN / CLEAR_SHM / NONE\"\n"
                "}"
            )
        }

    # --------------------------------------------------------------------------
    # 4. 插件生命周期与故障登记
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.error_ring: List[Dict[str, Any]] = []
        self.analyzed_logs_count: int = 0
        self.repair_suggestions_cache: List[Dict[str, Any]] = []
        return True

    def on_enable(self) -> None:
        logger.info("AI 日志自愈与系统保护插件已启动。")

    def on_disable(self) -> None:
        logger.info("AI 日志自愈与系统保护插件已安全停止。")

    def on_save_state(self) -> Dict[str, Any]:
        """保存已分析日志数与修复建议缓存"""
        return {
            "analyzed_logs_count": self.analyzed_logs_count,
            "repair_suggestions_cache": list(self.repair_suggestions_cache),
            "buffered_error_count": len(self.error_ring)
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复已分析日志数与修复建议缓存"""
        if isinstance(state, dict):
            self.analyzed_logs_count = int(state.get("analyzed_logs_count", 0))
            if "repair_suggestions_cache" in state and isinstance(state["repair_suggestions_cache"], list):
                self.repair_suggestions_cache = list(state["repair_suggestions_cache"])

    def record_incident(self, level: str, category: str, message: str, raw_payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        向自愈系统登记一条异常或故障事件，当满足阈值或发生严重错误时触发 AI 诊断
        """
        incident = {
            "timestamp": time.time(),
            "level": level.upper(),
            "category": category,
            "message": message,
            "payload": raw_payload or {}
        }
        self.error_ring.append(incident)
        if len(self.error_ring) > 100:
            self.error_ring.pop(0)

        # 遇到 CRITICAL 严重故障或异常频率超标时，主动触发诊断
        cfg = self.get_config()
        threshold = int(cfg.get("error_rate_threshold", 5))

        one_min_ago = time.time() - 60.0
        recent_errors = [e for e in self.error_ring if e["timestamp"] > one_min_ago]

        if incident["level"] == "CRITICAL" or len(recent_errors) >= threshold:
            logger.warning(f"触发系统日志自愈分析引擎 (近1分钟错误数: {len(recent_errors)})")
            return self.diagnose_recent_incidents(recent_errors)

        return {"status": "buffered", "recent_count": len(recent_errors)}

    def diagnose_recent_incidents(self, incidents: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        调用专有 AI 诊断大模型，推导故障根因并返回建议
        """
        user_prompt = "请诊断分析以下系统运行期异常事件流，并给出修复建议：\n" + json.dumps(incidents, ensure_ascii=False, indent=2)
        try:
            # 安全调用大模型中枢，自动注入本插件专属 System Prompt
            ai_reply = self.call_ai_service("default_system", user_prompt, temperature=0.1)
            # 清洗 markdown 代码块
            clean_reply = ai_reply.strip()
            if clean_reply.startswith("```json"):
                clean_reply = clean_reply[7:]
            if clean_reply.startswith("```"):
                clean_reply = clean_reply[3:]
            if clean_reply.endswith("```"):
                clean_reply = clean_reply[:-3]

            parsed = json.loads(clean_reply.strip())
            self.analyzed_logs_count += len(incidents)
            self.repair_suggestions_cache.append({
                "timestamp": time.time(),
                "analysis": parsed
            })
            if len(self.repair_suggestions_cache) > 50:
                self.repair_suggestions_cache.pop(0)
            logger.info(f"AI 诊断完成: 根因 [{parsed.get('root_cause')}] 严重度 [{parsed.get('severity')}]")
            return {"status": "diagnosed", "analysis": parsed}
        except Exception as e:
            logger.error(f"自愈诊断失败: {e}")
            return {"status": "error", "message": str(e)}
