# -*- coding: utf-8 -*-
"""
==============================================================================
插件标识: protocol_sacn_standard
插件名称: sACN (ANSI E1.31) 工业级以太网流控驱动 (1 类 · 系统底层核心插件)
物理位置: plugins/system/sacn_plugin.py
适用架构: AI-MA v5.3+ (遵循 ANSI E1.31-2016 工业规范)

【设计原则与教学规范】:
1. 权限与层级:
   - 继承 BaseProtocolPlugin，属于 PluginTier.SYSTEM (1 类)。
   - 随底层静默启动，属于系统推流底座。
2. 报文结构完整性:
   - ANSI E1.31 标准三层嵌套格式：
     * Root Layer (38 字节，包含 ACN 包标识 ASC-E1.17 与 CID)
     * Framing Layer (77 字节，包含 Source Name、Priority、Universe 与 Sequence 序号)
     * DMP Layer (523 字节，包含 1 字节起始码 0x00 + 512 字节 DMX 通道电平)
     * 完整帧共计 638 字节。
3. Sequence 序列号维护:
   - 每个 Universe 独立自增 (0~255)，供网络接收端（解码器/节点）进行抖动抑制与丢包检测。
==============================================================================
"""

import socket
import struct
import uuid
import logging
from typing import Dict, Any

try:
    from plugin_sdk import BaseProtocolPlugin, PluginType, CoreContext
except ImportError:
    from core.plugin_sdk import BaseProtocolPlugin, PluginType, CoreContext

logger = logging.getLogger("sACNPlugin")

# ANSI E1.31 常量定义
ACN_PACKET_IDENTIFIER = b"ASC-E1.17\x00\x00\x00"
VECTOR_ROOT_E131_DATA = 0x00000004
VECTOR_E131_DATA_PACKET = 0x0002
VECTOR_DMP_SET_PROPERTY = 0x02


class SACNProtocolPlugin(BaseProtocolPlugin):
    """
    sACN (ANSI E1.31) 工业标准协议驱动实现
    """

    # --------------------------------------------------------------------------
    # 1. 插件元数据规范
    # --------------------------------------------------------------------------
    def get_info(self) -> Dict[str, Any]:
        return {
            "id": "protocol_sacn_standard",
            "name": "sACN (ANSI E1.31) 工业协议驱动",
            "version": "1.0.0",
            "author": "AI-MA Core Team",
            "type": PluginType.PROTOCOL,
            "description": "基于 UDP 5568 的 ANSI E1.31 (sACN) 流明控协议驱动，具备单播/组播推流与 Sequence 帧控防丢机制。"
        }

    # --------------------------------------------------------------------------
    # 2. 声明式参数规范 (支持在系统配置中统一维护)
    # --------------------------------------------------------------------------
    def get_config_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "target_ip": {
                "type": "string",
                "label": "目标网络 IP",
                "default": "127.0.0.1",
                "description": "sACN 单播目标 IP，或设为 0.0.0.0 采用标准组播地址 239.255.u_hi.u_lo"
            },
            "port": {
                "type": "integer",
                "label": "UDP 端口",
                "default": 5568,
                "description": "标准 sACN E1.31 端口号 5568"
            },
            "source_name": {
                "type": "string",
                "label": "发送源名称",
                "default": "AI-MA-V5.3-Core",
                "description": "在 sACN 网络中广播显示的源控制台名称 (最长 64 字节)"
            },
            "priority": {
                "type": "integer",
                "label": "E1.31 优先级",
                "default": 100,
                "description": "E1.31 优先级 (0-200，默认 100)"
            }
        }

    # --------------------------------------------------------------------------
    # 3. 插件生命周期管理
    # --------------------------------------------------------------------------
    def on_init(self, context: CoreContext) -> bool:
        self.context = context
        self.sock = None
        self._cid = uuid.uuid4().bytes        # 生成该实例唯一的 16-byte CID
        self._sequences: Dict[int, int] = {}  # 每个 Universe 维护独立的 Sequence 序列号
        self.packet_count: int = 0
        return True

    def on_save_state(self) -> Dict[str, Any]:
        """保存包计数与每个 Universe 序列号状态"""
        return {
            "packet_count": self.packet_count,
            "sequences": dict(self._sequences)
        }

    def on_restore_state(self, state: Dict[str, Any]) -> None:
        """恢复包计数与每个 Universe 序列号状态"""
        if isinstance(state, dict):
            self.packet_count = int(state.get("packet_count", 0))
            seqs = state.get("sequences", {})
            if isinstance(seqs, dict):
                self._sequences = {int(k): int(v) for k, v in seqs.items()}

    def on_enable(self) -> None:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            cfg = self.get_config()
            logger.info(f"sACN (E1.31) 发送服务已就绪 -> {cfg.get('target_ip')}:{cfg.get('port')}")
        except Exception as e:
            logger.error(f"sACN Socket 初始化失败: {e}")
            raise e

    def on_disable(self) -> None:
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        logger.info("sACN (E1.31) 发送服务已安全停机释放。")

    # --------------------------------------------------------------------------
    # 4. ANSI E1.31 报文组装与发送
    # --------------------------------------------------------------------------
    def send_universe(self, universe: int, dmx_data_512: bytearray) -> bool:
        if not self.is_enabled or not self.sock:
            return False

        cfg = self.get_config()
        target_ip = str(cfg.get("target_ip", "127.0.0.1"))
        port = int(cfg.get("port", 5568))
        priority = max(0, min(200, int(cfg.get("priority", 100))))
        source_name = str(cfg.get("source_name", "AI-MA-V5.3-Core"))[:63].encode("utf-8")

        # 维护该 Universe 的帧序列号 (0~255 循环自增)
        seq = self._sequences.get(universe, 0)
        self._sequences[universe] = (seq + 1) & 0xFF

        packet = bytearray()

        # ==================== 1. Root Layer (38 字节) ====================
        # Preamble Size (2B) + Post-amble Size (2B) + ACN Packet Identifier (12B)
        packet.extend(struct.pack(">HH", 0x0010, 0x0000))
        packet.extend(ACN_PACKET_IDENTIFIER)
        # Flags & Length: 高 4 位为 0x7，低 12 位为后续剩余字节长度 (638 - 16 = 622)
        packet.extend(struct.pack(">H", 0x7000 | 622))
        packet.extend(struct.pack(">I", VECTOR_ROOT_E131_DATA))
        packet.extend(self._cid)

        # ==================== 2. Framing Layer (77 字节) ====================
        # Flags & Length: 638 - 38 = 600
        packet.extend(struct.pack(">H", 0x7000 | 600))
        packet.extend(struct.pack(">I", VECTOR_E131_DATA_PACKET))
        # Source Name (64 字节，空位用 0 补全)
        packet.extend(source_name.ljust(64, b"\x00"))
        packet.append(priority)
        packet.extend(struct.pack(">H", 0x0000))  # Synchronization Address
        packet.append(seq)                       # Sequence Number
        packet.append(0x00)                      # Options
        packet.extend(struct.pack(">H", universe))# Universe Address

        # ==================== 3. DMP Layer (523 字节) ====================
        # Flags & Length: 638 - 115 = 523
        packet.extend(struct.pack(">H", 0x7000 | 523))
        packet.append(VECTOR_DMP_SET_PROPERTY)
        packet.append(0xa1)                      # Address Type & Data Type
        packet.extend(struct.pack(">H", 0x0000)) # First Property Address
        packet.extend(struct.pack(">H", 0x0001)) # Address Increment
        packet.extend(struct.pack(">H", 513))    # Property value count (1 起始码 + 512 通道)
        packet.append(0x00)                      # DMX512 Start Code

        length = min(512, len(dmx_data_512))
        packet.extend(dmx_data_512[:length])
        if length < 512:
            packet.extend(b"\x00" * (512 - length))

        # 若 target_ip 为 0.0.0.0 则使用标准 E1.31 组播地址 239.255.u_hi.u_lo
        dest_ip = target_ip
        if dest_ip == "0.0.0.0":
            dest_ip = f"239.255.{(universe >> 8) & 0xFF}.{universe & 0xFF}"

        try:
            self.sock.sendto(packet, (dest_ip, port))
            self.packet_count += 1
            return True
        except Exception as e:
            logger.debug(f"sACN 发送异常: {e}")
            return False
