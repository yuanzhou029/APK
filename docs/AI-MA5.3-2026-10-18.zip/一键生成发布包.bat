@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title AI-MA Release Packager
echo ====================================================================
echo  AI-MA OS v5.3 Production Release Packaging Pipeline
echo  Hybrid Hard-Real-Time Microkernel (Rust 44Hz) + Python Layer
echo ====================================================================
echo.
cd /d "%~dp0"

rem ============================================================
rem  Interpreter discovery: the pipeline needs numpy.
rem  Probe every candidate before adopting it.
rem ============================================================
set "PYEXE="

if defined AIMA_PYTHON (
    if exist "%AIMA_PYTHON%" (
        "%AIMA_PYTHON%" -c "import numpy" >nul 2>nul
        if not errorlevel 1 set "PYEXE=%AIMA_PYTHON%"
    )
)

if not defined PYEXE (
    set "CAND=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    if exist "!CAND!" (
        "!CAND!" -c "import numpy" >nul 2>nul
        if not errorlevel 1 set "PYEXE=!CAND!"
    )
)

if not defined PYEXE (
    for /f "delims=" %%P in ('where python 2^>nul') do (
        if not defined PYEXE (
            "%%P" -c "import numpy" >nul 2>nul
            if not errorlevel 1 set "PYEXE=%%P"
        )
    )
)

if not defined PYEXE (
    echo [ERROR] No Python interpreter with numpy was found.
    echo         Set AIMA_PYTHON=C:\path\to\python.exe and retry.
    echo.
    pause
    exit /b 1
)

echo [1/2] Interpreter : %PYEXE%
echo [2/2] Running release pipeline...
echo.

"%PYEXE%" tools\build_release.py
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
    echo ====================================================================
    echo  [FAILED] Release pipeline aborted with exit code %RC%.
    echo ====================================================================
) else (
    echo ====================================================================
    echo  Package output: dist\ai-ma-v5-release
    echo ====================================================================
)
pause
exit /b %RC%
