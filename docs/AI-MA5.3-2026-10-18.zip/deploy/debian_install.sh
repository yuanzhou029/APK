#!/bin/bash
# ==============================================================================
# AI-MA OS v5.3 · Debian 11/12 生产级自动化部署脚本
# 架构基线：混合硬实时微内核 (Rust 44Hz 微内核 + Python 业务调度层)
# ==============================================================================
set -e

INSTALL_DIR="/opt/ai-ma"
ISOLATED_CPU="${AIMA_ISOLATED_CPU:-3}"

echo "=========================================================="
echo "  AI-MA OS v5.3 混合硬实时微内核架构 · Debian 生产部署"
echo "=========================================================="

# 1. 检查 root 权限
if [ "$EUID" -ne 0 ]; then
  echo "[错误] 请使用 sudo 或 root 运行此部署脚本！"
  exit 1
fi

# 2. 安装基础依赖
echo "[1/6] 安装 Debian 基础运行依赖..."
apt-get update -y
apt-get install -y python3 python3-pip python3-numpy libcap2-bin lsof curl util-linux

# 3. 部署目标目录
echo "[2/6] 部署系统文件至 ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}"
cp -r ./* "${INSTALL_DIR}/"

# 4. 内核构件完整性校验 (缺失直接中止，避免部署出"实际跑旧内核"的包)
echo "[3/6] 校验新内核构件完整性..."
FAIL=0
if [ ! -f "${INSTALL_DIR}/bin/aima-rt-daemon" ]; then
  echo "  [X] 缺失微内核二进制 bin/aima-rt-daemon"
  FAIL=1
else
  chmod +x "${INSTALL_DIR}/bin/aima-rt-daemon"
  echo "  [OK] bin/aima-rt-daemon"
fi
for sdk in "${INSTALL_DIR}/aima_shm_sdk.so" "${INSTALL_DIR}/core/aima_shm_sdk.so"; do
  if [ ! -f "$sdk" ]; then echo "  [X] 缺失 ABI 扩展 $sdk"; FAIL=1; else echo "  [OK] ${sdk#${INSTALL_DIR}/}"; fi
done
if [ "$FAIL" -ne 0 ]; then
  echo ""
  echo " [FATAL] 内核构件不完整，部署中止。"
  echo "         请先在本目录执行: bash build_debian.sh"
  exit 1
fi

# 5. 注册 systemd 双服务单元
echo "[4/6] 注册 systemd 双服务单元..."
cp "${INSTALL_DIR}/deploy/aima-rt.service" /etc/systemd/system/
cp "${INSTALL_DIR}/deploy/ai-ma.service"  /etc/systemd/system/
systemctl daemon-reload

# 6. 启动顺序：硬实时微内核先行，业务控制台随后挂靠
echo "[5/6] 启动硬实时微内核 aima-rt.service..."
systemctl enable aima-rt.service
systemctl restart aima-rt.service
sleep 1

echo "[6/6] 启动业务控制台 ai-ma.service..."
systemctl enable ai-ma.service
systemctl restart ai-ma.service

echo "=========================================================="
echo " 部署完成！"
echo ""
echo " 微内核状态: systemctl status aima-rt.service"
echo " 控制台状态: systemctl status ai-ma.service"
echo " 内核日志  : journalctl -u aima-rt.service -f"
echo " 业务日志  : journalctl -u ai-ma.service -f"
echo " 访问地址  : http://<主机IP>:9000   (默认 admin / admin123)"
echo "=========================================================="
echo ""
echo " [性能调优建议] 为实现真正的硬实时隔离，请在内核启动参数中隔离 CPU 核心:"
echo "   编辑 /etc/default/grub, 在 GRUB_CMDLINE_LINUX 追加:"
echo "     isolcpus=${ISOLATED_CPU} nohz_full=${ISOLATED_CPU} rcu_nocbs=${ISOLATED_CPU}"
echo "   然后执行: update-grub && reboot"
echo "   (aima-rt.service 已通过 CPUAffinity=${ISOLATED_CPU} 绑定该核心)"
echo "=========================================================="
