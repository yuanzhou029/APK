# -*- coding: utf-8 -*-
"""
[DEPRECATED] 原独立知识库管理工作台 (kb_workbench.py)

自 v4.0 起，三层 RAG 知识库的完整能力（Profiles / Venues / Presets 增删改查、
通道冲突碰撞检测、AI 说明书解析、RAG 语义检索实测）已全部迁移并整合进
统一总控台 control_station.py 的【RAG知识库管理】标签页。

本文件保留为兼容转发垫片，避免旧快捷方式失效；不再承载独立 Web 服务端口。
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

NOTICE = """
================================================================================
  [已合并] 知识库管理工作台已整合进统一总控台
================================================================================
  原独立的知识库管理台不再单独提供端口，其全部功能现位于：

      启动系统总控台.bat  ->  http://127.0.0.1:9000
      顶部导航 ->【RAG知识库管理】标签页

  该标签页现包含五个完整工作区：
    1. 资产总览           三层知识库统计 + 全库通道冲突扫描
    2. 物理灯库 Profiles  新建 / 编辑 / 删除灯库，危险通道自动锁定
    3. 场地空间拓扑 Venues 场地新建 / 编辑 / 删除 / 热切换 + 灯具布点明细
    4. 美学艺术预设 Presets 视觉拾色器 + RGBW 电平 + 情绪标签
    5. AI 解析与 RAG 实测  说明书智能提取 + 语义检索命中验证
================================================================================
"""

if __name__ == "__main__":
    print(NOTICE)
    target = os.path.join(BASE_DIR, "control_station.py")
    if os.path.exists(target):
        print("正在为您启动统一总控台...\n")
        os.execv(sys.executable, [sys.executable, target])
    else:
        sys.exit(1)
