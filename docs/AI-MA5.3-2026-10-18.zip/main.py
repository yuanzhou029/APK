# -*- coding: utf-8 -*-
"""
[DEPRECATED] 原命令行交互控制台 (main.py)

自 v4.0 起，自然语言控光、PANIC 紧急熔断、时序调度中断、DMX 通道实时电平监视
等全部能力已整合进统一总控台 control_station.py 的【交互控制台】标签页，
并新增 RBAC 鉴权、快捷场景直通、UDP 抓包监视、插件市场与知识库管理。

本文件保留为兼容转发垫片。
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

NOTICE = """
================================================================================
  [已合并] 命令行控制台已整合进统一总控台 (Web UI)
================================================================================
      启动系统总控台.bat  ->  http://127.0.0.1:9000
      顶部导航 ->【交互控制台】标签页

  该标签页提供：自然语言 AI 实时推理下发、自定义快捷场景 0 毫秒直通触发、
  PANIC 硬件安全熔断全黑、时序/宏中断、Universe 0 物理通道 30Hz 电平监视。
================================================================================
"""

if __name__ == "__main__":
    print(NOTICE)
    target = os.path.join(BASE_DIR, "control_station.py")
    if os.path.exists(target):
        print("正在为您启动统一总控台...\n")
        os.execv(sys.executable, [sys.executable, target])
    else:
        sys.exit(1)
